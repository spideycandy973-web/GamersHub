package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: vi */
/* loaded from: classes2.dex */
public abstract /* synthetic */ class AbstractC1672vi {

    /* renamed from: a */
    public static final /* synthetic */ int[] f40423a;

    static {
        int[] iArr = new int[EnumC1156in.values().length];
        try {
            iArr[0] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[1] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[2] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr[3] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        f40423a = iArr;
    }
}
