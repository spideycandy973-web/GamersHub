package p000;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.view.WindowManager;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class h90 implements g90, pw5 {

    /* renamed from: a */
    public static final h90 f16915a = new h90();

    /* renamed from: b */
    public static final h90 f16916b = new h90();

    @Override // p000.pw5
    /* renamed from: c */
    public final lw5 mo12599c(Context context, u61 u61Var) {
        WindowManager windowManager = (WindowManager) context.getSystemService(WindowManager.class);
        float f = context.getResources().getDisplayMetrics().density;
        Rect bounds = windowManager.getCurrentWindowMetrics().getBounds();
        bounds.getClass();
        return new lw5(bounds, f);
    }

    @Override // p000.g90
    /* renamed from: d */
    public final Rect mo11952d(Activity activity) {
        Rect bounds = ((WindowManager) activity.getSystemService(WindowManager.class)).getCurrentWindowMetrics().getBounds();
        bounds.getClass();
        return bounds;
    }
}
