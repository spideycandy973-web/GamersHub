package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class yb5 {

    /* renamed from: a */
    public final C1589tp f45211a;

    /* renamed from: b */
    public C1589tp f45212b;

    /* renamed from: c */
    public boolean f45213c = false;

    /* renamed from: d */
    public cd3 f45214d = null;

    public yb5(C1589tp c1589tp, C1589tp c1589tp2) {
        this.f45211a = c1589tp;
        this.f45212b = c1589tp2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof yb5)) {
            return false;
        }
        yb5 yb5Var = (yb5) obj;
        return ei2.m10070i(this.f45211a, yb5Var.f45211a) && ei2.m10070i(this.f45212b, yb5Var.f45212b) && this.f45213c == yb5Var.f45213c && ei2.m10070i(this.f45214d, yb5Var.f45214d);
    }

    public final int hashCode() {
        int m14689j = kh5.m14689j((this.f45212b.hashCode() + (this.f45211a.hashCode() * 31)) * 31, 31, this.f45213c);
        cd3 cd3Var = this.f45214d;
        return m14689j + (cd3Var == null ? 0 : cd3Var.hashCode());
    }

    public final String toString() {
        C1589tp c1589tp = this.f45212b;
        return "TextSubstitutionValue(original=" + ((Object) this.f45211a) + ", substitution=" + ((Object) c1589tp) + ", isShowingSubstitution=" + this.f45213c + ", layoutCache=" + this.f45214d + ")";
    }
}
