package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class tv4 {

    /* renamed from: a */
    public static final wr0 f37701a = new wr0(24);

    /* renamed from: b */
    public static final ur0 f37702b = new ur0((byte) 25);

    /* renamed from: a */
    public static u35 m20475a() {
        return new u35(5000L);
    }
}
