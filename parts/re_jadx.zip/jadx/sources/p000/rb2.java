package p000;

import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class rb2 {

    /* renamed from: a */
    public final String f33488a;

    /* renamed from: b */
    public final float f33489b;

    /* renamed from: c */
    public final float f33490c;

    /* renamed from: d */
    public final float f33491d;

    /* renamed from: e */
    public final float f33492e;

    /* renamed from: f */
    public final float f33493f;

    /* renamed from: g */
    public final float f33494g;

    /* renamed from: h */
    public final float f33495h;

    /* renamed from: i */
    public final List f33496i;

    /* renamed from: j */
    public final ArrayList f33497j;

    public rb2(String str, float f, float f2, float f3, float f4, float f5, float f6, float f7, List list, int i) {
        str = (i & 1) != 0 ? "" : str;
        f = (i & 2) != 0 ? 0.0f : f;
        f2 = (i & 4) != 0 ? 0.0f : f2;
        f3 = (i & 8) != 0 ? 0.0f : f3;
        f4 = (i & 16) != 0 ? 1.0f : f4;
        f5 = (i & 32) != 0 ? 1.0f : f5;
        f6 = (i & 64) != 0 ? 0.0f : f6;
        f7 = (i & 128) != 0 ? 0.0f : f7;
        if ((i & 256) != 0) {
            int i2 = xq5.f44214a;
            list = ci1.f4141a;
        }
        ArrayList arrayList = new ArrayList();
        this.f33488a = str;
        this.f33489b = f;
        this.f33490c = f2;
        this.f33491d = f3;
        this.f33492e = f4;
        this.f33493f = f5;
        this.f33494g = f6;
        this.f33495h = f7;
        this.f33496i = list;
        this.f33497j = arrayList;
    }
}
