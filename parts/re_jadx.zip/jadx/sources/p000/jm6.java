package p000;

import java.util.Objects;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class jm6 implements jo6 {

    /* renamed from: a */
    public final float f20433a;

    /* renamed from: b */
    public final im6 f20434b;

    /* renamed from: c */
    public final im6 f20435c;

    public jm6(float f, im6 im6Var, im6 im6Var2) {
        this.f20433a = f;
        this.f20434b = im6Var;
        this.f20435c = im6Var2;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof jm6)) {
            return false;
        }
        jm6 jm6Var = (jm6) obj;
        return Float.compare(this.f20433a, jm6Var.f20433a) == 0 && Objects.equals(this.f20434b, jm6Var.f20434b) && Objects.equals(this.f20435c, jm6Var.f20435c);
    }

    public final int hashCode() {
        int hashCode = Float.hashCode(this.f20433a) * 31;
        im6 im6Var = this.f20434b;
        int hashCode2 = (hashCode + (im6Var != null ? im6Var.hashCode() : 0)) * 31;
        im6 im6Var2 = this.f20435c;
        return hashCode2 + (im6Var2 != null ? im6Var2.hashCode() : 0);
    }

    public final String toString() {
        String valueOf = String.valueOf(this.f20434b);
        String valueOf2 = String.valueOf(this.f20435c);
        float f = this.f20433a;
        int length = String.valueOf(f).length();
        StringBuilder sb = new StringBuilder(length + 37 + valueOf.length() + 10 + valueOf2.length());
        sb.append("ReplayGain Xing/Info: peak=");
        sb.append(f);
        sb.append(", field 1=");
        sb.append(valueOf);
        return hn0.m12937j(", field 2=", valueOf2, sb);
    }
}
