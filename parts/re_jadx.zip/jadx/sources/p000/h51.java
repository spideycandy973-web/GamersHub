package p000;

import android.content.Intent;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class h51 implements pz1 {

    /* renamed from: a */
    public final /* synthetic */ byte f16758a;

    /* renamed from: b */
    public final /* synthetic */ Object f16759b;

    public /* synthetic */ h51(Object obj, byte b) {
        this.f16758a = b;
        this.f16759b = obj;
    }

    @Override // p000.pz1
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        byte b = this.f16758a;
        kn5 kn5Var = kn5.f22076a;
        Object obj4 = this.f16759b;
        switch (b) {
            case 0:
                long j = ((qj0) obj).f32058a;
                s02 s02Var = (s02) obj2;
                int intValue = ((Number) obj3).intValue();
                if ((intValue & 6) == 0) {
                    intValue |= s02Var.m19317e(j) ? 4 : 2;
                }
                if (s02Var.m19300R(intValue & 1, (intValue & 19) != 18)) {
                    i51.m13186b(((kc5) obj4).f21481c, j, s02Var, (intValue << 3) & 112);
                } else {
                    s02Var.m19303U();
                }
                return kn5Var;
            case 1:
                s02 s02Var2 = (s02) obj2;
                int intValue2 = ((Number) obj3).intValue();
                if (s02Var2.m19300R(intValue2 & 1, (intValue2 & 17) != 16)) {
                    ((nz1) obj4).invoke(s02Var2, 0);
                } else {
                    s02Var2.m19303U();
                }
                return kn5Var;
            case 2:
                int intValue3 = ((Number) obj).intValue();
                int intValue4 = ((Number) obj2).intValue();
                Intent intent = (Intent) obj3;
                be0 be0Var = (be0) obj4;
                if (intValue3 == 100) {
                    if (intValue4 != -1 || intent == null) {
                        be0Var.resumeWith(new a73("User cancelled"));
                    } else {
                        be0Var.resumeWith(new b73(intent, intValue4));
                    }
                }
                return kn5Var;
            case 3:
                s02 s02Var3 = (s02) obj2;
                int intValue5 = ((Number) obj3).intValue();
                if (s02Var3.m19300R(intValue5 & 1, (intValue5 & 17) != 16)) {
                    s95.m19493c((gm0) obj4, s02Var3, 0);
                } else {
                    s02Var3.m19303U();
                }
                return kn5Var;
            default:
                na3 na3Var = (na3) obj;
                s02 s02Var4 = (s02) obj2;
                ((Number) obj3).intValue();
                s02Var4.m19308Z(-1498516085);
                d35 m14995M = l11.m14995M(hc3.f17032b, s02Var4);
                d35 m14995M2 = l11.m14995M(hc3.f17034d, s02Var4);
                qj5 qj5Var = (qj5) obj4;
                bl5 bl5Var = y53.f44943s;
                al9 al9Var = qj5Var.f32066a;
                it3 it3Var = qj5Var.f32069d;
                boolean booleanValue = ((Boolean) al9Var.mo649k1()).booleanValue();
                s02Var4.m19308Z(-1553362193);
                float f = booleanValue ? 1.0f : 0.8f;
                s02Var4.m19338p(false);
                Float valueOf = Float.valueOf(f);
                boolean booleanValue2 = ((Boolean) it3Var.getValue()).booleanValue();
                s02Var4.m19308Z(-1553362193);
                float f2 = booleanValue2 ? 1.0f : 0.8f;
                s02Var4.m19338p(false);
                Float valueOf2 = Float.valueOf(f2);
                qj5Var.m18309f();
                s02Var4.m19308Z(386845748);
                s02Var4.m19338p(false);
                oj5 m9286v = di2.m9286v(qj5Var, valueOf, valueOf2, m14995M, bl5Var, s02Var4, 196608);
                boolean booleanValue3 = ((Boolean) qj5Var.f32066a.mo649k1()).booleanValue();
                s02Var4.m19308Z(2073045083);
                float f3 = booleanValue3 ? 1.0f : 0.0f;
                s02Var4.m19338p(false);
                Float valueOf3 = Float.valueOf(f3);
                boolean booleanValue4 = ((Boolean) it3Var.getValue()).booleanValue();
                s02Var4.m19308Z(2073045083);
                float f4 = booleanValue4 ? 1.0f : 0.0f;
                s02Var4.m19338p(false);
                Float valueOf4 = Float.valueOf(f4);
                qj5Var.m18309f();
                s02Var4.m19308Z(-281714272);
                s02Var4.m19338p(false);
                na3 m9243R = di2.m9243R(na3Var, ((Number) m9286v.f28951j.getValue()).floatValue(), ((Number) m9286v.f28951j.getValue()).floatValue(), ((Number) di2.m9286v(qj5Var, valueOf3, valueOf4, m14995M2, bl5Var, s02Var4, 196608).f28951j.getValue()).floatValue(), 0.0f, null, 131064);
                s02Var4.m19338p(false);
                return m9243R;
        }
    }
}
