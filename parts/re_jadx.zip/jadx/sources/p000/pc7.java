package p000;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.mediation.customevent.CustomEventAdapter;
import com.google.android.gms.ads.mediation.rtb.RtbAdapter;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class pc7 extends x07 implements rc7 {
    public pc7() {
        super("com.google.android.gms.ads.internal.mediation.client.IAdapterCreator");
    }

    /* renamed from: y4 */
    public static rc7 m17685y4(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IAdapterCreator");
        return queryLocalInterface instanceof rc7 ? (rc7) queryLocalInterface : new qc7(iBinder, "com.google.android.gms.ads.internal.mediation.client.IAdapterCreator", (byte) 4);
    }

    @Override // p000.rc7
    /* renamed from: f */
    public final tc7 mo17686f(String str) {
        try {
            try {
                Class<?> cls = Class.forName(str, false, pc7.class.getClassLoader());
                if (h73.class.isAssignableFrom(cls)) {
                    return new id7((h73) cls.getDeclaredConstructor(null).newInstance(null));
                }
                if (AbstractC1494r7.class.isAssignableFrom(cls)) {
                    return new id7((AbstractC1494r7) cls.getDeclaredConstructor(null).newInstance(null));
                }
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 64);
                sb.append("Could not instantiate mediation adapter: ");
                sb.append(str);
                sb.append(" (not a valid adapter).");
                v38.m21201h(sb.toString());
                throw new RemoteException();
            } catch (Throwable th) {
                StringBuilder sb2 = new StringBuilder(String.valueOf(str).length() + 43);
                sb2.append("Could not instantiate mediation adapter: ");
                sb2.append(str);
                sb2.append(". ");
                v38.m21202i(sb2.toString(), th);
                vk9.m21523e();
                return null;
            }
        } catch (Throwable unused) {
            v38.m21197d("Reflection failed, retrying using direct instantiation");
            if ("com.google.ads.mediation.admob.AdMobAdapter".equals(str)) {
                return new id7(new AdMobAdapter());
            }
            if ("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter".equals(str)) {
                return new id7(new CustomEventAdapter());
            }
            vk9.m21523e();
            return null;
        }
    }

    @Override // p000.rc7
    /* renamed from: i0 */
    public final boolean mo17687i0(String str) {
        try {
            return AbstractC1494r7.class.isAssignableFrom(Class.forName(str, false, pc7.class.getClassLoader()));
        } catch (Throwable unused) {
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 104);
            sb.append("Could not load custom event implementation class as Adapter: ");
            sb.append(str);
            sb.append(", assuming old custom event implementation.");
            v38.m21201h(sb.toString());
            return false;
        }
    }

    @Override // p000.rc7
    /* renamed from: l */
    public final boolean mo17688l(String str) {
        try {
            return az0.class.isAssignableFrom(Class.forName(str, false, pc7.class.getClassLoader()));
        } catch (Throwable unused) {
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 88);
            sb.append("Could not load custom event implementation class: ");
            sb.append(str);
            sb.append(", trying Adapter implementation class.");
            v38.m21201h(sb.toString());
            return false;
        }
    }

    @Override // p000.rc7
    /* renamed from: u */
    public final zd7 mo17689u(String str) {
        try {
            return new ee7((RtbAdapter) Class.forName(str, false, g55.class.getClassLoader()).getDeclaredConstructor(null).newInstance(null));
        } catch (Throwable unused) {
            vk9.m21523e();
            return null;
        }
    }

    @Override // p000.x07
    /* renamed from: x4 */
    public final boolean mo138x4(int i, Parcel parcel, Parcel parcel2) {
        if (i == 1) {
            String readString = parcel.readString();
            y07.m23086f(parcel);
            tc7 mo17686f = mo17686f(readString);
            parcel2.writeNoException();
            y07.m23085e(parcel2, mo17686f);
            return true;
        }
        if (i == 2) {
            String readString2 = parcel.readString();
            y07.m23086f(parcel);
            boolean mo17688l = mo17688l(readString2);
            parcel2.writeNoException();
            parcel2.writeInt(mo17688l ? 1 : 0);
            return true;
        }
        if (i == 3) {
            String readString3 = parcel.readString();
            y07.m23086f(parcel);
            zd7 mo17689u = mo17689u(readString3);
            parcel2.writeNoException();
            y07.m23085e(parcel2, mo17689u);
            return true;
        }
        if (i != 4) {
            return false;
        }
        String readString4 = parcel.readString();
        y07.m23086f(parcel);
        boolean mo17687i0 = mo17687i0(readString4);
        parcel2.writeNoException();
        parcel2.writeInt(mo17687i0 ? 1 : 0);
        return true;
    }
}
