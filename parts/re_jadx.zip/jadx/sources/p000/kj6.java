package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class kj6 implements p65 {

    /* renamed from: b */
    public static final kj6 f21983b = new kj6();

    /* renamed from: a */
    public final s65 f21984a = new s65(new mj6());

    @Override // p000.p65
    public final Object get() {
        return (mj6) this.f21984a.f34842a;
    }
}
