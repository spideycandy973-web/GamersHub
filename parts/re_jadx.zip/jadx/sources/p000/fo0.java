package p000;

import java.util.Set;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public abstract class fo0 {
    /* renamed from: a */
    public abstract void mo11154a(ko0 ko0Var, nz1 nz1Var);

    /* renamed from: b */
    public abstract ze3 mo11155b(ko0 ko0Var, ww4 ww4Var, nz1 nz1Var);

    /* renamed from: d */
    public boolean mo11157d() {
        return ((Boolean) s84.f34950A.get()).booleanValue();
    }

    /* renamed from: e */
    public boolean mo11158e() {
        return false;
    }

    /* renamed from: f */
    public boolean mo11159f() {
        return false;
    }

    /* renamed from: g */
    public long mo11160g() {
        return 1000L;
    }

    /* renamed from: h */
    public eo0 mo11161h() {
        return null;
    }

    /* renamed from: i */
    public ov3 mo11162i() {
        return go0.f16072a;
    }

    /* renamed from: j */
    public abstract cu0 mo11163j();

    /* renamed from: k */
    public boolean mo11164k() {
        return false;
    }

    /* renamed from: l */
    public abstract void mo11165l(ko0 ko0Var);

    /* renamed from: m */
    public abstract tc3 mo11166m(uc3 uc3Var);

    /* renamed from: n */
    public abstract ze3 mo11167n(ko0 ko0Var, ww4 ww4Var, ze3 ze3Var);

    /* renamed from: q */
    public abstract void mo11170q(m84 m84Var);

    /* renamed from: r */
    public abstract void mo11171r(ko0 ko0Var);

    /* renamed from: s */
    public abstract de0 mo11172s(at0 at0Var);

    /* renamed from: v */
    public abstract void mo11175v(ko0 ko0Var);

    /* renamed from: c */
    public void mo11156c() {
    }

    /* renamed from: t */
    public void mo11173t() {
    }

    /* renamed from: o */
    public void mo11168o(Set set) {
    }

    /* renamed from: p */
    public void mo11169p(s02 s02Var) {
    }

    /* renamed from: u */
    public void mo11174u(s02 s02Var) {
    }
}
