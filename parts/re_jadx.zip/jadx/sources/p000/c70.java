package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class c70 implements f70 {

    /* renamed from: a */
    public final C1626um f3648a;

    public c70(C1626um c1626um) {
        c1626um.getClass();
        this.f3648a = c1626um;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof c70) && ei2.m10070i(this.f3648a, ((c70) obj).f3648a);
    }

    public final int hashCode() {
        return this.f3648a.hashCode();
    }

    public final String toString() {
        return "Applied(snapshot=" + this.f3648a + ")";
    }
}
