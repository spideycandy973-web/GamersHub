package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public class e72 {
    private e72(Object... objArr) {
        throw new IllegalStateException("Failed to new a instance");
    }

    private static Object invoke(Object... objArr) {
        throw new IllegalStateException("Failed to invoke the method");
    }
}
