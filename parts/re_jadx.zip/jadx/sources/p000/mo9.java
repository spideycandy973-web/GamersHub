package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class mo9 extends kl9 {
    private static final mo9 zzd;
    private static volatile nm9 zze;
    private int zza;
    private String zzb = "";
    private long zzc;

    static {
        mo9 mo9Var = new mo9();
        zzd = mo9Var;
        kl9.m14763t(mo9.class, mo9Var);
    }

    @Override // p000.kl9
    /* renamed from: v */
    public final Object mo125v(int i, kl9 kl9Var) {
        nm9 nm9Var;
        int m23606C = yt0.m23606C(i);
        if (m23606C == 0) {
            return (byte) 1;
        }
        if (m23606C == 2) {
            return new rm9(zzd, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဈ\u0000\u0002ဂ\u0001", new Object[]{"zza", "zzb", "zzc"});
        }
        if (m23606C == 3) {
            return new mo9();
        }
        if (m23606C == 4) {
            return new nj9(zzd);
        }
        if (m23606C == 5) {
            return zzd;
        }
        if (m23606C != 6) {
            throw null;
        }
        nm9 nm9Var2 = zze;
        if (nm9Var2 != null) {
            return nm9Var2;
        }
        synchronized (mo9.class) {
            nm9Var = zze;
            if (nm9Var == null) {
                nm9Var = new jl9(zzd);
                zze = nm9Var;
            }
        }
        return nm9Var;
    }
}
