package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class g53 extends t75 implements nz1 {

    /* renamed from: a */
    public final /* synthetic */ byte f15294a;

    /* renamed from: b */
    public byte f15295b;

    /* renamed from: c */
    public final /* synthetic */ ef3 f15296c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ g53(ef3 ef3Var, ns0 ns0Var, byte b) {
        super(2, ns0Var);
        this.f15294a = b;
        this.f15296c = ef3Var;
    }

    @Override // p000.r50
    public final ns0 create(Object obj, ns0 ns0Var) {
        switch (this.f15294a) {
            case 0:
                return new g53(this.f15296c, ns0Var, (byte) 0);
            default:
                return new g53(this.f15296c, ns0Var, (byte) 1);
        }
    }

    @Override // p000.nz1
    public final Object invoke(Object obj, Object obj2) {
        byte b = this.f15294a;
        kn5 kn5Var = kn5.f22076a;
        mu0 mu0Var = (mu0) obj;
        ns0 ns0Var = (ns0) obj2;
        switch (b) {
            case 0:
                ((g53) create(mu0Var, ns0Var)).invokeSuspend(kn5Var);
                return nu0.f28013a;
            default:
                return ((g53) create(mu0Var, ns0Var)).invokeSuspend(kn5Var);
        }
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:37:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:38:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:31:0x00b1 -> B:32:0x006f). Please report as a decompilation issue!!! */
    @Override // p000.r50
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r10) {
        /*
            r9 = this;
            byte r0 = r9.f15294a
            ef3 r1 = r9.f15296c
            java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
            nu0 r3 = p000.nu0.f28013a
            r4 = 1
            r5 = 2
            r6 = 0
            switch(r0) {
                case 0: goto L5b;
                default: goto Le;
            }
        Le:
            byte r0 = r9.f15295b
            if (r0 == 0) goto L23
            if (r0 == r4) goto L1b
            if (r0 == r5) goto L1b
            p000.C0950f.m10585p(r2)
            r3 = r6
            goto L5a
        L1b:
            p000.v86.m21297X(r10)
            nd4 r10 = (p000.nd4) r10
            java.lang.Object r9 = r10.f27348a
            goto L58
        L23:
            p000.v86.m21297X(r10)
            java.lang.Object r10 = r1.getValue()
            java.lang.Boolean r10 = (java.lang.Boolean) r10
            boolean r10 = r10.booleanValue()
            r0 = 3
            if (r10 == 0) goto L48
            z4 r10 = p000.C1816z4.f46500a
            frb.axeron.manager.Axeron r1 = frb.axeron.manager.Axeron.INSTANCE
            java.lang.String r0 = frb.axeron.manager.Axeron.buildStartCommand$default(r1, r6, r6, r0, r6)
            r9.f15295b = r4
            int r1 = p000.C1816z4.m23797n()
            java.lang.Object r9 = r10.m23804b(r0, r1, r9)
            if (r9 != r3) goto L58
            goto L5a
        L48:
            z4 r10 = p000.C1816z4.f46500a
            frb.axeron.manager.Axeron r1 = frb.axeron.manager.Axeron.INSTANCE
            java.lang.String r0 = frb.axeron.manager.Axeron.buildStartCommand$default(r1, r6, r6, r0, r6)
            r9.f15295b = r5
            java.lang.Object r9 = r10.m23803a(r0, r9)
            if (r9 == r3) goto L5a
        L58:
            kn5 r3 = p000.kn5.f22076a
        L5a:
            return r3
        L5b:
            byte r0 = r9.f15295b
            if (r0 == 0) goto L6c
            if (r0 == r4) goto L68
            if (r0 == r5) goto L6c
            p000.C0950f.m10585p(r2)
            r3 = r6
            goto Lb3
        L68:
            p000.v86.m21297X(r10)
            goto L82
        L6c:
            p000.v86.m21297X(r10)
        L6f:
            r41 r10 = p000.ka1.f21425a
            w31 r10 = p000.w31.f41501b
            s8 r0 = new s8
            r2 = 8
            r0.<init>(r5, r6, r2)
            r9.f15295b = r4
            java.lang.Object r10 = p000.v86.m21301a0(r10, r0, r9)
            if (r10 == r3) goto Lb3
        L82:
            int[] r10 = (int[]) r10
            if (r10 == 0) goto La9
            r0 = 0
            r0 = r10[r0]
            java.lang.Integer r2 = new java.lang.Integer
            r2.<init>(r0)
            r10 = r10[r4]
            java.lang.Integer r0 = new java.lang.Integer
            r0.<init>(r10)
            ds3 r10 = new ds3
            r10.<init>(r2, r0)
            java.lang.Object r0 = r1.getValue()
            ds3 r0 = (p000.ds3) r0
            boolean r0 = r10.equals(r0)
            if (r0 != 0) goto La9
            r1.setValue(r10)
        La9:
            r9.f15295b = r5
            r7 = 500(0x1f4, double:2.47E-321)
            java.lang.Object r10 = p000.u99.m20782z(r7, r9)
            if (r10 != r3) goto L6f
        Lb3:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.g53.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
