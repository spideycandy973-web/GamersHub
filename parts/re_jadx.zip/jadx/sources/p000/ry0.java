package p000;

/* loaded from: classes2.dex */
public final class ry0 extends os0 {

    /* renamed from: a */
    public /* synthetic */ Object f34439a;

    /* renamed from: b */
    public int f34440b;

    /* renamed from: c */
    public final /* synthetic */ ty0 f34441c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ry0(ty0 ty0Var, ns0 ns0Var) {
        super(ns0Var);
        this.f34441c = ty0Var;
    }

    @Override // p000.r50
    public final Object invokeSuspend(Object obj) {
        this.f34439a = obj;
        this.f34440b |= Integer.MIN_VALUE;
        return this.f34441c.collect(null, this);
    }
}
