package p000;

import android.app.Activity;
import android.content.Context;
import android.os.RemoteException;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class fi7 {

    /* renamed from: a */
    public final wh7 f13853a;

    /* renamed from: b */
    public final Context f13854b;

    /* renamed from: c */
    public final ki7 f13855c;

    /* renamed from: d */
    public final long f13856d;

    public fi7(Context context, String str) {
        hu6 hu6Var = xv6.f44405g.f44407b;
        pc7 pc7Var = new pc7();
        hu6Var.getClass();
        wh7 wh7Var = (wh7) new n86(hu6Var, context, str, pc7Var).m10518d(context, false);
        this.f13856d = System.currentTimeMillis();
        this.f13854b = context.getApplicationContext();
        new AtomicReference(str);
        this.f13853a = wh7Var;
        this.f13855c = new ki7();
    }

    /* renamed from: a */
    public static void m10947a(Context context, String str, C0108c7 c0108c7, AbstractC1219k6 abstractC1219k6) {
        mt7.m16209z(context, "Context cannot be null.");
        mt7.m16209z(str, "AdUnitId cannot be null.");
        mt7.m16204u("#008 Must be called on the main UI thread.");
        l57.m15103a(context);
        if (((Boolean) r67.f33248k.m8826e()).booleanValue()) {
            if (((Boolean) by6.f3171e.f3174c.m14470a(l57.f23088Lc)).booleanValue()) {
                tx6.f37776b.execute(new zu5(context, str, c0108c7, abstractC1219k6, (byte) 6));
                return;
            }
        }
        v38.m21197d("Loading on UI thread");
        new fi7(context, str).m10949c(c0108c7.f3647a, abstractC1219k6);
    }

    /* renamed from: b */
    public final void m10948b(Activity activity, um3 um3Var) {
        ki7 ki7Var = this.f13855c;
        ki7Var.f21925b = um3Var;
        if (activity == null) {
            v38.m21201h("The activity for show is null, will proceed with show using the context provided when loading the ad.");
        }
        try {
            wh7 wh7Var = this.f13853a;
            if (wh7Var != null) {
                wh7Var.mo17781s4(ki7Var);
                wh7Var.mo17779k3(new yk3(activity));
            }
        } catch (RemoteException e) {
            v38.m21204k("#007 Could not call remote method.", e);
        }
    }

    /* renamed from: c */
    public final void m10949c(st5 st5Var, AbstractC1219k6 abstractC1219k6) {
        try {
            wh7 wh7Var = this.f13853a;
            if (wh7Var != null) {
                st5Var.f35928d = this.f13856d;
                wh7Var.mo17767A3(sv8.m19946f(this.f13854b, st5Var), new hi7(abstractC1219k6, this, (byte) 0));
            }
        } catch (RemoteException e) {
            v38.m21204k("#007 Could not call remote method.", e);
        }
    }
}
