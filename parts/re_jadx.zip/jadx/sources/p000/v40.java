package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class v40 implements xy1 {

    /* renamed from: a */
    public final /* synthetic */ byte f39749a;

    /* renamed from: b */
    public final /* synthetic */ p25 f39750b;

    public /* synthetic */ v40(p25 p25Var, byte b) {
        this.f39749a = b;
        this.f39750b = p25Var;
    }

    @Override // p000.xy1
    public final Object invoke() {
        switch (this.f39749a) {
        }
        return new qj0(this.f39750b.m17545a());
    }
}
