package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class hi7 extends ci7 {

    /* renamed from: a */
    public final /* synthetic */ byte f17215a;

    /* renamed from: b */
    public final AbstractC0871d6 f17216b;

    /* renamed from: c */
    public final Object f17217c;

    public /* synthetic */ hi7(AbstractC0871d6 abstractC0871d6, Object obj, byte b) {
        this.f17215a = b;
        this.f17216b = abstractC0871d6;
        this.f17217c = obj;
    }

    @Override // p000.di7
    /* renamed from: K1 */
    public final void mo1780K1(int i) {
        byte b = this.f17215a;
    }

    @Override // p000.di7
    /* renamed from: a */
    public final void mo1781a() {
        li7 li7Var;
        byte b = this.f17215a;
        Object obj = this.f17217c;
        AbstractC0871d6 abstractC0871d6 = this.f17216b;
        switch (b) {
            case 0:
                AbstractC1219k6 abstractC1219k6 = (AbstractC1219k6) abstractC0871d6;
                if (abstractC1219k6 != null) {
                    abstractC1219k6.mo7446D((fi7) obj);
                    break;
                }
                break;
            default:
                je4 je4Var = (je4) abstractC0871d6;
                if (je4Var != null && (li7Var = (li7) obj) != null) {
                    je4Var.mo7446D(li7Var);
                    break;
                }
                break;
        }
    }

    @Override // p000.di7
    /* renamed from: h */
    public final void mo1782h(t38 t38Var) {
        byte b = this.f17215a;
        AbstractC0871d6 abstractC0871d6 = this.f17216b;
        switch (b) {
            case 0:
                AbstractC1219k6 abstractC1219k6 = (AbstractC1219k6) abstractC0871d6;
                if (abstractC1219k6 != null) {
                    abstractC1219k6.mo7445C(t38Var.m20141b());
                    break;
                }
                break;
            default:
                je4 je4Var = (je4) abstractC0871d6;
                if (je4Var != null) {
                    je4Var.mo7445C(t38Var.m20141b());
                    break;
                }
                break;
        }
    }

    /* renamed from: y4 */
    private final void m12757y4(int i) {
    }

    /* renamed from: z4 */
    private final void m12758z4(int i) {
    }
}
