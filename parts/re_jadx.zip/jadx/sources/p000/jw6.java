package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class jw6 extends kl9 {
    private static final jw6 zzj;
    private static volatile nm9 zzk;
    private int zza;
    private long zzb = -1;
    private long zzc = -1;
    private long zzd = -1;
    private long zze = -1;
    private long zzf = -1;
    private long zzg = -1;
    private long zzh = -1;
    private long zzi = -1;

    static {
        jw6 jw6Var = new jw6();
        zzj = jw6Var;
        kl9.m14763t(jw6.class, jw6Var);
    }

    /* renamed from: z */
    public static iw6 m14303z() {
        return (iw6) zzj.m14772q();
    }

    /* renamed from: A */
    public final /* synthetic */ void m14304A(long j) {
        this.zza |= 1;
        this.zzb = j;
    }

    /* renamed from: B */
    public final /* synthetic */ void m14305B(long j) {
        this.zza |= 4;
        this.zzd = j;
    }

    /* renamed from: C */
    public final /* synthetic */ void m14306C(long j) {
        this.zza |= 8;
        this.zze = j;
    }

    /* renamed from: D */
    public final /* synthetic */ void m14307D(long j) {
        this.zza |= 16;
        this.zzf = j;
    }

    /* renamed from: E */
    public final /* synthetic */ void m14308E(long j) {
        this.zza |= 32;
        this.zzg = j;
    }

    @Override // p000.kl9
    /* renamed from: v */
    public final Object mo125v(int i, kl9 kl9Var) {
        nm9 nm9Var;
        int m23606C = yt0.m23606C(i);
        if (m23606C == 0) {
            return (byte) 1;
        }
        if (m23606C == 2) {
            return new rm9(zzj, "\u0001\b\u0000\u0001\u0001\b\b\u0000\u0000\u0000\u0001ဂ\u0000\u0002ဂ\u0001\u0003ဂ\u0002\u0004ဂ\u0003\u0005ဂ\u0004\u0006ဂ\u0005\u0007ဂ\u0006\bဂ\u0007", new Object[]{"zza", "zzb", "zzc", "zzd", "zze", "zzf", "zzg", "zzh", "zzi"});
        }
        if (m23606C == 3) {
            return new jw6();
        }
        if (m23606C == 4) {
            return new iw6(zzj);
        }
        if (m23606C == 5) {
            return zzj;
        }
        if (m23606C != 6) {
            throw null;
        }
        nm9 nm9Var2 = zzk;
        if (nm9Var2 != null) {
            return nm9Var2;
        }
        synchronized (jw6.class) {
            nm9Var = zzk;
            if (nm9Var == null) {
                nm9Var = new jl9(zzj);
                zzk = nm9Var;
            }
        }
        return nm9Var;
    }
}
