package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class f69 extends z59 {

    /* renamed from: v */
    public final l69 f13347v;

    /* renamed from: w */
    public final mj9 f13348w;

    /* renamed from: x */
    public final mj9 f13349x;

    /* renamed from: y */
    public final lj9 f13350y;

    /* renamed from: z */
    public final Integer f13351z;

    public f69(l69 l69Var, mj9 mj9Var, mj9 mj9Var2, lj9 lj9Var, Integer num) {
        super((byte) 27);
        this.f13347v = l69Var;
        this.f13348w = mj9Var;
        this.f13349x = mj9Var2;
        this.f13350y = lj9Var;
        this.f13351z = num;
    }

    @Override // p000.lx6
    /* renamed from: G */
    public final /* synthetic */ p59 mo157G() {
        return this.f13347v;
    }

    @Override // p000.lx6
    /* renamed from: K */
    public final Integer mo158K() {
        return this.f13351z;
    }

    @Override // p000.z59
    /* renamed from: X */
    public final lj9 mo159X() {
        return this.f13350y;
    }
}
