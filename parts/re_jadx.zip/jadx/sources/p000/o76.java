package p000;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class o76 extends AbstractC1489r2 {
    public static final Parcelable.Creator<o76> CREATOR = new j76(3);

    /* renamed from: a */
    public final int f28508a;

    /* renamed from: b */
    public final IBinder f28509b;

    /* renamed from: c */
    public final bq0 f28510c;

    /* renamed from: d */
    public final boolean f28511d;

    /* renamed from: e */
    public final boolean f28512e;

    public o76(int i, IBinder iBinder, bq0 bq0Var, boolean z, boolean z2) {
        this.f28508a = i;
        this.f28509b = iBinder;
        this.f28510c = bq0Var;
        this.f28511d = z;
        this.f28512e = z2;
    }

    public final boolean equals(Object obj) {
        Object d9aVar;
        if (obj == null) {
            return false;
        }
        if (this != obj) {
            if (!(obj instanceof o76)) {
                return false;
            }
            o76 o76Var = (o76) obj;
            if (!this.f28510c.equals(o76Var.f28510c)) {
                return false;
            }
            Object obj2 = null;
            IBinder iBinder = this.f28509b;
            if (iBinder == null) {
                d9aVar = null;
            } else {
                int i = AbstractBinderC1099h4.f16721b;
                IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.IAccountAccessor");
                d9aVar = queryLocalInterface instanceof ca2 ? (ca2) queryLocalInterface : new d9a(iBinder, "com.google.android.gms.common.internal.IAccountAccessor", (byte) 1);
            }
            IBinder iBinder2 = o76Var.f28509b;
            if (iBinder2 != null) {
                int i2 = AbstractBinderC1099h4.f16721b;
                IInterface queryLocalInterface2 = iBinder2.queryLocalInterface("com.google.android.gms.common.internal.IAccountAccessor");
                obj2 = queryLocalInterface2 instanceof ca2 ? (ca2) queryLocalInterface2 : new d9a(iBinder2, "com.google.android.gms.common.internal.IAccountAccessor", (byte) 1);
            }
            if (!qp7.m18399j(d9aVar, obj2)) {
                return false;
            }
        }
        return true;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        int m19648m0 = sca.m19648m0(parcel, 20293);
        sca.m19640i0(parcel, 1, 4);
        parcel.writeInt(this.f28508a);
        sca.m19620X(parcel, 2, this.f28509b);
        sca.m19624a0(parcel, 3, this.f28510c, i);
        sca.m19640i0(parcel, 4, 4);
        parcel.writeInt(this.f28511d ? 1 : 0);
        sca.m19640i0(parcel, 5, 4);
        parcel.writeInt(this.f28512e ? 1 : 0);
        sca.m19656q0(parcel, m19648m0);
    }
}
