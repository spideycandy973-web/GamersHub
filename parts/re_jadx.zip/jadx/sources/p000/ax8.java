package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public abstract class ax8 extends x07 implements bx8 {

    /* renamed from: a */
    public static final /* synthetic */ int f1611a = 0;
}
