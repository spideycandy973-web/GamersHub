package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class xa4 extends z21 {

    /* renamed from: n */
    public final z21 f43557n;

    /* renamed from: o */
    public final int f43558o;

    public xa4(z21 z21Var, int i) {
        this.f43557n = z21Var;
        this.f43558o = i;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof xa4)) {
            return false;
        }
        xa4 xa4Var = (xa4) obj;
        return xa4Var.f43557n.equals(this.f43557n) && xa4Var.f43558o == this.f43558o;
    }

    public final int hashCode() {
        return this.f43557n.hashCode() + (this.f43558o * 31);
    }
}
