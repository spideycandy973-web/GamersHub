package p000;

import java.nio.ByteBuffer;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public abstract class ry8 {

    /* renamed from: a */
    public static final byte[] f34460a;

    static {
        byte[] bArr = new byte[0];
        f34460a = bArr;
        ByteBuffer.wrap(bArr);
    }

    /* renamed from: a */
    public static int m19274a(int i, byte[] bArr, int i2, int i3) {
        for (int i4 = i2; i4 < i2 + i3; i4++) {
            i = (i * 31) + bArr[i4];
        }
        return i;
    }
}
