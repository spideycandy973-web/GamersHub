package p000;

import android.view.View;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class b03 extends sa3 {

    /* renamed from: a */
    public final zy1 f1687a;

    /* renamed from: b */
    public final zy1 f1688b;

    /* renamed from: c */
    public final xw3 f1689c;

    public b03(zy1 zy1Var, zy1 zy1Var2, xw3 xw3Var) {
        this.f1687a = zy1Var;
        this.f1688b = zy1Var2;
        this.f1689c = xw3Var;
    }

    @Override // p000.sa3
    /* renamed from: e */
    public final ma3 mo87e() {
        return new d03(this.f1687a, this.f1688b, this.f1689c);
    }

    public final boolean equals(Object obj) {
        return this == obj;
    }

    @Override // p000.sa3
    /* renamed from: f */
    public final void mo88f(ma3 ma3Var) {
        d03 d03Var = (d03) ma3Var;
        float f = d03Var.f9579q;
        long j = d03Var.f9581s;
        float f2 = d03Var.f9582t;
        boolean z = d03Var.f9580r;
        float f3 = d03Var.f9583u;
        boolean z2 = d03Var.f9584v;
        xw3 xw3Var = d03Var.f9585w;
        View view = d03Var.f9586x;
        t61 t61Var = d03Var.f9587y;
        d03Var.f9577o = this.f1687a;
        d03Var.f9579q = Float.NaN;
        d03Var.f9580r = true;
        d03Var.f9581s = 9205357640488583168L;
        d03Var.f9582t = Float.NaN;
        d03Var.f9583u = Float.NaN;
        d03Var.f9584v = true;
        d03Var.f9578p = this.f1688b;
        xw3 xw3Var2 = this.f1689c;
        d03Var.f9585w = xw3Var2;
        View m17424K = ov9.m17424K(d03Var);
        t61 t61Var2 = hl9.m12885P(d03Var).f42545y;
        if (d03Var.f9588z != null) {
            jq4 jq4Var = e03.f11066a;
            if ((!Float.isNaN(f) && Float.NaN != f && !xw3Var2.mo20692c()) || 9205357640488583168L != j || !oc1.m17100b(Float.NaN, f2) || !oc1.m17100b(Float.NaN, f3) || true != z || true != z2 || !xw3Var2.equals(xw3Var) || !m17424K.equals(view) || !ei2.m10070i(t61Var2, t61Var)) {
                d03Var.m8578U0();
            }
        }
        d03Var.m8579V0();
    }

    public final int hashCode() {
        return this.f1689c.hashCode() + ((this.f1688b.hashCode() + (((((((((((this.f1687a.hashCode() * 961) + 2143289344) * 31) + 1231) * 961) + 2143289344) * 31) + 2143289344) * 31) + 1231) * 31)) * 31);
    }
}
