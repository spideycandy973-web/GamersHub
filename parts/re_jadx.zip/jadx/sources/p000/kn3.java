package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class kn3 extends jo3 {

    /* renamed from: c */
    public static final kn3 f22073c = new kn3(0, 0, 3);

    @Override // p000.jo3
    /* renamed from: a */
    public final void mo960a(zi0 zi0Var, InterfaceC0898dv interfaceC0898dv, ty4 ty4Var, ab4 ab4Var, ko3 ko3Var) {
        ty4Var.m20519i();
    }
}
