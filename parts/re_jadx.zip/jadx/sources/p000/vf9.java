package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class vf9 extends kl9 {
    private static final vf9 zzf;
    private static volatile nm9 zzg;
    private int zza;
    private int zzb;
    private rf9 zzc;
    private uk9 zzd;
    private uk9 zze;

    static {
        vf9 vf9Var = new vf9();
        zzf = vf9Var;
        kl9.m14763t(vf9.class, vf9Var);
    }

    public vf9() {
        sk9 sk9Var = uk9.f38863b;
        this.zzd = sk9Var;
        this.zze = sk9Var;
    }

    /* renamed from: D */
    public static vf9 m21446D(uk9 uk9Var, bl9 bl9Var) {
        return (vf9) kl9.m14760m(zzf, uk9Var, bl9Var);
    }

    /* renamed from: E */
    public static uf9 m21447E() {
        return (uf9) zzf.m14772q();
    }

    /* renamed from: F */
    public static vf9 m21448F() {
        return zzf;
    }

    /* renamed from: G */
    public static nm9 m21449G() {
        return zzf.m14770o();
    }

    /* renamed from: A */
    public final rf9 m21450A() {
        rf9 rf9Var = this.zzc;
        return rf9Var == null ? rf9.m19084D() : rf9Var;
    }

    /* renamed from: B */
    public final uk9 m21451B() {
        return this.zzd;
    }

    /* renamed from: C */
    public final uk9 m21452C() {
        return this.zze;
    }

    /* renamed from: H */
    public final /* synthetic */ void m21453H(int i) {
        this.zzb = 0;
    }

    /* renamed from: I */
    public final /* synthetic */ void m21454I(rf9 rf9Var) {
        this.zzc = rf9Var;
        this.zza |= 1;
    }

    /* renamed from: J */
    public final /* synthetic */ void m21455J(sk9 sk9Var) {
        sk9Var.getClass();
        this.zzd = sk9Var;
    }

    /* renamed from: K */
    public final /* synthetic */ void m21456K(sk9 sk9Var) {
        sk9Var.getClass();
        this.zze = sk9Var;
    }

    @Override // p000.kl9
    /* renamed from: v */
    public final Object mo125v(int i, kl9 kl9Var) {
        nm9 nm9Var;
        int m23606C = yt0.m23606C(i);
        if (m23606C == 0) {
            return (byte) 1;
        }
        if (m23606C == 2) {
            return new rm9(zzf, "\u0000\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u000b\u0002ဉ\u0000\u0003\n\u0004\n", new Object[]{"zza", "zzb", "zzc", "zzd", "zze"});
        }
        if (m23606C == 3) {
            return new vf9();
        }
        if (m23606C == 4) {
            return new uf9(zzf);
        }
        if (m23606C == 5) {
            return zzf;
        }
        if (m23606C != 6) {
            throw null;
        }
        nm9 nm9Var2 = zzg;
        if (nm9Var2 != null) {
            return nm9Var2;
        }
        synchronized (vf9.class) {
            nm9Var = zzg;
            if (nm9Var == null) {
                nm9Var = new jl9(zzf);
                zzg = nm9Var;
            }
        }
        return nm9Var;
    }

    /* renamed from: z */
    public final int m21457z() {
        return this.zzb;
    }
}
