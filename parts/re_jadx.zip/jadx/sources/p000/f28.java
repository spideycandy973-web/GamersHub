package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class f28 implements cq9 {

    /* renamed from: a */
    public final /* synthetic */ byte f13232a;

    /* renamed from: b */
    public final pu7 f13233b;

    public /* synthetic */ f28(pu7 pu7Var, byte b) {
        this.f13232a = b;
        this.f13233b = pu7Var;
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x0067, code lost:
    
        if (android.text.TextUtils.isEmpty(r0) != false) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0052, code lost:
    
        if (android.text.TextUtils.isEmpty(r0) != false) goto L14;
     */
    @Override // p000.hq9
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object zzb() {
        /*
            r3 = this;
            byte r0 = r3.f13232a
            r1 = 3
            pu7 r3 = r3.f13233b
            switch(r0) {
                case 0: goto L8d;
                case 1: goto L7d;
                case 2: goto L23;
                case 3: goto L18;
                default: goto L8;
            }
        L8:
            ak7 r0 = p000.bk7.f2594a
            p000.n16.m16396G(r0)
            ki8 r3 = r3.m17892a()
            sc8 r1 = new sc8
            r2 = 1
            r1.<init>(r0, r3, r2)
            return r1
        L18:
            ki8 r3 = r3.m17892a()
            ic8 r0 = new ic8
            r1 = 2
            r0.<init>(r3, r1)
            return r0
        L23:
            ki8 r3 = r3.m17892a()
            yx9 r3 = r3.f21929d
            f57 r0 = p000.l57.f23634r8
            by6 r1 = p000.by6.f3171e
            k57 r1 = r1.f3174c
            java.lang.Object r0 = r1.m14470a(r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            if (r0 == 0) goto L69
            java.lang.String r0 = r3.f46246x
            boolean r1 = android.text.TextUtils.isEmpty(r0)
            java.lang.String r2 = "request_id"
            if (r1 != 0) goto L54
            org.json.JSONObject r1 = new org.json.JSONObject     // Catch: org.json.JSONException -> L54
            r1.<init>(r0)     // Catch: org.json.JSONException -> L54
            java.lang.String r0 = r1.getString(r2)     // Catch: org.json.JSONException -> L54
            boolean r1 = android.text.TextUtils.isEmpty(r0)     // Catch: org.json.JSONException -> L54
            if (r1 == 0) goto L79
        L54:
            tf7 r3 = r3.f46241s
            if (r3 == 0) goto L69
            org.json.JSONObject r0 = new org.json.JSONObject     // Catch: org.json.JSONException -> L69
            java.lang.String r3 = r3.f36981a     // Catch: org.json.JSONException -> L69
            r0.<init>(r3)     // Catch: org.json.JSONException -> L69
            java.lang.String r0 = r0.getString(r2)     // Catch: org.json.JSONException -> L69
            boolean r3 = android.text.TextUtils.isEmpty(r0)     // Catch: org.json.JSONException -> L69
            if (r3 == 0) goto L79
        L69:
            xv6 r3 = p000.xv6.f44405g
            java.util.Random r3 = r3.f44410e
            int r3 = r3.nextInt()
            r0 = 2147483647(0x7fffffff, float:NaN)
            r3 = r3 & r0
            java.lang.String r0 = java.lang.String.valueOf(r3)
        L79:
            p000.n16.m16396G(r0)
            return r0
        L7d:
            ki8 r3 = r3.m17892a()
            tx2 r3 = r3.f21941p
            byte r3 = r3.f37756b
            if (r3 != r1) goto L8a
            java.lang.String r3 = "rewarded_interstitial"
            goto L8c
        L8a:
            java.lang.String r3 = "rewarded"
        L8c:
            return r3
        L8d:
            ki8 r3 = r3.m17892a()
            tx2 r3 = r3.f21941p
            byte r3 = r3.f37756b
            if (r3 != r1) goto L9a
            c37 r3 = p000.c37.REWARDED_INTERSTITIAL
            goto L9c
        L9a:
            c37 r3 = p000.c37.REWARD_BASED_VIDEO_AD
        L9c:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.f28.zzb():java.lang.Object");
    }
}
