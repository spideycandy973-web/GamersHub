package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class pw1 extends AbstractC1096h1 implements gu0 {
    @Override // p000.gu0
    public final void handleException(cu0 cu0Var, Throwable th) {
    }
}
