package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class dz5 {

    /* renamed from: a */
    public final String f11039a;

    /* renamed from: b */
    public final String f11040b;

    public dz5(String str, String str2) {
        str.getClass();
        this.f11039a = str;
        this.f11040b = str2;
    }
}
