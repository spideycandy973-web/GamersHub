package p000;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class bx5 {

    /* renamed from: a */
    public static final bx5 f3122a;

    /* renamed from: b */
    public static final bx5 f3123b;

    /* renamed from: c */
    public static final bx5 f3124c;

    /* renamed from: d */
    public static final bx5 f3125d;

    /* renamed from: e */
    public static final bx5 f3126e;

    /* renamed from: f */
    public static final bx5 f3127f;

    /* renamed from: g */
    public static final bx5 f3128g;

    /* renamed from: h */
    public static final bx5 f3129h;

    /* renamed from: i */
    public static final bx5 f3130i;

    /* renamed from: j */
    public static final /* synthetic */ bx5[] f3131j;

    static {
        bx5 bx5Var = new bx5("INT", 0);
        f3122a = bx5Var;
        bx5 bx5Var2 = new bx5("LONG", 1);
        f3123b = bx5Var2;
        bx5 bx5Var3 = new bx5("FLOAT", 2);
        f3124c = bx5Var3;
        bx5 bx5Var4 = new bx5("DOUBLE", 3);
        f3125d = bx5Var4;
        bx5 bx5Var5 = new bx5("BOOLEAN", 4);
        f3126e = bx5Var5;
        bx5 bx5Var6 = new bx5("STRING", 5);
        f3127f = bx5Var6;
        lc0 lc0Var = lc0.f24063c;
        bx5 bx5Var7 = new bx5("BYTE_STRING", 6);
        f3128g = bx5Var7;
        bx5 bx5Var8 = new bx5("ENUM", 7);
        f3129h = bx5Var8;
        bx5 bx5Var9 = new bx5("MESSAGE", 8);
        f3130i = bx5Var9;
        f3131j = new bx5[]{bx5Var, bx5Var2, bx5Var3, bx5Var4, bx5Var5, bx5Var6, bx5Var7, bx5Var8, bx5Var9};
    }

    public static bx5 valueOf(String str) {
        return (bx5) Enum.valueOf(bx5.class, str);
    }

    public static bx5[] values() {
        return (bx5[]) f3131j.clone();
    }
}
