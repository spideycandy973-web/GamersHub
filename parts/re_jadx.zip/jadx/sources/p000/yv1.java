package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class yv1 extends x51 implements cl3, lo0 {

    /* renamed from: q */
    public final bw1 f46069q;

    /* renamed from: r */
    public tr2 f46070r;

    public yv1() {
        bw1 bw1Var = new bw1(0, new xv1(2, this, yv1.class, "onFocusStateChange", "onFocusStateChange(Landroidx/compose/ui/focus/FocusState;Landroidx/compose/ui/focus/FocusState;)V", 0, (byte) 0), 9);
        m22518T0(bw1Var);
        this.f46069q = bw1Var;
    }

    @Override // p000.cl3
    /* renamed from: j0 */
    public final void mo32j0() {
        aa4 aa4Var = new aa4();
        fw7.m11661I(this, new g51((Object) aa4Var, (Object) this, (byte) 6));
        tr2 tr2Var = (tr2) aa4Var.f354a;
        if (this.f46069q.m2010Y0().m21715b()) {
            tr2 tr2Var2 = this.f46070r;
            if (tr2Var2 != null) {
                tr2Var2.m20461b();
            }
            if (tr2Var != null) {
                tr2Var.m20460a();
            } else {
                tr2Var = null;
            }
            this.f46070r = tr2Var;
        }
    }
}
