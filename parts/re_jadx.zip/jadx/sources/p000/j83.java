package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class j83 {

    /* renamed from: a */
    public final nz1 f19814a;

    /* renamed from: b */
    public final bl0 f19815b;

    /* renamed from: c */
    public final w35 f19816c;

    /* renamed from: d */
    public final cu0 f19817d;

    public j83(nz1 nz1Var, bl0 bl0Var, w35 w35Var, cu0 cu0Var) {
        cu0Var.getClass();
        this.f19814a = nz1Var;
        this.f19815b = bl0Var;
        this.f19816c = w35Var;
        this.f19817d = cu0Var;
    }
}
