package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class j69 implements l49 {

    /* renamed from: c */
    public static final j69 f19739c;

    /* renamed from: d */
    public static final j69 f19740d;

    /* renamed from: e */
    public static final j69 f19741e;

    /* renamed from: f */
    public static final j69 f19742f;

    /* renamed from: g */
    public static final j69 f19743g;

    /* renamed from: h */
    public static final j69 f19744h;

    /* renamed from: i */
    public static final j69 f19745i;

    /* renamed from: j */
    public static final j69 f19746j;

    /* renamed from: k */
    public static final j69 f19747k;

    /* renamed from: a */
    public final /* synthetic */ byte f19748a;

    /* renamed from: b */
    public final String f19749b;

    static {
        byte b = 0;
        f19739c = new j69("SHA1", b);
        f19740d = new j69("SHA224", b);
        f19741e = new j69("SHA256", b);
        f19742f = new j69("SHA384", b);
        f19743g = new j69("SHA512", b);
        byte b2 = 1;
        f19744h = new j69("TINK", b2);
        f19745i = new j69("CRUNCHY", b2);
        f19746j = new j69("LEGACY", b2);
        f19747k = new j69("NO_PREFIX", b2);
    }

    public /* synthetic */ j69(String str, byte b) {
        this.f19748a = b;
        this.f19749b = str;
    }

    @Override // p000.l49
    /* renamed from: m */
    public final void mo378m(Throwable th) {
        f9a.f13493B.f13502h.m20871d(this.f19749b, th);
    }

    public final String toString() {
        byte b = this.f19748a;
        String str = this.f19749b;
        switch (b) {
            case 0:
            case 1:
                return str;
            default:
                return super.toString();
        }
    }

    @Override // p000.l49
    /* renamed from: g */
    public final void mo373g(Object obj) {
    }
}
