package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public abstract class uy5 {

    /* renamed from: a */
    public static final /* synthetic */ int f39501a = 0;

    static {
        tx2.m20484f("WorkForegroundRunnable");
    }
}
