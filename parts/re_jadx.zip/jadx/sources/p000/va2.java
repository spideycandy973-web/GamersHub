package p000;

import android.os.IBinder;
import android.os.Parcel;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class va2 implements wa2 {

    /* renamed from: a */
    public IBinder f40102a;

    @Override // p000.wa2
    /* renamed from: F0 */
    public final void mo21361F0(String[] strArr) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken(wa2.f41769b9);
            obtain.writeStringArray(strArr);
            this.f40102a.transact(1, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f40102a;
    }
}
