package p000;

import java.util.ArrayList;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class tb7 implements Runnable {

    /* renamed from: a */
    public final /* synthetic */ byte f36872a;

    /* renamed from: b */
    public final /* synthetic */ zb7 f36873b;

    /* renamed from: c */
    public final /* synthetic */ yb7 f36874c;

    /* renamed from: d */
    public final /* synthetic */ ob7 f36875d;

    /* renamed from: e */
    public final /* synthetic */ ArrayList f36876e;

    /* renamed from: f */
    public final /* synthetic */ long f36877f;

    public /* synthetic */ tb7(zb7 zb7Var, yb7 yb7Var, ob7 ob7Var, ArrayList arrayList, long j, byte b) {
        this.f36872a = b;
        this.f36874c = yb7Var;
        this.f36875d = ob7Var;
        this.f36876e = arrayList;
        this.f36877f = j;
        this.f36873b = zb7Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String sb;
        switch (this.f36872a) {
            case 0:
                v38.m21194a("loadJavascriptEngine > ADMOB_UI_HANDLER.postDelayed: Trying to acquire lock");
                zb7 zb7Var = this.f36873b;
                synchronized (zb7Var.f46866a) {
                    v38.m21194a("loadJavascriptEngine > ADMOB_UI_HANDLER.postDelayed: Lock acquired");
                    yb7 yb7Var = this.f36874c;
                    if (((AtomicInteger) yb7Var.f15200c).get() == -1 || ((AtomicInteger) yb7Var.f15200c).get() == 1) {
                        v38.m21194a("loadJavascriptEngine > ADMOB_UI_HANDLER.postDelayed: Lock released, the promise is already settled");
                        return;
                    }
                    f57 f57Var = l57.f23084L8;
                    by6 by6Var = by6.f3171e;
                    if (((Boolean) by6Var.f3174c.m14470a(f57Var)).booleanValue()) {
                        yb7Var.m11802k("SdkJavascriptFactory.loadJavascriptEngine.Runnable", new TimeoutException("Unable to fully load JS engine."));
                    } else {
                        yb7Var.m11801j();
                    }
                    bk7.f2599f.execute(new sb7(this.f36875d, (byte) 0));
                    String valueOf = String.valueOf(by6Var.f3174c.m14470a(l57.f23402e));
                    int i = ((AtomicInteger) yb7Var.f15200c).get();
                    byte b = zb7Var.f46872g;
                    ArrayList arrayList = this.f36876e;
                    if (arrayList.isEmpty()) {
                        sb = ". Still waiting for the engine to be loaded";
                    } else {
                        String valueOf2 = String.valueOf(arrayList.get(0));
                        StringBuilder sb2 = new StringBuilder(valueOf2.length() + 88);
                        sb2.append(". While waiting for the /jsLoaded gmsg, observed the loadNewJavascriptEngine latency is ");
                        sb2.append(valueOf2);
                        sb = sb2.toString();
                    }
                    f9a.f13493B.getClass();
                    long currentTimeMillis = System.currentTimeMillis() - this.f36877f;
                    StringBuilder sb3 = new StringBuilder(valueOf.length() + 107 + String.valueOf(i).length() + 36 + String.valueOf((int) b).length() + sb.length() + 39 + String.valueOf(currentTimeMillis).length() + 26);
                    sb3.append("Could not finish the full JS engine loading in ");
                    sb3.append(valueOf);
                    sb3.append(" ms. JS engine session reference status(fullLoadTimeout) is ");
                    sb3.append(i);
                    sb3.append(". Update status(fullLoadTimeout) is ");
                    sb3.append((int) b);
                    sb3.append(sb);
                    sb3.append(" ms. Total latency(fullLoadTimeout) is ");
                    sb3.append(currentTimeMillis);
                    sb3.append(" ms at timeout. Rejecting.");
                    v38.m21194a(sb3.toString());
                    v38.m21194a("loadJavascriptEngine > ADMOB_UI_HANDLER.postDelayed: Lock released");
                    return;
                }
            default:
                zb7 zb7Var2 = this.f36873b;
                yb7 yb7Var2 = this.f36874c;
                ob7 ob7Var = this.f36875d;
                ArrayList arrayList2 = this.f36876e;
                long j = this.f36877f;
                v38.m21194a("loadJavascriptEngine > newEngine.setLoadedListener(postDelayed): Trying to acquire lock");
                synchronized (zb7Var2.f46866a) {
                    v38.m21194a("loadJavascriptEngine > newEngine.setLoadedListener(postDelayed): Lock acquired");
                    if (((AtomicInteger) yb7Var2.f15200c).get() == -1 || ((AtomicInteger) yb7Var2.f15200c).get() == 1) {
                        v38.m21194a("loadJavascriptEngine > newEngine.setLoadedListener(postDelayed): Lock released, the promise is already settled");
                        return;
                    }
                    f57 f57Var2 = l57.f23084L8;
                    by6 by6Var2 = by6.f3171e;
                    if (((Boolean) by6Var2.f3174c.m14470a(f57Var2)).booleanValue()) {
                        yb7Var2.m11802k("SdkJavascriptFactory.loadJavascriptEngine.setLoadedListener", new TimeoutException("Unable to receive /jsLoaded GMSG."));
                    } else {
                        yb7Var2.m11801j();
                    }
                    bk7.f2599f.execute(new sb7(ob7Var, (byte) 1));
                    String valueOf3 = String.valueOf(by6Var2.f3174c.m14470a(l57.f23384d));
                    int i2 = ((AtomicInteger) yb7Var2.f15200c).get();
                    byte b2 = zb7Var2.f46872g;
                    String valueOf4 = String.valueOf(arrayList2.get(0));
                    f9a.f13493B.getClass();
                    long currentTimeMillis2 = System.currentTimeMillis() - j;
                    StringBuilder sb4 = new StringBuilder(valueOf3.length() + 94 + String.valueOf(i2).length() + 39 + String.valueOf((int) b2).length() + 57 + valueOf4.length() + 42 + String.valueOf(currentTimeMillis2).length() + 15);
                    sb4.append("Could not receive /jsLoaded in ");
                    sb4.append(valueOf3);
                    sb4.append(" ms. JS engine session reference status(onEngLoadedTimeout) is ");
                    sb4.append(i2);
                    sb4.append(". Update status(onEngLoadedTimeout) is ");
                    sb4.append((int) b2);
                    sb4.append(". LoadNewJavascriptEngine(onEngLoadedTimeout) latency is ");
                    sb4.append(valueOf4);
                    sb4.append(" ms. Total latency(onEngLoadedTimeout) is ");
                    sb4.append(currentTimeMillis2);
                    sb4.append(" ms. Rejecting.");
                    v38.m21194a(sb4.toString());
                    v38.m21194a("loadJavascriptEngine > newEngine.setLoadedListener(postDelayed): Lock released");
                    return;
                }
        }
    }
}
