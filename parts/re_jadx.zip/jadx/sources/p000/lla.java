package p000;

import com.mbridge.msdk.foundation.entity.CampaignEx;
import java.util.ArrayList;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class lla implements fla {
    @Override // p000.fla
    /* renamed from: a */
    public final Object mo12a(ArrayList arrayList, zj8 zj8Var) {
        return ((CampaignEx) arrayList.get(0)).getIconUrl();
    }
}
