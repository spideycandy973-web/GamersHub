package p000;

import android.app.Activity;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class r6b extends vsa {

    /* renamed from: b */
    public final /* synthetic */ Activity f33259b;

    /* renamed from: c */
    public final /* synthetic */ f5b f33260c;

    public r6b(f5b f5bVar, Activity activity) {
        this.f33260c = f5bVar;
        this.f33259b = activity;
    }

    @Override // p000.vsa
    /* renamed from: a */
    public final void mo66a() {
        Activity activity = this.f33259b;
        f5b f5bVar = this.f33260c;
        if (f5b.m10738x(f5bVar, activity)) {
            f5bVar.f13314h.getClass();
        }
    }
}
