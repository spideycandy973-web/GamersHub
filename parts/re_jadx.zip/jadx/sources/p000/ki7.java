package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class ki7 extends yh7 {

    /* renamed from: a */
    public ty1 f21924a;

    /* renamed from: b */
    public um3 f21925b;

    @Override // p000.zh7
    /* renamed from: C1 */
    public final void mo14717C1() {
        ty1 ty1Var = this.f21924a;
        if (ty1Var != null) {
            ty1Var.mo16069e();
        }
    }

    @Override // p000.zh7
    /* renamed from: E1 */
    public final void mo14718E1() {
        ty1 ty1Var = this.f21924a;
        if (ty1Var != null) {
            ty1Var.mo16067b();
        }
    }

    @Override // p000.zh7
    /* renamed from: a */
    public final void mo14719a() {
        ty1 ty1Var = this.f21924a;
        if (ty1Var != null) {
            ty1Var.mo14926f();
        }
    }

    @Override // p000.zh7
    /* renamed from: b4 */
    public final void mo14720b4(qh7 qh7Var) {
        um3 um3Var = this.f21925b;
        if (um3Var != null) {
            um3Var.mo19433b(new gi7((Object) qh7Var, (byte) 0));
        }
    }

    @Override // p000.zh7
    /* renamed from: p1 */
    public final void mo14721p1(t38 t38Var) {
        ty1 ty1Var = this.f21924a;
        if (ty1Var != null) {
            ty1Var.mo16068d(t38Var.m20140a());
        }
    }

    @Override // p000.zh7
    /* renamed from: z1 */
    public final void mo14723z1() {
        ty1 ty1Var = this.f21924a;
        if (ty1Var != null) {
            ty1Var.mo14925c();
        }
    }

    @Override // p000.zh7
    /* renamed from: q */
    public final void mo14722q(int i) {
    }
}
