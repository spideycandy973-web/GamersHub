package p000;

import android.webkit.WebView;
import com.ironsource.adqualitysdk.sdk.StringFog;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class f46 extends vsa {

    /* renamed from: b */
    public final /* synthetic */ String f13269b;

    /* renamed from: c */
    public final /* synthetic */ j46 f13270c;

    public f46(j46 j46Var, String str) {
        this.f13270c = j46Var;
        this.f13269b = str;
    }

    @Override // p000.vsa
    /* renamed from: a */
    public final void mo66a() {
        WebView webView = this.f13270c.f19662b;
        String str = AbstractC0864d.f9554a;
        if (webView != null) {
            if (webView.getHandler() == null && webView.getRootView() == null) {
                return;
            }
            StringBuilder sb = new StringBuilder();
            cl5.m2695j0("Y3uVdCCb7XF5btlwJZnzMGhujHd72g==\n", "CRrjFVP4nxg=\n", this.f13269b, sb);
            sb.append(StringFog.decrypt("6y+REg==\n", "yQa4KU0pi+o=\n"));
            webView.loadUrl(sb.toString());
        }
    }
}
