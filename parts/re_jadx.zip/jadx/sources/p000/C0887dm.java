package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: dm */
/* loaded from: classes2.dex */
public final class C0887dm extends os0 {

    /* renamed from: a */
    public /* synthetic */ Object f10599a;

    /* renamed from: b */
    public final /* synthetic */ u62 f10600b;

    /* renamed from: c */
    public int f10601c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0887dm(u62 u62Var, os0 os0Var) {
        super(os0Var);
        this.f10600b = u62Var;
    }

    @Override // p000.r50
    public final Object invokeSuspend(Object obj) {
        this.f10599a = obj;
        this.f10601c |= Integer.MIN_VALUE;
        return this.f10600b.m20685C(this);
    }
}
