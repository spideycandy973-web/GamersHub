package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class da1 extends Exception {

    /* renamed from: a */
    public final Throwable f10022a;

    public da1(Throwable th, eu0 eu0Var, cu0 cu0Var) {
        super("Coroutine dispatcher " + eu0Var + " threw an exception, context = " + cu0Var, th);
        this.f10022a = th;
    }

    @Override // java.lang.Throwable
    public final Throwable getCause() {
        return this.f10022a;
    }
}
