package p000;

import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import com.unity3d.ads.metadata.InAppPurchaseMetaData;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class jz7 {

    /* renamed from: a */
    public int f20986a;

    /* renamed from: b */
    public e38 f20987b;

    /* renamed from: c */
    public v77 f20988c;

    /* renamed from: d */
    public View f20989d;

    /* renamed from: e */
    public List f20990e;

    /* renamed from: g */
    public bd8 f20992g;

    /* renamed from: h */
    public Bundle f20993h;

    /* renamed from: i */
    public rm7 f20994i;

    /* renamed from: j */
    public rm7 f20995j;

    /* renamed from: k */
    public rm7 f20996k;

    /* renamed from: l */
    public q88 f20997l;

    /* renamed from: m */
    public cw2 f20998m;

    /* renamed from: n */
    public ck7 f20999n;

    /* renamed from: o */
    public View f21000o;

    /* renamed from: p */
    public View f21001p;

    /* renamed from: q */
    public ya2 f21002q;

    /* renamed from: r */
    public double f21003r;

    /* renamed from: s */
    public z77 f21004s;

    /* renamed from: t */
    public z77 f21005t;

    /* renamed from: u */
    public String f21006u;

    /* renamed from: x */
    public float f21009x;

    /* renamed from: y */
    public String f21010y;

    /* renamed from: v */
    public final ox4 f21007v = new ox4(0);

    /* renamed from: w */
    public final ox4 f21008w = new ox4(0);

    /* renamed from: f */
    public List f20991f = Collections.EMPTY_LIST;

    /* renamed from: l */
    public static jz7 m14397l(dd7 dd7Var) {
        iz7 iz7Var;
        dd7 dd7Var2;
        try {
            b48 mo2491I1 = dd7Var.mo2491I1();
            if (mo2491I1 == null) {
                dd7Var2 = dd7Var;
                iz7Var = null;
            } else {
                dd7Var2 = dd7Var;
                iz7Var = new iz7(mo2491I1, dd7Var2);
            }
            return m14398m(iz7Var, dd7Var2.mo2493J1(), (View) m14399n(dd7Var2.mo2501e()), dd7Var2.mo2499a(), dd7Var2.mo2507z1(), dd7Var2.mo2500b(), dd7Var2.mo2492I3(), dd7Var2.mo2488F1(), (View) m14399n(dd7Var2.mo2489G1()), dd7Var2.mo2503g(), dd7Var2.mo2486D1(), dd7Var2.mo2490H1(), dd7Var2.mo2487E1(), dd7Var2.mo2483A1(), dd7Var2.mo2485C1(), dd7Var2.mo2504i());
        } catch (RemoteException e) {
            int i = v38.f39727b;
            v38.m21202i("Failed to get native ad assets from unified ad mapper", e);
            return null;
        }
    }

    /* renamed from: m */
    public static jz7 m14398m(iz7 iz7Var, v77 v77Var, View view, String str, List list, String str2, Bundle bundle, String str3, View view2, ya2 ya2Var, String str4, String str5, double d, z77 z77Var, String str6, float f) {
        jz7 jz7Var = new jz7();
        jz7Var.f20986a = 6;
        jz7Var.f20987b = iz7Var;
        jz7Var.f20988c = v77Var;
        jz7Var.f20989d = view;
        jz7Var.m14411o("headline", str);
        jz7Var.f20990e = list;
        jz7Var.m14411o("body", str2);
        jz7Var.f20993h = bundle;
        jz7Var.m14411o("call_to_action", str3);
        jz7Var.f21000o = view2;
        jz7Var.f21002q = ya2Var;
        jz7Var.m14411o("store", str4);
        jz7Var.m14411o(InAppPurchaseMetaData.KEY_PRICE, str5);
        jz7Var.f21003r = d;
        jz7Var.f21004s = z77Var;
        jz7Var.m14411o("advertiser", str6);
        synchronized (jz7Var) {
            jz7Var.f21009x = f;
        }
        return jz7Var;
    }

    /* renamed from: n */
    public static Object m14399n(ya2 ya2Var) {
        if (ya2Var == null) {
            return null;
        }
        return yk3.m23517R1(ya2Var);
    }

    /* renamed from: a */
    public final synchronized String m14400a() {
        return m14412p("headline");
    }

    /* renamed from: b */
    public final z77 m14401b() {
        List list = this.f20990e;
        if (list == null || list.isEmpty()) {
            return null;
        }
        Object obj = this.f20990e.get(0);
        if (obj instanceof IBinder) {
            return r77.m18858y4((IBinder) obj);
        }
        return null;
    }

    /* renamed from: c */
    public final synchronized String m14402c() {
        return m14412p("body");
    }

    /* renamed from: d */
    public final synchronized Bundle m14403d() {
        Bundle bundle;
        bundle = this.f20993h;
        if (bundle == null) {
            bundle = new Bundle();
            this.f20993h = bundle;
        }
        return bundle;
    }

    /* renamed from: e */
    public final synchronized String m14404e() {
        return m14412p("call_to_action");
    }

    /* renamed from: f */
    public final synchronized String m14405f() {
        return m14412p("advertiser");
    }

    /* renamed from: g */
    public final synchronized String m14406g() {
        return this.f21006u;
    }

    /* renamed from: h */
    public final synchronized rm7 m14407h() {
        return this.f20994i;
    }

    /* renamed from: i */
    public final synchronized rm7 m14408i() {
        return this.f20995j;
    }

    /* renamed from: j */
    public final synchronized rm7 m14409j() {
        return this.f20996k;
    }

    /* renamed from: k */
    public final synchronized q88 m14410k() {
        return this.f20997l;
    }

    /* renamed from: o */
    public final synchronized void m14411o(String str, String str2) {
        ox4 ox4Var = this.f21008w;
        if (str2 == null) {
            ox4Var.remove(str);
        } else {
            ox4Var.put(str, str2);
        }
    }

    /* renamed from: p */
    public final synchronized String m14412p(String str) {
        return (String) this.f21008w.get(str);
    }

    /* renamed from: q */
    public final synchronized int m14413q() {
        return this.f20986a;
    }

    /* renamed from: r */
    public final synchronized b48 m14414r() {
        return this.f20987b;
    }

    /* renamed from: s */
    public final synchronized v77 m14415s() {
        return this.f20988c;
    }
}
