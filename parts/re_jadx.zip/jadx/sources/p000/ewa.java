package p000;

import java.util.List;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ewa extends x4b {

    /* renamed from: b */
    public final /* synthetic */ String f12979b;

    /* renamed from: c */
    public final /* synthetic */ List f12980c;

    /* renamed from: d */
    public final /* synthetic */ r8b f12981d;

    public ewa(r8b r8bVar, String str, List list) {
        this.f12981d = r8bVar;
        this.f12979b = str;
        this.f12980c = list;
    }

    @Override // p000.vsa
    /* renamed from: a */
    public final void mo66a() {
        r8b.m18915i(this.f12981d, this.f12979b, false, true, this.f12980c);
    }
}
