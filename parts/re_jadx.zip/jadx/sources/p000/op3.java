package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class op3 extends AbstractC1499rc {

    /* renamed from: r */
    public final y84 f29178r;

    public op3(y84 y84Var) {
        this.f29178r = y84Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof op3) {
            return this.f29178r.equals(((op3) obj).f29178r);
        }
        return false;
    }

    public final int hashCode() {
        return this.f29178r.hashCode();
    }

    @Override // p000.AbstractC1499rc
    /* renamed from: t */
    public final y84 mo16797t() {
        return this.f29178r;
    }
}
