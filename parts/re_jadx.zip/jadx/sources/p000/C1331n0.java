package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: n0 */
/* loaded from: classes.dex */
public final class C1331n0 extends AbstractRunnableC1411p0 {
}
