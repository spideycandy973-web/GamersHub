package p000;

import java.util.Arrays;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class ax4 implements InterfaceC1756xp {

    /* renamed from: b */
    public static final ax4 f1604b = new ax4();

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        return (obj instanceof ax4) && qp7.m18399j(null, null) && qp7.m18399j(null, null) && qp7.m18399j(null, null) && qp7.m18399j(null, null) && qp7.m18399j(null, null);
    }

    public final int hashCode() {
        Boolean bool = Boolean.FALSE;
        return Arrays.hashCode(new Object[]{bool, bool, null, bool, bool, null, null, null, null});
    }
}
