package p000;

import java.util.Collections;
import java.util.Comparator;
import java.util.NavigableSet;
import java.util.SortedSet;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public abstract class kc2 extends jc2 implements NavigableSet, Iterable {

    /* renamed from: f */
    public static final /* synthetic */ int f21469f = 0;

    /* renamed from: d */
    public final transient Comparator f21470d;

    /* renamed from: e */
    public transient kc2 f21471e;

    public kc2(Comparator comparator) {
        this.f21470d = comparator;
    }

    /* renamed from: m */
    public static ua4 m14519m(Comparator comparator) {
        if (ig3.f18579a == comparator) {
            return ua4.f38459h;
        }
        dc2 dc2Var = hc2.f17030b;
        return new ua4(na4.f27243e, comparator);
    }

    @Override // java.util.SortedSet
    public final Comparator comparator() {
        return this.f21470d;
    }

    @Override // java.util.NavigableSet
    public final NavigableSet descendingSet() {
        kc2 kc2Var = this.f21471e;
        if (kc2Var == null) {
            ua4 ua4Var = (ua4) this;
            Comparator reverseOrder = Collections.reverseOrder(ua4Var.f21470d);
            kc2Var = ua4Var.isEmpty() ? m14519m(reverseOrder) : new ua4(ua4Var.f38460g.mo9934m(), reverseOrder);
            this.f21471e = kc2Var;
            kc2Var.f21471e = this;
        }
        return kc2Var;
    }

    @Override // java.util.NavigableSet
    public final NavigableSet headSet(Object obj, boolean z) {
        obj.getClass();
        ua4 ua4Var = (ua4) this;
        return ua4Var.m20785o(0, ua4Var.m20786p(obj, z));
    }

    @Override // java.util.NavigableSet
    /* renamed from: n, reason: merged with bridge method [inline-methods] */
    public final ua4 subSet(Object obj, boolean z, Object obj2, boolean z2) {
        obj.getClass();
        obj2.getClass();
        fw7.m11681h(this.f21470d.compare(obj, obj2) <= 0);
        ua4 ua4Var = (ua4) this;
        ua4 m20785o = ua4Var.m20785o(ua4Var.m20787r(obj, z), ua4Var.f38460g.size());
        return m20785o.m20785o(0, m20785o.m20786p(obj2, z2));
    }

    @Override // java.util.NavigableSet
    public final Object pollFirst() {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.NavigableSet
    public final Object pollLast() {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.NavigableSet, java.util.SortedSet
    public final SortedSet subSet(Object obj, Object obj2) {
        return subSet(obj, true, obj2, false);
    }

    @Override // java.util.NavigableSet, java.util.SortedSet
    public final SortedSet tailSet(Object obj) {
        obj.getClass();
        ua4 ua4Var = (ua4) this;
        return ua4Var.m20785o(ua4Var.m20787r(obj, true), ua4Var.f38460g.size());
    }

    @Override // java.util.NavigableSet, java.util.SortedSet
    public final SortedSet headSet(Object obj) {
        obj.getClass();
        ua4 ua4Var = (ua4) this;
        return ua4Var.m20785o(0, ua4Var.m20786p(obj, false));
    }

    @Override // java.util.NavigableSet
    public final NavigableSet tailSet(Object obj, boolean z) {
        obj.getClass();
        ua4 ua4Var = (ua4) this;
        return ua4Var.m20785o(ua4Var.m20787r(obj, z), ua4Var.f38460g.size());
    }
}
