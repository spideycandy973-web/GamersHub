package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
final class il3 extends sa3 {

    /* renamed from: a */
    public final float f18799a;

    /* renamed from: b */
    public final float f18800b;

    public il3(float f, float f2) {
        this.f18799a = f;
        this.f18800b = f2;
    }

    @Override // p000.sa3
    /* renamed from: e */
    public final ma3 mo87e() {
        ll3 ll3Var = new ll3();
        ll3Var.f24344o = this.f18799a;
        ll3Var.f24345p = this.f18800b;
        ll3Var.f24346q = true;
        return ll3Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        il3 il3Var = obj instanceof il3 ? (il3) obj : null;
        return il3Var != null && oc1.m17100b(this.f18799a, il3Var.f18799a) && oc1.m17100b(this.f18800b, il3Var.f18800b);
    }

    @Override // p000.sa3
    /* renamed from: f */
    public final void mo88f(ma3 ma3Var) {
        ll3 ll3Var = (ll3) ma3Var;
        float f = ll3Var.f24344o;
        float f2 = this.f18799a;
        boolean m17100b = oc1.m17100b(f, f2);
        float f3 = this.f18800b;
        if (!m17100b || !oc1.m17100b(ll3Var.f24345p, f3) || !ll3Var.f24346q) {
            hl9.m12885P(ll3Var).m22232V(false);
        }
        ll3Var.f24344o = f2;
        ll3Var.f24345p = f3;
        ll3Var.f24346q = true;
    }

    public final int hashCode() {
        return ((Float.hashCode(this.f18800b) + (Float.hashCode(this.f18799a) * 31)) * 31) + 1231;
    }

    public final String toString() {
        return d63.m8811r("OffsetModifierElement(x=", oc1.m17101c(this.f18799a), ", y=", oc1.m17101c(this.f18800b), ", rtlAware=true)");
    }
}
