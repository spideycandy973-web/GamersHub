package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class jn6 {

    /* renamed from: a */
    public int f20459a;

    /* renamed from: b */
    public int f20460b;

    /* renamed from: c */
    public long f20461c;

    /* renamed from: d */
    public long f20462d;

    /* renamed from: e */
    public long f20463e;

    /* renamed from: f */
    public long f20464f;

    /* renamed from: g */
    public jaa f20465g;

    /* renamed from: h */
    public boolean f20466h;

    /* renamed from: i */
    public ln6[] f20467i;

    /* renamed from: j */
    public int f20468j;

    /* renamed from: k */
    public y29 f20469k;

    /* renamed from: l */
    public y29 f20470l;

    /* renamed from: m */
    public boolean f20471m;

    /* renamed from: n */
    public int f20472n;

    public /* synthetic */ jn6(kn6 kn6Var) {
        this.f20459a = kn6Var.f22077a;
        this.f20460b = kn6Var.f22078b;
        this.f20461c = kn6Var.f22079c;
        this.f20462d = kn6Var.f22080d;
        this.f20463e = kn6Var.f22081e;
        this.f20464f = kn6Var.f22082f;
        this.f20465g = kn6Var.f22083g;
        this.f20466h = kn6Var.f22084h;
        this.f20467i = kn6Var.f22090n;
        this.f20468j = kn6Var.f22087k;
        this.f20469k = kn6Var.f22085i;
        this.f20470l = kn6Var.f22086j;
        this.f20471m = kn6Var.f22089m;
        this.f20472n = kn6Var.f22088l;
    }
}
