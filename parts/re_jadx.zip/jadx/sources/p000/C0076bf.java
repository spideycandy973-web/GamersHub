package p000;

import android.graphics.DashPathEffect;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: bf */
/* loaded from: classes2.dex */
public final class C0076bf {

    /* renamed from: a */
    public final DashPathEffect f2354a;

    public C0076bf(DashPathEffect dashPathEffect) {
        this.f2354a = dashPathEffect;
    }
}
