package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class k9a extends h5a {
    private static final k9a zzb;
    private String zzd = "";
    private long zze;
    private int zzf;

    static {
        k9a k9aVar = new k9a();
        zzb = k9aVar;
        h5a.m12550k(k9a.class, k9aVar);
    }

    @Override // p000.h5a
    /* renamed from: f */
    public final Object mo141f(int i) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return new n7a(zzb, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002\u0002\u0003\u0004", new Object[]{"zzd", "zze", "zzf"});
        }
        if (i2 == 3) {
            return new k9a();
        }
        if (i2 == 4) {
            return new l2a(zzb);
        }
        if (i2 == 5) {
            return zzb;
        }
        throw null;
    }
}
