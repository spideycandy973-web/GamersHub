package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class ka3 implements na3 {

    /* renamed from: a */
    public static final /* synthetic */ ka3 f21426a = new ka3();

    @Override // p000.na3
    /* renamed from: a */
    public final boolean mo14493a(zy1 zy1Var) {
        return true;
    }

    public final String toString() {
        return "Modifier";
    }

    @Override // p000.na3
    /* renamed from: d */
    public final na3 mo14495d(na3 na3Var) {
        return na3Var;
    }

    @Override // p000.na3
    /* renamed from: b */
    public final Object mo14494b(Object obj, nz1 nz1Var) {
        return obj;
    }
}
