package p000;

import android.media.AudioTrack;
import android.os.Build;
import android.os.SystemClock;
import java.lang.reflect.Method;
import java.math.RoundingMode;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class n9a {

    /* renamed from: a */
    public final e78 f27211a;

    /* renamed from: b */
    public final oua f27212b;

    /* renamed from: c */
    public final long[] f27213c;

    /* renamed from: d */
    public final AudioTrack f27214d;

    /* renamed from: e */
    public final int f27215e;

    /* renamed from: f */
    public final long f27216f;

    /* renamed from: g */
    public final boolean f27217g;

    /* renamed from: h */
    public final h8a f27218h;

    /* renamed from: i */
    public final float f27219i;

    /* renamed from: j */
    public long f27220j;

    /* renamed from: k */
    public long f27221k;

    /* renamed from: l */
    public long f27222l;

    /* renamed from: m */
    public Method f27223m;

    /* renamed from: n */
    public long f27224n;

    /* renamed from: o */
    public long f27225o;

    /* renamed from: p */
    public long f27226p;

    /* renamed from: q */
    public long f27227q;

    /* renamed from: r */
    public long f27228r;

    /* renamed from: s */
    public int f27229s;

    /* renamed from: t */
    public int f27230t;

    /* renamed from: u */
    public long f27231u;

    /* renamed from: v */
    public long f27232v;

    /* renamed from: w */
    public long f27233w;

    /* renamed from: x */
    public long f27234x;

    /* renamed from: y */
    public long f27235y;

    /* renamed from: z */
    public long f27236z;

    public n9a(e78 e78Var, oua ouaVar, AudioTrack audioTrack, int i, int i2, int i3) {
        this.f27211a = e78Var;
        this.f27212b = ouaVar;
        this.f27214d = audioTrack;
        try {
            this.f27223m = AudioTrack.class.getMethod("getLatency", null);
        } catch (NoSuchMethodException unused) {
        }
        this.f27213c = new long[10];
        this.f27236z = -9223372036854775807L;
        this.f27235y = -9223372036854775807L;
        this.f27218h = new h8a(audioTrack, e78Var);
        int sampleRate = audioTrack.getSampleRate();
        this.f27215e = sampleRate;
        boolean m15313d = li8.m15313d(i);
        this.f27217g = m15313d;
        this.f27216f = m15313d ? li8.m15330u(sampleRate, i3 / i2) : -9223372036854775807L;
        this.f27227q = 0L;
        this.f27228r = 0L;
        this.f27231u = -9223372036854775807L;
        this.f27232v = -9223372036854775807L;
        this.f27225o = 0L;
        this.f27224n = 0L;
        this.f27219i = 1.0f;
        this.f27220j = -9223372036854775807L;
    }

    /* renamed from: a */
    public final void m16551a(long j) {
        long j2 = this.f27220j;
        if (j2 == -9223372036854775807L || j < j2) {
            return;
        }
        long j3 = j - j2;
        String str = li8.f24265a;
        float f = this.f27219i;
        if (f != 1.0f) {
            j3 = Math.round(j3 / f);
        }
        long m15328s = li8.m15328s(j3);
        this.f27212b.getClass();
        long currentTimeMillis = System.currentTimeMillis() - m15328s;
        this.f27220j = -9223372036854775807L;
        l68 l68Var = ((j9a) this.f27211a.f11412b).f19889i;
        l68Var.getClass();
        if (Thread.currentThread() == l68Var.f23823a) {
            qg6 qg6Var = new qg6();
            qg6Var.f31890a = currentTimeMillis;
            l68Var.m15129c(-1, qg6Var);
            l68Var.m15130d();
        }
    }

    /* renamed from: b */
    public final long m16552b(long j) {
        int i = this.f27230t;
        int i2 = this.f27215e;
        long max = Math.max(0L, (i == 0 ? this.f27231u != -9223372036854775807L ? li8.m15330u(i2, m16554d()) : li8.m15330u(i2, m16553c()) : li8.m15333x(this.f27219i, j + this.f27221k)) - this.f27224n);
        return this.f27231u != -9223372036854775807L ? Math.min(li8.m15330u(i2, this.f27234x), max) : max;
    }

    /* renamed from: c */
    public final long m16553c() {
        if (this.f27231u != -9223372036854775807L) {
            return Math.min(this.f27234x, m16554d());
        }
        this.f27212b.getClass();
        long elapsedRealtime = SystemClock.elapsedRealtime();
        if (elapsedRealtime - this.f27226p >= 5) {
            int playState = this.f27214d.getPlayState();
            if (playState != 1) {
                long playbackHeadPosition = r4.getPlaybackHeadPosition() & 4294967295L;
                if (Build.VERSION.SDK_INT <= 29) {
                    if (playbackHeadPosition != 0 || this.f27227q <= 0 || playState != 3) {
                        this.f27232v = -9223372036854775807L;
                    } else if (this.f27232v == -9223372036854775807L) {
                        this.f27232v = elapsedRealtime;
                    }
                }
                if (this.f27227q > playbackHeadPosition) {
                    this.f27228r++;
                }
                this.f27227q = playbackHeadPosition;
            }
            this.f27226p = elapsedRealtime;
        }
        return this.f27227q + (this.f27228r << 32);
    }

    /* renamed from: d */
    public final long m16554d() {
        if (this.f27214d.getPlayState() == 2) {
            return this.f27233w;
        }
        this.f27212b.getClass();
        return this.f27233w + li8.m15331v(li8.m15333x(this.f27219i, li8.m15329t(SystemClock.elapsedRealtime()) - this.f27231u), this.f27215e, 1000000L, RoundingMode.UP);
    }
}
