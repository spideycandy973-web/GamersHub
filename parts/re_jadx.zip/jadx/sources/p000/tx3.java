package p000;

import android.view.MotionEvent;
import java.util.List;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class tx3 {

    /* renamed from: a */
    public final List f37757a;

    /* renamed from: b */
    public final oh2 f37758b;

    /* renamed from: c */
    public final int f37759c;

    /* renamed from: d */
    public final int f37760d;

    /* renamed from: e */
    public final int f37761e;

    /* renamed from: f */
    public byte f37762f;

    /* JADX WARN: Code restructure failed: missing block: B:36:0x007f, code lost:
    
        if (r12 != false) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0090, code lost:
    
        r1 = 8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x0086, code lost:
    
        if (r12 != false) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x008e, code lost:
    
        if (r12 != false) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0098, code lost:
    
        if (r12 == false) goto L57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x00a2, code lost:
    
        if (r12 == false) goto L62;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x009c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public tx3(java.util.List r12, p000.oh2 r13) {
        /*
            Method dump skipped, instructions count: 218
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.tx3.<init>(java.util.List, oh2):void");
    }

    /* renamed from: a */
    public final MotionEvent m20489a() {
        oh2 oh2Var = this.f37758b;
        if (oh2Var != null) {
            return (MotionEvent) ((cf2) oh2Var.f28860c).f4056c;
        }
        return null;
    }
}
