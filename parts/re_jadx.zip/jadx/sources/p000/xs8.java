package p000;

import android.view.MotionEvent;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class xs8 {

    /* renamed from: a */
    public long f44321a;

    /* renamed from: b */
    public long f44322b;

    /* renamed from: c */
    public long f44323c;

    /* renamed from: d */
    public long f44324d;

    /* renamed from: e */
    public double f44325e;

    /* renamed from: f */
    public double f44326f;

    /* renamed from: g */
    public double f44327g;

    /* renamed from: h */
    public float f44328h;

    /* renamed from: i */
    public float f44329i;

    /* renamed from: j */
    public float f44330j;

    /* renamed from: k */
    public float f44331k;

    /* renamed from: a */
    public final void m22909a(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 0) {
            this.f44321a++;
            this.f44327g = 0.0d;
            this.f44325e = motionEvent.getRawX();
            this.f44326f = motionEvent.getRawY();
            this.f44328h = motionEvent.getX();
            this.f44329i = motionEvent.getY();
            this.f44330j = motionEvent.getRawX();
            this.f44331k = motionEvent.getRawY();
            return;
        }
        if (action == 1) {
            this.f44323c++;
            this.f44327g = Math.hypot(motionEvent.getRawX() - this.f44325e, motionEvent.getRawY() - this.f44326f) + this.f44327g;
            this.f44325e = motionEvent.getRawX();
            this.f44326f = motionEvent.getRawY();
            return;
        }
        if (action != 2) {
            if (action != 3) {
                return;
            }
            this.f44324d++;
            return;
        }
        this.f44322b += motionEvent.getHistorySize() + 1;
        this.f44327g = Math.hypot(motionEvent.getRawX() - this.f44325e, motionEvent.getRawY() - this.f44326f) + this.f44327g;
        this.f44325e = motionEvent.getRawX();
        this.f44326f = motionEvent.getRawY();
    }
}
