package p000;

import java.util.concurrent.locks.ReentrantLock;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class al3 {

    /* renamed from: b */
    public final long[] f816b;

    /* renamed from: c */
    public final boolean[] f817c;

    /* renamed from: d */
    public volatile boolean f818d;

    /* renamed from: f */
    public volatile boolean f820f;

    /* renamed from: a */
    public final ReentrantLock f815a = new ReentrantLock();

    /* renamed from: e */
    public final ReentrantLock f819e = new ReentrantLock();

    public al3(int i) {
        this.f816b = new long[i];
        this.f817c = new boolean[i];
    }
}
