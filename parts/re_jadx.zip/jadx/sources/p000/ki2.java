package p000;

import java.util.Map;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class ki2 implements q63, wh2 {

    /* renamed from: a */
    public final /* synthetic */ wh2 f21912a;

    /* renamed from: b */
    public final fo2 f21913b;

    public ki2(wh2 wh2Var, fo2 fo2Var) {
        this.f21912a = wh2Var;
        this.f21913b = fo2Var;
    }

    @Override // p000.t61
    /* renamed from: H */
    public final long mo41H(float f) {
        return this.f21912a.mo41H(f);
    }

    @Override // p000.t61
    /* renamed from: M */
    public final float mo42M(int i) {
        return this.f21912a.mo42M(i);
    }

    @Override // p000.t61
    /* renamed from: P */
    public final float mo43P(float f) {
        return this.f21912a.mo43P(f);
    }

    @Override // p000.wh2
    /* renamed from: Y */
    public final boolean mo1906Y() {
        return this.f21912a.mo1906Y();
    }

    @Override // p000.t61
    /* renamed from: a */
    public final float mo44a() {
        return this.f21912a.mo44a();
    }

    @Override // p000.t61
    /* renamed from: c0 */
    public final float mo47c0(float f) {
        return this.f21912a.mo47c0(f);
    }

    @Override // p000.t61
    public final float getFontScale() {
        return this.f21912a.getFontScale();
    }

    @Override // p000.wh2
    public final fo2 getLayoutDirection() {
        return this.f21913b;
    }

    @Override // p000.t61
    /* renamed from: i0 */
    public final int mo50i0(long j) {
        return this.f21912a.mo50i0(j);
    }

    @Override // p000.q63
    /* renamed from: m0 */
    public final p63 mo1907m0(int i, int i2, Map map, zy1 zy1Var, zy1 zy1Var2) {
        if (i < 0) {
            i = 0;
        }
        if (i2 < 0) {
            i2 = 0;
        }
        if ((i & (-16777216)) != 0 || ((-16777216) & i2) != 0) {
            de2.m9011b("Size(" + i + " x " + i2 + ") is out of range. Each dimension must be between 0 and 16777215.");
        }
        return new ji2(i, i2, map, zy1Var);
    }

    @Override // p000.t61
    /* renamed from: o0 */
    public final int mo51o0(float f) {
        return this.f21912a.mo51o0(f);
    }

    @Override // p000.t61
    /* renamed from: q */
    public final long mo52q(float f) {
        return this.f21912a.mo52q(f);
    }

    @Override // p000.t61
    /* renamed from: r */
    public final long mo53r(long j) {
        return this.f21912a.mo53r(j);
    }

    @Override // p000.t61
    /* renamed from: u0 */
    public final long mo54u0(long j) {
        return this.f21912a.mo54u0(j);
    }

    @Override // p000.t61
    /* renamed from: w */
    public final float mo55w(long j) {
        return this.f21912a.mo55w(j);
    }

    @Override // p000.t61
    /* renamed from: z0 */
    public final float mo56z0(long j) {
        return this.f21912a.mo56z0(j);
    }
}
