package p000;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class lr0 {

    /* renamed from: a */
    public static final lr0 f24672a;

    /* renamed from: b */
    public static final lr0 f24673b;

    /* renamed from: c */
    public static final /* synthetic */ lr0[] f24674c;

    static {
        lr0 lr0Var = new lr0("VIEW_APPEAR", 0);
        f24672a = lr0Var;
        lr0 lr0Var2 = new lr0("VIEW_DISAPPEAR", 1);
        f24673b = lr0Var2;
        f24674c = new lr0[]{lr0Var, lr0Var2};
    }

    public static lr0 valueOf(String str) {
        return (lr0) Enum.valueOf(lr0.class, str);
    }

    public static lr0[] values() {
        return (lr0[]) f24674c.clone();
    }
}
