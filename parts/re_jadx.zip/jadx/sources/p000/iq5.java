package p000;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import p000.C0941er;
import p000.C1720wq;
import p000.jq5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public abstract class iq5 {
    private iq5() {
    }

    /* renamed from: a */
    private static C1720wq.f.a m13572a(jq5.C1200b c1200b, byte[] bArr) throws NoSuchAlgorithmException {
        byte[] encoded;
        C1720wq.f.a aVar = new C1720wq.f.a();
        aVar.f37481a = 0;
        int i = c1200b.f20582e;
        byte[] bArr2 = c1200b.f20583f;
        aVar.f42702j.add(new C1720wq.f.a.c(i, bArr2));
        cx4 m8534b = cx4.m8534b(i);
        if (m8534b == null) {
            aVar.m22335j(C0941er.e.V4_SIG_UNKNOWN_SIG_ALGORITHM, Integer.valueOf(i));
            return aVar;
        }
        String m10445a = m8534b.m8539g().m10445a();
        AlgorithmParameterSpec m10446b = m8534b.m8539g().m10446b();
        String m8537e = m8534b.m8537e();
        byte[] bArr3 = c1200b.f20581d;
        try {
            PublicKey generatePublic = KeyFactory.getInstance(m8537e).generatePublic(new X509EncodedKeySpec(bArr3));
            try {
                Signature signature = Signature.getInstance(m10445a);
                signature.initVerify(generatePublic);
                if (m10446b != null) {
                    signature.setParameter(m10446b);
                }
                signature.update(bArr);
                if (!signature.verify(bArr2)) {
                    aVar.m22335j(C0941er.e.V4_SIG_DID_NOT_VERIFY, m8534b);
                    return aVar;
                }
                aVar.f42703k.put(m8534b, bArr2);
                if (c1200b.f20579b == null) {
                    aVar.m22335j(C0941er.e.V4_SIG_NO_CERTIFICATE, new Object[0]);
                    return aVar;
                }
                try {
                    c52 c52Var = new c52(w06.m21853d(c1200b.f20579b), c1200b.f20579b);
                    aVar.f37483c.add(c52Var);
                    try {
                        encoded = C1720wq.m22314s(c52Var.getPublicKey());
                    } catch (InvalidKeyException e) {
                        System.out.println("Caught an exception encoding the public key: " + e);
                        e.printStackTrace();
                        encoded = c52Var.getPublicKey().getEncoded();
                    }
                    if (!Arrays.equals(bArr3, encoded)) {
                        aVar.m22335j(C0941er.e.V4_SIG_PUBLIC_KEY_MISMATCH_BETWEEN_CERTIFICATE_AND_SIGNATURES_RECORD, C1720wq.m22294J(encoded), C1720wq.m22294J(bArr3));
                        return aVar;
                    }
                    aVar.f42700h.add(new C1720wq.f.a.b(0, c1200b.f20578a));
                    return aVar;
                } catch (CertificateException e2) {
                    aVar.m22335j(C0941er.e.V4_SIG_MALFORMED_CERTIFICATE, e2);
                    return aVar;
                }
            } catch (InvalidAlgorithmParameterException | InvalidKeyException | SignatureException e3) {
                aVar.m22335j(C0941er.e.V4_SIG_VERIFY_EXCEPTION, m8534b, e3);
                return aVar;
            }
        } catch (Exception e4) {
            aVar.m22335j(C0941er.e.V4_SIG_MALFORMED_PUBLIC_KEY, e4);
            return aVar;
        }
    }

    /* renamed from: b */
    public static C1720wq.f m13573b(u11 u11Var, File file) throws IOException, NoSuchAlgorithmException {
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            jq5 m14188e = jq5.m14188e(fileInputStream);
            byte[] m14186c = jq5.m14186c(fileInputStream);
            fileInputStream.close();
            C1720wq.f fVar = new C1720wq.f(4);
            if (m14188e == null) {
                fVar.m22333g(C0941er.e.V4_SIG_NO_SIGNATURES, "Signature file does not contain a v4 signature.");
                return fVar;
            }
            int i = m14188e.f20571a;
            if (i != 2) {
                fVar.m22334h(C0941er.e.V4_SIG_VERSION_NOT_CURRENT, Integer.valueOf(i), 2);
            }
            jq5.C1199a m14195a = jq5.C1199a.m14195a(m14188e.f20572b);
            jq5.C1202d m14202a = jq5.C1202d.m14202a(m14188e.f20573c);
            jq5.C1200b c1200b = m14202a.f20586a;
            C1720wq.f.a m13572a = m13572a(c1200b, jq5.m14185b(u11Var.size(), m14195a, c1200b));
            fVar.f42697g.add(m13572a);
            if (!fVar.mo17852c()) {
                jq5.C1201c[] c1201cArr = m14202a.f20587b;
                int length = c1201cArr.length;
                int i2 = 0;
                while (true) {
                    if (i2 < length) {
                        jq5.C1200b m14197a = jq5.C1200b.m14197a(c1201cArr[i2].f20585b);
                        fVar.f42697g.add(m13572a(m14197a, jq5.m14185b(u11Var.size(), m14195a, m14197a)));
                        if (fVar.mo17852c()) {
                            break;
                        }
                        i2++;
                    } else {
                        m13574c(u11Var, m13572a, m14195a.f20577d, m14186c);
                        if (!fVar.mo17852c()) {
                            fVar.f30815b = true;
                        }
                    }
                }
            }
            return fVar;
        } catch (Throwable th) {
            try {
                fileInputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    /* renamed from: c */
    private static void m13574c(u11 u11Var, C1720wq.f.a aVar, byte[] bArr, byte[] bArr2) throws IOException, NoSuchAlgorithmException {
        C1720wq.k m22302g = C1720wq.m22302g(u11Var);
        or0 or0Var = m22302g.f42728a;
        byte[] bArr3 = m22302g.f42729b;
        byte[] bArr4 = m22302g.f42730c;
        if (!Arrays.equals(bArr, bArr3)) {
            aVar.m22335j(C0941er.e.V4_SIG_APK_ROOT_DID_NOT_VERIFY, or0Var, C1720wq.m22294J(bArr), C1720wq.m22294J(bArr3));
        } else if (bArr2 == null || Arrays.equals(bArr2, bArr4)) {
            aVar.f42701i.put(or0Var, bArr3);
        } else {
            aVar.m22335j(C0941er.e.V4_SIG_APK_TREE_DID_NOT_VERIFY, or0Var, C1720wq.m22294J(bArr), C1720wq.m22294J(bArr3));
        }
    }
}
