package p000;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class dy1 extends yl3 {

    /* renamed from: d */
    public final /* synthetic */ byte f10994d;

    /* renamed from: e */
    public final /* synthetic */ Object f10995e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public dy1(zy1 zy1Var) {
        super(true);
        this.f10994d = (byte) 2;
        this.f10995e = zy1Var;
    }

    @Override // p000.yl3
    /* renamed from: b */
    public final void mo2070b() {
        byte b = this.f10994d;
        Object obj = this.f10995e;
        switch (b) {
            case 0:
                ((ha6) obj).m12636k();
                throw null;
            case 1:
                ((ih3) obj).m13361a();
                return;
            default:
                ((zy1) obj).invoke(this);
                return;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ dy1(Object obj, byte b) {
        super(false);
        this.f10994d = b;
        this.f10995e = obj;
    }
}
