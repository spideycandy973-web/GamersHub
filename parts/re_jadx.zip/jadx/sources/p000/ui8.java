package p000;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class ui8 {

    /* renamed from: a */
    public final Pattern f38724a;

    public ui8() {
        Pattern pattern;
        try {
            pattern = Pattern.compile((String) by6.f3171e.f3174c.m14470a(l57.f23236U7));
        } catch (PatternSyntaxException unused) {
            pattern = null;
        }
        this.f38724a = pattern;
    }
}
