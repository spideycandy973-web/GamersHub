package p000;

import java.util.regex.Pattern;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class dp6 {

    /* renamed from: d */
    public static final Pattern f10707d = Pattern.compile("\\s+");

    /* renamed from: e */
    public static final n09 f10708e = n09.m16381p(2, "auto", "none");

    /* renamed from: f */
    public static final n09 f10709f = n09.m16381p(3, "dot", "sesame", "circle");

    /* renamed from: g */
    public static final n09 f10710g = n09.m16381p(2, "filled", "open");

    /* renamed from: h */
    public static final n09 f10711h = n09.m16381p(3, "after", "before", "outside");

    /* renamed from: a */
    public final int f10712a;

    /* renamed from: b */
    public final byte f10713b;

    /* renamed from: c */
    public final int f10714c;

    /* JADX WARN: Multi-variable type inference failed */
    public dp6(int i, int i2, int i3) {
        this.f10712a = i;
        this.f10713b = i2;
        this.f10714c = i3;
    }
}
