package p000;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public abstract class tp5 {

    /* renamed from: a */
    public static final String f37447a = "META-INF/MANIFEST.MF";

    /* renamed from: c */
    private static final String f37449c = "1.0";

    /* renamed from: d */
    private static final String f37450d = "1.0";

    /* renamed from: b */
    private static final Attributes.Name f37448b = new Attributes.Name("Created-By");

    /* renamed from: e */
    private static final Attributes.Name f37451e = new Attributes.Name(sp5.f35761b);

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    /* renamed from: tp5$a */
    static /* synthetic */ class C1590a {

        /* renamed from: a */
        static final /* synthetic */ int[] f37452a;

        static {
            int[] iArr = new int[j91.values().length];
            f37452a = iArr;
            try {
                iArr[j91.SHA1.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f37452a[j91.SHA256.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    /* renamed from: tp5$b */
    public static class C1591b {

        /* renamed from: a */
        public byte[] f37453a;

        /* renamed from: b */
        public SortedMap<String, byte[]> f37454b;

        /* renamed from: c */
        public Attributes f37455c;
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    /* renamed from: tp5$c */
    public static class C1592c {

        /* renamed from: a */
        public String f37456a;

        /* renamed from: b */
        public PrivateKey f37457b;

        /* renamed from: c */
        public sm2 f37458c;

        /* renamed from: d */
        public List<X509Certificate> f37459d;

        /* renamed from: e */
        public j91 f37460e;

        /* renamed from: f */
        public boolean f37461f;
    }

    private tp5() {
    }

    /* renamed from: a */
    private static void m20403a(String str) throws C1398oq {
        for (char c : str.toCharArray()) {
            if (c == '\r' || c == '\n' || c == 0) {
                throw new C1398oq(String.format("Unsupported character 0x%1$02x in ZIP entry name \"%2$s\"", Integer.valueOf(c), str));
            }
        }
    }

    /* renamed from: b */
    public static C1591b m20404b(j91 j91Var, Map<String, byte[]> map, byte[] bArr) throws C1398oq {
        Manifest manifest;
        if (bArr != null) {
            try {
                manifest = new Manifest(new ByteArrayInputStream(bArr));
            } catch (IOException e) {
                throw new C1398oq("Malformed source META-INF/MANIFEST.MF", e);
            }
        } else {
            manifest = null;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Attributes attributes = new Attributes();
        if (manifest != null) {
            attributes.putAll(manifest.getMainAttributes());
        } else {
            attributes.put(Attributes.Name.MANIFEST_VERSION, "1.0");
        }
        try {
            g13.m11767g(byteArrayOutputStream, attributes);
            ArrayList arrayList = new ArrayList(map.keySet());
            Collections.sort(arrayList);
            TreeMap treeMap = new TreeMap();
            String m20407e = m20407e(j91Var);
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                Object obj = arrayList.get(i);
                i++;
                String str = (String) obj;
                m20403a(str);
                byte[] bArr2 = map.get(str);
                Attributes attributes2 = new Attributes();
                attributes2.putValue(m20407e, Base64.getEncoder().encodeToString(bArr2));
                ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
                try {
                    g13.m11765e(byteArrayOutputStream2, str, attributes2);
                    byte[] byteArray = byteArrayOutputStream2.toByteArray();
                    byteArrayOutputStream.write(byteArray);
                    treeMap.put(str, byteArray);
                } catch (IOException e2) {
                    ip5.m13548h("Failed to write in-memory MANIFEST.MF", e2);
                    return null;
                }
            }
            C1591b c1591b = new C1591b();
            c1591b.f37453a = byteArrayOutputStream.toByteArray();
            c1591b.f37455c = attributes;
            c1591b.f37454b = treeMap;
            return c1591b;
        } catch (IOException e3) {
            ip5.m13548h("Failed to write in-memory MANIFEST.MF", e3);
            return null;
        }
    }

    /* renamed from: c */
    private static byte[] m20405c(C1592c c1592c, byte[] bArr) throws NoSuchAlgorithmException, InvalidKeyException, CertificateException, SignatureException {
        List<X509Certificate> list = c1592c.f37459d;
        PublicKey publicKey = list.get(0).getPublicKey();
        j91 j91Var = c1592c.f37460e;
        es3<String, C1000g9> m11951d = C1000g9.m11951d(publicKey, j91Var, c1592c.f37461f);
        String m10445a = m11951d.m10445a();
        try {
            byte[] mo13669a = kx4.m14961c(c1592c.f37458c, m10445a, null).mo13669a(bArr);
            try {
                Signature signature = Signature.getInstance(m10445a);
                signature.initVerify(publicKey);
                signature.update(bArr);
                if (!signature.verify(mo13669a)) {
                    throw new SignatureException("Signature did not verify");
                }
                try {
                    return C1720wq.m22319x(mo13669a, null, list, C1000g9.m11950c(j91Var), m11951d.m10446b());
                } catch (CertificateEncodingException | C1363nw unused) {
                    throw new SignatureException("Failed to encode signature block");
                }
            } catch (InvalidKeyException e) {
                throw new InvalidKeyException(hn0.m12936i("Failed to verify generated ", m10445a, " signature using public key from certificate"), e);
            } catch (SignatureException e2) {
                throw new SignatureException(hn0.m12936i("Failed to verify generated ", m10445a, " signature using public key from certificate"), e2);
            }
        } catch (InvalidAlgorithmParameterException e3) {
            e = e3;
            throw new SignatureException(d63.m8810q("Failed to sign using ", m10445a), e);
        } catch (InvalidKeyException e4) {
            throw new InvalidKeyException(d63.m8810q("Failed to sign using ", m10445a), e4);
        } catch (SignatureException e5) {
            e = e5;
            throw new SignatureException(d63.m8810q("Failed to sign using ", m10445a), e);
        }
    }

    /* renamed from: d */
    private static byte[] m20406d(List<Integer> list, j91 j91Var, String str, C1591b c1591b) throws NoSuchAlgorithmException {
        Attributes mainAttributes = new Manifest().getMainAttributes();
        mainAttributes.put(Attributes.Name.SIGNATURE_VERSION, "1.0");
        mainAttributes.put(f37448b, str);
        if (!list.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            Iterator<Integer> it = list.iterator();
            while (it.hasNext()) {
                int intValue = it.next().intValue();
                if (sb.length() > 0) {
                    sb.append(", ");
                }
                sb.append(String.valueOf(intValue));
            }
            mainAttributes.put(f37451e, sb.toString());
        }
        MessageDigest m20410h = m20410h(j91Var);
        mainAttributes.putValue(m20409g(j91Var), Base64.getEncoder().encodeToString(m20410h.digest(c1591b.f37453a)));
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            dx4.m9556b(byteArrayOutputStream, mainAttributes);
            String m20407e = m20407e(j91Var);
            for (Map.Entry<String, byte[]> entry : c1591b.f37454b.entrySet()) {
                String key = entry.getKey();
                byte[] digest = m20410h.digest(entry.getValue());
                Attributes attributes = new Attributes();
                attributes.putValue(m20407e, Base64.getEncoder().encodeToString(digest));
                try {
                    dx4.m9555a(byteArrayOutputStream, key, attributes);
                } catch (IOException e) {
                    ip5.m13548h("Failed to write in-memory .SF file", e);
                    return null;
                }
            }
            if (byteArrayOutputStream.size() > 0 && byteArrayOutputStream.size() % 1024 == 0) {
                try {
                    dx4.m9557c(byteArrayOutputStream);
                } catch (IOException e2) {
                    ip5.m13548h("Failed to write to ByteArrayOutputStream", e2);
                    return null;
                }
            }
            return byteArrayOutputStream.toByteArray();
        } catch (IOException e3) {
            ip5.m13548h("Failed to write in-memory .SF file", e3);
            return null;
        }
    }

    /* renamed from: e */
    private static String m20407e(j91 j91Var) {
        int i = C1590a.f37452a[j91Var.ordinal()];
        if (i == 1) {
            return "SHA1-Digest";
        }
        if (i == 2) {
            return "SHA-256-Digest";
        }
        C0950f.m10587r(j91Var, "Unexpected content digest algorithm: ");
        return null;
    }

    /* renamed from: f */
    public static String m20408f(j91 j91Var) {
        return j91Var.m13836b();
    }

    /* renamed from: g */
    private static String m20409g(j91 j91Var) {
        int i = C1590a.f37452a[j91Var.ordinal()];
        if (i == 1) {
            return "SHA1-Digest-Manifest";
        }
        if (i == 2) {
            return "SHA-256-Digest-Manifest";
        }
        C0950f.m10587r(j91Var, "Unexpected content digest algorithm: ");
        return null;
    }

    /* renamed from: h */
    private static MessageDigest m20410h(j91 j91Var) throws NoSuchAlgorithmException {
        return MessageDigest.getInstance(j91Var.m13836b());
    }

    /* renamed from: i */
    public static Set<String> m20411i(List<C1592c> list) {
        HashSet hashSet = new HashSet((list.size() << 1) + 1);
        for (C1592c c1592c : list) {
            String str = c1592c.f37456a;
            hashSet.add("META-INF/" + str + ".SF");
            PublicKey publicKey = c1592c.f37459d.get(0).getPublicKey();
            StringBuilder m23623p = yt0.m23623p("META-INF/", str, ".");
            m23623p.append(publicKey.getAlgorithm().toUpperCase(Locale.US));
            hashSet.add(m23623p.toString());
        }
        hashSet.add("META-INF/MANIFEST.MF");
        return hashSet;
    }

    /* renamed from: j */
    public static String m20412j(String str) {
        if (str.isEmpty()) {
            C0950f.m10578i("Empty name");
            return null;
        }
        StringBuilder sb = new StringBuilder();
        char[] charArray = str.toUpperCase(Locale.US).toCharArray();
        for (int i = 0; i < Math.min(charArray.length, 8); i++) {
            char c = charArray[i];
            if ((c < 'A' || c > 'Z') && !((c >= '0' && c <= '9') || c == '-' || c == '_')) {
                sb.append('_');
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /* renamed from: k */
    public static j91 m20413k(PublicKey publicKey, int i) throws InvalidKeyException {
        String algorithm = publicKey.getAlgorithm();
        if ("RSA".equalsIgnoreCase(algorithm) || "1.2.840.113549.1.1.1".equals(algorithm)) {
            return i < 18 ? j91.SHA1 : j91.SHA256;
        }
        if ("DSA".equalsIgnoreCase(algorithm)) {
            return i < 21 ? j91.SHA1 : j91.SHA256;
        }
        if (!"EC".equalsIgnoreCase(algorithm)) {
            throw new InvalidKeyException(d63.m8810q("Unsupported key algorithm: ", algorithm));
        }
        if (i >= 18) {
            return j91.SHA256;
        }
        throw new InvalidKeyException("ECDSA signatures only supported for minSdkVersion 18 and higher");
    }

    /* renamed from: l */
    public static boolean m20414l(String str) {
        if (str.endsWith("/")) {
            return false;
        }
        if (!str.startsWith("META-INF/") || str.indexOf(47, 9) != -1) {
            return true;
        }
        String lowerCase = str.substring(9).toLowerCase(Locale.US);
        return ("manifest.mf".equals(lowerCase) || lowerCase.endsWith(".sf") || lowerCase.endsWith(".rsa") || lowerCase.endsWith(".dsa") || lowerCase.endsWith(".ec") || lowerCase.startsWith("sig-")) ? false : true;
    }

    /* renamed from: m */
    public static List<es3<String, byte[]>> m20415m(List<C1592c> list, j91 j91Var, Map<String, byte[]> map, List<Integer> list2, byte[] bArr, String str) throws NoSuchAlgorithmException, C1398oq, InvalidKeyException, CertificateException, SignatureException {
        if (list.isEmpty()) {
            C0950f.m10578i("At least one signer config must be provided");
            return null;
        }
        if (list.size() <= 10) {
            return m20416n(list, j91Var, list2, str, m20404b(j91Var, map, bArr));
        }
        throw new IllegalArgumentException("APK Signature Scheme v1 only supports a maximum of 10, " + list.size() + " provided");
    }

    /* renamed from: n */
    public static List<es3<String, byte[]>> m20416n(List<C1592c> list, j91 j91Var, List<Integer> list2, String str, C1591b c1591b) throws NoSuchAlgorithmException, InvalidKeyException, CertificateException, SignatureException {
        if (list.isEmpty()) {
            C0950f.m10578i("At least one signer config must be provided");
            return null;
        }
        ArrayList arrayList = new ArrayList((list.size() << 1) + 1);
        byte[] m20406d = m20406d(list2, j91Var, str, c1591b);
        for (C1592c c1592c : list) {
            String str2 = c1592c.f37456a;
            try {
                byte[] m20405c = m20405c(c1592c, m20406d);
                arrayList.add(es3.m10444c("META-INF/" + str2 + ".SF", m20406d));
                PublicKey publicKey = c1592c.f37459d.get(0).getPublicKey();
                StringBuilder m23623p = yt0.m23623p("META-INF/", str2, ".");
                m23623p.append(publicKey.getAlgorithm().toUpperCase(Locale.US));
                arrayList.add(es3.m10444c(m23623p.toString(), m20405c));
            } catch (InvalidKeyException e) {
                throw new InvalidKeyException(hn0.m12936i("Failed to sign using signer \"", str2, "\""), e);
            } catch (SignatureException e2) {
                throw new SignatureException(hn0.m12936i("Failed to sign using signer \"", str2, "\""), e2);
            } catch (CertificateException e3) {
                throw new CertificateException(hn0.m12936i("Failed to sign using signer \"", str2, "\""), e3);
            }
        }
        arrayList.add(es3.m10444c("META-INF/MANIFEST.MF", c1591b.f37453a));
        return arrayList;
    }
}
