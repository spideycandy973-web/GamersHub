package p000;

import java.util.Arrays;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: fv */
/* loaded from: classes.dex */
public final class C0984fv {

    /* renamed from: a */
    public final float f14601a;

    /* renamed from: b */
    public final float f14602b;

    /* renamed from: c */
    public final float f14603c;

    /* renamed from: d */
    public final float f14604d;

    /* renamed from: e */
    public final float f14605e;

    /* renamed from: f */
    public final float f14606f;

    /* renamed from: g */
    public final float f14607g;

    /* renamed from: h */
    public float f14608h;

    /* renamed from: i */
    public float f14609i;

    /* renamed from: j */
    public final float[] f14610j;

    /* renamed from: k */
    public final float f14611k;

    /* renamed from: l */
    public final float f14612l;

    /* renamed from: m */
    public final float f14613m;

    /* renamed from: n */
    public final float f14614n;

    /* renamed from: o */
    public final float f14615o;

    /* renamed from: p */
    public final boolean f14616p;

    /* renamed from: q */
    public final float f14617q;

    /* renamed from: r */
    public final float f14618r;

    public C0984fv(float f, float f2, float f3, float f4, float f5, float f6, int i) {
        boolean z;
        int i2;
        float f7 = f3;
        this.f14601a = f;
        this.f14602b = f2;
        this.f14603c = f7;
        this.f14604d = f4;
        this.f14605e = f5;
        this.f14606f = f6;
        float f8 = f5 - f7;
        float f9 = f6 - f4;
        int i3 = 1;
        boolean z2 = i == 1 || (i == 4 ? f9 > 0.0f : i == 5 && f9 < 0.0f);
        float f10 = z2 ? -1.0f : 1.0f;
        this.f14613m = f10;
        float f11 = 1.0f / (f2 - f);
        this.f14611k = f11;
        float[] fArr = new float[101];
        this.f14610j = fArr;
        boolean z3 = i == 3;
        if (z3 || Math.abs(f8) < 0.001f || Math.abs(f9) < 0.001f) {
            float hypot = (float) Math.hypot(f9, f8);
            this.f14607g = hypot;
            this.f14612l = hypot * f11;
            this.f14617q = f8 * f11;
            this.f14618r = f9 * f11;
            this.f14614n = Float.NaN;
            this.f14615o = Float.NaN;
            z = true;
        } else {
            this.f14614n = f8 * f10;
            this.f14615o = f9 * (-f10);
            this.f14617q = z2 ? f5 : f7;
            this.f14618r = z2 ? f4 : f6;
            float f12 = f4 - f6;
            float[] fArr2 = fn5.f14011a;
            float f13 = f12;
            int i4 = 1;
            float f14 = 0.0f;
            float f15 = 0.0f;
            while (true) {
                double d = (float) (((i4 * 90.0d) / 90.0d) * 0.017453292519943295d);
                i2 = i3;
                float sin = ((float) Math.sin(d)) * f8;
                float cos = ((float) Math.cos(d)) * f12;
                f14 += (float) Math.hypot(sin - f15, cos - f13);
                fArr2[i4] = f14;
                if (i4 == 90) {
                    break;
                }
                i4++;
                f15 = sin;
                f13 = cos;
                i3 = i2;
            }
            this.f14607g = f14;
            int i5 = i2;
            while (true) {
                fArr2[i5] = fArr2[i5] / f14;
                if (i5 == 90) {
                    break;
                } else {
                    i5++;
                }
            }
            for (int i6 = 0; i6 < 101; i6++) {
                float f16 = i6 / 100.0f;
                int binarySearch = Arrays.binarySearch(fArr2, 0, 91, f16);
                if (binarySearch >= 0) {
                    fArr[i6] = binarySearch / 90.0f;
                } else if (binarySearch == -1) {
                    fArr[i6] = 0.0f;
                } else {
                    int i7 = -binarySearch;
                    int i8 = i7 - 2;
                    float f17 = i8;
                    float f18 = fArr2[i8];
                    fArr[i6] = (((f16 - f18) / (fArr2[i7 - i2] - f18)) + f17) / 90.0f;
                }
            }
            this.f14612l = this.f14607g * this.f14611k;
            z = z3;
        }
        this.f14616p = z;
    }

    /* renamed from: a */
    public final float m11615a() {
        float f = this.f14614n * this.f14609i;
        return f * this.f14613m * (this.f14612l / ((float) Math.hypot(f, (-this.f14615o) * this.f14608h)));
    }

    /* renamed from: b */
    public final float m11616b() {
        float f = this.f14614n * this.f14609i;
        float f2 = (-this.f14615o) * this.f14608h;
        return f2 * this.f14613m * (this.f14612l / ((float) Math.hypot(f, f2)));
    }

    /* renamed from: c */
    public final void m11617c(float f) {
        float f2 = (this.f14613m == -1.0f ? this.f14602b - f : f - this.f14601a) * this.f14611k;
        float f3 = 0.0f;
        if (f2 > 0.0f) {
            f3 = 1.0f;
            if (f2 < 1.0f) {
                float f4 = f2 * 100.0f;
                int i = (int) f4;
                float[] fArr = this.f14610j;
                float f5 = fArr[i];
                f3 = ((fArr[i + 1] - f5) * (f4 - i)) + f5;
            }
        }
        double d = f3 * 1.5707964f;
        this.f14608h = (float) Math.sin(d);
        this.f14609i = (float) Math.cos(d);
    }
}
