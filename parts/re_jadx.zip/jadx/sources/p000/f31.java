package p000;

import p000.C0962fb;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class f31 {

    /* renamed from: a */
    public static final f31 f13243a = new f31();

    /* renamed from: a */
    public final void m10642a(es4 es4Var, s02 s02Var, int i) {
        s02Var.m19312b0(1565826668);
        int i2 = (s02Var.m19319f(es4Var) ? 4 : 2) | i;
        byte b = 1;
        if (s02Var.m19300R(i2 & 1, (i2 & 3) != 2)) {
            y53.m23265a((xy1) es4Var.f12662b, (f91) es4Var.f12664d, mt7.m16166P(1163527043, new C1535sb(es4Var, b), s02Var), s02Var, C0962fb.c.f13595h);
        } else {
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new C1576tc(this, es4Var, i, jq5.f20569f);
        }
    }
}
