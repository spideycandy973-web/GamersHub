package p000;

import android.util.SparseArray;
import android.util.SparseBooleanArray;
import java.util.HashMap;
import java.util.Map;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class f96 extends s57 {

    /* renamed from: A */
    public final boolean f13475A;

    /* renamed from: B */
    public final boolean f13476B;

    /* renamed from: C */
    public final boolean f13477C;

    /* renamed from: D */
    public final SparseArray f13478D;

    /* renamed from: E */
    public final SparseBooleanArray f13479E;

    /* renamed from: w */
    public final boolean f13480w;

    /* renamed from: x */
    public final boolean f13481x;

    /* renamed from: y */
    public final boolean f13482y;

    /* renamed from: z */
    public final boolean f13483z;

    public f96(h96 h96Var) {
        m19432a(h96Var);
        this.f13480w = h96Var.f16950w;
        this.f13481x = h96Var.f16951x;
        this.f13482y = h96Var.f16952y;
        this.f13483z = h96Var.f16953z;
        this.f13475A = h96Var.f16945A;
        this.f13476B = h96Var.f16946B;
        this.f13477C = h96Var.f16947C;
        SparseArray sparseArray = new SparseArray();
        int i = 0;
        while (true) {
            SparseArray sparseArray2 = h96Var.f16948D;
            if (i >= sparseArray2.size()) {
                this.f13478D = sparseArray;
                this.f13479E = h96Var.f16949E.clone();
                return;
            } else {
                sparseArray.put(sparseArray2.keyAt(i), new HashMap((Map) sparseArray2.valueAt(i)));
                i++;
            }
        }
    }

    public f96() {
        this.f13478D = new SparseArray();
        this.f13479E = new SparseBooleanArray();
        this.f13480w = true;
        this.f13481x = true;
        this.f13482y = true;
        this.f13483z = true;
        this.f13475A = true;
        this.f13476B = true;
        this.f13477C = true;
    }
}
