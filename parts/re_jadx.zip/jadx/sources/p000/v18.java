package p000;

import android.content.Context;
import java.util.Map;
import java.util.concurrent.Executor;
import org.json.JSONObject;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class v18 {

    /* renamed from: b */
    public final cf2 f39654b;

    /* renamed from: c */
    public final Context f39655c;

    /* renamed from: d */
    public final e48 f39656d;

    /* renamed from: e */
    public final Executor f39657e;

    /* renamed from: f */
    public final oy6 f39658f;

    /* renamed from: g */
    public final zr5 f39659g;

    /* renamed from: i */
    public final d88 f39661i;

    /* renamed from: j */
    public final rl8 f39662j;

    /* renamed from: k */
    public final j88 f39663k;

    /* renamed from: l */
    public final qi8 f39664l;

    /* renamed from: m */
    public final fu7 f39665m;

    /* renamed from: n */
    public r39 f39666n;

    /* renamed from: a */
    public final r18 f39653a = new r18();

    /* renamed from: h */
    public final u97 f39660h = new u97();

    public v18(u18 u18Var) {
        this.f39655c = u18Var.f38119b;
        this.f39657e = u18Var.f38122e;
        this.f39658f = u18Var.f38123f;
        this.f39659g = u18Var.f38124g;
        this.f39654b = u18Var.f38118a;
        this.f39661i = u18Var.f38121d;
        this.f39662j = u18Var.f38125h;
        this.f39656d = u18Var.f38120c;
        this.f39663k = u18Var.f38126i;
        this.f39664l = u18Var.f38127j;
        this.f39665m = u18Var.f38128k;
    }

    /* renamed from: a */
    public final synchronized cw2 m21177a(String str, JSONObject jSONObject) {
        r39 r39Var = this.f39666n;
        if (r39Var == null) {
            return p49.f29849b;
        }
        return v86.m21326n0(r39Var, new pn6(this, str, jSONObject), this.f39657e);
    }

    /* renamed from: b */
    public final synchronized void m21178b(String str, x97 x97Var) {
        r39 r39Var = this.f39666n;
        if (r39Var != null) {
            fk7 fk7Var = new fk7((Object) this, (Object) str, (Object) x97Var, (byte) 4);
            r39Var.mo2640a(new m49(r39Var, fk7Var, (byte) 0), this.f39657e);
        }
    }

    /* renamed from: c */
    public final synchronized void m21179c(String str, x97 x97Var) {
        r39 r39Var = this.f39666n;
        if (r39Var != null) {
            ms7 ms7Var = new ms7(this, str, x97Var);
            r39Var.mo2640a(new m49(r39Var, ms7Var, (byte) 0), this.f39657e);
        }
    }

    /* renamed from: d */
    public final synchronized void m21180d(Map map) {
        r39 r39Var = this.f39666n;
        if (r39Var != null) {
            ag4 ag4Var = new ag4(this, map);
            r39Var.mo2640a(new m49(r39Var, ag4Var, (byte) 0), this.f39657e);
        }
    }
}
