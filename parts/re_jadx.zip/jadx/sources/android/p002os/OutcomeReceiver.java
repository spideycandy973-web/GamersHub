package android.p002os;

/* loaded from: classes.dex */
public /* synthetic */ interface OutcomeReceiver {
    static {
        throw new NoClassDefFoundError();
    }
}
