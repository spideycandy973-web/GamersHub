package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import p000.as5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(as5 as5Var) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(as5Var);
    }

    public static void write(IconCompat iconCompat, as5 as5Var) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, as5Var);
    }
}
