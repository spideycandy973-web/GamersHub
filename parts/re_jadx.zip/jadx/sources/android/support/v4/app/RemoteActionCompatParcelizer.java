package android.support.v4.app;

import androidx.core.app.RemoteActionCompat;
import p000.as5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class RemoteActionCompatParcelizer extends androidx.core.app.RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(as5 as5Var) {
        return androidx.core.app.RemoteActionCompatParcelizer.read(as5Var);
    }

    public static void write(RemoteActionCompat remoteActionCompat, as5 as5Var) {
        androidx.core.app.RemoteActionCompatParcelizer.write(remoteActionCompat, as5Var);
    }
}
