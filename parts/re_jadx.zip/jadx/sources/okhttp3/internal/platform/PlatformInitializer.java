package okhttp3.internal.platform;

import android.content.Context;
import java.util.List;
import p000.ci1;
import p000.ds0;
import p000.sw3;
import p000.xd2;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class PlatformInitializer implements xd2 {
    @Override // p000.xd2
    public final Object create(Context context) {
        context.getClass();
        sw3 sw3Var = sw3.f36090a;
        Object obj = sw3.f36090a;
        ds0 ds0Var = obj != null ? (ds0) obj : null;
        if (ds0Var != null) {
            ds0Var.mo9503a(context);
        }
        return sw3.f36090a;
    }

    @Override // p000.xd2
    public final List dependencies() {
        return ci1.f4141a;
    }
}
