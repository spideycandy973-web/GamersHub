package org.chromium.support_lib_boundary;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
@Retention(RetentionPolicy.SOURCE)
/* loaded from: classes2.dex */
public @interface PrefetchStatusCodeBoundaryInterface {
    public static final int FAILURE = 1;
    public static final int SUCCESS = 0;
}
