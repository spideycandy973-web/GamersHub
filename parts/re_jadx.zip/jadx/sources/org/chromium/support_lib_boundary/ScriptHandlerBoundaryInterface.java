package org.chromium.support_lib_boundary;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public interface ScriptHandlerBoundaryInterface {
    void remove();
}
