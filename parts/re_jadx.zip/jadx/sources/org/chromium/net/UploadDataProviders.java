package org.chromium.net;

import android.os.ParcelFileDescriptor;
import java.io.File;
import java.nio.ByteBuffer;
import p000.j22;
import p000.jq5;
import p000.to5;
import p000.vo5;
import p000.zt5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class UploadDataProviders {
    private UploadDataProviders() {
    }

    public static UploadDataProvider create(byte[] bArr, int i, int i2) {
        return new to5(ByteBuffer.wrap(bArr, i, i2).slice());
    }

    public static UploadDataProvider create(ParcelFileDescriptor parcelFileDescriptor) {
        return new vo5(new zt5(parcelFileDescriptor, (byte) 13));
    }

    public static UploadDataProvider create(ByteBuffer byteBuffer) {
        return new to5(byteBuffer.slice());
    }

    public static UploadDataProvider create(File file) {
        return new vo5(new j22(file, jq5.f20569f));
    }

    public static UploadDataProvider create(byte[] bArr) {
        return create(bArr, 0, bArr.length);
    }
}
