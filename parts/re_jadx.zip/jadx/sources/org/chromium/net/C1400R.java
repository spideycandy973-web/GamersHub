package org.chromium.net;

/* renamed from: org.chromium.net.R */
/* loaded from: classes2.dex */
public final class C1400R {

    /* renamed from: org.chromium.net.R$raw */
    public static final class raw {
        public static int keep_cronet_api = 2131820551;

        private raw() {
        }
    }

    private C1400R() {
    }
}
