package frb.axeron.core;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import p000.BinderC0870d5;
import p000.C1110hf;
import p000.da2;
import p000.fn5;
import p000.j03;
import p000.ka1;
import p000.ls0;
import p000.ns0;
import p000.o65;
import p000.pz1;
import p000.qp7;
import p000.r41;
import p000.v86;
import p000.wr0;
import p000.xk1;
import p000.xy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class ExecutionActivity extends Activity {

    /* renamed from: f */
    public static final wr0 f14276f = new wr0(6);

    /* renamed from: a */
    public final o65 f14277a;

    /* renamed from: b */
    public final ls0 f14278b;

    /* renamed from: c */
    public xy1 f14279c;

    /* renamed from: d */
    public C1110hf f14280d;

    /* renamed from: e */
    public pz1 f14281e;

    public ExecutionActivity() {
        o65 m18391b = qp7.m18391b();
        this.f14277a = m18391b;
        r41 r41Var = ka1.f21425a;
        this.f14278b = fn5.m11125b(j03.f19481a.plus(m18391b));
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        pz1 pz1Var = this.f14281e;
        if (pz1Var != null) {
            pz1Var.invoke(Integer.valueOf(i), Integer.valueOf(i2), intent);
        }
        this.f14281e = null;
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Bundle bundleExtra = getIntent().getBundleExtra("extra_callback_bundle");
        ns0 ns0Var = null;
        IBinder binder = bundleExtra != null ? bundleExtra.getBinder("extra_callback_binder") : null;
        BinderC0870d5 binderC0870d5 = binder instanceof BinderC0870d5 ? (BinderC0870d5) binder : null;
        da2 da2Var = binderC0870d5 != null ? binderC0870d5.f9786a : null;
        if (da2Var == null) {
            finish();
        } else {
            v86.m21284K(this.f14278b, null, null, new xk1(da2Var, this, ns0Var, (byte) 0), 3);
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        this.f14277a.mo1322a(null);
        super.onDestroy();
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        strArr.getClass();
        iArr.getClass();
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 1001) {
            boolean z = false;
            if (iArr.length != 0 && iArr[0] == 0) {
                z = true;
            }
            C1110hf c1110hf = this.f14280d;
            if (c1110hf != null) {
                c1110hf.invoke(Boolean.valueOf(z));
            }
            this.f14280d = null;
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        xy1 xy1Var = this.f14279c;
        if (xy1Var != null) {
            xy1Var.invoke();
        }
        this.f14279c = null;
    }
}
