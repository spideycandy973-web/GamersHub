package frb.axeron.core;

import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import p000.BinderC0870d5;
import p000.da2;
import p000.fn5;
import p000.j03;
import p000.ka1;
import p000.ls0;
import p000.ns0;
import p000.o65;
import p000.qp7;
import p000.r41;
import p000.v86;
import p000.xk1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ForegroundLaunchActivity extends Activity {

    /* renamed from: b */
    public static final /* synthetic */ int f14282b = 0;

    /* renamed from: a */
    public final ls0 f14283a;

    public ForegroundLaunchActivity() {
        o65 m18391b = qp7.m18391b();
        r41 r41Var = ka1.f21425a;
        this.f14283a = fn5.m11125b(j03.f19481a.plus(m18391b));
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Bundle bundleExtra = getIntent().getBundleExtra("extra_callback_bundle");
        ns0 ns0Var = null;
        IBinder binder = bundleExtra != null ? bundleExtra.getBinder("extra_callback_binder") : null;
        BinderC0870d5 binderC0870d5 = binder instanceof BinderC0870d5 ? (BinderC0870d5) binder : null;
        da2 da2Var = binderC0870d5 != null ? binderC0870d5.f9786a : null;
        if (da2Var == null) {
            finish();
            return;
        }
        r41 r41Var = ka1.f21425a;
        v86.m21284K(this.f14283a, j03.f19481a.f3577e, null, new xk1(da2Var, this, ns0Var, (byte) 4), 2);
        finish();
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
    }
}
