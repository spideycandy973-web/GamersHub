package frb.axeron.manager;

import android.app.Application;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.DeadObjectException;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Process;
import android.os.RemoteException;
import android.util.Log;
import frb.axeron.server.IAxgcService;
import frb.axeron.server.ServiceInfo;
import frb.axeron.server.input.IInputCallback;
import frb.axeron.server.input.IInputListener;
import frb.axeron.server.watcher.IPackageWatcher;
import java.io.File;
import java.util.Arrays;
import p000.AbstractC0946ew;
import p000.C0085bl;
import p000.C0950f;
import p000.C0962fb;
import p000.C1524s0;
import p000.a45;
import p000.b45;
import p000.c30;
import p000.cc1;
import p000.ei2;
import p000.f55;
import p000.fa2;
import p000.ff3;
import p000.fn5;
import p000.fv8;
import p000.gb0;
import p000.hn0;
import p000.i53;
import p000.ij0;
import p000.iv3;
import p000.k30;
import p000.ka1;
import p000.kn5;
import p000.ku1;
import p000.ls0;
import p000.lw9;
import p000.md4;
import p000.mu0;
import p000.n85;
import p000.nd4;
import p000.ns0;
import p000.nu0;
import p000.qp7;
import p000.r41;
import p000.s30;
import p000.tv4;
import p000.v86;
import p000.vy1;
import p000.w31;
import p000.y20;
import p000.y35;
import p000.z20;
import p000.z21;
import p000.zs1;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class Axeron {
    private static final int AXGC_DESTROY_TRANSACTION = 16777115;
    private static final String AXGC_SERVICE_DESCRIPTOR = "frb.axeron.server.IAxgcService";
    private static final int AXGC_UPDATE_TRANSACTION = 16777114;
    public static final String CLIENT_VERSION = "1.3.1";
    public static final int CLIENT_VERSION_CODE = 13015;
    public static final Axeron INSTANCE = new Axeron();
    private static final long STALE_SERVER_KILL_TIMEOUT_MS = 3000;
    private static final ff3 _connected;
    private static final ff3 _serviceInfo;
    public static Application appContext;
    private static final Binder clientLifeline;
    private static final y35 connected;
    private static final IBinder.DeathRecipient deathRecipient;
    private static volatile zy1 diagnosticsListener;
    private static final y35 inputAllowed;
    private static volatile boolean isKillingStaleServer;
    private static volatile boolean isServiceStarted;
    private static volatile boolean isStoppedByUser;
    private static volatile IBinder lastRawBinder;
    private static final mu0 scope;
    private static volatile IAxgcService serviceBinderField;
    private static final y35 serviceInfo;

    static {
        r41 r41Var = ka1.f21425a;
        ls0 m11125b = fn5.m11125b(w31.f41501b.plus(qp7.m18391b()));
        scope = m11125b;
        clientLifeline = new Binder();
        a45 m1397a = b45.m1397a(null);
        _serviceInfo = m1397a;
        serviceInfo = cc1.m2438m(m1397a);
        Boolean bool = Boolean.FALSE;
        a45 m1397a2 = b45.m1397a(bool);
        _connected = m1397a2;
        connected = cc1.m2438m(m1397a2);
        byte b = 0;
        inputAllowed = cc1.m2412Y(new ku1(m1397a2, m1397a, new z20(3, null, b), b), m11125b, tv4.f37701a, bool);
        deathRecipient = new y20(b);
    }

    private Axeron() {
    }

    public static /* synthetic */ String buildRemoteStartCommand$default(Axeron axeron, String str, String str2, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "frb.axeron.server.AxgcService";
        }
        if ((i & 2) != 0) {
            String packageName = axeron.getAppContext().getPackageName();
            packageName.getClass();
            str2 = ij0.m13409m0(f55.m10696E0(packageName, new String[]{"."}, 6)) + "_server";
        }
        return axeron.buildRemoteStartCommand(str, str2);
    }

    public static /* synthetic */ String buildStartCommand$default(Axeron axeron, String str, String str2, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "frb.axeron.server.AxgcService";
        }
        if ((i & 2) != 0) {
            String packageName = axeron.getAppContext().getPackageName();
            packageName.getClass();
            str2 = ij0.m13409m0(f55.m10696E0(packageName, new String[]{"."}, 6)) + "_server";
        }
        return axeron.buildStartCommand(str, str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void deathRecipient$lambda$0() {
        Log.w("Axeron", "Service binder died");
        Axeron axeron = INSTANCE;
        a45 a45Var = (a45) _serviceInfo;
        ServiceInfo serviceInfo2 = (ServiceInfo) a45Var.getValue();
        axeron.diagnostic$manager("service binder died version=" + (serviceInfo2 != null ? Integer.valueOf(serviceInfo2.getVersionCode()) : null));
        axeron.setServiceBinder(null);
        a45Var.m93k(null);
        k30 k30Var = k30.f21152a;
        k30.m14444c();
        isServiceStarted = false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final IAxgcService getServiceBinder() {
        return serviceBinderField;
    }

    private final File getStarterFile() {
        return new File(getAppContext().getApplicationInfo().nativeLibraryDir, "libaxeron.so");
    }

    private final void grantWriteSecureSettingsIfAvailable(ServiceInfo serviceInfo2) {
        Object md4Var;
        if (serviceInfo2.getGrantRuntime()) {
            if (appContext == null) {
                Log.w("Axeron", "grantWriteSecureSettingsIfAvailable: appContext not ready, skipping");
                return;
            }
            if (getAppContext().checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != 0) {
                try {
                    iv3.m13651b(Process.myUid() / 100000, getAppContext().getPackageName(), "android.permission.WRITE_SECURE_SETTINGS");
                    md4Var = kn5.f22076a;
                } catch (Throwable th) {
                    md4Var = new md4(th);
                }
                Throwable m16656b = nd4.m16656b(md4Var);
                if (m16656b != null) {
                    Log.w("Axeron", "Failed to grant WRITE_SECURE_SETTINGS", m16656b);
                }
            }
        }
    }

    public static /* synthetic */ void handleStartService$default(Axeron axeron, String str, String str2, zy1 zy1Var, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "frb.axeron.server.AxgcService";
        }
        if ((i & 2) != 0) {
            String packageName = axeron.getAppContext().getPackageName();
            packageName.getClass();
            str2 = ij0.m13409m0(f55.m10696E0(packageName, new String[]{"."}, 6)) + "_server";
        }
        axeron.handleStartService(str, str2, zy1Var);
    }

    public static final AxeronRemoteProcess newProcess(String[] strArr, String[] strArr2, String str) {
        strArr.getClass();
        IAxgcService serviceBinder = INSTANCE.getServiceBinder();
        if (serviceBinder == null) {
            C0950f.m10585p("AxgcService is not connected");
            return null;
        }
        try {
            fa2 newProcess = serviceBinder.newProcess((String[]) AbstractC0946ew.m10536R0(strArr).toArray(new String[0]), strArr2 != null ? (String[]) AbstractC0946ew.m10536R0(strArr2).toArray(new String[0]) : null, str);
            newProcess.getClass();
            return new AxeronRemoteProcess(newProcess);
        } catch (DeadObjectException e) {
            INSTANCE.setServiceBinder(null);
            throw e;
        } catch (RemoteException e2) {
            vy1.m21787p(e2);
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void publishServiceInfo(IAxgcService iAxgcService, ServiceInfo serviceInfo2) {
        grantWriteSecureSettingsIfAvailable(serviceInfo2);
        IAxgcService serviceBinder = getServiceBinder();
        if ((serviceBinder != null ? serviceBinder.asBinder() : null) == iAxgcService.asBinder()) {
            ((a45) _serviceInfo).m93k(serviceInfo2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void rawDestroy(IBinder iBinder) {
        Parcel obtain = Parcel.obtain();
        obtain.getClass();
        try {
            obtain.writeInterfaceToken("frb.axeron.server.IAxgcService");
            iBinder.transact(AXGC_DESTROY_TRANSACTION, obtain, null, 1);
        } catch (Exception unused) {
        } catch (Throwable th) {
            obtain.recycle();
            throw th;
        }
        obtain.recycle();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object rawUpdate(IBinder iBinder, String str, ns0 ns0Var) {
        r41 r41Var = ka1.f21425a;
        return v86.m21301a0(w31.f41501b, new C0085bl(str, iBinder, null, (byte) 3), ns0Var);
    }

    private final void setServiceBinder(IAxgcService iAxgcService) {
        serviceBinderField = iAxgcService;
        ff3 ff3Var = _connected;
        Boolean valueOf = Boolean.valueOf(iAxgcService != null);
        a45 a45Var = (a45) ff3Var;
        a45Var.getClass();
        a45Var.m94l(null, valueOf);
        if (iAxgcService == null) {
            k30 k30Var = k30.f21152a;
            k30.m14444c();
        }
    }

    public static final Object update(String str, ns0 ns0Var) {
        r41 r41Var = ka1.f21425a;
        Object m21301a0 = v86.m21301a0(w31.f41501b, new c30(str, null, (byte) 0), ns0Var);
        return m21301a0 == nu0.f28013a ? m21301a0 : kn5.f22076a;
    }

    public final String buildRemoteStartCommand(String str, String str2) {
        str.getClass();
        str2.getClass();
        StringBuilder m12943p = hn0.m12943p("PKG=\"", getAppContext().getPackageName(), "\"; APK=$(pm path \"$PKG\" | head -n 1 | sed 's/package://;s/\\r//g'); LIB=$(find \"$(dirname \"$APK\")/lib\" -name 'libaxeron.so' 2>/dev/null | head -1); \"$LIB\" --apk=\"$APK\" --pkg=\"$PKG\" --name=", str2, " --class=");
        m12943p.append(str);
        return m12943p.toString();
    }

    public final String buildStartCommand(String str, String str2) {
        str.getClass();
        str2.getClass();
        String userCommand = getUserCommand();
        String str3 = getAppContext().getApplicationInfo().sourceDir;
        String packageName = getAppContext().getPackageName();
        StringBuilder sb = new StringBuilder();
        sb.append(userCommand);
        sb.append(" --apk=\"");
        sb.append(str3);
        sb.append("\" --pkg=\"");
        sb.append(packageName);
        return hn0.m12941n(sb, "\" --name=", str2, " --class=", str);
    }

    public final String consumeServerDiagnostics() {
        try {
            IAxgcService serviceBinder = getServiceBinder();
            if (serviceBinder != null) {
                return serviceBinder.consumeDiagnostics();
            }
            return null;
        } catch (Exception e) {
            Log.e("Axeron", "Failed to consume server diagnostics", e);
            return null;
        }
    }

    public final int[] currentDisplayMetrics() {
        int[] currentDisplayMetrics;
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null && (currentDisplayMetrics = inputListener.currentDisplayMetrics()) != null && currentDisplayMetrics.length >= 2 && currentDisplayMetrics[0] > 0) {
                if (currentDisplayMetrics[1] > 0) {
                    return currentDisplayMetrics;
                }
            }
            return null;
        } catch (Exception e) {
            Log.e("AxeronInput", "currentDisplayMetrics failed", e);
            return null;
        }
    }

    public final String currentForegroundPackage() {
        try {
            IPackageWatcher packageWatcher = INSTANCE.packageWatcher();
            if (packageWatcher != null) {
                return packageWatcher.getForegroundPackage();
            }
            return null;
        } catch (Exception unused) {
            return null;
        }
    }

    public final String describeStartError(int i) {
        k30 k30Var = k30.f21152a;
        return k30.m14442a(i);
    }

    public final void diagnostic$manager(String str) {
        str.getClass();
        try {
            zy1 zy1Var = diagnosticsListener;
            if (zy1Var != null) {
                zy1Var.invoke(str);
            }
        } catch (Throwable unused) {
        }
    }

    public final Application getAppContext() {
        Application application = appContext;
        if (application != null) {
            return application;
        }
        ei2.m10039H("appContext");
        throw null;
    }

    public final y35 getConnected() {
        return connected;
    }

    public final zy1 getDiagnosticsListener() {
        return diagnosticsListener;
    }

    public final y35 getInputAllowed() {
        return inputAllowed;
    }

    public final y35 getInputState() {
        return k30.f21156e;
    }

    public final int getMouseHardwareRate() {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                return inputListener.getMouseHardwareRate();
            }
            return 0;
        } catch (Exception unused) {
            return 0;
        }
    }

    public final int getMousePollingRate() {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                return inputListener.getMousePollingRate();
            }
            return 0;
        } catch (Exception unused) {
            return 0;
        }
    }

    public final int getMousePollingRateLimit() {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                return inputListener.getMousePollingRateLimit();
            }
            return 0;
        } catch (Exception unused) {
            return 0;
        }
    }

    public final y35 getServiceInfo() {
        return serviceInfo;
    }

    public final k30 getTouch() {
        return k30.f21152a;
    }

    public final String getUserCommand() {
        String absolutePath = getStarterFile().getAbsolutePath();
        absolutePath.getClass();
        return absolutePath;
    }

    public final s30 getWatcher() {
        return s30.f34689a;
    }

    public final void handleStartService(String str, String str2, zy1 zy1Var) {
        str.getClass();
        str2.getClass();
        zy1Var.getClass();
        isStoppedByUser = false;
        IAxgcService serviceBinder = getServiceBinder();
        if (serviceBinder != null && pingServiceBinder()) {
            ServiceInfo serviceInfo2 = null;
            try {
                serviceInfo2 = serviceBinder.getServiceInfo();
            } catch (BadParcelableException e) {
                Log.e("Axeron", "Unmarshall mismatch on serviceInfo", e);
            } catch (Exception e2) {
                Log.e("Axeron", "Failed to read serviceInfo", e2);
            }
            if (serviceInfo2 != null && ei2.m10070i(serviceInfo2.getVersion(), CLIENT_VERSION) && serviceInfo2.getVersionCode() == 13015) {
                publishServiceInfo(serviceBinder, serviceInfo2);
            } else {
                ((a45) _serviceInfo).m93k(serviceInfo2);
            }
        }
        ServiceInfo serviceInfo3 = (ServiceInfo) ((a45) _serviceInfo).getValue();
        boolean z = serviceInfo3 != null && ei2.m10070i(serviceInfo3.getVersion(), CLIENT_VERSION) && serviceInfo3.getVersionCode() == 13015;
        if (pingServiceBinder() && z) {
            isServiceStarted = true;
            return;
        }
        if (isKillingStaleServer || isServiceStarted) {
            return;
        }
        isServiceStarted = true;
        try {
            String buildStartCommand = buildStartCommand(str, str2);
            Log.i("Axeron", "executing: " + buildStartCommand);
            diagnostic$manager("spawning server");
            zy1Var.invoke(buildStartCommand);
        } catch (Exception e3) {
            isServiceStarted = false;
            Log.e("Axeron", "Failed to start service", e3);
        }
    }

    public final void hideSystemCursor() {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.hideSystemCursor();
            }
        } catch (Exception e) {
            Log.e("AxeronInput", "hideSystemCursor failed", e);
        }
    }

    public final void init(Application application) {
        application.getClass();
        setAppContext(application);
        lw9.f24945q = new fv8((byte) 23);
    }

    public final IInputListener inputListener() {
        try {
            IAxgcService serviceBinder = getServiceBinder();
            if (serviceBinder != null) {
                return serviceBinder.getInputListener();
            }
            return null;
        } catch (Exception e) {
            Log.e("Axeron", "Failed to obtain touch listener", e);
            return null;
        }
    }

    public final boolean isAltKeyActive() {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                return inputListener.isAltKeyActive();
            }
            return false;
        } catch (Exception unused) {
            return false;
        }
    }

    public final boolean isForeground(String str) {
        str.getClass();
        try {
            IPackageWatcher packageWatcher = INSTANCE.packageWatcher();
            if (packageWatcher != null) {
                return packageWatcher.isForeground(str);
            }
            return false;
        } catch (Exception unused) {
            return false;
        }
    }

    public final boolean isKeyboardInject() {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                return inputListener.isKeyboardInject();
            }
            return false;
        } catch (Exception unused) {
            return false;
        }
    }

    public final boolean isMouseInject() {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                return inputListener.isMouseInject();
            }
            return false;
        } catch (Exception unused) {
            return false;
        }
    }

    public final boolean isStoppedByUser() {
        return isStoppedByUser;
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0037 A[Catch: Exception -> 0x0130, TryCatch #0 {Exception -> 0x0130, blocks: (B:9:0x001d, B:14:0x0037, B:16:0x003e, B:19:0x0050, B:21:0x0058, B:23:0x005e, B:26:0x0067, B:28:0x0073, B:31:0x00d0, B:35:0x0028, B:38:0x002f, B:12:0x0022), top: B:8:0x001d, inners: #1, #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:16:0x003e A[Catch: Exception -> 0x0130, TRY_LEAVE, TryCatch #0 {Exception -> 0x0130, blocks: (B:9:0x001d, B:14:0x0037, B:16:0x003e, B:19:0x0050, B:21:0x0058, B:23:0x005e, B:26:0x0067, B:28:0x0073, B:31:0x00d0, B:35:0x0028, B:38:0x002f, B:12:0x0022), top: B:8:0x001d, inners: #1, #2 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onBinderReceived(android.os.IBinder r14, java.lang.String r15) {
        /*
            Method dump skipped, instructions count: 311
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.manager.Axeron.onBinderReceived(android.os.IBinder, java.lang.String):void");
    }

    public final zs1 packageEvents(String... strArr) {
        strArr.getClass();
        zs1 m23761o = z21.m23761o(gb0.m12012e(new C1524s0((String[]) Arrays.copyOf(strArr, strArr.length), null, (byte) 7)), Integer.MAX_VALUE);
        r41 r41Var = ka1.f21425a;
        return z21.m23764t(m23761o, w31.f41501b);
    }

    public final IPackageWatcher packageWatcher() {
        try {
            IAxgcService serviceBinder = getServiceBinder();
            if (serviceBinder != null) {
                return serviceBinder.getPackageWatcher();
            }
            return null;
        } catch (Exception e) {
            Log.e("Axeron", "Failed to obtain package watcher", e);
            return null;
        }
    }

    public final boolean pingServiceBinder() {
        IBinder asBinder;
        IAxgcService serviceBinder = getServiceBinder();
        if (serviceBinder == null || (asBinder = serviceBinder.asBinder()) == null) {
            return false;
        }
        return asBinder.pingBinder();
    }

    public final boolean recordTestServerDiagnostics() {
        IAxgcService serviceBinder = getServiceBinder();
        if (serviceBinder == null) {
            return false;
        }
        try {
            serviceBinder.recordTestDiagnostics();
            return true;
        } catch (Exception e) {
            Log.e("Axeron", "Failed to record test server diagnostics", e);
            return false;
        }
    }

    public final void refreshInputState() {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        Object value;
        a45 a45Var = k30.f21154c;
        Axeron axeron = INSTANCE;
        IInputListener inputListener = axeron.inputListener();
        if (inputListener == null) {
            if (axeron.pingServiceBinder()) {
                return;
            }
            n85 n85Var = new n85();
            a45Var.getClass();
            a45Var.m94l(null, n85Var);
            return;
        }
        try {
            z = inputListener.isListening();
        } catch (Exception unused) {
            z = ((n85) a45Var.getValue()).f27148b;
        }
        boolean z7 = z;
        int i = 0;
        try {
            z2 = inputListener.isInjectEnabled();
        } catch (Exception unused2) {
            z2 = false;
        }
        try {
            z3 = inputListener.isMouseInject();
        } catch (Exception unused3) {
            z3 = false;
        }
        try {
            z4 = inputListener.isKeyboardInject();
        } catch (Exception unused4) {
            z4 = false;
        }
        if (z2 || z3 || z4) {
            try {
                z5 = inputListener.isMappingEnabled();
            } catch (Exception unused5) {
                z5 = false;
            }
            z6 = z5;
        } else {
            z6 = false;
        }
        if (z7) {
            try {
                i = inputListener.monitoredDeviceCount();
            } catch (Exception unused6) {
                i = ((n85) a45Var.getValue()).f27153g;
            }
        }
        int i2 = i;
        do {
            value = a45Var.getValue();
        } while (!a45Var.m92j(value, n85.m16536a((n85) value, z7, z2, z3, z4, z6, i2, 0.0f, 0.0f, C0962fb.c.f13595h)));
    }

    public final void registerTouchCallback(IInputCallback iInputCallback) {
        iInputCallback.getClass();
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.registerCallback(iInputCallback);
            }
        } catch (Exception unused) {
        }
    }

    public final void setAltKeyActive(boolean z) {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.setAltKeyActive(z);
            }
        } catch (Exception e) {
            Log.e("AxeronInput", "setAltKeyActive failed", e);
        }
    }

    public final void setAppContext(Application application) {
        application.getClass();
        appContext = application;
    }

    public final void setDiagnosticsListener(zy1 zy1Var) {
        diagnosticsListener = zy1Var;
    }

    public final void setInjectSensitivity(float f, float f2) {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.setInjectSensitivity(f, f2);
            }
            a45 a45Var = k30.f21154c;
            while (true) {
                Object value = a45Var.getValue();
                float f3 = f;
                float f4 = f2;
                if (a45Var.m92j(value, n85.m16536a((n85) value, false, false, false, false, false, 0, f3, f4, 127))) {
                    return;
                }
                f = f3;
                f2 = f4;
            }
        } catch (Exception e) {
            Log.e("AxeronInput", "setInjectSensitivity failed", e);
        }
    }

    public final void setInjectSensitivityArea(int i) {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.setInjectSensitivityArea(i);
            }
        } catch (Exception e) {
            Log.e("AxeronInput", "setInjectSensitivityArea failed", e);
        }
    }

    public final void setInjectSensitivityCurve(int i) {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.setInjectSensitivityCurve(i);
            }
        } catch (Exception e) {
            Log.e("AxeronInput", "setInjectSensitivityCurve failed", e);
        }
    }

    public final void setInjectSmoothing(boolean z, float f, float f2) {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.setInjectSmoothing(z, f, f2);
            }
        } catch (Exception e) {
            Log.e("AxeronInput", "setInjectSmoothing failed", e);
        }
    }

    public final void setKeyboardInject(boolean z) {
        boolean z2;
        Object value;
        synchronized (k30.f21153b) {
            try {
                IInputListener inputListener = INSTANCE.inputListener();
                if (inputListener != null) {
                    inputListener.setKeyboardInject(z);
                    try {
                        z2 = inputListener.isKeyboardInject();
                    } catch (Exception unused) {
                        z2 = false;
                    }
                    boolean z3 = z2;
                    a45 a45Var = k30.f21154c;
                    do {
                        value = a45Var.getValue();
                    } while (!a45Var.m92j(value, n85.m16536a((n85) value, false, false, false, z3, false, 0, 0.0f, 0.0f, 495)));
                }
            } catch (Exception e) {
                Log.e("AxeronInput", "setKeyboardInject failed", e);
            }
        }
    }

    public final void setMappingProfile(i53 i53Var) {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.setMappingProfile(i53Var);
            }
        } catch (Exception e) {
            Log.e("AxeronInput", "setMappingProfile failed", e);
        }
    }

    public final void setMouseInject(boolean z) {
        boolean z2;
        Object value;
        k30 k30Var = k30.f21152a;
        synchronized (k30.f21153b) {
            try {
                k30.m14443b();
                IInputListener inputListener = INSTANCE.inputListener();
                if (inputListener != null) {
                    inputListener.setMouseInject(z);
                    try {
                        z2 = inputListener.isMouseInject();
                    } catch (Exception unused) {
                        z2 = false;
                    }
                    boolean z3 = z2;
                    a45 a45Var = k30.f21154c;
                    do {
                        value = a45Var.getValue();
                    } while (!a45Var.m92j(value, n85.m16536a((n85) value, false, false, z3, false, false, 0, 0.0f, 0.0f, 503)));
                }
            } catch (Exception e) {
                Log.e("AxeronInput", "setMouseInject failed", e);
            }
        }
    }

    public final void setMousePollingRateLimit(int i) {
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.setMousePollingRateLimit(i);
            }
        } catch (Exception e) {
            Log.e("AxeronInput", "setMousePollingRateLimit failed", e);
        }
    }

    public final boolean setTouchInject(boolean z) {
        boolean z2;
        Object value;
        boolean z3;
        Object value2;
        n85 n85Var;
        synchronized (k30.f21153b) {
            IInputListener inputListener = INSTANCE.inputListener();
            z2 = false;
            if (inputListener != null) {
                try {
                    inputListener.setInjectEnabled(z);
                    try {
                        z3 = inputListener.isInjectEnabled();
                    } catch (Exception unused) {
                        z3 = false;
                    }
                    a45 a45Var = k30.f21154c;
                    do {
                        value2 = a45Var.getValue();
                        n85Var = (n85) value2;
                    } while (!a45Var.m92j(value2, n85.m16536a(n85Var, false, z3, false, false, z3 ? n85Var.f27152f : false, 0, 0.0f, 0.0f, 475)));
                    z2 = z3;
                } catch (Exception e) {
                    Log.e("AxeronInput", "setTouchInject failed", e);
                    a45 a45Var2 = k30.f21154c;
                    do {
                        value = a45Var2.getValue();
                    } while (!a45Var2.m92j(value, n85.m16536a((n85) value, false, false, false, false, false, 0, 0.0f, 0.0f, 475)));
                }
            }
        }
        return z2;
    }

    public final boolean setTouchMapping(boolean z) {
        boolean z2;
        boolean z3;
        Object value;
        synchronized (k30.f21153b) {
            IInputListener inputListener = INSTANCE.inputListener();
            z2 = false;
            if (inputListener != null) {
                try {
                    inputListener.setMappingEnabled(z);
                    try {
                        z3 = inputListener.isMappingEnabled();
                    } catch (Exception unused) {
                        z3 = false;
                    }
                    a45 a45Var = k30.f21154c;
                    do {
                        value = a45Var.getValue();
                    } while (!a45Var.m92j(value, n85.m16536a((n85) value, false, false, false, false, z3, 0, 0.0f, 0.0f, 479)));
                    z2 = z3;
                } catch (Exception e) {
                    Log.e("AxeronInput", "setTouchMapping failed", e);
                }
            }
        }
        return z2;
    }

    public final int startInputListener() {
        Object value;
        int i;
        Object value2;
        n85 n85Var;
        boolean z;
        int i2;
        synchronized (k30.f21153b) {
            Axeron axeron = INSTANCE;
            IInputListener inputListener = axeron.inputListener();
            if (inputListener == null) {
                if (!axeron.pingServiceBinder()) {
                    a45 a45Var = k30.f21154c;
                    n85 n85Var2 = new n85();
                    a45Var.getClass();
                    a45Var.m94l(null, n85Var2);
                }
                Log.e("AxeronInput", "startInputListener: inputListener() is null, binder alive=" + axeron.pingServiceBinder());
                axeron.diagnostic$manager("startInputListener: no listener binder, alive=" + axeron.pingServiceBinder());
                return -100;
            }
            try {
                i = inputListener.start();
                a45 a45Var2 = k30.f21154c;
                do {
                    value2 = a45Var2.getValue();
                    n85Var = (n85) value2;
                    if (i > 0) {
                        z = true;
                        i2 = i;
                    } else {
                        z = false;
                        i2 = 0;
                    }
                } while (!a45Var2.m92j(value2, n85.m16536a(n85Var, z, i > 0 ? n85Var.f27149c : false, false, false, false, i2, 0.0f, 0.0f, 440)));
                if (i <= 0) {
                    k30 k30Var = k30.f21152a;
                    Log.e("AxeronInput", "startInputListener failed: " + k30.m14442a(i));
                }
                INSTANCE.diagnostic$manager("startInputListener result=" + i);
            } catch (Exception e) {
                Log.e("AxeronInput", "startInputListener failed", e);
                INSTANCE.diagnostic$manager("startInputListener threw " + e.getClass().getName() + ": " + e.getMessage());
                a45 a45Var3 = k30.f21154c;
                do {
                    value = a45Var3.getValue();
                } while (!a45Var3.m92j(value, n85.m16536a((n85) value, false, false, false, false, false, 0, 0.0f, 0.0f, 441)));
                i = -1;
            }
            return i;
        }
    }

    public final void stopInputListener() {
        Object value;
        synchronized (k30.f21153b) {
            try {
                IInputListener inputListener = INSTANCE.inputListener();
                if (inputListener != null) {
                    inputListener.stop();
                }
            } catch (Exception e) {
                Log.e("AxeronInput", "stopInputListener failed", e);
            }
            a45 a45Var = k30.f21154c;
            do {
                value = a45Var.getValue();
            } while (!a45Var.m92j(value, n85.m16536a((n85) value, false, false, false, false, false, 0, 0.0f, 0.0f, 409)));
        }
    }

    public final void stopService() {
        diagnostic$manager("stopService requested");
        isStoppedByUser = true;
        IAxgcService serviceBinder = getServiceBinder();
        if (serviceBinder != null) {
            try {
                serviceBinder.destroy();
            } catch (Exception unused) {
            }
            setServiceBinder(null);
            ((a45) _serviceInfo).m93k(null);
            isServiceStarted = false;
            return;
        }
        IBinder iBinder = lastRawBinder;
        if (iBinder == null) {
            return;
        }
        rawDestroy(iBinder);
        lastRawBinder = null;
        ((a45) _serviceInfo).m93k(null);
        isServiceStarted = false;
    }

    public final void unregisterTouchCallback(IInputCallback iInputCallback) {
        iInputCallback.getClass();
        k30 k30Var = k30.f21152a;
        try {
            IInputListener inputListener = INSTANCE.inputListener();
            if (inputListener != null) {
                inputListener.unregisterCallback(iInputCallback);
            }
        } catch (Exception unused) {
        }
    }

    public static final AxeronRemoteProcess newProcess(String str) {
        str.getClass();
        return newProcess(new String[]{"sh", "-c", str}, null, null);
    }
}
