package frb.axeron.manager;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.os.RemoteException;
import android.util.ArraySet;
import android.util.Log;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import p000.C0950f;
import p000.fa2;
import p000.j22;
import p000.l30;
import p000.m30;
import p000.n30;
import p000.s76;
import p000.vy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class AxeronRemoteProcess extends Process implements Parcelable {
    private static final String TAG = "AxeronRemoteProcess";
    private InputStream isStream;

    /* renamed from: os */
    private OutputStream f14330os;
    private n30 remote;
    public static final m30 Companion = new m30();
    private static final Set<AxeronRemoteProcess> CACHE = Collections.synchronizedSet(new ArraySet());
    public static final Parcelable.Creator<AxeronRemoteProcess> CREATOR = new s76(2);

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public AxeronRemoteProcess(android.os.Parcel r3) {
        /*
            r2 = this;
            r3.getClass()
            android.os.IBinder r3 = r3.readStrongBinder()
            int r0 = p000.p30.f29724d
            if (r3 != 0) goto Ld
            r3 = 0
            goto L25
        Ld:
            java.lang.String r0 = "frb.axeron.server.process.IAxeronRemoteProcess"
            android.os.IInterface r0 = r3.queryLocalInterface(r0)
            if (r0 == 0) goto L1d
            boolean r1 = r0 instanceof p000.fa2
            if (r1 == 0) goto L1d
            r3 = r0
            fa2 r3 = (p000.fa2) r3
            goto L25
        L1d:
            ea2 r0 = new ea2
            r0.<init>()
            r0.f11569a = r3
            r3 = r0
        L25:
            r3.getClass()
            r2.<init>(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.manager.AxeronRemoteProcess.<init>(android.os.Parcel):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$0(AxeronRemoteProcess axeronRemoteProcess) {
        axeronRemoteProcess.remote = null;
        Log.v(TAG, "remote process is dead");
        CACHE.remove(axeronRemoteProcess);
    }

    public final boolean alive() {
        n30 n30Var = this.remote;
        if (n30Var == null) {
            return false;
        }
        try {
            return ((fa2) ((j22) n30Var).f19591b).mo9835P3();
        } catch (RemoteException e) {
            Log.e(TAG, "alive", e);
            return false;
        }
    }

    public final IBinder asBinder() {
        n30 n30Var = this.remote;
        if (n30Var == null) {
            C0950f.m10585p("Remote process is dead");
            return null;
        }
        IBinder asBinder = ((fa2) ((j22) n30Var).f19591b).asBinder();
        asBinder.getClass();
        return asBinder;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // java.lang.Process
    public void destroy() {
        try {
            n30 n30Var = this.remote;
            if (n30Var != null) {
                ((fa2) ((j22) n30Var).f19591b).destroy();
            }
        } catch (RemoteException e) {
            Log.w(TAG, "destroy: remote process already dead or connection lost", e);
        }
    }

    @Override // java.lang.Process
    public int exitValue() {
        n30 n30Var = this.remote;
        if (n30Var == null) {
            return -1;
        }
        try {
            return ((fa2) ((j22) n30Var).f19591b).mo9836T3();
        } catch (RemoteException e) {
            Log.e(TAG, "exitValue", e);
            return -1;
        }
    }

    @Override // java.lang.Process
    public InputStream getErrorStream() {
        n30 n30Var = this.remote;
        if (n30Var == null) {
            C0950f.m10585p("Remote process is dead");
            return null;
        }
        try {
            ParcelFileDescriptor mo9837a0 = ((fa2) ((j22) n30Var).f19591b).mo9837a0();
            mo9837a0.getClass();
            return new ParcelFileDescriptor.AutoCloseInputStream(mo9837a0);
        } catch (RemoteException e) {
            vy1.m21787p(e);
            return null;
        }
    }

    @Override // java.lang.Process
    public InputStream getInputStream() {
        n30 n30Var = this.remote;
        if (n30Var == null) {
            C0950f.m10585p("Remote process is dead");
            return null;
        }
        if (this.isStream == null) {
            try {
                ParcelFileDescriptor mo9833D2 = ((fa2) ((j22) n30Var).f19591b).mo9833D2();
                mo9833D2.getClass();
                this.isStream = new ParcelFileDescriptor.AutoCloseInputStream(mo9833D2);
            } catch (RemoteException e) {
                vy1.m21787p(e);
                return null;
            }
        }
        InputStream inputStream = this.isStream;
        inputStream.getClass();
        return inputStream;
    }

    @Override // java.lang.Process
    public OutputStream getOutputStream() {
        n30 n30Var = this.remote;
        if (n30Var == null) {
            C0950f.m10585p("Remote process is dead");
            return null;
        }
        if (this.f14330os == null) {
            try {
                ParcelFileDescriptor mo9832B2 = ((fa2) ((j22) n30Var).f19591b).mo9832B2();
                mo9832B2.getClass();
                this.f14330os = new ParcelFileDescriptor.AutoCloseOutputStream(mo9832B2);
            } catch (RemoteException e) {
                vy1.m21787p(e);
                return null;
            }
        }
        OutputStream outputStream = this.f14330os;
        outputStream.getClass();
        return outputStream;
    }

    @Override // java.lang.Process
    public int waitFor() throws InterruptedException {
        n30 n30Var = this.remote;
        if (n30Var == null) {
            return -1;
        }
        try {
            return ((fa2) ((j22) n30Var).f19591b).mo9838h2();
        } catch (RemoteException e) {
            Log.e(TAG, "waitFor", e);
            return -1;
        }
    }

    public final boolean waitForTimeout(long j, TimeUnit timeUnit) throws InterruptedException {
        timeUnit.getClass();
        n30 n30Var = this.remote;
        if (n30Var == null) {
            return false;
        }
        try {
            String obj = timeUnit.toString();
            obj.getClass();
            return ((fa2) ((j22) n30Var).f19591b).mo9834L3(j, obj);
        } catch (RemoteException e) {
            Log.e(TAG, "waitForTimeout", e);
            return false;
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        IBinder iBinder;
        parcel.getClass();
        n30 n30Var = this.remote;
        if (n30Var != null) {
            iBinder = ((fa2) ((j22) n30Var).f19591b).asBinder();
            iBinder.getClass();
        } else {
            iBinder = null;
        }
        parcel.writeStrongBinder(iBinder);
    }

    private AxeronRemoteProcess(n30 n30Var) {
        this.remote = n30Var;
        try {
            IBinder asBinder = ((fa2) ((j22) n30Var).f19591b).asBinder();
            asBinder.getClass();
            asBinder.linkToDeath(new l30(this, (byte) 0), 0);
        } catch (RemoteException e) {
            Log.e(TAG, "linkToDeath", e);
        }
        CACHE.add(this);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public AxeronRemoteProcess(fa2 fa2Var) {
        this(new j22((Object) fa2Var, (byte) 3));
        fa2Var.getClass();
    }
}
