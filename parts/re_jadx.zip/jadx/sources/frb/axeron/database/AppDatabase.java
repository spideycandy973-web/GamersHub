package frb.axeron.database;

import p000.e52;
import p000.fu8;
import p000.gr1;
import p000.jf4;
import p000.jq5;
import p000.jy0;
import p000.k93;
import p000.nx0;
import p000.or1;
import p000.py0;
import p000.q52;
import p000.r14;
import p000.tb3;
import p000.vy0;
import p000.y14;
import p000.za3;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public abstract class AppDatabase extends jf4 {

    /* renamed from: a */
    public static final fu8 f14301a = new fu8((byte) 21);

    /* renamed from: b */
    public static volatile y14 f14302b;

    /* renamed from: c */
    public static volatile or1 f14303c;

    /* renamed from: d */
    public static volatile jy0 f14304d;

    /* renamed from: e */
    public static volatile vy0 f14305e;

    /* renamed from: f */
    public static volatile tb3 f14306f;

    /* renamed from: g */
    public static volatile q52 f14307g;

    /* renamed from: h */
    public static volatile AppDatabase f14308h;

    /* renamed from: i */
    public static final k93 f14309i;

    /* renamed from: j */
    public static final k93 f14310j;

    /* renamed from: k */
    public static final k93 f14311k;

    static {
        int i = 4;
        f14309i = new k93(3, i, (byte) 10);
        int i2 = 5;
        f14310j = new k93(i, i2, (byte) 11);
        f14311k = new k93(i2, 6, jq5.f20569f);
    }

    /* renamed from: b */
    public abstract nx0 mo11369b();

    /* renamed from: c */
    public abstract py0 mo11370c();

    /* renamed from: d */
    public abstract gr1 mo11371d();

    /* renamed from: e */
    public abstract e52 mo11372e();

    /* renamed from: f */
    public abstract za3 mo11373f();

    /* renamed from: g */
    public abstract r14 mo11374g();
}
