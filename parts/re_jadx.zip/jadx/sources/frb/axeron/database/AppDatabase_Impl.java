package frb.axeron.database;

import frb.axeron.database.AppDatabase_Impl;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import p000.C1282ls;
import p000.ca4;
import p000.ci1;
import p000.e52;
import p000.gr1;
import p000.i85;
import p000.nf4;
import p000.nx0;
import p000.py0;
import p000.r14;
import p000.ri2;
import p000.sh0;
import p000.xy1;
import p000.za3;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class AppDatabase_Impl extends AppDatabase {

    /* renamed from: l */
    public final i85 f14312l;

    /* renamed from: m */
    public final i85 f14313m;

    /* renamed from: n */
    public final i85 f14314n;

    /* renamed from: o */
    public final i85 f14315o;

    /* renamed from: p */
    public final i85 f14316p;

    /* renamed from: q */
    public final i85 f14317q;

    public AppDatabase_Impl() {
        final byte b = 0;
        this.f14312l = new i85(new xy1(this) { // from class: ks

            /* renamed from: b */
            public final /* synthetic */ AppDatabase_Impl f22339b;

            {
                this.f22339b = this;
            }

            @Override // p000.xy1
            public final Object invoke() {
                byte b2 = b;
                AppDatabase_Impl appDatabase_Impl = this.f22339b;
                switch (b2) {
                    case 0:
                        return new r14(appDatabase_Impl);
                    case 1:
                        return new gr1(appDatabase_Impl);
                    case 2:
                        return new nx0(appDatabase_Impl);
                    case 3:
                        return new py0(appDatabase_Impl);
                    case 4:
                        return new za3(appDatabase_Impl);
                    default:
                        return new e52(appDatabase_Impl);
                }
            }
        });
        final byte b2 = 1;
        this.f14313m = new i85(new xy1(this) { // from class: ks

            /* renamed from: b */
            public final /* synthetic */ AppDatabase_Impl f22339b;

            {
                this.f22339b = this;
            }

            @Override // p000.xy1
            public final Object invoke() {
                byte b22 = b2;
                AppDatabase_Impl appDatabase_Impl = this.f22339b;
                switch (b22) {
                    case 0:
                        return new r14(appDatabase_Impl);
                    case 1:
                        return new gr1(appDatabase_Impl);
                    case 2:
                        return new nx0(appDatabase_Impl);
                    case 3:
                        return new py0(appDatabase_Impl);
                    case 4:
                        return new za3(appDatabase_Impl);
                    default:
                        return new e52(appDatabase_Impl);
                }
            }
        });
        final byte b3 = 2;
        this.f14314n = new i85(new xy1(this) { // from class: ks

            /* renamed from: b */
            public final /* synthetic */ AppDatabase_Impl f22339b;

            {
                this.f22339b = this;
            }

            @Override // p000.xy1
            public final Object invoke() {
                byte b22 = b3;
                AppDatabase_Impl appDatabase_Impl = this.f22339b;
                switch (b22) {
                    case 0:
                        return new r14(appDatabase_Impl);
                    case 1:
                        return new gr1(appDatabase_Impl);
                    case 2:
                        return new nx0(appDatabase_Impl);
                    case 3:
                        return new py0(appDatabase_Impl);
                    case 4:
                        return new za3(appDatabase_Impl);
                    default:
                        return new e52(appDatabase_Impl);
                }
            }
        });
        final byte b4 = 3;
        this.f14315o = new i85(new xy1(this) { // from class: ks

            /* renamed from: b */
            public final /* synthetic */ AppDatabase_Impl f22339b;

            {
                this.f22339b = this;
            }

            @Override // p000.xy1
            public final Object invoke() {
                byte b22 = b4;
                AppDatabase_Impl appDatabase_Impl = this.f22339b;
                switch (b22) {
                    case 0:
                        return new r14(appDatabase_Impl);
                    case 1:
                        return new gr1(appDatabase_Impl);
                    case 2:
                        return new nx0(appDatabase_Impl);
                    case 3:
                        return new py0(appDatabase_Impl);
                    case 4:
                        return new za3(appDatabase_Impl);
                    default:
                        return new e52(appDatabase_Impl);
                }
            }
        });
        final byte b5 = 4;
        this.f14316p = new i85(new xy1(this) { // from class: ks

            /* renamed from: b */
            public final /* synthetic */ AppDatabase_Impl f22339b;

            {
                this.f22339b = this;
            }

            @Override // p000.xy1
            public final Object invoke() {
                byte b22 = b5;
                AppDatabase_Impl appDatabase_Impl = this.f22339b;
                switch (b22) {
                    case 0:
                        return new r14(appDatabase_Impl);
                    case 1:
                        return new gr1(appDatabase_Impl);
                    case 2:
                        return new nx0(appDatabase_Impl);
                    case 3:
                        return new py0(appDatabase_Impl);
                    case 4:
                        return new za3(appDatabase_Impl);
                    default:
                        return new e52(appDatabase_Impl);
                }
            }
        });
        final byte b6 = 5;
        this.f14317q = new i85(new xy1(this) { // from class: ks

            /* renamed from: b */
            public final /* synthetic */ AppDatabase_Impl f22339b;

            {
                this.f22339b = this;
            }

            @Override // p000.xy1
            public final Object invoke() {
                byte b22 = b6;
                AppDatabase_Impl appDatabase_Impl = this.f22339b;
                switch (b22) {
                    case 0:
                        return new r14(appDatabase_Impl);
                    case 1:
                        return new gr1(appDatabase_Impl);
                    case 2:
                        return new nx0(appDatabase_Impl);
                    case 3:
                        return new py0(appDatabase_Impl);
                    case 4:
                        return new za3(appDatabase_Impl);
                    default:
                        return new e52(appDatabase_Impl);
                }
            }
        });
    }

    @Override // frb.axeron.database.AppDatabase
    /* renamed from: b */
    public final nx0 mo11369b() {
        return (nx0) this.f14314n.getValue();
    }

    @Override // frb.axeron.database.AppDatabase
    /* renamed from: c */
    public final py0 mo11370c() {
        return (py0) this.f14315o.getValue();
    }

    @Override // p000.jf4
    public final List createAutoMigrations(Map map) {
        return new ArrayList();
    }

    @Override // p000.jf4
    public final ri2 createInvalidationTracker() {
        return new ri2(this, new LinkedHashMap(), new LinkedHashMap(), "prioritized_apps", "crosshair_config", "currencies", "monitor_config", "gyro_config", "floating_apps");
    }

    @Override // p000.jf4
    public final nf4 createOpenDelegate() {
        return new C1282ls(this);
    }

    @Override // frb.axeron.database.AppDatabase
    /* renamed from: d */
    public final gr1 mo11371d() {
        return (gr1) this.f14313m.getValue();
    }

    @Override // frb.axeron.database.AppDatabase
    /* renamed from: e */
    public final e52 mo11372e() {
        return (e52) this.f14317q.getValue();
    }

    @Override // frb.axeron.database.AppDatabase
    /* renamed from: f */
    public final za3 mo11373f() {
        return (za3) this.f14316p.getValue();
    }

    @Override // frb.axeron.database.AppDatabase
    /* renamed from: g */
    public final r14 mo11374g() {
        return (r14) this.f14312l.getValue();
    }

    @Override // p000.jf4
    public final Set getRequiredAutoMigrationSpecClasses() {
        return new LinkedHashSet();
    }

    @Override // p000.jf4
    public final Map getRequiredTypeConverterClasses() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        sh0 m2313a = ca4.m2313a(r14.class);
        ci1 ci1Var = ci1.f4141a;
        linkedHashMap.put(m2313a, ci1Var);
        linkedHashMap.put(ca4.m2313a(gr1.class), ci1Var);
        linkedHashMap.put(ca4.m2313a(nx0.class), ci1Var);
        linkedHashMap.put(ca4.m2313a(py0.class), ci1Var);
        linkedHashMap.put(ca4.m2313a(za3.class), ci1Var);
        linkedHashMap.put(ca4.m2313a(e52.class), ci1Var);
        return linkedHashMap;
    }
}
