package frb.axeron.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import androidx.activity.ComponentActivity;
import java.lang.reflect.Field;
import p000.C0021ak;
import p000.a15;
import p000.di2;
import p000.gm0;
import p000.gm3;
import p000.ha3;
import p000.hl7;
import p000.ls5;
import p000.mx0;
import p000.n16;
import p000.rs5;
import p000.sy6;
import p000.wl0;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class SpaceActivity extends ComponentActivity {

    /* renamed from: b */
    public static final /* synthetic */ int f14248b = 0;

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    public final void attachBaseContext(Context context) {
        context.getClass();
        super.attachBaseContext(di2.m9282r(context));
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        setRequestedOrientation(6);
        n16.m16421m(this);
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.layoutInDisplayCutoutMode = 1;
        getWindow().setAttributes(attributes);
        sy6 sy6Var = new sy6(getWindow(), getWindow().getDecorView());
        ((hl7) sy6Var.f36209b).mo1229x();
        View decorView = getWindow().getDecorView();
        a15 a15Var = new a15(sy6Var, (byte) 0);
        Field field = rs5.f34281a;
        ls5.m15446b(decorView, a15Var);
        super.onCreate(bundle);
        wl0.m22186a(this, new gm0(1021436522, true, new C0021ak(getIntent().getStringExtra("EXTRA_PACKAGE_NAME"), (byte) 17)));
        gm3 onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.getClass();
        mx0.m16307e(onBackPressedDispatcher, null, new ha3(this, (byte) 25), 3);
    }
}
