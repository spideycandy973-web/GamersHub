package frb.axeron.app;

import android.content.Context;
import android.os.Bundle;
import androidx.activity.ComponentActivity;
import p000.di2;
import p000.n16;
import p000.v86;
import p000.wl0;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class VortexActivity extends ComponentActivity {
    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    public final void attachBaseContext(Context context) {
        context.getClass();
        super.attachBaseContext(di2.m9282r(context));
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        if (bundle == null) {
            setRequestedOrientation(7);
        }
        n16.m16421m(this);
        super.onCreate(bundle);
        wl0.m22186a(this, v86.f40001b);
    }
}
