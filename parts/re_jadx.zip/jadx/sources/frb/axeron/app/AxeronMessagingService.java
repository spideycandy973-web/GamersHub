package frb.axeron.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import com.google.firebase.messaging.FirebaseMessagingService;
import frb.axeron.redcorner.R;
import p000.ek3;
import p000.hb4;
import p000.ib4;
import p000.sy6;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class AxeronMessagingService extends FirebaseMessagingService {
    @Override // com.google.firebase.messaging.FirebaseMessagingService
    /* renamed from: c */
    public final void mo7501c(ib4 ib4Var) {
        Bundle bundle = ib4Var.f18401a;
        if (ib4Var.f18403c == null && sy6.m20031s(bundle)) {
            ib4Var.f18403c = new hb4(new sy6(bundle));
        }
        hb4 hb4Var = ib4Var.f18403c;
        if (hb4Var != null) {
            m11336f(hb4Var.f17008a, hb4Var.f17009b);
            return;
        }
        if (ib4Var.m13233a().isEmpty()) {
            return;
        }
        String str = (String) ib4Var.m13233a().get("title");
        String str2 = (String) ib4Var.m13233a().get("body");
        if (str == null && str2 == null) {
            return;
        }
        m11336f(str, str2);
    }

    @Override // com.google.firebase.messaging.FirebaseMessagingService
    /* renamed from: d */
    public final void mo7502d(String str) {
        str.getClass();
    }

    @Override // com.google.firebase.messaging.FirebaseMessagingService
    /* renamed from: e */
    public final void mo7503e(String str) {
        str.getClass();
    }

    /* renamed from: f */
    public final void m11336f(String str, String str2) {
        Intent intent = new Intent(this, (Class<?>) VortexActivity.class);
        intent.addFlags(67108864);
        PendingIntent activity = PendingIntent.getActivity(this, 0, intent, 1140850688);
        ek3 ek3Var = new ek3(this, "fcm_default_channel");
        ek3Var.f11989u.icon = R.drawable.axgc_new;
        ek3Var.f11973e = ek3.m10157c(str);
        ek3Var.f11974f = ek3.m10157c(str2);
        ek3Var.m10160d(16, true);
        ek3Var.f11975g = activity;
        ek3Var.f11978j = 1;
        Object systemService = getSystemService("notification");
        systemService.getClass();
        NotificationManager notificationManager = (NotificationManager) systemService;
        notificationManager.createNotificationChannel(new NotificationChannel("fcm_default_channel", "Cloud Messaging", 4));
        notificationManager.notify((int) System.currentTimeMillis(), ek3Var.m10159b());
    }
}
