package frb.axeron.app.activation;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import frb.axeron.app.VortexActivity;
import frb.axeron.redcorner.R;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import p000.AbstractC1479qt;
import p000.C1816z4;
import p000.ak3;
import p000.ek3;
import p000.fn5;
import p000.gb4;
import p000.j03;
import p000.ka1;
import p000.ls0;
import p000.m35;
import p000.ms3;
import p000.qp7;
import p000.r41;
import p000.v86;
import p000.xk1;
import p000.xy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class PairingWatcherService extends Service {

    /* renamed from: d */
    public static final /* synthetic */ int f14250d = 0;

    /* renamed from: a */
    public final ls0 f14251a;

    /* renamed from: b */
    public m35 f14252b;

    /* renamed from: c */
    public m35 f14253c;

    public PairingWatcherService() {
        r41 r41Var = ka1.f21425a;
        this.f14251a = fn5.m11125b(j03.f19481a.plus(qp7.m18391b()));
    }

    /* renamed from: a */
    public static Notification m11337a(PairingWatcherService pairingWatcherService, int i, boolean z, Object[] objArr, int i2) {
        int i3;
        boolean z2 = (i2 & 2) == 0;
        boolean z3 = (i2 & 4) == 0;
        boolean z4 = (i2 & 8) != 0 ? false : z;
        boolean z5 = (i2 & 16) == 0;
        pairingWatcherService.getClass();
        PendingIntent activity = PendingIntent.getActivity(pairingWatcherService, 0, new Intent(pairingWatcherService, (Class<?>) VortexActivity.class).addFlags(67108864), 201326592);
        Intent action = new Intent(pairingWatcherService, (Class<?>) PairingWatcherService.class).setAction("frb.axeron.app.activation.STOP");
        action.getClass();
        PendingIntent service = PendingIntent.getService(pairingWatcherService, 0, action, 201326592);
        boolean z6 = i == R.string.activation_notif_success || i == R.string.activation_notif_failed || i == R.string.activation_notif_failed_key_expired || i == R.string.activation_notif_failed_unreachable || i == R.string.activation_notif_failed_wrong_code;
        boolean z7 = z2 || z3 || z4 || z5;
        ek3 ek3Var = new ek3(pairingWatcherService, "wireless_debugging_pairing");
        ek3Var.f11989u.icon = R.drawable.axgc_new;
        ek3Var.f11973e = ek3.m10157c(pairingWatcherService.getString(R.string.activation_title));
        ek3Var.f11974f = ek3.m10157c(pairingWatcherService.getString(i, Arrays.copyOf(objArr, objArr.length)));
        ek3Var.m10160d(2, !z6);
        ek3Var.m10160d(8, !z7);
        ek3Var.f11978j = z7 ? 1 : -1;
        ek3Var.f11975g = activity;
        ek3Var.m10158a(0, service, pairingWatcherService.getString(R.string.activation_stop_button));
        if (z2) {
            gb4 gb4Var = new gb4(pairingWatcherService.getString(R.string.activation_code_hint), new Bundle(), new HashSet());
            PendingIntent foregroundService = PendingIntent.getForegroundService(pairingWatcherService, 0, new Intent(pairingWatcherService, (Class<?>) PairingWatcherService.class).setAction("frb.axeron.app.activation.REPLY"), 167772160);
            String string = pairingWatcherService.getString(R.string.activation_code_input_label);
            Bundle bundle = new Bundle();
            CharSequence m10157c = ek3.m10157c(string);
            ArrayList arrayList = new ArrayList();
            arrayList.add(gb4Var);
            ArrayList arrayList2 = new ArrayList();
            ArrayList arrayList3 = new ArrayList();
            int size = arrayList.size();
            int i4 = 0;
            while (i4 < size) {
                Object obj = arrayList.get(i4);
                i4++;
                gb4 gb4Var2 = (gb4) obj;
                gb4Var2.getClass();
                arrayList3.add(gb4Var2);
            }
            if (!arrayList2.isEmpty()) {
            }
            ek3Var.f11970b.add(new ak3(null, m10157c, foregroundService, bundle, arrayList3.isEmpty() ? null : (gb4[]) arrayList3.toArray(new gb4[arrayList3.size()])));
        }
        if (z3) {
            i3 = 201326592;
            ek3Var.m10158a(0, PendingIntent.getForegroundService(pairingWatcherService, 0, new Intent(pairingWatcherService, (Class<?>) PairingWatcherService.class).setAction("frb.axeron.app.activation.RETRY"), 201326592), pairingWatcherService.getString(R.string.activation_retry_button));
        } else {
            i3 = 201326592;
        }
        if (z5) {
            ek3Var.m10158a(0, PendingIntent.getForegroundService(pairingWatcherService, 0, new Intent(pairingWatcherService, (Class<?>) PairingWatcherService.class).setAction("frb.axeron.app.activation.REPAIR"), i3), pairingWatcherService.getString(R.string.activation_repair_button));
        }
        if (z4) {
            ek3Var.m10158a(0, PendingIntent.getActivity(pairingWatcherService, 0, new Intent("android.settings.APPLICATION_DEVELOPMENT_SETTINGS"), i3), pairingWatcherService.getString(R.string.activation_open_settings));
        }
        Notification m10159b = ek3Var.m10159b();
        m10159b.getClass();
        return m10159b;
    }

    /* renamed from: b */
    public final boolean m11338b(Notification notification) {
        try {
            int i = Build.VERSION.SDK_INT;
            if (i < 34) {
                startForeground(2001, notification);
                return true;
            }
            if (i >= 34) {
                AbstractC1479qt.m18546r(this, 2001, notification, 1073741824);
                return true;
            }
            if (i >= 29) {
                AbstractC1479qt.m18544p(this, 2001, notification, 1073741824);
                return true;
            }
            startForeground(2001, notification);
            return true;
        } catch (Exception e) {
            Log.w("PairingWatcherService", "Failed to start foreground", e);
            return false;
        }
    }

    /* renamed from: c */
    public final void m11339c(xy1 xy1Var) {
        if (this.f14252b != null) {
            return;
        }
        this.f14252b = v86.m21284K(this.f14251a, null, null, new xk1(this, null, (byte) 21), 3);
        xy1Var.invoke();
    }

    /* renamed from: d */
    public final void m11340d(long j) {
        m35 m35Var = this.f14252b;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        this.f14252b = null;
        m35 m35Var2 = this.f14253c;
        if (m35Var2 != null) {
            m35Var2.mo1322a(null);
        }
        this.f14253c = v86.m21284K(this.f14251a, null, null, new ms3(j, this, null), 3);
    }

    /* renamed from: e */
    public final void m11341e(Notification notification) {
        ((NotificationManager) getSystemService(NotificationManager.class)).notify(2001, notification);
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(new NotificationChannel("wireless_debugging_pairing", getString(R.string.activation_notif_channel), 4));
    }

    @Override // android.app.Service
    public final void onDestroy() {
        C1816z4 c1816z4 = C1816z4.f46500a;
        C1816z4.m23800q();
        m35 m35Var = this.f14252b;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        m35 m35Var2 = this.f14253c;
        if (m35Var2 != null) {
            m35Var2.mo1322a(null);
        }
        super.onDestroy();
    }

    /* JADX WARN: Code restructure failed: missing block: B:119:0x01bd, code lost:
    
        if (r12 == false) goto L115;
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:106:0x01b6  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x01b9  */
    /* JADX WARN: Removed duplicated region for block: B:111:0x01c2 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:115:0x01d1  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x01d5  */
    @Override // android.app.Service
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final int onStartCommand(android.content.Intent r11, int r12, int r13) {
        /*
            Method dump skipped, instructions count: 496
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.app.activation.PairingWatcherService.onStartCommand(android.content.Intent, int, int):int");
    }
}
