package frb.axeron.loosening;

import android.os.Bundle;
import android.util.Log;
import frb.axeron.base.FeatureFactoryBase;
import p000.au2;
import p000.ka1;
import p000.n22;
import p000.o60;
import p000.r41;
import p000.t75;
import p000.v86;
import p000.w31;
import p000.xy2;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class LooseningFeature extends FeatureFactoryBase {
    /* renamed from: C */
    public static Object m11378C(String str, t75 t75Var) {
        r41 r41Var = ka1.f21425a;
        return v86.m21301a0(w31.f41501b, new o60(str, null, (byte) 7), t75Var);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        Log.i("LooseningFeature", "Applying session performance settings");
        au2 m11349q = m11349q();
        r41 r41Var = ka1.f21425a;
        v86.m21284K(m11349q, w31.f41501b, null, new xy2(this, null, (byte) 0), 2);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        Log.i("LooseningFeature", "Restoring default performance settings");
        r41 r41Var = ka1.f21425a;
        v86.m21284K(n22.f26792a, w31.f41501b, null, new xy2(this, null, (byte) 1), 2);
        super.mo11334u();
    }
}
