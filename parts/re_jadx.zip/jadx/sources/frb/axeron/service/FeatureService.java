package frb.axeron.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import com.applovin.shadow.okhttp3.internal.p007ws.WebSocketProtocol;
import frb.axeron.base.FeatureFactoryBase;
import frb.axeron.crosshair.CrosshairMenuFeature;
import frb.axeron.redcorner.R;
import p000.AbstractC1343nc;
import p000.AbstractC1479qt;
import p000.C1604u0;
import p000.bn1;
import p000.d33;
import p000.di2;
import p000.ei2;
import p000.ek3;
import p000.fn5;
import p000.j03;
import p000.ka1;
import p000.kn5;
import p000.ls0;
import p000.ma2;
import p000.md4;
import p000.nd4;
import p000.ns0;
import p000.nz1;
import p000.o65;
import p000.qp7;
import p000.r41;
import p000.rm1;
import p000.t75;
import p000.tn1;
import p000.un1;
import p000.v86;
import p000.wn1;
import p000.y35;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class FeatureService extends Service implements ma2 {

    /* renamed from: h */
    public static volatile FeatureService f14430h;

    /* renamed from: a */
    public bn1 f14431a;

    /* renamed from: b */
    public final o65 f14432b;

    /* renamed from: c */
    public final ls0 f14433c;

    /* renamed from: d */
    public int f14434d;

    /* renamed from: e */
    public int f14435e;

    /* renamed from: f */
    public Notification f14436f;

    /* renamed from: g */
    public boolean f14437g;

    public FeatureService() {
        o65 m18391b = qp7.m18391b();
        this.f14432b = m18391b;
        r41 r41Var = ka1.f21425a;
        this.f14433c = fn5.m11125b(j03.f19481a.plus(m18391b));
        this.f14435e = -1;
    }

    @Override // android.app.Service, android.content.ContextWrapper
    public final void attachBaseContext(Context context) {
        context.getClass();
        super.attachBaseContext(di2.m9282r(context));
    }

    /* renamed from: b */
    public final void m11513b(Bundle bundle, Class cls, String str) {
        Object md4Var;
        if (ei2.m10070i(str, "ACTION_CALL_FEATURE") && !this.f14437g) {
            try {
                startForegroundService(new Intent(this, (Class<?>) FeatureService.class));
                md4Var = kn5.f22076a;
            } catch (Throwable th) {
                md4Var = new md4(th);
            }
            Throwable m16656b = nd4.m16656b(md4Var);
            if (m16656b != null) {
                Log.e("FeatureService", "Could not promote the bound service to a started one", m16656b);
            }
        }
        if (str != null) {
            int hashCode = str.hashCode();
            ns0 ns0Var = null;
            ls0 ls0Var = this.f14433c;
            if (hashCode == -2040212700) {
                if (str.equals("ACTION_PAUSE_FEATURE")) {
                    v86.m21284K(ls0Var, null, null, new un1(this, cls, ns0Var, (byte) 1), 3);
                }
            } else if (hashCode == 1091396190) {
                if (str.equals("ACTION_KILL_FEATURE")) {
                    v86.m21284K(ls0Var, null, null, new un1(this, cls, ns0Var, (byte) 0), 3);
                }
            } else if (hashCode == 1549443422 && str.equals("ACTION_CALL_FEATURE")) {
                v86.m21284K(ls0Var, null, null, new C1604u0(this, cls, bundle, ns0Var, (byte) 20), 3);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x002c  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* renamed from: d */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11514d(boolean r5, p000.os0 r6) {
        /*
            r4 = this;
            boolean r0 = r6 instanceof p000.vn1
            if (r0 == 0) goto L13
            r0 = r6
            vn1 r0 = (p000.vn1) r0
            int r1 = r0.f40702c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f40702c = r1
            goto L18
        L13:
            vn1 r0 = new vn1
            r0.<init>(r4, r6)
        L18:
            java.lang.Object r6 = r0.f40700a
            int r1 = r0.f40702c
            r2 = 0
            r3 = 1
            if (r1 == 0) goto L2c
            if (r1 != r3) goto L26
            p000.v86.m21297X(r6)
            goto L4b
        L26:
            java.lang.String r4 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r4)
            return r2
        L2c:
            p000.v86.m21297X(r6)
            bn1 r6 = r4.f14431a
            java.lang.String r1 = "registry"
            if (r5 == 0) goto L46
            if (r6 == 0) goto L42
            r0.f40702c = r3
            java.lang.Object r5 = r6.m1851i(r0)
            nu0 r6 = p000.nu0.f28013a
            if (r5 != r6) goto L4b
            return r6
        L42:
            p000.ei2.m10039H(r1)
            throw r2
        L46:
            if (r6 == 0) goto L57
            r6.m1847b()
        L4b:
            r4.stopForeground(r3)
            r5 = 0
            r4.f14437g = r5
            r4.stopSelf()
            kn5 r4 = p000.kn5.f22076a
            return r4
        L57:
            p000.ei2.m10039H(r1)
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.service.FeatureService.m11514d(boolean, os0):java.lang.Object");
    }

    /* renamed from: e */
    public final boolean m11515e(Notification notification, int i) {
        try {
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 34) {
                AbstractC1479qt.m18546r(this, WebSocketProtocol.CLOSE_CLIENT_GOING_AWAY, notification, i);
                return true;
            }
            if (i2 >= 29) {
                AbstractC1479qt.m18544p(this, WebSocketProtocol.CLOSE_CLIENT_GOING_AWAY, notification, i);
                return true;
            }
            startForeground(WebSocketProtocol.CLOSE_CLIENT_GOING_AWAY, notification);
            return true;
        } catch (Exception e) {
            if (Build.VERSION.SDK_INT < 31 || !AbstractC1343nc.m16643w(e)) {
                Log.e("FeatureService", "startForeground failed (type=" + i + ")", e);
                return false;
            }
            Log.e("FeatureService", "Foreground service start not allowed (type=" + i + ")", e);
            return false;
        }
    }

    @Override // p000.ma2
    /* renamed from: g */
    public final y35 mo409g() {
        bn1 bn1Var = this.f14431a;
        if (bn1Var != null) {
            return bn1Var.f2713g;
        }
        ei2.m10039H("registry");
        throw null;
    }

    @Override // p000.ma2
    /* renamed from: h */
    public final Object mo410h(Class cls, Class cls2, nz1 nz1Var, t75 t75Var) {
        bn1 bn1Var = this.f14431a;
        if (bn1Var != null) {
            return bn1Var.mo410h(cls, cls2, nz1Var, t75Var);
        }
        ei2.m10039H("registry");
        throw null;
    }

    /* renamed from: i */
    public final void m11516i(boolean z) {
        Notification m10159b;
        int i = this.f14434d;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 34) {
            i = (i & 1073741856) | 1073741824;
        } else if (i2 < 29) {
            i = 0;
        }
        if (z || i != this.f14435e || (m10159b = this.f14436f) == null) {
            Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(getPackageName());
            PendingIntent activity = launchIntentForPackage != null ? PendingIntent.getActivity(this, 0, launchIntentForPackage, 67108864) : null;
            Intent intent = new Intent(this, (Class<?>) FeatureService.class);
            intent.setAction("ACTION_KILL_ALL");
            PendingIntent service = PendingIntent.getService(this, WebSocketProtocol.CLOSE_CLIENT_GOING_AWAY, intent, 67108864);
            ek3 ek3Var = new ek3(this, "crosshair_channel");
            ek3Var.f11973e = ek3.m10157c("Game Corner: Service");
            ek3Var.f11989u.icon = R.drawable.axgc_new;
            ek3Var.f11982n = "service";
            ek3Var.m10160d(2, true);
            ek3Var.f11987s = true;
            ek3Var.f11978j = -1;
            ek3Var.m10158a(0, service, "STOP SERVICE");
            if (activity != null) {
                ek3Var.f11975g = activity;
            }
            m10159b = ek3Var.m10159b();
            m10159b.getClass();
            this.f14436f = m10159b;
        }
        if (m11515e(m10159b, i)) {
            this.f14435e = i;
            return;
        }
        int i3 = i2 < 34 ? 0 : 1073741824;
        if (!m11515e(m10159b, i3)) {
            if (this.f14435e == -1) {
                stopSelf();
            }
        } else {
            this.f14434d = 0;
            this.f14435e = i3;
            Log.w("FeatureService", "Recovered from startForeground failure by falling back to type=" + i3);
        }
    }

    @Override // p000.ma2
    /* renamed from: k */
    public final FeatureFactoryBase mo411k(Class cls) {
        bn1 bn1Var = this.f14431a;
        if (bn1Var != null) {
            return bn1Var.mo411k(CrosshairMenuFeature.class);
        }
        ei2.m10039H("registry");
        throw null;
    }

    /* renamed from: l */
    public final void m11517l(int i, boolean z) {
        int i2 = this.f14434d;
        this.f14434d = z ? i2 | i : i2 & (~i);
        m11516i(false);
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        intent.getClass();
        return new tn1(this);
    }

    /* JADX WARN: Code restructure failed: missing block: B:24:0x008d, code lost:
    
        if ((r13 | (r6 ^ (-3036666899081369764L))) == 0) goto L41;
     */
    @Override // android.app.Service, android.content.ComponentCallbacks
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onConfigurationChanged(android.content.res.Configuration r22) {
        /*
            Method dump skipped, instructions count: 315
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.service.FeatureService.onConfigurationChanged(android.content.res.Configuration):void");
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(new NotificationChannel("crosshair_channel", "Feature Service", 2));
        m11516i(true);
        bn1 bn1Var = new bn1(this);
        bn1Var.f2708b = new d33(this, (byte) 21);
        this.f14431a = bn1Var;
        f14430h = this;
        v86.m21284K(this.f14433c, null, null, new wn1(this, null, (byte) 1), 3);
    }

    @Override // android.app.Service
    public final void onDestroy() {
        if (f14430h == this) {
            f14430h = null;
        }
        bn1 bn1Var = this.f14431a;
        if (bn1Var != null) {
            bn1Var.m1847b();
        }
        this.f14432b.mo1322a(null);
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        this.f14437g = true;
        m11516i(false);
        byte b = 3;
        ls0 ls0Var = this.f14433c;
        ns0 ns0Var = null;
        if (intent == null) {
            v86.m21284K(ls0Var, null, null, new wn1(this, ns0Var, (byte) 2), 3);
            return 1;
        }
        Bundle bundleExtra = intent.getBundleExtra("data");
        Bundle bundleExtra2 = intent.getBundleExtra("feature_bundle");
        IBinder binder = bundleExtra2 != null ? bundleExtra2.getBinder("feature_binder") : null;
        rm1 rm1Var = binder instanceof rm1 ? (rm1) binder : null;
        Class cls = rm1Var != null ? rm1Var.f33965a : null;
        String action = intent.getAction();
        if (action != null) {
            int hashCode = action.hashCode();
            if (hashCode != -747938551) {
                if (hashCode == -330187705 && action.equals("ACTION_UPDATE_LOCALE")) {
                    m11516i(true);
                    return 1;
                }
            } else if (action.equals("ACTION_KILL_ALL")) {
                v86.m21284K(ls0Var, null, null, new wn1(this, ns0Var, b), 3);
                return 1;
            }
        }
        m11513b(bundleExtra, cls, intent.getAction());
        return 1;
    }
}
