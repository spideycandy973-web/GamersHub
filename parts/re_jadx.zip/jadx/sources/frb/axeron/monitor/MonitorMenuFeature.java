package frb.axeron.monitor;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import p000.ViewOnTouchListenerC1541sh;
import p000.di2;
import p000.ei2;
import p000.gm0;
import p000.i85;
import p000.ib3;
import p000.it3;
import p000.kb3;
import p000.lb3;
import p000.mp0;
import p000.o60;
import p000.t75;
import p000.tb3;
import p000.v86;
import p000.va3;
import p000.wa3;
import p000.z80;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class MonitorMenuFeature extends FloatingFactoryBase implements wa3 {

    /* renamed from: q */
    public zm5 f14386q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14387r;

    /* renamed from: s */
    public final i85 f14388s = new i85(new ib3(this, 0));

    /* renamed from: t */
    public final va3 f14389t = new va3();

    /* renamed from: u */
    public final it3 f14390u = z80.m23867J(Boolean.FALSE);

    @Override // p000.wa3
    /* renamed from: b */
    public final Object mo11440b(va3 va3Var, t75 t75Var) {
        return ((tb3) this.f14388s.getValue()).m20250b(new mp0(va3Var, (byte) 1), t75Var);
    }

    @Override // p000.wa3
    /* renamed from: e */
    public final void mo11441e() {
        v86.m21284K(m11349q(), null, null, new o60(this, null, (byte) 10), 3);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: l */
    public final void mo11344l(Context context) {
        super.mo11344l(context);
        v86.m21284K(m11349q(), null, null, new lb3(this, null, (byte) 0), 3);
    }

    @Override // frb.axeron.base.FloatingFactoryBase, frb.axeron.base.FeatureFactoryBase
    /* renamed from: s */
    public final void mo11351s(Configuration configuration) {
        WindowManager.LayoutParams layoutParams;
        configuration.getClass();
        super.mo11351s(configuration);
        WindowManager.LayoutParams layoutParams2 = this.f14387r;
        if (layoutParams2 != null) {
            if (configuration.orientation == 1) {
                layoutParams2.gravity = 81;
                layoutParams2.x = 0;
                layoutParams2.y = di2.m9248W(18, m11348p());
                layoutParams = this.f14387r;
                if (layoutParams == null) {
                    ei2.m10039H("params");
                    throw null;
                }
                layoutParams.windowAnimations = R.style.WAnim_InBottom_OutBottom;
            } else {
                layoutParams2.gravity = 19;
                layoutParams2.x = di2.m9248W(18, m11348p());
                layoutParams = this.f14387r;
                if (layoutParams == null) {
                    ei2.m10039H("params");
                    throw null;
                }
                layoutParams.y = 0;
                layoutParams.windowAnimations = R.style.WAnim_InLeft_OutLeft;
            }
            View view = this.f14386q;
            if (view != null) {
                try {
                    updateViewLayout(view, layoutParams);
                } catch (Exception unused) {
                }
            }
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 262952, -3);
        if (m11348p().getResources().getConfiguration().orientation == 1) {
            layoutParams.gravity = 81;
            layoutParams.y = di2.m9248W(18, m11348p());
            layoutParams.windowAnimations = R.style.WAnim_InBottom_OutBottom;
        } else {
            layoutParams.gravity = 19;
            layoutParams.x = di2.m9248W(18, m11348p());
            layoutParams.windowAnimations = R.style.WAnim_InLeft_OutLeft;
        }
        this.f14387r = layoutParams;
        zm5 m11345m = m11345m(false, new gm0(-44456539, true, new kb3(this, (byte) 0)));
        this.f14386q = m11345m;
        m11345m.setOnTouchListener(new ViewOnTouchListenerC1541sh(this, (byte) 8));
        zm5 zm5Var = this.f14386q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14387r;
        if (layoutParams2 != null) {
            addView(zm5Var, layoutParams2);
        } else {
            ei2.m10039H("params");
            throw null;
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        zm5 zm5Var = this.f14386q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(zm5Var);
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: w */
    public final void mo11352w() {
        super.mo11352w();
        zm5 zm5Var = this.f14386q;
        if (zm5Var != null) {
            m11358D(zm5Var, null);
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: x */
    public final void mo11353x() {
        super.mo11353x();
        zm5 zm5Var = this.f14386q;
        if (zm5Var != null) {
            WindowManager.LayoutParams layoutParams = this.f14387r;
            if (layoutParams != null) {
                m11361H(zm5Var, layoutParams, null);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        }
    }
}
