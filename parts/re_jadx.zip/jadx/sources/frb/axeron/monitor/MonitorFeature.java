package frb.axeron.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.WindowManager;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import java.util.ArrayList;
import java.util.Set;
import p000.C0122cl;
import p000.C0950f;
import p000.at0;
import p000.ce1;
import p000.d90;
import p000.di2;
import p000.ds3;
import p000.ei2;
import p000.el4;
import p000.ft3;
import p000.gm0;
import p000.i85;
import p000.it3;
import p000.kn5;
import p000.l11;
import p000.m35;
import p000.m55;
import p000.ns0;
import p000.p50;
import p000.sx8;
import p000.t75;
import p000.v86;
import p000.va3;
import p000.wa3;
import p000.xa3;
import p000.z80;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class MonitorFeature extends FloatingFactoryBase implements wa3 {

    /* renamed from: A */
    public int f14372A;

    /* renamed from: C */
    public m35 f14374C;

    /* renamed from: D */
    public boolean f14375D;

    /* renamed from: q */
    public zm5 f14376q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14377r;

    /* renamed from: s */
    public zm5 f14378s;

    /* renamed from: t */
    public WindowManager.LayoutParams f14379t;

    /* renamed from: y */
    public el4 f14384y;

    /* renamed from: z */
    public int f14385z;

    /* renamed from: u */
    public final ft3 f14380u = new ft3(0);

    /* renamed from: v */
    public final ft3 f14381v = new ft3(0);

    /* renamed from: w */
    public final i85 f14382w = new i85(new at0(this, 26));

    /* renamed from: x */
    public final it3 f14383x = z80.m23867J(new va3());

    /* renamed from: B */
    public long f14373B = 0;

    /* renamed from: I */
    public final int m11433I() {
        return (-(((Number) this.f14382w.getValue()).intValue() + this.f14380u.m11534h())) / 2;
    }

    /* renamed from: J */
    public final String m11434J() {
        return m11348p().getResources().getConfiguration().orientation == 2 ? "norm_anchor_land" : "norm_anchor_port";
    }

    /* renamed from: K */
    public final ds3 m11435K() {
        String m11434J = m11434J();
        p50 p50Var = sx8.f36147A;
        if (p50Var == null) {
            C0950f.m10585p("AppPreferences must be initialized in Application.onCreate()");
            return null;
        }
        SharedPreferences sharedPreferences = p50Var.getSharedPreferences("floating_monitor_prefs", 0);
        sharedPreferences.getClass();
        if (sharedPreferences.getInt("layout_version", 0) != 1) {
            SharedPreferences.Editor edit = sharedPreferences.edit();
            edit.getClass();
            Set<String> keySet = sharedPreferences.getAll().keySet();
            ArrayList arrayList = new ArrayList();
            for (Object obj : keySet) {
                String str = (String) obj;
                str.getClass();
                if (m55.m15777Y(str, "_x", false) || m55.m15777Y(str, "_y", false)) {
                    arrayList.add(obj);
                }
            }
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                Object obj2 = arrayList.get(i);
                i++;
                edit.remove((String) obj2);
            }
            edit.putInt("layout_version", 1);
            edit.apply();
        }
        p50 p50Var2 = sx8.f36147A;
        if (p50Var2 == null) {
            C0950f.m10585p("AppPreferences must be initialized in Application.onCreate()");
            return null;
        }
        SharedPreferences sharedPreferences2 = p50Var2.getSharedPreferences("floating_monitor_prefs", 0);
        sharedPreferences2.getClass();
        if (!sharedPreferences2.contains(m11434J.concat("_x"))) {
            return null;
        }
        float f = sharedPreferences2.getFloat(m11434J.concat("_x"), 0.0f);
        float f2 = sharedPreferences2.getFloat(m11434J.concat("_y"), 0.0f);
        if (0.0f <= f && f <= 1.0f && 0.0f <= f2 && f2 <= 1.0f) {
            return new ds3(Float.valueOf(f), Float.valueOf(f2));
        }
        SharedPreferences.Editor edit2 = sharedPreferences2.edit();
        edit2.getClass();
        edit2.remove(m11434J.concat("_x"));
        edit2.remove(m11434J.concat("_y"));
        edit2.apply();
        return null;
    }

    /* renamed from: L */
    public final void m11436L() {
        WindowManager.LayoutParams layoutParams = this.f14379t;
        if (layoutParams == null) {
            ei2.m10039H("paramsInfo");
            throw null;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14377r;
        if (layoutParams2 == null) {
            ei2.m10039H("paramsAnchor");
            throw null;
        }
        layoutParams.y = layoutParams2.y;
        int i = layoutParams2.x;
        i85 i85Var = this.f14382w;
        ft3 ft3Var = this.f14381v;
        ft3 ft3Var2 = this.f14380u;
        if (i > 0) {
            layoutParams.x = (i - ((ft3Var.m11534h() + ft3Var2.m11534h()) / 2)) - ((Number) i85Var.getValue()).intValue();
        } else {
            layoutParams.x = ((Number) i85Var.getValue()).intValue() + ((ft3Var.m11534h() + ft3Var2.m11534h()) / 2) + i;
        }
    }

    /* renamed from: M */
    public final void m11437M(WindowManager.LayoutParams layoutParams, zm5 zm5Var) {
        Context m11348p = m11348p();
        int width = zm5Var.getWidth();
        int height = zm5Var.getHeight();
        el4 el4Var = this.f14384y;
        if (el4Var == null) {
            ei2.m10039H("specs");
            throw null;
        }
        ds3 m2511b = ce1.m2511b(layoutParams, m11348p, width, height, el4Var);
        float floatValue = ((Number) m2511b.f10834a).floatValue();
        float floatValue2 = ((Number) m2511b.f10835b).floatValue();
        String m11434J = m11434J();
        p50 p50Var = sx8.f36147A;
        if (p50Var == null) {
            C0950f.m10585p("AppPreferences must be initialized in Application.onCreate()");
            return;
        }
        SharedPreferences sharedPreferences = p50Var.getSharedPreferences("floating_monitor_prefs", 0);
        sharedPreferences.getClass();
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.getClass();
        edit.putFloat(m11434J.concat("_x"), floatValue);
        edit.putFloat(m11434J.concat("_y"), floatValue2);
        edit.putInt("layout_version", 1);
        edit.apply();
    }

    /* renamed from: N */
    public final boolean m11438N() {
        ft3 ft3Var = this.f14380u;
        if (ft3Var.m11534h() <= 0) {
            return false;
        }
        ft3 ft3Var2 = this.f14381v;
        if (ft3Var2.m11534h() <= 0) {
            return false;
        }
        try {
            int m9248W = di2.m9248W(20, m11348p());
            int m9248W2 = di2.m9248W(20, m11348p());
            if (this.f14375D) {
                WindowManager.LayoutParams layoutParams = this.f14377r;
                if (layoutParams == null) {
                    ei2.m10039H("paramsAnchor");
                    throw null;
                }
                layoutParams.x = m11433I();
            }
            zm5 zm5Var = this.f14376q;
            if (zm5Var == null) {
                ei2.m10039H("viewAnchor");
                throw null;
            }
            WindowManager.LayoutParams layoutParams2 = this.f14377r;
            if (layoutParams2 == null) {
                ei2.m10039H("paramsAnchor");
                throw null;
            }
            int m11534h = ft3Var2.m11534h();
            el4 el4Var = this.f14384y;
            if (el4Var == null) {
                ei2.m10039H("specs");
                throw null;
            }
            ce1.m2514e(this, zm5Var, layoutParams2, m11534h, m9248W, el4Var, 4080);
            m11436L();
            zm5 zm5Var2 = this.f14378s;
            if (zm5Var2 == null) {
                ei2.m10039H("viewInfo");
                throw null;
            }
            WindowManager.LayoutParams layoutParams3 = this.f14379t;
            if (layoutParams3 == null) {
                ei2.m10039H("paramsInfo");
                throw null;
            }
            int m11534h2 = ft3Var.m11534h();
            el4 el4Var2 = this.f14384y;
            if (el4Var2 != null) {
                ce1.m2514e(this, zm5Var2, layoutParams3, m11534h2, m9248W2, el4Var2, 4080);
                return true;
            }
            ei2.m10039H("specs");
            throw null;
        } catch (Exception unused) {
            return true;
        }
    }

    /* renamed from: O */
    public final void m11439O() {
        if (m11438N()) {
            m35 m35Var = this.f14374C;
            ns0 ns0Var = null;
            if (m35Var != null) {
                m35Var.mo1322a(null);
            }
            this.f14374C = v86.m21284K(m11349q(), null, null, new C0122cl((Object) this, ns0Var, (byte) 27), 3);
        }
    }

    @Override // p000.wa3
    /* renamed from: b */
    public final Object mo11440b(va3 va3Var, t75 t75Var) {
        ((va3) this.f14383x.getValue()).m21372k(va3Var.m21371j(va3Var.f40103a.f389a));
        ds3 m11435K = m11435K();
        if (m11435K != null) {
            float floatValue = ((Number) m11435K.f10834a).floatValue();
            float floatValue2 = ((Number) m11435K.f10835b).floatValue();
            int m9248W = di2.m9248W(20, m11348p());
            WindowManager.LayoutParams layoutParams = this.f14377r;
            if (layoutParams == null) {
                ei2.m10039H("paramsAnchor");
                throw null;
            }
            Context m11348p = m11348p();
            el4 el4Var = this.f14384y;
            if (el4Var == null) {
                ei2.m10039H("specs");
                throw null;
            }
            ce1.m2510a(layoutParams, m11348p, floatValue, floatValue2, m9248W, m9248W, el4Var);
            m11439O();
        }
        return kn5.f22076a;
    }

    @Override // p000.wa3
    /* renamed from: e */
    public final void mo11441e() {
        va3 va3Var = (va3) this.f14383x.getValue();
        va3Var.m21372k(va3Var.f40103a);
        d90.m8862m("norm_anchor_port");
        d90.m8862m("norm_anchor_land");
        d90.m8862m("norm_info_port");
        d90.m8862m("norm_info_land");
        this.f14375D = true;
        WindowManager.LayoutParams layoutParams = this.f14377r;
        if (layoutParams == null) {
            ei2.m10039H("paramsAnchor");
            throw null;
        }
        layoutParams.x = m11433I();
        WindowManager.LayoutParams layoutParams2 = this.f14377r;
        if (layoutParams2 == null) {
            ei2.m10039H("paramsAnchor");
            throw null;
        }
        layoutParams2.y = di2.m9248W(52, m11348p());
        m11436L();
        try {
            zm5 zm5Var = this.f14378s;
            if (zm5Var == null) {
                ei2.m10039H("viewInfo");
                throw null;
            }
            WindowManager.LayoutParams layoutParams3 = this.f14379t;
            if (layoutParams3 == null) {
                ei2.m10039H("paramsInfo");
                throw null;
            }
            updateViewLayout(zm5Var, layoutParams3);
            zm5 zm5Var2 = this.f14376q;
            if (zm5Var2 == null) {
                ei2.m10039H("viewAnchor");
                throw null;
            }
            WindowManager.LayoutParams layoutParams4 = this.f14377r;
            if (layoutParams4 == null) {
                ei2.m10039H("paramsAnchor");
                throw null;
            }
            updateViewLayout(zm5Var2, layoutParams4);
            m11439O();
        } catch (Exception unused) {
        }
    }

    @Override // frb.axeron.base.FloatingFactoryBase, frb.axeron.base.FeatureFactoryBase
    /* renamed from: s */
    public final void mo11351s(Configuration configuration) {
        configuration.getClass();
        super.mo11351s(configuration);
        this.f14384y = l11.m15025p(m11348p());
        ds3 m11435K = m11435K();
        if (m11435K != null) {
            int m9248W = di2.m9248W(20, m11348p());
            WindowManager.LayoutParams layoutParams = this.f14377r;
            if (layoutParams == null) {
                ei2.m10039H("paramsAnchor");
                throw null;
            }
            Context m11348p = m11348p();
            float floatValue = ((Number) m11435K.f10834a).floatValue();
            float floatValue2 = ((Number) m11435K.f10835b).floatValue();
            el4 el4Var = this.f14384y;
            if (el4Var == null) {
                ei2.m10039H("specs");
                throw null;
            }
            ce1.m2510a(layoutParams, m11348p, floatValue, floatValue2, m9248W, m9248W, el4Var);
        } else {
            this.f14375D = true;
            WindowManager.LayoutParams layoutParams2 = this.f14377r;
            if (layoutParams2 == null) {
                ei2.m10039H("paramsAnchor");
                throw null;
            }
            layoutParams2.x = m11433I();
            WindowManager.LayoutParams layoutParams3 = this.f14377r;
            if (layoutParams3 == null) {
                ei2.m10039H("paramsAnchor");
                throw null;
            }
            layoutParams3.y = di2.m9248W(52, m11348p());
        }
        m11439O();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        this.f14384y = l11.m15025p(m11348p());
        this.f14380u.m11535i(di2.m9248W(160, m11348p()));
        this.f14381v.m11535i(di2.m9248W(20, m11348p()));
        byte b = 0;
        byte b2 = 1;
        if (bundle != null) {
            va3 va3Var = (va3) this.f14383x.getValue();
            boolean z = bundle.getBoolean("cpu", true);
            boolean z2 = bundle.getBoolean("gpu", false);
            boolean z3 = bundle.getBoolean("ram", true);
            boolean z4 = bundle.getBoolean("ram_usage", false);
            boolean z5 = bundle.getBoolean("battery", true);
            boolean z6 = bundle.getBoolean("temp", true);
            boolean z7 = bundle.getBoolean("fps", true);
            boolean z8 = bundle.getBoolean("time", true);
            va3Var.getClass();
            va3Var.f40104b.setValue(Boolean.valueOf(z));
            va3Var.f40105c.setValue(Boolean.valueOf(z2));
            va3Var.f40106d.setValue(Boolean.valueOf(z3));
            va3Var.f40107e.setValue(Boolean.valueOf(z4));
            va3Var.f40108f.setValue(Boolean.valueOf(z5));
            va3Var.f40109g.setValue(Boolean.valueOf(z6));
            va3Var.f40110h.setValue(Boolean.valueOf(z7));
            va3Var.f40111i.setValue(Boolean.valueOf(z8));
        }
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 824, -3);
        layoutParams.gravity = 81;
        layoutParams.y = di2.m9248W(52, m11348p());
        layoutParams.windowAnimations = R.style.WAnim_InBottom_OutBottom;
        this.f14379t = layoutParams;
        WindowManager.LayoutParams layoutParams2 = new WindowManager.LayoutParams(-2, -2, 2038, 776, -3);
        layoutParams2.gravity = 81;
        layoutParams2.y = di2.m9248W(52, m11348p());
        layoutParams2.windowAnimations = R.style.WAnim_InBottom_OutBottom;
        this.f14377r = layoutParams2;
        ds3 m11435K = m11435K();
        if (m11435K != null) {
            int m9248W = di2.m9248W(20, m11348p());
            WindowManager.LayoutParams layoutParams3 = this.f14377r;
            if (layoutParams3 == null) {
                ei2.m10039H("paramsAnchor");
                throw null;
            }
            Context m11348p = m11348p();
            float floatValue = ((Number) m11435K.f10834a).floatValue();
            float floatValue2 = ((Number) m11435K.f10835b).floatValue();
            el4 el4Var = this.f14384y;
            if (el4Var == null) {
                ei2.m10039H("specs");
                throw null;
            }
            ce1.m2510a(layoutParams3, m11348p, floatValue, floatValue2, m9248W, m9248W, el4Var);
        } else {
            this.f14375D = true;
            WindowManager.LayoutParams layoutParams4 = this.f14377r;
            if (layoutParams4 == null) {
                ei2.m10039H("paramsAnchor");
                throw null;
            }
            layoutParams4.x = m11433I();
        }
        m11436L();
        this.f14378s = m11345m(true, new gm0(1702679834, true, new xa3(this, b)));
        this.f14376q = m11345m(false, new gm0(1803233313, true, new xa3(this, b2)));
        zm5 zm5Var = this.f14378s;
        if (zm5Var == null) {
            ei2.m10039H("viewInfo");
            throw null;
        }
        WindowManager.LayoutParams layoutParams5 = this.f14379t;
        if (layoutParams5 == null) {
            ei2.m10039H("paramsInfo");
            throw null;
        }
        addView(zm5Var, layoutParams5);
        zm5 zm5Var2 = this.f14376q;
        if (zm5Var2 == null) {
            ei2.m10039H("viewAnchor");
            throw null;
        }
        WindowManager.LayoutParams layoutParams6 = this.f14377r;
        if (layoutParams6 != null) {
            addView(zm5Var2, layoutParams6);
        } else {
            ei2.m10039H("paramsAnchor");
            throw null;
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        m35 m35Var = this.f14374C;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        zm5 zm5Var = this.f14378s;
        if (zm5Var == null) {
            ei2.m10039H("viewInfo");
            throw null;
        }
        m11357C(zm5Var);
        zm5 zm5Var2 = this.f14376q;
        if (zm5Var2 == null) {
            ei2.m10039H("viewAnchor");
            throw null;
        }
        m11357C(zm5Var2);
        super.mo11334u();
    }
}
