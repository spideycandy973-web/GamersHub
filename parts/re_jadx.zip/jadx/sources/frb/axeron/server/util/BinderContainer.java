package frb.axeron.server.util;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import p000.t70;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class BinderContainer implements Parcelable {
    public static final t70 CREATOR = new t70();
    private IBinder binder;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public BinderContainer(Parcel parcel) {
        this(parcel.readStrongBinder());
        parcel.getClass();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public final IBinder getBinder() {
        return this.binder;
    }

    public final void setBinder(IBinder iBinder) {
        this.binder = iBinder;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.getClass();
        parcel.writeStrongBinder(this.binder);
    }

    public BinderContainer(IBinder iBinder) {
        this.binder = iBinder;
    }
}
