package frb.axeron.server.util;

import android.util.Log;
import java.util.Arrays;
import java.util.Locale;
import p000.hn0;
import p000.nr4;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class Logger {
    private final String format(String str, Object[] objArr) {
        Locale locale = Locale.ENGLISH;
        Object[] copyOf = Arrays.copyOf(objArr, objArr.length);
        return String.format(locale, str, Arrays.copyOf(copyOf, copyOf.length));
    }

    private final boolean isLoggable(int i) {
        return true;
    }

    private final void report(int i, String str, String str2, String str3, Throwable th) {
        try {
            nr4.f27900a.m16829j(i, str, str2, str3, th);
        } catch (Throwable unused) {
        }
    }

    /* renamed from: d */
    public final void m11496d(String str, String str2, Throwable th) {
        str.getClass();
        str2.getClass();
        th.getClass();
        if (isLoggable(3)) {
            println(3, str, hn0.m12936i(str2, "\n", Log.getStackTraceString(th)));
        }
    }

    /* renamed from: e */
    public final void m11501e(String str, Throwable th, String str2, Object... objArr) {
        str.getClass();
        th.getClass();
        str2.getClass();
        objArr.getClass();
        String format = format(str2, objArr);
        if (isLoggable(6)) {
            println(6, str, format + "\n" + Log.getStackTraceString(th));
        }
        report(6, str, str2, format, th);
    }

    /* renamed from: i */
    public final void m11503i(String str, String str2, Throwable th) {
        str.getClass();
        str2.getClass();
        th.getClass();
        if (isLoggable(4)) {
            println(4, str, hn0.m12936i(str2, "\n", Log.getStackTraceString(th)));
        }
    }

    public final int println(int i, String str, String str2) {
        str.getClass();
        str2.getClass();
        return Log.println(i, str, str2);
    }

    /* renamed from: v */
    public final void m11506v(String str, String str2, Throwable th) {
        str.getClass();
        str2.getClass();
        th.getClass();
        if (isLoggable(2)) {
            println(2, str, hn0.m12936i(str2, "\n", Log.getStackTraceString(th)));
        }
    }

    /* renamed from: w */
    public final void m11511w(String str, Throwable th, String str2, Object... objArr) {
        str.getClass();
        th.getClass();
        str2.getClass();
        objArr.getClass();
        String format = format(str2, objArr);
        if (isLoggable(5)) {
            println(5, str, format + "\n" + Log.getStackTraceString(th));
        }
        report(5, str, str2, format, th);
    }

    /* renamed from: d */
    public final void m11497d(String str, String str2, Object... objArr) {
        str.getClass();
        str2.getClass();
        objArr.getClass();
        if (isLoggable(3)) {
            println(3, str, format(str2, objArr));
        }
    }

    /* renamed from: i */
    public final void m11504i(String str, String str2, Object... objArr) {
        str.getClass();
        str2.getClass();
        objArr.getClass();
        if (isLoggable(4)) {
            println(4, str, format(str2, objArr));
        }
    }

    /* renamed from: v */
    public final void m11507v(String str, String str2, Object... objArr) {
        str.getClass();
        str2.getClass();
        objArr.getClass();
        if (isLoggable(2)) {
            println(2, str, format(str2, objArr));
        }
    }

    /* renamed from: d */
    public final void m11495d(String str, String str2) {
        str.getClass();
        str2.getClass();
        if (isLoggable(3)) {
            println(3, str, str2);
        }
    }

    /* renamed from: i */
    public final void m11502i(String str, String str2) {
        str.getClass();
        str2.getClass();
        if (isLoggable(4)) {
            println(4, str, str2);
        }
    }

    /* renamed from: v */
    public final void m11505v(String str, String str2) {
        str.getClass();
        str2.getClass();
        if (isLoggable(2)) {
            println(2, str, str2);
        }
    }

    /* renamed from: e */
    public final void m11500e(String str, String str2, Object... objArr) {
        str.getClass();
        str2.getClass();
        objArr.getClass();
        String format = format(str2, objArr);
        if (isLoggable(6)) {
            println(6, str, format);
        }
        report(6, str, str2, format, null);
    }

    /* renamed from: w */
    public final void m11510w(String str, String str2, Object... objArr) {
        str.getClass();
        str2.getClass();
        objArr.getClass();
        String format = format(str2, objArr);
        if (isLoggable(5)) {
            println(5, str, format);
        }
        report(5, str, str2, format, null);
    }

    /* renamed from: e */
    public final void m11499e(String str, String str2, Throwable th) {
        str.getClass();
        str2.getClass();
        th.getClass();
        if (isLoggable(6)) {
            println(6, str, hn0.m12936i(str2, "\n", Log.getStackTraceString(th)));
        }
        report(6, str, str2, str2, th);
    }

    /* renamed from: w */
    public final void m11509w(String str, String str2, Throwable th) {
        str.getClass();
        str2.getClass();
        th.getClass();
        if (isLoggable(5)) {
            println(5, str, hn0.m12936i(str2, "\n", Log.getStackTraceString(th)));
        }
        report(5, str, str2, str2, th);
    }

    /* renamed from: e */
    public final void m11498e(String str, String str2) {
        str.getClass();
        str2.getClass();
        if (isLoggable(6)) {
            println(6, str, str2);
        }
        report(6, str, str2, str2, null);
    }

    /* renamed from: w */
    public final void m11508w(String str, String str2) {
        str.getClass();
        str2.getClass();
        if (isLoggable(5)) {
            println(5, str, str2);
        }
        report(5, str, str2, str2, null);
    }
}
