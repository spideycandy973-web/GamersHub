package frb.axeron.server.util;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class ContentProviderCompat {
    public static final ContentProviderCompat INSTANCE = new ContentProviderCompat();

    private ContentProviderCompat() {
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0045 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.os.Bundle call(android.content.IContentProvider r9, java.lang.String r10, java.lang.String r11, java.lang.String r12, java.lang.String r13, java.lang.String r14, android.os.Bundle r15) throws java.lang.Exception {
        /*
            r8 = this;
            r9.getClass()
            int r8 = android.os.Build.VERSION.SDK_INT
            r0 = 31
            if (r8 < r0) goto L60
            p000.AbstractC1343nc.m16619A()     // Catch: java.lang.Throwable -> L37
            int r8 = android.system.Os.getuid()     // Catch: java.lang.Throwable -> L37
            android.content.AttributionSource$Builder r8 = p000.AbstractC1343nc.m16622b(r8)     // Catch: java.lang.Throwable -> L37
            android.content.AttributionSource$Builder r8 = p000.AbstractC1343nc.m16623c(r8, r10)     // Catch: java.lang.Throwable -> L37
            android.content.AttributionSource$Builder r8 = p000.AbstractC1343nc.m16645y(r8, r11)     // Catch: java.lang.Throwable -> L37
            android.content.AttributionSource r2 = p000.AbstractC1343nc.m16624d(r8)     // Catch: java.lang.Throwable -> L37
            r1 = r9
            r3 = r12
            r4 = r13
            r5 = r14
            r6 = r15
            android.os.Bundle r8 = r1.call(r2, r3, r4, r5, r6)     // Catch: java.lang.Throwable -> L2f
            r9 = r1
            r12 = r3
            r13 = r4
            r14 = r5
            r15 = r6
            goto L3f
        L2f:
            r0 = move-exception
            r9 = r1
            r12 = r3
            r13 = r4
            r14 = r5
            r15 = r6
        L35:
            r8 = r0
            goto L39
        L37:
            r0 = move-exception
            goto L35
        L39:
            md4 r0 = new md4
            r0.<init>(r8)
            r8 = r0
        L3f:
            java.lang.Throwable r0 = p000.nd4.m16656b(r8)
            if (r0 == 0) goto L5a
            boolean r8 = r0 instanceof java.lang.LinkageError     // Catch: java.lang.Throwable -> L52
            if (r8 == 0) goto L51
            r7 = r11
            r11 = r10
            r10 = r7
            android.os.Bundle r8 = r9.call(r10, r11, r12, r13, r14, r15)     // Catch: java.lang.Throwable -> L52
            goto L5a
        L51:
            throw r0     // Catch: java.lang.Throwable -> L52
        L52:
            r0 = move-exception
            r8 = r0
            md4 r9 = new md4
            r9.<init>(r8)
            r8 = r9
        L5a:
            p000.v86.m21297X(r8)
            android.os.Bundle r8 = (android.os.Bundle) r8
            return r8
        L60:
            r7 = r11
            r11 = r10
            r10 = r7
            r0 = 30
            if (r8 != r0) goto L6c
            android.os.Bundle r8 = r9.call(r10, r11, r12, r13, r14, r15)
            return r8
        L6c:
            r11 = 29
            if (r8 != r11) goto L79
            r11 = r12
            r12 = r13
            r13 = r14
            r14 = r15
            android.os.Bundle r8 = r9.call(r10, r11, r12, r13, r14)
            return r8
        L79:
            android.os.Bundle r8 = r9.call(r10, r13, r14, r15)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.util.ContentProviderCompat.call(android.content.IContentProvider, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, android.os.Bundle):android.os.Bundle");
    }
}
