package frb.axeron.server.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import frb.axeron.manager.Axeron;
import frb.axeron.server.util.BinderContainer;
import p000.C0950f;
import p000.sr4;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ServerProvider extends ContentProvider {
    public static final sr4 Companion = new sr4();
    public static final String EXTRA_BINDER = "AxServer.BINDER";
    public static final String METHOD_SEND_BINDER = "sendBinder";
    public static final String TAG = "ServerProvider";

    private final void handleSendBinder(Bundle bundle) {
        BinderContainer binderContainer;
        Object parcelable;
        if (Build.VERSION.SDK_INT >= 34) {
            parcelable = bundle.getParcelable(EXTRA_BINDER, BinderContainer.class);
            binderContainer = (BinderContainer) parcelable;
        } else {
            binderContainer = (BinderContainer) bundle.getParcelable(EXTRA_BINDER);
        }
        Axeron axeron = Axeron.INSTANCE;
        if (axeron.pingServiceBinder() || binderContainer == null || binderContainer.getBinder() == null) {
            return;
        }
        IBinder binder = binderContainer.getBinder();
        Context context = getContext();
        context.getClass();
        String packageName = context.getPackageName();
        packageName.getClass();
        axeron.onBinderReceived(binder, packageName);
    }

    @Override // android.content.ContentProvider
    public void attachInfo(Context context, ProviderInfo providerInfo) {
        super.attachInfo(context, providerInfo);
        if (providerInfo != null) {
            if (providerInfo.multiprocess) {
                C0950f.m10585p("android:multiprocess must be false");
            } else {
                if (providerInfo.exported) {
                    return;
                }
                C0950f.m10585p("android:exported must be true");
            }
        }
    }

    @Override // android.content.ContentProvider
    public Bundle call(String str, String str2, Bundle bundle) {
        str.getClass();
        if (bundle == null) {
            return null;
        }
        bundle.setClassLoader(BinderContainer.class.getClassLoader());
        Bundle bundle2 = new Bundle();
        if (str.equals(METHOD_SEND_BINDER)) {
            handleSendBinder(bundle);
        }
        return bundle2;
    }

    @Override // android.content.ContentProvider
    public int delete(Uri uri, String str, String[] strArr) {
        uri.getClass();
        return 0;
    }

    @Override // android.content.ContentProvider
    public String getType(Uri uri) {
        uri.getClass();
        return null;
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues contentValues) {
        uri.getClass();
        return null;
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        return true;
    }

    @Override // android.content.ContentProvider
    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        uri.getClass();
        return null;
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        uri.getClass();
        return 0;
    }
}
