package frb.axeron.server.input;

import android.os.Build;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteCallbackList;
import android.os.SystemClock;
import android.view.InputDevice;
import com.applovin.shadow.okio.Segment;
import frb.axeron.server.input.IInputCallback;
import frb.axeron.server.input.IInputListener;
import frb.axeron.server.input.InputListenerService;
import frb.axeron.server.util.Logger;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import p000.AbstractC0946ew;
import p000.C0985fw;
import p000.RunnableC1823zb;
import p000.ay1;
import p000.b62;
import p000.bn2;
import p000.cl5;
import p000.d63;
import p000.dg2;
import p000.ds3;
import p000.ei2;
import p000.f55;
import p000.hg0;
import p000.hn0;
import p000.i53;
import p000.jb1;
import p000.jf4;
import p000.jj0;
import p000.kf2;
import p000.kn5;
import p000.l30;
import p000.m55;
import p000.md4;
import p000.me2;
import p000.nr4;
import p000.o30;
import p000.se2;
import p000.te2;
import p000.we2;
import p000.x13;
import p000.xe2;
import p000.xy1;
import p000.ye2;
import p000.yt0;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class InputListenerService extends IInputListener.Stub {
    private static final xe2 Companion = new xe2();

    @Deprecated
    public static final long GEN_CHECK_INTERVAL_MS = 250;

    @Deprecated
    public static final long GRAB_CHECK_INTERVAL_MS = 1000;

    @Deprecated
    public static final int GRAB_UNPARSED_FRAME_LIMIT = 30;

    @Deprecated
    public static final long OPEN_DENIED_RETRY_DELAY_MS = 750;

    @Deprecated
    public static final int UNRESOLVED_TOUCH_ID = Integer.MIN_VALUE;
    private int accumRelDx;
    private int accumRelDy;
    private final int[] androidTouchIds;
    private final int[][] axisCache;
    private int axisGeneration;
    private final RemoteCallbackList<IInputCallback> callbacks;
    private final ExecutorService controlExecutor;
    private final AtomicBoolean cursorBusy;
    private final ExecutorService cursorExecutor;
    private final AtomicBoolean dispatchBusy;
    private final ExecutorService dispatchExecutor;
    private final SyntheticInputEvent[] dispatchPool;
    private final int dispatchPoolMask;
    private volatile int dispatchReadIdx;
    private final Runnable dispatchTask;
    private final AtomicInteger dispatchWriteIdx;
    private final DisplayTransform displayTransform;
    private int effectiveMouseSampleCount;
    private long failedAtGrab;
    private final xy1 hasRuntimePermission;
    private volatile boolean injectEnabled;
    private long injectedAtGrab;
    private final SyntheticInputInjector injector;
    private volatile boolean isMouseDown;
    private final SyntheticInputEvent keyEvent;
    private volatile long keyEventsReceived;
    private volatile boolean keyboardInjectEnabled;
    private volatile boolean lastCursorDown;
    private volatile boolean lastCursorVisible;
    private volatile float lastCursorX;
    private volatile float lastCursorY;
    private volatile long lastEventUptime;
    private long lastGenerationCheckUptime;
    private long lastHzWindowTime;
    private long lastInjectedMouseNs;
    private volatile long lastMouseSampleTime;
    private volatile boolean libraryLoaded;
    private final String libraryPath;
    private final Object lifecycleLock;
    private volatile IBinder lifeline;
    private final IBinder.DeathRecipient lifelineDeath;
    private final Logger logger;
    private volatile boolean mappingEnabled;
    private volatile int monitoredCount;
    private final SyntheticInputEvent mouseEvent;
    private volatile long mouseEventsReceived;
    private ScheduledFuture<?> mouseFlushFuture;
    private volatile int mouseHardwareRateHz;
    private volatile boolean mouseInjectEnabled;
    private final Object mouseLock;
    private volatile int mousePollingRateHz;
    private volatile int mousePollingRateLimitHz;
    private int pendingMouseAction;
    private int pendingMouseButton;
    private int pendingMouseDeviceId;
    private boolean pendingMouseDown;
    private long pendingMouseTimestamp;
    private int pendingMouseX;
    private int pendingMouseY;
    private final SyntheticInputEvent pooledEvent;
    private int rawFramesAtGrab;
    private int rawMouseSampleCount;
    private volatile boolean relativeAim;
    private final kf2 router;
    private ScheduledFuture<?> safetyCheck;
    private final ScheduledExecutorService safetyExecutor;
    private volatile int sensArea;
    private volatile int sensCurve;
    private volatile float sensX;
    private volatile float sensY;
    private final ye2 sink;
    private long touchCalibrationKey;
    private long touchForwardedAtGrab;
    private volatile long touchForwardedCount;
    private volatile boolean touchFrameSinceGrab;
    private volatile long touchFramesReceived;
    private final SyntheticInputEvent wheelEvent;

    /* JADX WARN: Multi-variable type inference failed */
    public InputListenerService(String str, Logger logger, xy1 xy1Var) {
        str.getClass();
        logger.getClass();
        xy1Var.getClass();
        this.libraryPath = str;
        this.logger = logger;
        this.hasRuntimePermission = xy1Var;
        this.libraryLoaded = tryLoadLibrary();
        if (!this.libraryLoaded) {
            logger.m11508w("InputListener", "Initial native library load failed — will retry on start()");
        }
        this.callbacks = new RemoteCallbackList<>();
        this.displayTransform = new DisplayTransform();
        SyntheticInputInjector syntheticInputInjector = new SyntheticInputInjector(logger);
        this.injector = syntheticInputInjector;
        this.controlExecutor = Executors.newSingleThreadExecutor(new te2((byte) 2));
        kf2 kf2Var = new kf2(syntheticInputInjector);
        kf2Var.f21623g.f2718e = new we2(this, 0 == true ? 1 : 0);
        kf2Var.f21621e.f1626d = new b62(this, kf2Var, (byte) 3);
        this.router = kf2Var;
        this.lifecycleLock = new Object();
        this.sensX = 1.0f;
        this.sensY = 1.0f;
        this.relativeAim = true;
        this.sensArea = 1;
        nr4 nr4Var = nr4.f27900a;
        nr4.m16817q("input", true, new we2(this, (byte) 1));
        nr4.m16817q("input.pipeline", true, new we2(this, (byte) 2));
        nr4.m16817q("input.latency", false, new we2(this, (byte) 3));
        this.lifelineDeath = new l30(this, (byte) 1);
        this.dispatchBusy = new AtomicBoolean(false);
        this.dispatchExecutor = Executors.newSingleThreadExecutor(new te2((byte) 3));
        this.lastCursorX = -100.0f;
        this.lastCursorY = -100.0f;
        this.cursorBusy = new AtomicBoolean(false);
        this.cursorExecutor = Executors.newSingleThreadExecutor(new te2(0 == true ? 1 : 0));
        this.safetyExecutor = Executors.newSingleThreadScheduledExecutor(new te2((byte) 1));
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        float f = 0.0f;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        int i10 = 0;
        float f2 = 0.0f;
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        this.pooledEvent = new SyntheticInputEvent(0, i, i2, i3, i4, i5, 0.0f, f, 0, i6, i7, i8, i9, 0L, 0, i10, 0.0f, f2, 0, i11, i12, i13, 4177920, null);
        int i14 = 0;
        float f3 = 0.0f;
        int i15 = 0;
        int i16 = 0;
        float f4 = 0.0f;
        int i17 = 0;
        this.mouseEvent = new SyntheticInputEvent(i, i2, i3, i4, i5, i14, f, f3, i6, i7, i8, i9, i15, 0L, i10, i16, f2, f4, i11, i12, i13, i17, 4177920, null);
        int i18 = 0;
        float f5 = 0.0f;
        int i19 = 0;
        int i20 = 0;
        float f6 = 0.0f;
        int i21 = 0;
        this.keyEvent = new SyntheticInputEvent(i2, i3, i4, i5, i14, i18, f3, f5, i7, i8, i9, i15, i19, 0L, i16, i20, f4, f6, i12, i13, i17, i21, 4177920, null);
        this.wheelEvent = new SyntheticInputEvent(i3, i4, i5, i14, i18, 0, f5, 0.0f, i8, i9, i15, i19, 0, 0L, i20, 0, f6, 0.0f, i13, i17, i21, 0, 4177920, null);
        SyntheticInputEvent[] syntheticInputEventArr = new SyntheticInputEvent[32];
        for (int i22 = 0; i22 < 32; i22++) {
            syntheticInputEventArr[i22] = new SyntheticInputEvent(0, 0, 0, 0, 0, 0, 0.0f, 0.0f, 0, 0, 0, 0, 0, 0L, 0, 0, 0.0f, 0.0f, 0, 0, 0, 0, 4177920, null);
        }
        this.dispatchPool = syntheticInputEventArr;
        this.dispatchPoolMask = 31;
        this.dispatchWriteIdx = new AtomicInteger(0);
        this.dispatchTask = new RunnableC1823zb((Object) this, (byte) 6);
        this.mouseLock = new Object();
        this.axisCache = new int[32][];
        this.axisGeneration = Integer.MIN_VALUE;
        this.touchCalibrationKey = -1L;
        int[] iArr = new int[32];
        for (int i23 = 0; i23 < 32; i23++) {
            iArr[i23] = Integer.MIN_VALUE;
        }
        this.androidTouchIds = iArr;
        this.sink = new ye2(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String _init_$lambda$0(InputListenerService inputListenerService) {
        Object md4Var;
        try {
            md4Var = Boolean.valueOf(inputListenerService.isListening());
        } catch (Throwable th) {
            md4Var = new md4(th);
        }
        Boolean bool = Boolean.FALSE;
        if (md4Var instanceof md4) {
            md4Var = bool;
        }
        return "listening=" + md4Var + " devices=" + inputListenerService.monitoredCount + " touchInject=" + inputListenerService.injectEnabled + " mapping=" + inputListenerService.mappingEnabled + " keyboardInject=" + inputListenerService.keyboardInjectEnabled + " mouseInject=" + inputListenerService.mouseInjectEnabled + " display=" + inputListenerService.displayTransform.getSnapshot() + " lifeline=" + (inputListenerService.lifeline != null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String _init_$lambda$1(InputListenerService inputListenerService) {
        Object md4Var;
        long j = inputListenerService.touchFramesReceived;
        long j2 = inputListenerService.mouseEventsReceived;
        long j3 = inputListenerService.keyEventsReceived;
        long uptimeMillis = inputListenerService.lastEventUptime > 0 ? SystemClock.uptimeMillis() - inputListenerService.lastEventUptime : -1L;
        try {
            md4Var = Integer.valueOf(inputListenerService.callbacks.getRegisteredCallbackCount());
        } catch (Throwable th) {
            md4Var = new md4(th);
        }
        if (md4Var instanceof md4) {
            md4Var = -1;
        }
        String diagnosticsSummary = inputListenerService.injector.diagnosticsSummary();
        StringBuilder m8813t = d63.m8813t(j, "touch_frames=", " mouse_events=");
        m8813t.append(j2);
        d63.m8818y(m8813t, " key_events=", j3, " last_event_ago_ms=");
        m8813t.append(uptimeMillis);
        m8813t.append(" callbacks=");
        m8813t.append(md4Var);
        return hn0.m12937j(" ", diagnosticsSummary, m8813t);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String _init_$lambda$2(InputListenerService inputListenerService) {
        return inputListenerService.injector.latencySummary();
    }

    private final void applySystemPointerSpeed() {
        Thread thread = new Thread(new se2(this, (byte) 0), "pointer-speed");
        thread.setDaemon(true);
        thread.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void applySystemPointerSpeed$lambda$0(InputListenerService inputListenerService) {
        Object md4Var;
        Process start;
        BufferedReader bufferedReader;
        try {
            start = new ProcessBuilder("settings", "get", "system", "pointer_speed").redirectErrorStream(true).start();
            InputStream inputStream = start.getInputStream();
            inputStream.getClass();
            bufferedReader = new BufferedReader(new InputStreamReader(inputStream, hg0.f17140a), Segment.SIZE);
        } catch (Throwable th) {
            md4Var = new md4(th);
        }
        try {
            String m2657H = cl5.m2657H(bufferedReader);
            bufferedReader.close();
            String obj = f55.m10707P0(m2657H).toString();
            start.waitFor();
            Integer m15787i0 = m55.m15787i0(obj);
            md4Var = Integer.valueOf(m15787i0 != null ? dg2.m9133t(m15787i0.intValue(), -7, 7) : 0);
            if (md4Var instanceof md4) {
                md4Var = 0;
            }
            int intValue = ((Number) md4Var).intValue();
            boolean z = Build.VERSION.SDK_INT >= 36;
            try {
                InputListener.INSTANCE.nativeSetPointerSpeed(intValue, z, true);
            } catch (Throwable unused) {
            }
            inputListenerService.logger.m11504i("InputListener", "pointer speed=%d curved=%b", Integer.valueOf(intValue), Boolean.valueOf(z));
        } finally {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int[] axisFor(int i) {
        int i2;
        int[] iArr = null;
        if (i >= 0) {
            int[][] iArr2 = this.axisCache;
            if (i < iArr2.length) {
                int[] iArr3 = iArr2[i];
                long uptimeMillis = SystemClock.uptimeMillis();
                if (iArr3 != null && uptimeMillis - this.lastGenerationCheckUptime < 250) {
                    return iArr3;
                }
                this.lastGenerationCheckUptime = uptimeMillis;
                try {
                    i2 = InputListener.INSTANCE.nativeGetDeviceGeneration();
                } catch (Throwable unused) {
                    i2 = this.axisGeneration;
                }
                if (i2 != this.axisGeneration) {
                    this.axisGeneration = i2;
                    String str = "input devices changed gen=" + i2;
                    nr4.f27900a.m16823b(str, str);
                    AbstractC0946ew.m10532N0(0, r1.length, null, this.axisCache);
                    AbstractC0946ew.m10533O0(Integer.MIN_VALUE, this.androidTouchIds);
                    this.touchCalibrationKey = -1L;
                }
                int[] iArr4 = this.axisCache[i];
                if (iArr4 != null) {
                    return iArr4;
                }
                try {
                    iArr = InputListener.INSTANCE.nativeGetDeviceAxis(i);
                } catch (Throwable unused2) {
                }
                if (iArr != null && iArr.length >= 4) {
                    this.axisCache[i] = iArr;
                }
                return this.axisCache[i];
            }
        }
        return null;
    }

    private final void cancelSafetyCheck() {
        ScheduledFuture<?> scheduledFuture = this.safetyCheck;
        if (scheduledFuture != null) {
            scheduledFuture.cancel(false);
        }
        this.safetyCheck = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Thread controlExecutor$lambda$0(Runnable runnable) {
        Thread thread = new Thread(runnable, "input-control");
        thread.setDaemon(true);
        return thread;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Thread cursorExecutor$lambda$0(Runnable runnable) {
        Thread thread = new Thread(runnable, "touch-cursor");
        thread.setDaemon(true);
        return thread;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void dispatch(SyntheticInputEvent syntheticInputEvent) {
        synchronized (this.callbacks) {
            try {
                int beginBroadcast = this.callbacks.beginBroadcast();
                for (int i = 0; i < beginBroadcast; i++) {
                    try {
                        this.callbacks.getBroadcastItem(i).onTouchEvent(syntheticInputEvent);
                    } catch (Throwable unused) {
                    }
                }
                try {
                    this.callbacks.finishBroadcast();
                } catch (Throwable th) {
                    this.logger.m11499e("InputListener", "finishBroadcast failed in dispatch", th);
                }
            } catch (Throwable th2) {
                this.logger.m11499e("InputListener", "beginBroadcast failed in dispatch", th2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void dispatchCursor(float f, float f2, boolean z, boolean z2) {
        this.lastCursorX = f;
        this.lastCursorY = f2;
        this.lastCursorDown = z;
        this.lastCursorVisible = z2;
        if (this.callbacks.getRegisteredCallbackCount() == 0) {
            return;
        }
        scheduleCursorBroadcast();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Thread dispatchExecutor$lambda$0(Runnable runnable) {
        Thread thread = new Thread(runnable, "touch-dispatch");
        thread.setDaemon(true);
        return thread;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void enqueueForDispatch(SyntheticInputEvent syntheticInputEvent, boolean z) {
        if (z || !this.dispatchBusy.get()) {
            int i = this.dispatchWriteIdx.get();
            this.dispatchPool[this.dispatchPoolMask & i].copyFrom(syntheticInputEvent);
            this.dispatchWriteIdx.lazySet(i + 1);
            if (this.dispatchBusy.compareAndSet(false, true)) {
                this.dispatchExecutor.execute(this.dispatchTask);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0088  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00d2  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00e4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void flushPendingMouse() {
        /*
            Method dump skipped, instructions count: 255
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.input.InputListenerService.flushPendingMouse():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void lifelineDeath$lambda$0(InputListenerService inputListenerService) {
        inputListenerService.logger.m11508w("InputListener", "client process died — stopping listener + inject");
        nr4 nr4Var = nr4.f27900a;
        nr4Var.m16823b("client died", "client died");
        if (inputListenerService.injectEnabled || inputListenerService.mappingEnabled || inputListenerService.keyboardInjectEnabled || inputListenerService.mouseInjectEnabled) {
            nr4Var.m16831p("client_died_active", null, new IllegalStateException("client process died while active touchInject=" + inputListenerService.injectEnabled + " mapping=" + inputListenerService.mappingEnabled + " keyboardInject=" + inputListenerService.keyboardInjectEnabled + " mouseInject=" + inputListenerService.mouseInjectEnabled));
        }
        inputListenerService.lifeline = null;
        try {
            inputListenerService.stop();
        } catch (Throwable unused) {
        }
    }

    private final int recoverOpenDenied(final int i) {
        Object md4Var;
        nr4 nr4Var = nr4.f27900a;
        String m16815m = nr4.m16815m();
        nr4Var.m16823b("listener open denied, recovering", "listener open denied, recovering");
        final byte b = 0;
        final byte b2 = 1;
        Iterator it = jj0.m14031D(new ds3("main-thread", new xy1() { // from class: ue2
            @Override // p000.xy1
            public final Object invoke() {
                int recoverOpenDenied$lambda$0;
                byte b3 = b;
                int i2 = i;
                switch (b3) {
                    case 0:
                        recoverOpenDenied$lambda$0 = InputListenerService.recoverOpenDenied$lambda$0(i2);
                        break;
                    default:
                        recoverOpenDenied$lambda$0 = InputListenerService.recoverOpenDenied$lambda$1(i2);
                        break;
                }
                return Integer.valueOf(recoverOpenDenied$lambda$0);
            }
        }), new ds3("delayed-owner", new xy1() { // from class: ue2
            @Override // p000.xy1
            public final Object invoke() {
                int recoverOpenDenied$lambda$0;
                byte b3 = b2;
                int i2 = i;
                switch (b3) {
                    case 0:
                        recoverOpenDenied$lambda$0 = InputListenerService.recoverOpenDenied$lambda$0(i2);
                        break;
                    default:
                        recoverOpenDenied$lambda$0 = InputListenerService.recoverOpenDenied$lambda$1(i2);
                        break;
                }
                return Integer.valueOf(recoverOpenDenied$lambda$0);
            }
        })).iterator();
        int i2 = i;
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            ds3 ds3Var = (ds3) it.next();
            String str = (String) ds3Var.f10834a;
            try {
                md4Var = Integer.valueOf(((Number) ((xy1) ds3Var.f10835b).invoke()).intValue());
            } catch (Throwable th) {
                md4Var = new md4(th);
            }
            Object valueOf = Integer.valueOf(i);
            if (md4Var instanceof md4) {
                md4Var = valueOf;
            }
            i2 = ((Number) md4Var).intValue();
            nr4 nr4Var2 = nr4.f27900a;
            String str2 = "listener recovery " + str + " code=" + i2;
            nr4Var2.m16823b(str2, str2);
            if (i2 > 0) {
                this.logger.m11504i("InputListener", "start() recovered from open denied via %s", str);
                StringBuilder m23622o = yt0.m23622o(i, "recovered via ", str, " after code=", " ");
                m23622o.append(m16815m);
                nr4Var2.m16831p("listener_start_recovered", null, new IllegalStateException(m23622o.toString()));
                break;
            }
        }
        return i2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int recoverOpenDenied$lambda$0(int i) {
        return ((Number) InputListener.INSTANCE.runOnMain(Integer.valueOf(i), new me2((byte) 5))).intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int recoverOpenDenied$lambda$0$0() {
        return InputListener.INSTANCE.nativeStart();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int recoverOpenDenied$lambda$1(int i) {
        SystemClock.sleep(750L);
        return ((Number) InputListener.INSTANCE.runOnOwner(Integer.valueOf(i), new me2((byte) 2))).intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int recoverOpenDenied$lambda$1$0() {
        return InputListener.INSTANCE.nativeStart();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void registerCallback$lambda$0(IInputCallback iInputCallback, float f, float f2, boolean z, boolean z2) {
        try {
            iInputCallback.onCursorEvent(f, f2, z, z2);
        } catch (Throwable unused) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v0, types: [md4] */
    /* JADX WARN: Type inference failed for: r3v1 */
    /* JADX WARN: Type inference failed for: r3v13, types: [java.util.ArrayList] */
    private final int resolveAndroidTouchDeviceId(int i) {
        Object md4Var;
        ?? md4Var2;
        Object obj;
        try {
            md4Var = InputListener.INSTANCE.nativeGetDeviceName(i);
        } catch (Throwable th) {
            md4Var = new md4(th);
        }
        if (md4Var instanceof md4) {
            md4Var = null;
        }
        String str = (String) md4Var;
        try {
            int[] deviceIds = InputDevice.getDeviceIds();
            deviceIds.getClass();
            C0985fw c0985fw = new C0985fw(deviceIds);
            ArrayList arrayList = new ArrayList();
            Iterator it = c0985fw.iterator();
            while (it.hasNext()) {
                InputDevice device = InputDevice.getDevice(((Number) it.next()).intValue());
                if (device != null) {
                    arrayList.add(device);
                }
            }
            md4Var2 = new ArrayList();
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj2 = arrayList.get(i2);
                i2++;
                InputDevice inputDevice = (InputDevice) obj2;
                if (!inputDevice.isVirtual() && inputDevice.supportsSource(4098)) {
                    md4Var2.add(obj2);
                }
            }
        } catch (Throwable th2) {
            md4Var2 = new md4(th2);
        }
        boolean z = md4Var2 instanceof md4;
        List list = md4Var2;
        if (z) {
            list = null;
        }
        List list2 = list;
        if (list2 == null) {
            return 0;
        }
        Iterator it2 = list2.iterator();
        while (true) {
            if (!it2.hasNext()) {
                obj = null;
                break;
            }
            obj = it2.next();
            if (ei2.m10070i(((InputDevice) obj).getName(), str)) {
                break;
            }
        }
        InputDevice inputDevice2 = (InputDevice) obj;
        if (inputDevice2 == null) {
            inputDevice2 = (InputDevice) (list2.size() == 1 ? list2.get(0) : null);
        }
        this.logger.m11504i("InputListener", "touch device '%s' -> android deviceId %d", str == null ? "?" : str, Integer.valueOf(inputDevice2 != null ? inputDevice2.getId() : 0));
        nr4 nr4Var = nr4.f27900a;
        if (str == null) {
            str = "?";
        }
        String str2 = "touch device '" + str + "' androidId=" + (inputDevice2 != null ? inputDevice2.getId() : 0);
        nr4Var.m16823b(str2, str2);
        if (inputDevice2 != null) {
            return inputDevice2.getId();
        }
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void routeWheel(int i, int i2, int i3, int i4, long j, int i5, int i6, int i7) {
        this.wheelEvent.populate(i, 0, jf4.MAX_BIND_PARAMETER_CNT, 0, i2, i3, i5 > 0 ? i2 / i5 : 0.0f, i6 > 0 ? i3 / i6 : 0.0f, 0, 4, 1, i4, 1, j);
        this.wheelEvent.setDevType(4);
        this.wheelEvent.setDispX(i2);
        this.wheelEvent.setDispY(i3);
        this.wheelEvent.setDispXf(i2);
        this.wheelEvent.setDispYf(i3);
        this.wheelEvent.setRotation(i7);
        this.wheelEvent.setDisplayWidth(i5);
        this.wheelEvent.setDisplayHeight(i6);
        this.router.m14613b(this.wheelEvent);
        this.injector.onFrame();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final kn5 router$lambda$0$0(InputListenerService inputListenerService) {
        inputListenerService.controlExecutor.execute(new se2(inputListenerService, (byte) 2));
        return kn5.f22076a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void router$lambda$0$0$0(InputListenerService inputListenerService) {
        boolean z = !inputListenerService.isKeyboardInject();
        inputListenerService.setKeyboardInject(z);
        inputListenerService.logger.m11504i("InputListener", "Mode.KEYBOARD toggle -> keyboard inject is now %b", Boolean.valueOf(z));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x008d, code lost:
    
        if (r8 != false) goto L43;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final p000.kn5 router$lambda$0$1(frb.axeron.server.input.InputListenerService r6, p000.kf2 r7, boolean r8) {
        /*
            frb.axeron.server.input.DisplayTransform r0 = r6.displayTransform
            jb1 r0 = r0.getSnapshot()
            float r1 = r6.lastCursorX
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            r3 = 1073741824(0x40000000, float:2.0)
            if (r1 < 0) goto L12
            float r1 = r6.lastCursorX
            goto L1b
        L12:
            int r1 = r0.f19970b
            if (r1 <= 0) goto L19
            float r1 = (float) r1
            float r1 = r1 / r3
            goto L1b
        L19:
            r1 = 1141309440(0x44070000, float:540.0)
        L1b:
            float r4 = r6.lastCursorY
            int r2 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r2 < 0) goto L24
            float r0 = r6.lastCursorY
            goto L2d
        L24:
            int r0 = r0.f19971c
            if (r0 <= 0) goto L2b
            float r0 = (float) r0
            float r0 = r0 / r3
            goto L2d
        L2b:
            r0 = 1150681088(0x44960000, float:1200.0)
        L2d:
            boolean r2 = r6.lastCursorDown
            boolean r3 = r6.mouseInjectEnabled
            r4 = 0
            r5 = 1
            if (r3 == 0) goto L39
            if (r8 != 0) goto L39
            r3 = r5
            goto L3a
        L39:
            r3 = r4
        L3a:
            r6.dispatchCursor(r1, r0, r2, r3)
            if (r8 != 0) goto L4f
            ck2 r0 = r7.f21620d
            r0.m2635b()
            bn2 r0 = r7.f21623g
            r0.m1855b()
            kc3 r0 = r7.f21622f
            r0.m14529o()
            goto L54
        L4f:
            kc3 r0 = r7.f21622f
            r0.m14529o()
        L54:
            boolean r0 = r6.keyboardInjectEnabled
            if (r0 == 0) goto L95
            frb.axeron.server.input.InputListener r0 = frb.axeron.server.input.InputListener.INSTANCE
            boolean r0 = r0.isLoaded()
            if (r0 == 0) goto L95
            i53 r0 = r7.f21624h
            if (r0 == 0) goto L8f
            java.util.List r0 = r0.f18199b
            if (r0 == 0) goto L8f
            boolean r1 = r0.isEmpty()
            if (r1 != 0) goto L8f
            java.util.Iterator r0 = r0.iterator()
        L72:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L8f
            java.lang.Object r1 = r0.next()
            x13 r1 = (p000.x13) r1
            boolean r2 = r1.f43220c
            if (r2 == 0) goto L72
            ay1 r2 = r7.f21621e
            r2.getClass()
            boolean r1 = p000.ay1.m1246b(r1)
            if (r1 == 0) goto L72
            if (r8 == 0) goto L90
        L8f:
            r4 = r5
        L90:
            frb.axeron.server.input.InputListener r7 = frb.axeron.server.input.InputListener.INSTANCE
            r7.nativeSetKeyboardGrab(r4)
        L95:
            frb.axeron.server.util.Logger r6 = r6.logger
            if (r8 == 0) goto L9c
            java.lang.String r7 = "FPS"
            goto L9e
        L9c:
            java.lang.String r7 = "cursor"
        L9e:
            java.lang.Object[] r7 = new java.lang.Object[]{r7}
            java.lang.String r8 = "InputListener"
            java.lang.String r0 = "FPS look toggle -> mode is now %s"
            r6.m11504i(r8, r0, r7)
            kn5 r6 = p000.kn5.f22076a
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.input.InputListenerService.router$lambda$0$1(frb.axeron.server.input.InputListenerService, kf2, boolean):kn5");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Thread safetyExecutor$lambda$0(Runnable runnable) {
        Thread thread = new Thread(runnable, "grab-safety");
        thread.setDaemon(true);
        return thread;
    }

    private final void scheduleCursorBroadcast() {
        if (this.cursorBusy.compareAndSet(false, true)) {
            this.cursorExecutor.execute(new se2(this, (byte) 1));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scheduleCursorBroadcast$lambda$0(InputListenerService inputListenerService) {
        float f;
        Throwable th;
        int registeredCallbackCount;
        float f2;
        float f3;
        boolean z;
        boolean z2;
        float f4;
        boolean z3;
        float f5 = Float.NaN;
        float f6 = Float.NaN;
        boolean z4 = false;
        boolean z5 = false;
        while (true) {
            try {
                f = inputListenerService.lastCursorX;
                f4 = inputListenerService.lastCursorY;
                z3 = inputListenerService.lastCursorDown;
                z5 = inputListenerService.lastCursorVisible;
                try {
                    synchronized (inputListenerService.callbacks) {
                        try {
                            int beginBroadcast = inputListenerService.callbacks.beginBroadcast();
                            for (int i = 0; i < beginBroadcast; i++) {
                                try {
                                    inputListenerService.callbacks.getBroadcastItem(i).onCursorEvent(f, f4, z3, z5);
                                } catch (Throwable unused) {
                                }
                            }
                            try {
                                inputListenerService.callbacks.finishBroadcast();
                            } finally {
                                if (f != inputListenerService.lastCursorX) {
                                }
                                f5 = f;
                                f6 = f4;
                                z4 = z3;
                            }
                        } catch (Throwable th2) {
                            inputListenerService.logger.m11499e("InputListener", "beginBroadcast failed in dispatchCursor", th2);
                            inputListenerService.cursorBusy.set(false);
                            if (inputListenerService.callbacks.getRegisteredCallbackCount() <= 0) {
                                return;
                            }
                            if (inputListenerService.lastCursorX == f && inputListenerService.lastCursorY == f4 && inputListenerService.lastCursorDown == z3 && inputListenerService.lastCursorVisible == z5) {
                                return;
                            }
                        }
                    }
                    if (f != inputListenerService.lastCursorX && f4 == inputListenerService.lastCursorY && z3 == inputListenerService.lastCursorDown && z5 == inputListenerService.lastCursorVisible) {
                        break;
                    }
                    f5 = f;
                    f6 = f4;
                    z4 = z3;
                } catch (Throwable th3) {
                    th = th3;
                    f6 = f4;
                    z4 = z3;
                    try {
                        inputListenerService.logger.m11499e("InputListener", "dispatchCursor worker failed", th);
                        if (registeredCallbackCount > 0) {
                            if ((f2 > f ? 1 : (f2 == f ? 0 : -1)) == 0) {
                                if ((f3 > f6 ? 1 : (f3 == f6 ? 0 : -1)) == 0) {
                                    if (z == z4) {
                                        if (z2 == z5) {
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                        return;
                    } finally {
                        inputListenerService.cursorBusy.set(false);
                        if (inputListenerService.callbacks.getRegisteredCallbackCount() > 0 && (inputListenerService.lastCursorX != f || inputListenerService.lastCursorY != f6 || inputListenerService.lastCursorDown != z4 || inputListenerService.lastCursorVisible != z5)) {
                            inputListenerService.scheduleCursorBroadcast();
                        }
                    }
                }
            } catch (Throwable th4) {
                f = f5;
                th = th4;
            }
        }
        inputListenerService.cursorBusy.set(false);
        if (inputListenerService.callbacks.getRegisteredCallbackCount() > 0) {
            if (inputListenerService.lastCursorX == f && inputListenerService.lastCursorY == f4 && inputListenerService.lastCursorDown == z3 && inputListenerService.lastCursorVisible == z5) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setInjectEnabled$lambda$0$0(InputListenerService inputListenerService) {
        String str;
        synchronized (inputListenerService.lifecycleLock) {
            boolean z = true;
            boolean z2 = inputListenerService.touchForwardedCount > inputListenerService.touchForwardedAtGrab;
            if (inputListenerService.injector.getInjectedCount() <= inputListenerService.injectedAtGrab && inputListenerService.injector.getFailedCount() <= inputListenerService.failedAtGrab) {
                z = false;
            }
            if (!inputListenerService.injectEnabled || (z2 && z)) {
                inputListenerService.cancelSafetyCheck();
            } else {
                InputListener inputListener = InputListener.INSTANCE;
                int nativeGetTouchRawFrameCount = inputListener.nativeGetTouchRawFrameCount() - inputListenerService.rawFramesAtGrab;
                if (nativeGetTouchRawFrameCount >= 30) {
                    long failedCount = inputListenerService.injector.getFailedCount() - inputListenerService.failedAtGrab;
                    if (failedCount > 0) {
                        str = failedCount + " injections rejected: " + inputListenerService.injector.getLastFailure();
                    } else if (inputListenerService.touchFrameSinceGrab) {
                        str = "frames parsed but nothing injected display=" + inputListenerService.displayTransform.getSnapshot();
                    } else {
                        str = "no parsed frame";
                    }
                    inputListenerService.logger.m11510w("InputListener", "SAFETY NET: %d raw touch frames, %s — releasing grab", Integer.valueOf(nativeGetTouchRawFrameCount), str);
                    nr4.f27900a.m16831p("safety_net", null, new IllegalStateException("safety net released grab after " + nativeGetTouchRawFrameCount + " raw touch frames: " + str));
                    inputListener.nativeSetGrab(false);
                    inputListenerService.setInjectEnabled(false);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final int start$lambda$0$0() {
        return InputListener.INSTANCE.nativeStart();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String start$lambda$0$1() {
        nr4 nr4Var = nr4.f27900a;
        return nr4.m16815m();
    }

    private final boolean tryLoadLibrary() {
        InputListener inputListener = InputListener.INSTANCE;
        if (inputListener.isLoaded()) {
            return true;
        }
        boolean load = inputListener.load(this.libraryPath);
        Logger logger = this.logger;
        if (load) {
            logger.m11504i("InputListener", "Loaded libaxinput.so from %s", this.libraryPath);
            return true;
        }
        logger.m11510w("InputListener", "Failed to load libaxinput.so from %s, attempting System.loadLibrary fallback...", this.libraryPath);
        boolean loadLibraryFallback = inputListener.loadLibraryFallback("touch");
        if (loadLibraryFallback) {
            this.logger.m11502i("InputListener", "Loaded libaxinput via System.loadLibrary fallback");
        }
        return loadLibraryFallback;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateTouchCalibration(int i, int[] iArr, int i2, int i3, int i4) {
        float[] fArr;
        Float m10541W0;
        Float m10541W02;
        Float m10541W03;
        Float m10541W04;
        Float m10541W05;
        if (iArr == null || i2 <= 0 || i3 <= 0) {
            return;
        }
        long j = ((i & 255) << 56) | ((i4 & 15) << 48) | ((i2 & 16777215) << 24) | (i3 & 16777215);
        if (j != this.touchCalibrationKey) {
            this.touchCalibrationKey = j;
            int i5 = (iArr[1] - iArr[0]) + 1;
            if (i5 < 1) {
                i5 = 1;
            }
            float f = i5;
            int i6 = (iArr[3] - iArr[2]) + 1;
            if (i6 < 1) {
                i6 = 1;
            }
            float f2 = i6;
            boolean z = ((i4 + (6 < iArr.length ? iArr[6] : 0)) & 1) == 1;
            float f3 = i2 / (z ? f2 : f);
            float f4 = i3;
            if (!z) {
                f = f2;
            }
            float f5 = f4 / f;
            try {
                fArr = InputListener.INSTANCE.nativeGetDeviceCalibration(i);
            } catch (Throwable unused) {
                fArr = null;
            }
            SyntheticInputInjector syntheticInputInjector = this.injector;
            int i7 = 4 < iArr.length ? iArr[4] : 0;
            int i8 = 5 < iArr.length ? iArr[5] : 0;
            float f6 = (f3 + f5) / 2.0f;
            float f7 = 1.0f / f3;
            float f8 = 1.0f / f5;
            float f9 = Float.NaN;
            float floatValue = (fArr == null || (m10541W05 = AbstractC0946ew.m10541W0(0, fArr)) == null) ? Float.NaN : m10541W05.floatValue();
            boolean z2 = !(((fArr == null || (m10541W04 = AbstractC0946ew.m10541W0(1, fArr)) == null) ? 0.0f : m10541W04.floatValue()) == 0.0f);
            float floatValue2 = (fArr == null || (m10541W03 = AbstractC0946ew.m10541W0(2, fArr)) == null) ? Float.NaN : m10541W03.floatValue();
            if (fArr != null && (m10541W02 = AbstractC0946ew.m10541W0(3, fArr)) != null) {
                f9 = m10541W02.floatValue();
            }
            syntheticInputInjector.setTouchCalibration(i7, i8, f6, f7, f8, floatValue, z2, floatValue2, f9, !(((fArr == null || (m10541W0 = AbstractC0946ew.m10541W0(4, fArr)) == null) ? 0.0f : m10541W0.floatValue()) == 0.0f));
            int[] iArr2 = this.androidTouchIds;
            if (iArr2[i] == Integer.MIN_VALUE) {
                iArr2[i] = resolveAndroidTouchDeviceId(i);
            }
            this.injector.setTouchDeviceId(this.androidTouchIds[i]);
        }
    }

    @Override // frb.axeron.server.input.IInputListener
    public int[] currentDisplayMetrics() {
        this.displayTransform.refreshNow();
        jb1 snapshot = this.displayTransform.getSnapshot();
        return new int[]{snapshot.f19970b, snapshot.f19971c, snapshot.f19969a};
    }

    public final boolean getLibraryLoaded() {
        return this.libraryLoaded;
    }

    @Override // frb.axeron.server.input.IInputListener
    public int getMouseHardwareRate() {
        if (SystemClock.uptimeMillis() - this.lastMouseSampleTime > 1500) {
            return 0;
        }
        return this.mouseHardwareRateHz;
    }

    @Override // frb.axeron.server.input.IInputListener
    public int getMousePollingRate() {
        if (SystemClock.uptimeMillis() - this.lastMouseSampleTime > 1500) {
            return 0;
        }
        return this.mousePollingRateHz;
    }

    @Override // frb.axeron.server.input.IInputListener
    public int getMousePollingRateLimit() {
        return this.mousePollingRateLimitHz;
    }

    @Override // frb.axeron.server.input.IInputListener
    public void hideSystemCursor() {
        this.injector.hideSystemCursor();
    }

    @Override // frb.axeron.server.input.IInputListener
    public boolean injectTap(float f, float f2) {
        int i;
        this.displayTransform.refreshNow();
        jb1 snapshot = this.displayTransform.getSnapshot();
        int i2 = snapshot.f19970b;
        if (i2 <= 0 || (i = snapshot.f19971c) <= 0) {
            return false;
        }
        return this.injector.injectTap(f * i2, f2 * i);
    }

    @Override // frb.axeron.server.input.IInputListener
    public boolean isAltKeyActive() {
        return this.router.f21623g.f2719f;
    }

    @Override // frb.axeron.server.input.IInputListener
    public boolean isInjectEnabled() {
        return this.injectEnabled;
    }

    @Override // frb.axeron.server.input.IInputListener
    public boolean isKeyboardInject() {
        return this.keyboardInjectEnabled;
    }

    @Override // frb.axeron.server.input.IInputListener
    public boolean isListening() {
        InputListener inputListener = InputListener.INSTANCE;
        return inputListener.isLoaded() && inputListener.nativeIsRunning();
    }

    @Override // frb.axeron.server.input.IInputListener
    public boolean isMappingEnabled() {
        return this.mappingEnabled;
    }

    @Override // frb.axeron.server.input.IInputListener
    public boolean isMouseInject() {
        return this.mouseInjectEnabled;
    }

    @Override // frb.axeron.server.input.IInputListener
    public int monitoredDeviceCount() {
        if (isListening()) {
            return this.monitoredCount;
        }
        return 0;
    }

    @Override // frb.axeron.server.input.IInputListener.Stub, android.os.Binder
    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        parcel.getClass();
        return nr4.f27900a.m16827h("IInputListener", i, new o30(this, i, parcel, parcel2, i2, (byte) 2));
    }

    @Override // frb.axeron.server.input.IInputListener
    public void registerCallback(final IInputCallback iInputCallback) {
        if (iInputCallback != null) {
            this.callbacks.register(iInputCallback);
            if (this.lastCursorX < 0.0f || this.lastCursorY < 0.0f) {
                jb1 snapshot = this.displayTransform.getSnapshot();
                int i = snapshot.f19970b;
                float f = i > 0 ? i : 1080.0f;
                int i2 = snapshot.f19971c;
                float f2 = i2 > 0 ? i2 : 2400.0f;
                this.lastCursorX = f / 2.0f;
                this.lastCursorY = f2 / 2.0f;
            }
            final float f3 = this.lastCursorX;
            final float f4 = this.lastCursorY;
            final boolean z = this.lastCursorDown;
            final boolean z2 = this.mouseInjectEnabled && !this.router.f21621e.f1625c;
            this.cursorExecutor.execute(new Runnable() { // from class: ve2
                @Override // java.lang.Runnable
                public final void run() {
                    InputListenerService.registerCallback$lambda$0(IInputCallback.this, f3, f4, z, z2);
                }
            });
        }
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setAltKeyActive(boolean z) {
        kf2 kf2Var = this.router;
        synchronized (kf2Var) {
            bn2 bn2Var = kf2Var.f21623g;
            synchronized (bn2Var) {
                try {
                    bn2Var.f2719f = z;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        this.logger.m11504i("InputListener", "altKeyActive: %b", Boolean.valueOf(z));
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setClientLifeline(IBinder iBinder) {
        IBinder iBinder2 = this.lifeline;
        if (iBinder2 != null) {
            try {
                iBinder2.unlinkToDeath(this.lifelineDeath, 0);
            } catch (Throwable unused) {
            }
        }
        this.lifeline = iBinder;
        if (iBinder != null) {
            try {
                iBinder.linkToDeath(this.lifelineDeath, 0);
            } catch (Throwable unused2) {
            }
        }
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setInjectEnabled(boolean z) {
        synchronized (this.lifecycleLock) {
            if (z) {
                if (!isListening()) {
                    start();
                    if (!isListening()) {
                        this.logger.m11508w("InputListener", "setInjectEnabled(true) ignored: auto-start failed");
                        this.injectEnabled = false;
                    }
                }
            }
            boolean z2 = this.injectEnabled;
            this.injectEnabled = z;
            this.injector.setUseTouchDeviceId(z);
            boolean z3 = z || this.mouseInjectEnabled || this.keyboardInjectEnabled;
            if (!z) {
                this.injector.liftPhysicalPointers();
                this.router.f21619c.m20357k();
            }
            InputListener inputListener = InputListener.INSTANCE;
            if (inputListener.isLoaded()) {
                inputListener.nativeSetGrab(z);
            }
            if (!z3) {
                this.mappingEnabled = false;
                this.router.m14612a();
                this.injector.reset();
                stop();
            }
            if (!z) {
                cancelSafetyCheck();
            } else if (!z2) {
                cancelSafetyCheck();
                this.touchFrameSinceGrab = false;
                this.rawFramesAtGrab = inputListener.nativeGetTouchRawFrameCount();
                this.injectedAtGrab = this.injector.getInjectedCount();
                this.failedAtGrab = this.injector.getFailedCount();
                this.touchForwardedAtGrab = this.touchForwardedCount;
                this.safetyCheck = this.safetyExecutor.scheduleWithFixedDelay(new se2(this, (byte) 3), 1000L, 1000L, TimeUnit.MILLISECONDS);
            }
            this.logger.m11504i("InputListener", "inject %s", z ? "enabled (real touch grabbed)" : "disabled");
            String str = "touch inject " + z;
            nr4.f27900a.m16823b(str, str);
        }
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setInjectRelativeAim(boolean z) {
        this.relativeAim = z;
        this.injector.setRelativeAim(z);
        this.logger.m11504i("InputListener", "inject relative aim: %b", Boolean.valueOf(z));
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setInjectSensitivity(float f, float f2) {
        this.sensX = f;
        this.sensY = f2;
        this.injector.setSensitivity(f, f2);
        this.logger.m11504i("InputListener", "inject sensitivity: x=%.2f y=%.2f", Float.valueOf(f), Float.valueOf(f2));
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setInjectSensitivityArea(int i) {
        this.sensArea = i;
        this.injector.setSensitivityArea(i);
        this.logger.m11504i("InputListener", "inject sensitivity area: %d", Integer.valueOf(i));
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setInjectSensitivityCurve(int i) {
        this.sensCurve = i;
        this.injector.setSensitivityCurve(i);
        this.logger.m11504i("InputListener", "inject sensitivity curve: %d", Integer.valueOf(i));
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setInjectSmoothing(boolean z, float f, float f2) {
        this.injector.setSmoothing(z, f, f2);
        this.logger.m11504i("InputListener", "inject smoothing: enabled=%b minCutoff=%.2f beta=%.4f", Boolean.valueOf(z), Float.valueOf(f), Float.valueOf(f2));
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setKeyboardInject(boolean z) {
        synchronized (this.lifecycleLock) {
            this.keyboardInjectEnabled = z;
            if (!z || isListening()) {
                InputListener inputListener = InputListener.INSTANCE;
                if (inputListener.isLoaded()) {
                    inputListener.nativeSetKeyboardGrab(z);
                }
            } else {
                start();
                if (!isListening()) {
                    this.logger.m11508w("InputListener", "setKeyboardInject(true) ignored: auto-start failed");
                    this.keyboardInjectEnabled = false;
                }
            }
            if (!z) {
                this.router.f21623g.m1855b();
                if (!this.injectEnabled && !this.mouseInjectEnabled) {
                    this.mappingEnabled = false;
                    this.router.m14612a();
                    this.injector.reset();
                    stop();
                }
            }
            this.logger.m11504i("InputListener", "keyboard inject: %b", Boolean.valueOf(z));
            String str = "keyboard inject " + z;
            nr4.f27900a.m16823b(str, str);
        }
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setMappingEnabled(boolean z) {
        synchronized (this.lifecycleLock) {
            if (z) {
                if (!isListening()) {
                    start();
                    if (!isListening()) {
                        this.logger.m11508w("InputListener", "setMappingEnabled(true) ignored: auto-start failed");
                        this.mappingEnabled = false;
                    }
                }
            }
            this.mappingEnabled = z;
            if (!z) {
                this.router.m14612a();
            }
            this.logger.m11504i("InputListener", "mapping %s", this.mappingEnabled ? "enabled" : "disabled");
            nr4 nr4Var = nr4.f27900a;
            String str = "mapping " + this.mappingEnabled;
            nr4Var.m16823b(str, str);
        }
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setMappingProfile(i53 i53Var) {
        String str;
        boolean z;
        List<x13> list;
        List list2;
        this.displayTransform.refreshNow();
        kf2 kf2Var = this.router;
        synchronized (kf2Var) {
            kf2Var.m14612a();
            kf2Var.f21624h = (i53Var == null || i53Var.f18199b.isEmpty()) ? null : i53Var;
        }
        if (i53Var == null || i53Var.f18199b.isEmpty()) {
            i53Var = null;
        }
        Logger logger = this.logger;
        if (i53Var == null || (str = i53Var.f18198a) == null) {
            str = "none";
        }
        logger.m11504i("InputListener", "mapping profile: %s (%d)", str, Integer.valueOf((i53Var == null || (list2 = i53Var.f18199b) == null) ? 0 : list2.size()));
        if (i53Var != null && (list = i53Var.f18199b) != null && !list.isEmpty()) {
            for (x13 x13Var : list) {
                if (x13Var.f43220c) {
                    this.router.f21621e.getClass();
                    if (ay1.m1246b(x13Var)) {
                        z = true;
                        break;
                    }
                }
            }
        }
        z = false;
        if (this.keyboardInjectEnabled) {
            InputListener inputListener = InputListener.INSTANCE;
            if (inputListener.isLoaded()) {
                inputListener.nativeSetKeyboardGrab(!z || this.router.f21621e.f1625c);
            }
        }
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setMouseInject(boolean z) {
        synchronized (this.lifecycleLock) {
            this.mouseInjectEnabled = z;
            if (!z || isListening()) {
                InputListener inputListener = InputListener.INSTANCE;
                if (inputListener.isLoaded()) {
                    inputListener.nativeSetMouseGrab(z);
                }
            } else {
                start();
                if (!isListening()) {
                    this.logger.m11508w("InputListener", "setMouseInject(true) ignored: auto-start failed");
                    this.mouseInjectEnabled = false;
                }
            }
            SyntheticInputInjector syntheticInputInjector = this.injector;
            if (z) {
                syntheticInputInjector.hideSystemCursor();
            } else {
                syntheticInputInjector.showSystemCursor();
                synchronized (this.mouseLock) {
                    ScheduledFuture<?> scheduledFuture = this.mouseFlushFuture;
                    if (scheduledFuture != null) {
                        scheduledFuture.cancel(false);
                    }
                    this.mouseFlushFuture = null;
                    this.accumRelDx = 0;
                    this.accumRelDy = 0;
                    this.isMouseDown = false;
                    this.lastInjectedMouseNs = 0L;
                }
                this.router.f21621e.m1249d();
                this.router.f21622f.m14529o();
            }
            if (!z && !this.injectEnabled && !this.keyboardInjectEnabled) {
                this.mappingEnabled = false;
                this.router.m14612a();
                this.injector.reset();
                stop();
            }
            if (z && (this.lastCursorX < 0.0f || this.lastCursorY < 0.0f)) {
                jb1 snapshot = this.displayTransform.getSnapshot();
                int i = snapshot.f19970b;
                float f = i > 0 ? i : 1080.0f;
                int i2 = snapshot.f19971c;
                float f2 = i2 > 0 ? i2 : 2400.0f;
                this.lastCursorX = f / 2.0f;
                this.lastCursorY = f2 / 2.0f;
            }
            dispatchCursor(this.lastCursorX, this.lastCursorY, false, z && !this.router.f21621e.f1625c);
            this.logger.m11504i("InputListener", "mouse inject: %b (cursor at %.1f, %.1f)", Boolean.valueOf(z), Float.valueOf(this.lastCursorX), Float.valueOf(this.lastCursorY));
            String str = "mouse inject " + z;
            nr4.f27900a.m16823b(str, str);
        }
    }

    @Override // frb.axeron.server.input.IInputListener
    public void setMousePollingRateLimit(int i) {
        if (i < 0) {
            i = 0;
        }
        this.mousePollingRateLimitHz = i;
        this.logger.m11504i("InputListener", "mouse polling rate limit set to %d Hz", Integer.valueOf(this.mousePollingRateLimitHz));
    }

    /* JADX WARN: Code restructure failed: missing block: B:51:0x0160, code lost:
    
        if (r12.router.f21621e.f1625c != false) goto L48;
     */
    @Override // frb.axeron.server.input.IInputListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public int start() {
        /*
            Method dump skipped, instructions count: 432
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.input.InputListenerService.start():int");
    }

    @Override // frb.axeron.server.input.IInputListener
    public void stop() {
        synchronized (this.lifecycleLock) {
            InputListener inputListener = InputListener.INSTANCE;
            if (inputListener.isLoaded()) {
                inputListener.nativeSetGrab(false);
                inputListener.nativeSetKeyboardGrab(false);
                inputListener.nativeSetMouseGrab(false);
                inputListener.nativeStop();
            }
            inputListener.setSink(null);
            this.displayTransform.stop();
            cancelSafetyCheck();
            synchronized (this.mouseLock) {
                ScheduledFuture<?> scheduledFuture = this.mouseFlushFuture;
                if (scheduledFuture != null) {
                    scheduledFuture.cancel(false);
                }
                this.mouseFlushFuture = null;
                this.accumRelDx = 0;
                this.accumRelDy = 0;
                this.isMouseDown = false;
                this.lastInjectedMouseNs = 0L;
            }
            this.injectEnabled = false;
            this.injector.setUseTouchDeviceId(false);
            this.mappingEnabled = false;
            this.keyboardInjectEnabled = false;
            this.mouseInjectEnabled = false;
            this.monitoredCount = 0;
            this.router.m14612a();
            this.injector.reset();
            this.logger.m11502i("InputListener", "stopped");
            nr4.f27900a.m16823b("listener stop", "listener stop");
        }
    }

    @Override // frb.axeron.server.input.IInputListener
    public void unregisterCallback(IInputCallback iInputCallback) {
        if (iInputCallback != null) {
            this.callbacks.unregister(iInputCallback);
        }
    }
}
