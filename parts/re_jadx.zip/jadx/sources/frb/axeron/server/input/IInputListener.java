package frb.axeron.server.input;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import frb.axeron.server.input.IInputCallback;
import p000.i53;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public interface IInputListener extends IInterface {
    public static final String DESCRIPTOR = "frb.axeron.server.input.IInputListener";

    int[] currentDisplayMetrics() throws RemoteException;

    int getMouseHardwareRate() throws RemoteException;

    int getMousePollingRate() throws RemoteException;

    int getMousePollingRateLimit() throws RemoteException;

    void hideSystemCursor() throws RemoteException;

    boolean injectTap(float f, float f2) throws RemoteException;

    boolean isAltKeyActive() throws RemoteException;

    boolean isInjectEnabled() throws RemoteException;

    boolean isKeyboardInject() throws RemoteException;

    boolean isListening() throws RemoteException;

    boolean isMappingEnabled() throws RemoteException;

    boolean isMouseInject() throws RemoteException;

    int monitoredDeviceCount() throws RemoteException;

    void registerCallback(IInputCallback iInputCallback) throws RemoteException;

    void setAltKeyActive(boolean z) throws RemoteException;

    void setClientLifeline(IBinder iBinder) throws RemoteException;

    void setInjectEnabled(boolean z) throws RemoteException;

    void setInjectRelativeAim(boolean z) throws RemoteException;

    void setInjectSensitivity(float f, float f2) throws RemoteException;

    void setInjectSensitivityArea(int i) throws RemoteException;

    void setInjectSensitivityCurve(int i) throws RemoteException;

    void setInjectSmoothing(boolean z, float f, float f2) throws RemoteException;

    void setKeyboardInject(boolean z) throws RemoteException;

    void setMappingEnabled(boolean z) throws RemoteException;

    void setMappingProfile(i53 i53Var) throws RemoteException;

    void setMouseInject(boolean z) throws RemoteException;

    void setMousePollingRateLimit(int i) throws RemoteException;

    int start() throws RemoteException;

    void stop() throws RemoteException;

    void unregisterCallback(IInputCallback iInputCallback) throws RemoteException;

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static abstract class Stub extends Binder implements IInputListener {
        static final int TRANSACTION_currentDisplayMetrics = 13;
        static final int TRANSACTION_getMouseHardwareRate = 31;
        static final int TRANSACTION_getMousePollingRate = 27;
        static final int TRANSACTION_getMousePollingRateLimit = 29;
        static final int TRANSACTION_hideSystemCursor = 30;
        static final int TRANSACTION_injectTap = 9;
        static final int TRANSACTION_isAltKeyActive = 22;
        static final int TRANSACTION_isInjectEnabled = 8;
        static final int TRANSACTION_isKeyboardInject = 24;
        static final int TRANSACTION_isListening = 4;
        static final int TRANSACTION_isMappingEnabled = 12;
        static final int TRANSACTION_isMouseInject = 26;
        static final int TRANSACTION_monitoredDeviceCount = 18;
        static final int TRANSACTION_registerCallback = 5;
        static final int TRANSACTION_setAltKeyActive = 21;
        static final int TRANSACTION_setClientLifeline = 19;
        static final int TRANSACTION_setInjectEnabled = 7;
        static final int TRANSACTION_setInjectRelativeAim = 16;
        static final int TRANSACTION_setInjectSensitivity = 14;
        static final int TRANSACTION_setInjectSensitivityArea = 17;
        static final int TRANSACTION_setInjectSensitivityCurve = 20;
        static final int TRANSACTION_setInjectSmoothing = 15;
        static final int TRANSACTION_setKeyboardInject = 23;
        static final int TRANSACTION_setMappingEnabled = 11;
        static final int TRANSACTION_setMappingProfile = 10;
        static final int TRANSACTION_setMouseInject = 25;
        static final int TRANSACTION_setMousePollingRateLimit = 28;
        static final int TRANSACTION_start = 2;
        static final int TRANSACTION_stop = 3;
        static final int TRANSACTION_unregisterCallback = 6;

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        private static final class Proxy implements IInputListener {
            private IBinder mRemote;

            public Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            @Override // frb.axeron.server.input.IInputListener
            public int[] currentDisplayMetrics() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.createIntArray();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final String getInterfaceDescriptor() {
                return IInputListener.DESCRIPTOR;
            }

            @Override // frb.axeron.server.input.IInputListener
            public int getMouseHardwareRate() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(31, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public int getMousePollingRate() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(27, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public int getMousePollingRateLimit() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(29, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void hideSystemCursor() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(30, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public boolean injectTap(float f, float f2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeFloat(f);
                    obtain.writeFloat(f2);
                    this.mRemote.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public boolean isAltKeyActive() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(22, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public boolean isInjectEnabled() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public boolean isKeyboardInject() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(24, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public boolean isListening() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public boolean isMappingEnabled() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public boolean isMouseInject() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(26, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public int monitoredDeviceCount() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void registerCallback(IInputCallback iInputCallback) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeStrongInterface(iInputCallback);
                    this.mRemote.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setAltKeyActive(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(z ? 1 : 0);
                    this.mRemote.transact(21, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setClientLifeline(IBinder iBinder) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeStrongBinder(iBinder);
                    this.mRemote.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setInjectEnabled(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(z ? 1 : 0);
                    this.mRemote.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setInjectRelativeAim(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(z ? 1 : 0);
                    this.mRemote.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setInjectSensitivity(float f, float f2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeFloat(f);
                    obtain.writeFloat(f2);
                    this.mRemote.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setInjectSensitivityArea(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(i);
                    this.mRemote.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setInjectSensitivityCurve(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(i);
                    this.mRemote.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setInjectSmoothing(boolean z, float f, float f2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(z ? 1 : 0);
                    obtain.writeFloat(f);
                    obtain.writeFloat(f2);
                    this.mRemote.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setKeyboardInject(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(z ? 1 : 0);
                    this.mRemote.transact(23, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setMappingEnabled(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(z ? 1 : 0);
                    this.mRemote.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setMappingProfile(i53 i53Var) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    if (i53Var != null) {
                        obtain.writeInt(1);
                        i53Var.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.mRemote.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setMouseInject(boolean z) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(z ? 1 : 0);
                    this.mRemote.transact(25, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void setMousePollingRateLimit(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeInt(i);
                    this.mRemote.transact(28, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public int start() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void stop() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    this.mRemote.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputListener
            public void unregisterCallback(IInputCallback iInputCallback) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputListener.DESCRIPTOR);
                    obtain.writeStrongInterface(iInputCallback);
                    this.mRemote.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, IInputListener.DESCRIPTOR);
        }

        public static IInputListener asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(IInputListener.DESCRIPTOR);
            return (queryLocalInterface == null || !(queryLocalInterface instanceof IInputListener)) ? new Proxy(iBinder) : (IInputListener) queryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i >= 1 && i <= 16777215) {
                parcel.enforceInterface(IInputListener.DESCRIPTOR);
            }
            switch (i) {
                case 2:
                    int start = start();
                    parcel2.writeNoException();
                    parcel2.writeInt(start);
                    return true;
                case 3:
                    stop();
                    parcel2.writeNoException();
                    return true;
                case 4:
                    boolean isListening = isListening();
                    parcel2.writeNoException();
                    parcel2.writeInt(isListening ? 1 : 0);
                    return true;
                case 5:
                    registerCallback(IInputCallback.Stub.asInterface(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 6:
                    unregisterCallback(IInputCallback.Stub.asInterface(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 7:
                    setInjectEnabled(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 8:
                    boolean isInjectEnabled = isInjectEnabled();
                    parcel2.writeNoException();
                    parcel2.writeInt(isInjectEnabled ? 1 : 0);
                    return true;
                case 9:
                    boolean injectTap = injectTap(parcel.readFloat(), parcel.readFloat());
                    parcel2.writeNoException();
                    parcel2.writeInt(injectTap ? 1 : 0);
                    return true;
                case 10:
                    setMappingProfile(parcel.readInt() != 0 ? i53.CREATOR.createFromParcel(parcel) : null);
                    parcel2.writeNoException();
                    return true;
                case 11:
                    setMappingEnabled(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 12:
                    boolean isMappingEnabled = isMappingEnabled();
                    parcel2.writeNoException();
                    parcel2.writeInt(isMappingEnabled ? 1 : 0);
                    return true;
                case 13:
                    int[] currentDisplayMetrics = currentDisplayMetrics();
                    parcel2.writeNoException();
                    parcel2.writeIntArray(currentDisplayMetrics);
                    return true;
                case 14:
                    setInjectSensitivity(parcel.readFloat(), parcel.readFloat());
                    parcel2.writeNoException();
                    return true;
                case 15:
                    setInjectSmoothing(parcel.readInt() != 0, parcel.readFloat(), parcel.readFloat());
                    parcel2.writeNoException();
                    return true;
                case 16:
                    setInjectRelativeAim(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 17:
                    setInjectSensitivityArea(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 18:
                    int monitoredDeviceCount = monitoredDeviceCount();
                    parcel2.writeNoException();
                    parcel2.writeInt(monitoredDeviceCount);
                    return true;
                case 19:
                    setClientLifeline(parcel.readStrongBinder());
                    parcel2.writeNoException();
                    return true;
                case 20:
                    setInjectSensitivityCurve(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 21:
                    setAltKeyActive(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 22:
                    boolean isAltKeyActive = isAltKeyActive();
                    parcel2.writeNoException();
                    parcel2.writeInt(isAltKeyActive ? 1 : 0);
                    return true;
                case 23:
                    setKeyboardInject(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 24:
                    boolean isKeyboardInject = isKeyboardInject();
                    parcel2.writeNoException();
                    parcel2.writeInt(isKeyboardInject ? 1 : 0);
                    return true;
                case 25:
                    setMouseInject(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 26:
                    boolean isMouseInject = isMouseInject();
                    parcel2.writeNoException();
                    parcel2.writeInt(isMouseInject ? 1 : 0);
                    return true;
                case 27:
                    int mousePollingRate = getMousePollingRate();
                    parcel2.writeNoException();
                    parcel2.writeInt(mousePollingRate);
                    return true;
                case 28:
                    setMousePollingRateLimit(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 29:
                    int mousePollingRateLimit = getMousePollingRateLimit();
                    parcel2.writeNoException();
                    parcel2.writeInt(mousePollingRateLimit);
                    return true;
                case 30:
                    hideSystemCursor();
                    parcel2.writeNoException();
                    return true;
                case 31:
                    int mouseHardwareRate = getMouseHardwareRate();
                    parcel2.writeNoException();
                    parcel2.writeInt(mouseHardwareRate);
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
