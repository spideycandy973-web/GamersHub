package frb.axeron.server.input;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;
import java.io.File;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import p000.di1;
import p000.ei2;
import p000.ij0;
import p000.jj0;
import p000.k41;
import p000.kn5;
import p000.lk1;
import p000.m53;
import p000.md4;
import p000.me2;
import p000.nd4;
import p000.ne2;
import p000.nr4;
import p000.pr4;
import p000.qr4;
import p000.us0;
import p000.xy1;
import p000.ye2;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class InputListener {
    public static final InputListener INSTANCE = new InputListener();
    private static final int RUN_ACTIVE = 1;
    private static final int RUN_CANCELLED = 2;
    private static final int RUN_PENDING = 0;
    private static final long RUN_TIMEOUT_MS = 3000;
    private static volatile boolean loaded;
    private static volatile Handler ownerHandler;
    private static volatile ne2 sink;

    private InputListener() {
    }

    public static final void dispatchKey(int i, long j, int i2, int i3) {
        try {
            ne2 ne2Var = sink;
            if (ne2Var != null) {
                ((ye2) ne2Var).m23397a(i, i2, j, i3);
            }
        } catch (Throwable th) {
            Log.e("InputListener", "dispatchKey failed", th);
            nr4.f27900a.m16831p("dispatch_exception", "key", th);
        }
    }

    public static final void dispatchMouse(int i, long j, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
        try {
            ne2 ne2Var = sink;
            if (ne2Var != null) {
                ((ye2) ne2Var).m23398b(i, j, i2, i3, i4, i5, i6, i7, i8, i9);
            }
        } catch (Throwable th) {
            Log.e("InputListener", "dispatchMouse failed", th);
            nr4.f27900a.m16831p("dispatch_exception", "mouse", th);
        }
    }

    public static final void dispatchTouchFrame(int i, long j, int[] iArr, int i2) {
        iArr.getClass();
        try {
            ne2 ne2Var = sink;
            if (ne2Var != null) {
                ((ye2) ne2Var).m23399c(i, j, iArr, i2);
            }
        } catch (Throwable th) {
            Log.e("InputListener", "dispatchTouchFrame failed", th);
            nr4.f27900a.m16831p("dispatch_exception", "touch", th);
        }
    }

    public static /* synthetic */ boolean loadLibraryFallback$default(InputListener inputListener, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = "touch";
        }
        return inputListener.loadLibraryFallback(str);
    }

    private final void onLoaded() {
        Object md4Var;
        File file = nr4.f27909j;
        String path = file != null ? new File(file, "native_crash.txt").getPath() : null;
        if (path != null) {
            try {
                INSTANCE.nativeInstallCrashHandler(path);
                md4Var = kn5.f22076a;
            } catch (Throwable th) {
                md4Var = new md4(th);
            }
            Throwable m16656b = nd4.m16656b(md4Var);
            if (m16656b != null) {
                nr4 nr4Var = nr4.f27900a;
                String concat = "native crash handler unavailable: ".concat(m16656b.getClass().getName());
                nr4Var.m16823b(concat, concat);
            }
        }
        nr4 nr4Var2 = nr4.f27900a;
        nr4.m16817q("native", true, new us0((byte) 29));
        nr4.m16817q("native.state", true, new me2((byte) 0));
        nr4.m16817q("input.nodes", false, new me2((byte) 1));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String onLoaded$lambda$1() {
        if (loaded) {
            return INSTANCE.nativeGetLogSnapshot();
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String onLoaded$lambda$2() {
        if (loaded) {
            return INSTANCE.nativeGetDiagnosticsState();
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String onLoaded$lambda$3() {
        List list = qr4.f32608a;
        List m18501b = qr4.m18501b();
        Map map = (Map) INSTANCE.runOnOwner(di1.f10339a, new k41(m18501b, (byte) 2));
        map.getClass();
        return ij0.m13408l0(qr4.m18501b(), "\n", null, null, new pr4(map, (byte) 0), 30);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Map onLoaded$lambda$3$0(List list) {
        List list2 = qr4.f32608a;
        int m15765Z = m53.m15765Z(jj0.m14060l(list, 10));
        if (m15765Z < 16) {
            m15765Z = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(m15765Z);
        for (Object obj : list) {
            linkedHashMap.put(obj, qr4.m18502c((String) obj));
        }
        return linkedHashMap;
    }

    private final <T> T runOn(Handler handler, T t, xy1 xy1Var) {
        if (handler == null || ei2.m10070i(Looper.myLooper(), handler.getLooper())) {
            return (T) xy1Var.invoke();
        }
        AtomicReference atomicReference = new AtomicReference(t);
        AtomicInteger atomicInteger = new AtomicInteger(0);
        CountDownLatch countDownLatch = new CountDownLatch(1);
        handler.post(new lk1(atomicInteger, atomicReference, t, countDownLatch, xy1Var, (byte) 1));
        if (!countDownLatch.await(RUN_TIMEOUT_MS, TimeUnit.MILLISECONDS) && !atomicInteger.compareAndSet(0, 2)) {
            countDownLatch.await();
        }
        return (T) atomicReference.get();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void runOn$lambda$0(AtomicInteger atomicInteger, AtomicReference atomicReference, Object obj, CountDownLatch countDownLatch, xy1 xy1Var) {
        Object md4Var;
        if (atomicInteger.compareAndSet(0, 1)) {
            try {
                md4Var = xy1Var.invoke();
            } catch (Throwable th) {
                md4Var = new md4(th);
            }
            if (!(md4Var instanceof md4)) {
                obj = md4Var;
            }
            atomicReference.set(obj);
        }
        countDownLatch.countDown();
    }

    public final boolean isLoaded() {
        return loaded;
    }

    public final synchronized boolean load(String str) {
        str.getClass();
        boolean z = true;
        if (loaded) {
            return true;
        }
        try {
        } catch (Throwable th) {
            Log.e("InputListener", "System.load(" + str + ") failed", th);
            nr4.f27900a.m16831p("native_load_failed", str, th);
            z = false;
        }
        if (!new File(str).exists()) {
            Log.e("InputListener", "Library file does not exist at path: ".concat(str));
            return false;
        }
        System.load(str);
        loaded = true;
        Log.i("InputListener", "Successfully loaded " + str + " via System.load");
        onLoaded();
        return z;
    }

    public final synchronized boolean loadLibraryFallback(String str) {
        str.getClass();
        boolean z = true;
        if (loaded) {
            return true;
        }
        try {
            System.loadLibrary(str);
            loaded = true;
            Log.i("InputListener", "Successfully loaded " + str + " via System.loadLibrary");
            onLoaded();
        } catch (Throwable th) {
            Log.e("InputListener", "System.loadLibrary(" + str + ") failed", th);
            nr4.f27900a.m16831p("native_load_failed", str, th);
            z = false;
        }
        return z;
    }

    public final native int[] nativeGetDeviceAxis(int i);

    public final native float[] nativeGetDeviceCalibration(int i);

    public final native int nativeGetDeviceGeneration();

    public final native String nativeGetDeviceName(int i);

    public final native String nativeGetDiagnosticsState();

    public final native String nativeGetLogSnapshot();

    public final native int nativeGetTouchRawFrameCount();

    public final native void nativeInstallCrashHandler(String str);

    public final native boolean nativeIsKeyboardGrab();

    public final native boolean nativeIsMouseGrab();

    public final native boolean nativeIsRunning();

    public final native int nativeRescanDevices();

    public final native void nativeSetDisplayMetrics(int i, int i2, int i3);

    public final native void nativeSetDisplayRotation(int i);

    public final native void nativeSetGrab(boolean z);

    public final native void nativeSetKeyboardGrab(boolean z);

    public final native void nativeSetMouseGrab(boolean z);

    public final native void nativeSetPointerSpeed(int i, boolean z, boolean z2);

    public final native int nativeStart();

    public final native void nativeStop();

    public final <T> T runOnMain(T t, xy1 xy1Var) {
        xy1Var.getClass();
        return (T) runOn(new Handler(Looper.getMainLooper()), t, xy1Var);
    }

    public final <T> T runOnOwner(T t, xy1 xy1Var) {
        xy1Var.getClass();
        return (T) runOn(ownerHandler, t, xy1Var);
    }

    public final void setSink(ne2 ne2Var) {
        sink = ne2Var;
    }

    public final synchronized void startOwnerThread() {
        if (ownerHandler != null) {
            return;
        }
        HandlerThread handlerThread = new HandlerThread("axgc-input-owner");
        handlerThread.start();
        ownerHandler = new Handler(handlerThread.getLooper());
        nr4 nr4Var = nr4.f27900a;
        Looper looper = handlerThread.getLooper();
        looper.getClass();
        nr4.m16819s("input-owner", looper);
        String str = "input owner thread started from " + Thread.currentThread().getName();
        nr4Var.m16823b(str, str);
    }
}
