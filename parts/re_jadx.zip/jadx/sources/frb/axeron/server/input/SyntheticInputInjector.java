package frb.axeron.server.input;

import android.os.Process;
import android.os.SystemClock;
import android.view.MotionEvent;
import com.unity3d.services.UnityAdsConstants;
import frb.axeron.server.util.Logger;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.ListIterator;
import java.util.Set;
import java.util.concurrent.locks.LockSupport;
import p000.d63;
import p000.dg2;
import p000.ei2;
import p000.hi1;
import p000.hn0;
import p000.ij0;
import p000.k85;
import p000.l85;
import p000.lv4;
import p000.m53;
import p000.m85;
import p000.qp7;
import p000.r53;
import p000.sg2;
import p000.ud4;
import p000.wm3;
import p000.xy1;
import p000.ze2;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class SyntheticInputInjector {
    public static final float AIM_REGION_X_FRACTION = 0.5f;
    public static final int AREA_ALL = 0;
    public static final int AREA_LEFT = -1;
    public static final int AREA_RIGHT = 1;
    public static final long CLOCK_SANITY_MS = 2000;
    public static final int CURVE_ACCELERATE = 1;
    public static final float CURVE_ACC_MAX = 1.8f;
    public static final int CURVE_DECELERATE = 2;
    public static final float CURVE_DEC_MIN = 0.5f;
    public static final int CURVE_LINEAR = 0;
    public static final float CURVE_SPEED_REF = 0.04f;
    public static final k85 Companion = new k85();
    public static final int FLAG_CANCELED = 32;
    public static final int INJECT_MODE_ASYNC = 0;
    public static final int INJECT_RING_CAPACITY = 1024;
    public static final long LAG_RELEASE_DIV = 8;
    public static final int MAX_POINTERS = 16;
    private final LinkedHashMap<Long, m85> active;
    private final MotionEvent.PointerCoords[][] batchCoords;
    private int clockSource;
    private final MotionEvent.PointerCoords[] coordsPool;
    private long downTime;
    private final MotionEvent.PointerCoords[] emitCoords;
    private final MotionEvent.PointerProperties[] emitProps;
    private volatile float euroBeta;
    private volatile boolean euroEnabled;
    private volatile float euroMinCutoff;
    private volatile long failedCount;
    private final l85 frameProcessHist;
    private volatile float geometricScale;
    private int gestureDeviceId;
    private final l85 handoffHist;
    private final ThreadLocal<Boolean> hwContext;
    private long hwLagMs;
    private volatile float idcSizeBias;
    private volatile float idcSizeScale;
    private final MotionEvent[] injectRing;
    private volatile int injectRingRead;
    private volatile int injectRingWrite;
    private final Thread injectThread;
    private volatile long injectedCount;
    private final long[] keyById;
    private float lastContactMajor;
    private float lastContactPressure;
    private float lastContactSize;
    private volatile String lastFailure;
    private long lastHwTimeMs;
    private long lastInjectEventTime;
    private volatile long lastInjectUptime;
    private final Logger logger;
    private long mouseClickDownTime;
    private boolean moveDirty;
    private final HashSet<Long> pending;
    private volatile long pendingEnqueueNs;
    private long pendingMoveTime;
    private volatile float pressureScale;
    private final MotionEvent.PointerProperties[] propsPool;
    private volatile boolean relativeAimEnabled;
    private volatile int sensArea;
    private volatile int sensCurve;
    private volatile float sensX;
    private volatile float sensY;
    private final Method setDisplayIdMethod;
    private volatile float sizeScale;
    private volatile int targetDisplayId;
    private volatile int touchDeviceId;
    private volatile boolean useTouchDeviceId;
    private final boolean[] usedIds;
    private volatile float xPrecision;
    private volatile float yPrecision;

    public SyntheticInputInjector(Logger logger) {
        Method method;
        logger.getClass();
        this.logger = logger;
        this.euroMinCutoff = 1.0f;
        this.euroBeta = 0.007f;
        this.sensX = 1.0f;
        this.sensY = 1.0f;
        this.relativeAimEnabled = true;
        this.sensArea = 1;
        this.active = new LinkedHashMap<>();
        this.usedIds = new boolean[16];
        this.hwContext = new ThreadLocal<>();
        this.pending = new HashSet<>();
        MotionEvent.PointerProperties[] pointerPropertiesArr = new MotionEvent.PointerProperties[16];
        for (int i = 0; i < 16; i++) {
            pointerPropertiesArr[i] = new MotionEvent.PointerProperties();
        }
        this.propsPool = pointerPropertiesArr;
        MotionEvent.PointerCoords[] pointerCoordsArr = new MotionEvent.PointerCoords[16];
        for (int i2 = 0; i2 < 16; i2++) {
            pointerCoordsArr[i2] = new MotionEvent.PointerCoords();
        }
        this.coordsPool = pointerCoordsArr;
        MotionEvent.PointerProperties[] pointerPropertiesArr2 = new MotionEvent.PointerProperties[16];
        for (int i3 = 0; i3 < 16; i3++) {
            pointerPropertiesArr2[i3] = this.propsPool[i3];
        }
        this.emitProps = pointerPropertiesArr2;
        MotionEvent.PointerCoords[] pointerCoordsArr2 = new MotionEvent.PointerCoords[16];
        for (int i4 = 0; i4 < 16; i4++) {
            pointerCoordsArr2[i4] = this.coordsPool[i4];
        }
        this.emitCoords = pointerCoordsArr2;
        this.xPrecision = 1.0f;
        this.yPrecision = 1.0f;
        this.keyById = new long[16];
        this.lastContactPressure = 1.0f;
        this.idcSizeScale = Float.NaN;
        this.idcSizeBias = Float.NaN;
        try {
            method = MotionEvent.class.getMethod("setDisplayId", Integer.TYPE);
        } catch (Throwable unused) {
            method = null;
        }
        this.setDisplayIdMethod = method;
        MotionEvent.PointerCoords[][] pointerCoordsArr3 = new MotionEvent.PointerCoords[16][];
        int i5 = 0;
        while (i5 < 16) {
            int i6 = i5 + 1;
            MotionEvent.PointerCoords[] pointerCoordsArr4 = new MotionEvent.PointerCoords[i6];
            for (int i7 = 0; i7 < i6; i7++) {
                pointerCoordsArr4[i7] = new MotionEvent.PointerCoords();
            }
            pointerCoordsArr3[i5] = pointerCoordsArr4;
            i5 = i6;
        }
        this.batchCoords = pointerCoordsArr3;
        this.handoffHist = new l85();
        this.frameProcessHist = new l85();
        this.injectRing = new MotionEvent[1024];
        Thread thread = new Thread(new lv4(this, (byte) 5), "touch-inject");
        thread.setDaemon(true);
        thread.start();
        this.injectThread = thread;
    }

    private final int allocId(long j) {
        sg2 m9089U = j >= 0 ? dg2.m9089U(0, 16) : new sg2(15, 0, -1);
        int i = m9089U.f35307a;
        int i2 = m9089U.f35308b;
        int i3 = m9089U.f35309c;
        if ((i3 > 0 && i <= i2) || (i3 < 0 && i2 <= i)) {
            while (true) {
                boolean[] zArr = this.usedIds;
                if (!zArr[i]) {
                    zArr[i] = true;
                    return i;
                }
                if (i == i2) {
                    break;
                }
                i += i3;
            }
        }
        this.logger.m11510w("SyntheticInputInjector", "allocId: all %d pointer slots exhausted! active keys=%s", 16, this.active.keySet().toString());
        return -1;
    }

    private final void applySample(SyntheticInputEvent syntheticInputEvent) {
        long key = key(syntheticInputEvent);
        int action = syntheticInputEvent.getAction();
        if (action == 0) {
            if (this.active.containsKey(Long.valueOf(key))) {
                flushPendingMove();
                emit$default(this, this.active.size() == 1 ? 1 : 6, Long.valueOf(key), 0L, 0, 12, null);
                m85 remove = this.active.remove(Long.valueOf(key));
                if (remove != null) {
                    this.usedIds[remove.f25424a] = false;
                }
                this.moveDirty = false;
            }
            this.pending.remove(Long.valueOf(key));
            if (inBounds(syntheticInputEvent)) {
                startPointer(key, syntheticInputEvent);
                return;
            } else {
                this.pending.add(Long.valueOf(key));
                return;
            }
        }
        if (action == 1) {
            m85 m85Var = this.active.get(Long.valueOf(key));
            if (m85Var != null) {
                integrateMove(m85Var, syntheticInputEvent);
                return;
            } else {
                if (inBounds(syntheticInputEvent)) {
                    this.pending.remove(Long.valueOf(key));
                    startPointer(key, syntheticInputEvent);
                    return;
                }
                return;
            }
        }
        if (action != 2) {
            if (action == 4) {
                if (!this.active.containsKey(Long.valueOf(key))) {
                    this.pending.remove(Long.valueOf(key));
                    return;
                } else {
                    flushPendingMove();
                    cancelPointer(key);
                    return;
                }
            }
            return;
        }
        if (!this.active.containsKey(Long.valueOf(key))) {
            this.pending.remove(Long.valueOf(key));
            return;
        }
        flushPendingMove();
        emit$default(this, this.active.size() == 1 ? 1 : 6, Long.valueOf(key), 0L, 0, 12, null);
        m85 remove2 = this.active.remove(Long.valueOf(key));
        if (remove2 != null) {
            this.usedIds[remove2.f25424a] = false;
        }
        this.moveDirty = false;
    }

    private final void beginPointer(long j, float f, float f2, float f3, float f4, float f5, boolean z, long j2) {
        flushPendingMove();
        int allocId = allocId(j);
        Integer valueOf = Integer.valueOf(allocId);
        if (allocId < 0) {
            valueOf = null;
        }
        if (valueOf != null) {
            int intValue = valueOf.intValue();
            if (this.active.isEmpty()) {
                this.downTime = j2;
                this.gestureDeviceId = this.useTouchDeviceId ? this.touchDeviceId : 0;
            }
            this.keyById[intValue] = j;
            this.active.put(Long.valueOf(j), new m85(intValue, f, f2, f3, f4, f5, z));
            emit$default(this, this.active.size() == 1 ? 0 : 5, Long.valueOf(j), j2, 0, 8, null);
            this.moveDirty = false;
        }
    }

    public static /* synthetic */ void beginPointer$default(SyntheticInputInjector syntheticInputInjector, long j, float f, float f2, float f3, float f4, float f5, boolean z, long j2, int i, Object obj) {
        long j3;
        SyntheticInputInjector syntheticInputInjector2;
        long j4;
        float f6;
        float f7;
        float f8 = (i & 8) != 0 ? syntheticInputInjector.lastContactPressure : f3;
        float f9 = (i & 16) != 0 ? syntheticInputInjector.lastContactSize : f4;
        float f10 = (i & 32) != 0 ? syntheticInputInjector.lastContactMajor : f5;
        boolean z2 = (i & 64) != 0 ? false : z;
        if ((i & 128) != 0) {
            j3 = syntheticInputInjector.stampTime();
            syntheticInputInjector2 = syntheticInputInjector;
            f6 = f;
            f7 = f2;
            j4 = j;
        } else {
            j3 = j2;
            syntheticInputInjector2 = syntheticInputInjector;
            j4 = j;
            f6 = f;
            f7 = f2;
        }
        syntheticInputInjector2.beginPointer(j4, f6, f7, f8, f9, f10, z2, j3);
    }

    private final float biasedGain(float f, float f2, float f3) {
        return f == f2 ? f : ((float) Math.pow(f, 1.0f - f3)) * ((float) Math.pow(f2, f3));
    }

    private final boolean canBatch(MotionEvent motionEvent, MotionEvent motionEvent2) {
        if (motionEvent2.getAction() != 2 || motionEvent2.getPointerCount() != motionEvent.getPointerCount() || motionEvent2.getDownTime() != motionEvent.getDownTime() || motionEvent2.getDeviceId() != motionEvent.getDeviceId() || motionEvent2.getSource() != motionEvent.getSource() || motionEvent2.getEventTime() <= motionEvent.getEventTime()) {
            return false;
        }
        int pointerCount = motionEvent2.getPointerCount();
        for (int i = 0; i < pointerCount; i++) {
            if (motionEvent2.getPointerId(i) != motionEvent.getPointerId(i)) {
                return false;
            }
        }
        return true;
    }

    private final void cancelPointer(long j) {
        if (this.active.size() == 1) {
            emit$default(this, 3, Long.valueOf(j), 0L, 0, 12, null);
        } else {
            emit$default(this, 6, Long.valueOf(j), 0L, 32, 4, null);
        }
        m85 remove = this.active.remove(Long.valueOf(j));
        if (remove != null) {
            this.usedIds[remove.f25424a] = false;
        }
        this.moveDirty = false;
    }

    private final float cookPressure(int i, float f) {
        if (this.pressureScale <= 0.0f) {
            return 1.0f;
        }
        return i <= 0 ? f : i * this.pressureScale;
    }

    private final float cookSize(int i) {
        if (this.sizeScale <= 0.0f || i <= 0) {
            return 0.0f;
        }
        return i * this.sizeScale;
    }

    private final float cookTouchMajor(int i) {
        if (this.sizeScale <= 0.0f || i <= 0) {
            return 0.0f;
        }
        float f = i * this.geometricScale;
        if (!Float.isNaN(this.idcSizeScale)) {
            f *= this.idcSizeScale;
        }
        return !Float.isNaN(this.idcSizeBias) ? f + this.idcSizeBias : f;
    }

    private final float curveFactor(float f) {
        if (this.sensCurve == 0) {
            return 1.0f;
        }
        float m9131s = dg2.m9131s(f / 0.04f, 0.0f, 1.0f);
        int i = this.sensCurve;
        if (i == 1) {
            return (m9131s * 0.79999995f) + 1.0f;
        }
        if (i != 2) {
            return 1.0f;
        }
        return 1.0f - (m9131s * 0.5f);
    }

    private final float dispXf(SyntheticInputEvent syntheticInputEvent) {
        return Float.isNaN(syntheticInputEvent.getDispXf()) ? syntheticInputEvent.getDispX() : syntheticInputEvent.getDispXf();
    }

    private final float dispYf(SyntheticInputEvent syntheticInputEvent) {
        return Float.isNaN(syntheticInputEvent.getDispYf()) ? syntheticInputEvent.getDispY() : syntheticInputEvent.getDispYf();
    }

    private final void emit(int i, Long l, long j, int i2) {
        if (this.active.isEmpty()) {
            return;
        }
        int i3 = 0;
        int i4 = 0;
        for (int i5 = 0; i5 < 16; i5++) {
            if (this.usedIds[i5]) {
                long j2 = this.keyById[i5];
                m85 m85Var = this.active.get(Long.valueOf(j2));
                if (m85Var != null) {
                    MotionEvent.PointerProperties pointerProperties = this.propsPool[i4];
                    pointerProperties.clear();
                    pointerProperties.id = m85Var.f25424a;
                    pointerProperties.toolType = 1;
                    MotionEvent.PointerCoords pointerCoords = this.coordsPool[i4];
                    pointerCoords.clear();
                    pointerCoords.x = m85Var.f25425b;
                    pointerCoords.y = m85Var.f25426c;
                    pointerCoords.pressure = m85Var.f25429f;
                    pointerCoords.size = m85Var.f25430g;
                    float f = m85Var.f25431h;
                    pointerCoords.touchMajor = f;
                    pointerCoords.touchMinor = f;
                    pointerCoords.toolMajor = f;
                    pointerCoords.toolMinor = f;
                    if (l != null && j2 == l.longValue()) {
                        i3 = i4;
                    }
                    i4++;
                }
            }
        }
        if (i4 == 0) {
            return;
        }
        inject(this.downTime, j, (i == 5 || i == 6) ? i | (i3 << 8) : i, i4, this.emitProps, this.emitCoords, this.gestureDeviceId, this.xPrecision, this.yPrecision, i2);
    }

    public static /* synthetic */ void emit$default(SyntheticInputInjector syntheticInputInjector, int i, Long l, long j, int i2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            j = syntheticInputInjector.stampTime();
        }
        long j2 = j;
        if ((i3 & 8) != 0) {
            i2 = 0;
        }
        syntheticInputInjector.emit(i, l, j2, i2);
    }

    private final boolean enqueueInject(MotionEvent motionEvent) {
        int i = this.injectRingWrite;
        int i2 = (i + 1) & 1023;
        if (i2 == this.injectRingRead) {
            return false;
        }
        this.injectRing[i] = motionEvent;
        this.pendingEnqueueNs = System.nanoTime();
        this.injectRingWrite = i2;
        LockSupport.unpark(this.injectThread);
        return true;
    }

    private final long eventTime() {
        long uptimeMillis = SystemClock.uptimeMillis();
        long j = this.lastHwTimeMs;
        long j2 = uptimeMillis - 2000;
        boolean z = false;
        if (j <= 1000 + uptimeMillis && j2 <= j) {
            z = true;
        }
        if (j > 0) {
            int i = z ? 1 : 2;
            if (i != this.clockSource) {
                this.clockSource = i;
                Logger logger = this.logger;
                if (z) {
                    logger.m11504i("SyntheticInputInjector", "eventTime source = HARDWARE (monotonic), skew=%dms — replaying with real sample timing", Long.valueOf(uptimeMillis - j));
                } else {
                    logger.m11508w("SyntheticInputInjector", "eventTime source = FALLBACK inject-time — hw ts not in uptime domain (EVIOCSCLOCKID failed?); velocity fidelity reduced");
                }
            }
        }
        return z ? j : uptimeMillis;
    }

    private final void flushPendingMove() {
        SyntheticInputInjector syntheticInputInjector;
        if (!this.moveDirty || this.active.isEmpty()) {
            syntheticInputInjector = this;
        } else {
            long j = this.pendingMoveTime;
            if (j <= 0) {
                j = stampTime();
            }
            syntheticInputInjector = this;
            emit$default(syntheticInputInjector, 2, null, j, 0, 8, null);
        }
        syntheticInputInjector.moveDirty = false;
        syntheticInputInjector.pendingMoveTime = 0L;
    }

    private final boolean inBounds(SyntheticInputEvent syntheticInputEvent) {
        return syntheticInputEvent.getDisplayWidth() > 0 && syntheticInputEvent.getDisplayHeight() > 0 && syntheticInputEvent.getDispX() >= 0 && syntheticInputEvent.getDispX() < syntheticInputEvent.getDisplayWidth() && syntheticInputEvent.getDispY() >= 0 && syntheticInputEvent.getDispY() < syntheticInputEvent.getDisplayHeight();
    }

    private final boolean inSensArea(SyntheticInputEvent syntheticInputEvent) {
        if (syntheticInputEvent.getTouchMajor() != 4 && syntheticInputEvent.getTouchMajor() != 5 && syntheticInputEvent.getTrackingId() != 999 && syntheticInputEvent.getAction() != 7) {
            if (syntheticInputEvent.getDisplayWidth() <= 0) {
                return true;
            }
            float displayWidth = syntheticInputEvent.getDisplayWidth() * 0.5f;
            int i = this.sensArea;
            if (i != -1) {
                return i == 0 || dispXf(syntheticInputEvent) >= displayWidth;
            }
            if (dispXf(syntheticInputEvent) < displayWidth) {
                return true;
            }
        }
        return false;
    }

    private final boolean inject(long j, long j2, int i, int i2, MotionEvent.PointerProperties[] pointerPropertiesArr, MotionEvent.PointerCoords[] pointerCoordsArr, int i3, float f, float f2, int i4) {
        long j3 = this.lastInjectEventTime;
        long j4 = j2 > j3 ? j2 : j3 + 1;
        this.lastInjectEventTime = j4;
        MotionEvent obtain = MotionEvent.obtain(j > j4 ? j4 : j, j4, i, i2, pointerPropertiesArr, pointerCoordsArr, 0, 0, f, f2, i3, 0, 4098, i4);
        obtain.getClass();
        if (enqueueInject(obtain)) {
            return true;
        }
        try {
            obtain.recycle();
        } catch (Throwable unused) {
        }
        this.failedCount++;
        this.lastFailure = "inject ring full (consumer stalled), event dropped";
        return false;
    }

    public static /* synthetic */ boolean inject$default(SyntheticInputInjector syntheticInputInjector, long j, long j2, int i, int i2, MotionEvent.PointerProperties[] pointerPropertiesArr, MotionEvent.PointerCoords[] pointerCoordsArr, int i3, float f, float f2, int i4, int i5, Object obj) {
        return syntheticInputInjector.inject(j, j2, i, i2, pointerPropertiesArr, pointerCoordsArr, (i5 & 64) != 0 ? 0 : i3, (i5 & 128) != 0 ? 1.0f : f, (i5 & 256) != 0 ? 1.0f : f2, (i5 & 512) != 0 ? 0 : i4);
    }

    public static /* synthetic */ boolean injectMouseButton$default(SyntheticInputInjector syntheticInputInjector, float f, float f2, int i, int i2, int i3, Object obj) {
        if ((i3 & 8) != 0) {
            i2 = 1;
        }
        return syntheticInputInjector.injectMouseButton(f, f2, i, i2);
    }

    private final void injectNow(MotionEvent motionEvent) {
        try {
            int i = this.targetDisplayId;
            if (i != 0) {
                try {
                    Method method = this.setDisplayIdMethod;
                    if (method != null) {
                        method.invoke(motionEvent, Integer.valueOf(i));
                    }
                } catch (Throwable unused) {
                }
            }
            if (ze2.m24050a(motionEvent)) {
                this.injectedCount++;
                this.lastInjectUptime = SystemClock.uptimeMillis();
            } else {
                this.failedCount++;
                this.lastFailure = "rejected action=" + motionEvent.getActionMasked() + " pointers=" + motionEvent.getPointerCount();
            }
        } finally {
            try {
            } finally {
            }
        }
    }

    public static /* synthetic */ boolean injectScroll$default(SyntheticInputInjector syntheticInputInjector, float f, float f2, float f3, float f4, int i, Object obj) {
        if ((i & 8) != 0) {
            f4 = 0.0f;
        }
        return syntheticInputInjector.injectScroll(f, f2, f3, f4);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:32:0x0004 -> B:4:0x0004). Please report as a decompilation issue!!! */
    public static final void injectThread$lambda$0(SyntheticInputInjector syntheticInputInjector) {
        try {
            Process.setThreadPriority(-8);
        } catch (Throwable unused) {
        }
        while (!Thread.interrupted()) {
            MotionEvent pollInject = syntheticInputInjector.pollInject();
            if (pollInject == null) {
                LockSupport.park();
            } else {
                long j = syntheticInputInjector.pendingEnqueueNs;
                if (j > 0) {
                    l85 l85Var = syntheticInputInjector.handoffHist;
                    long nanoTime = (System.nanoTime() - j) / 1000;
                    l85Var.getClass();
                    l85Var.f23889a.incrementAndGet((int) dg2.m9135u(nanoTime / 100, 0L, 127L));
                }
                try {
                    if (pollInject.getAction() == 2) {
                        while (true) {
                            MotionEvent peekInject = syntheticInputInjector.peekInject();
                            if (peekInject == null || !syntheticInputInjector.canBatch(pollInject, peekInject)) {
                                break;
                            }
                            syntheticInputInjector.pollInject();
                            int pointerCount = peekInject.getPointerCount();
                            MotionEvent.PointerCoords[] pointerCoordsArr = syntheticInputInjector.batchCoords[pointerCount - 1];
                            for (int i = 0; i < pointerCount; i++) {
                                peekInject.getPointerCoords(i, pointerCoordsArr[i]);
                            }
                            pollInject.addBatch(peekInject.getEventTime(), pointerCoordsArr, peekInject.getMetaState());
                            peekInject.recycle();
                        }
                    }
                    syntheticInputInjector.injectNow(pollInject);
                } catch (Throwable th) {
                    syntheticInputInjector.logger.m11501e("SyntheticInputInjector", th, "inject worker iteration failed", new Object[0]);
                    pollInject.recycle();
                }
            }
        }
    }

    private final void integrateMove(m85 m85Var, SyntheticInputEvent syntheticInputEvent) {
        float f;
        float f2;
        float f3;
        float dispXf = dispXf(syntheticInputEvent);
        float dispYf = dispYf(syntheticInputEvent);
        if (!m85Var.f25432i || (this.sensX == 1.0f && this.sensY == 1.0f && this.sensCurve == 0)) {
            float m9131s = syntheticInputEvent.getDisplayWidth() > 0 ? dg2.m9131s(dispXf, 0.0f, syntheticInputEvent.getDisplayWidth() - 1) : dispXf;
            float m9131s2 = syntheticInputEvent.getDisplayHeight() > 0 ? dg2.m9131s(dispYf, 0.0f, syntheticInputEvent.getDisplayHeight() - 1) : dispYf;
            m85Var.f25427d = dispXf;
            m85Var.f25428e = dispYf;
            m85Var.f25433j = m9131s;
            m85Var.f25434k = m9131s2;
            f = m9131s;
            f2 = m9131s2;
        } else {
            float f4 = dispXf - m85Var.f25427d;
            float f5 = dispYf - m85Var.f25428e;
            m85Var.f25427d = dispXf;
            m85Var.f25428e = dispYf;
            float abs = Math.abs(f4);
            float abs2 = Math.abs(f5);
            float f6 = abs + abs2;
            float biasedGain = f6 > 1.0E-4f ? biasedGain(this.sensX, this.sensY, abs2 / f6) * curveFactor(syntheticInputEvent.getDisplayWidth() > 0 ? f6 / syntheticInputEvent.getDisplayWidth() : 0.0f) : 1.0f;
            float f7 = (f4 * biasedGain) + m85Var.f25433j;
            float f8 = (f5 * biasedGain) + m85Var.f25434k;
            if (!this.relativeAimEnabled || syntheticInputEvent.getDisplayWidth() <= 0 || syntheticInputEvent.getDisplayHeight() <= 0) {
                if (syntheticInputEvent.getDisplayWidth() > 0) {
                    f7 = dg2.m9131s(f7, 0.0f, syntheticInputEvent.getDisplayWidth() - 1);
                }
                if (syntheticInputEvent.getDisplayHeight() > 0) {
                    f8 = dg2.m9131s(f8, 0.0f, syntheticInputEvent.getDisplayHeight() - 1);
                }
                f3 = f7;
                f2 = f8;
            } else {
                float max = (Math.max(this.sensX, this.sensY) * maxCurveFactor()) - 1.0f;
                float f9 = max >= 0.0f ? max : 0.0f;
                float displayWidth = syntheticInputEvent.getDisplayWidth() * f9;
                float displayHeight = f9 * syntheticInputEvent.getDisplayHeight();
                f3 = dg2.m9131s(f7, -displayWidth, (syntheticInputEvent.getDisplayWidth() - 1) + displayWidth);
                f2 = dg2.m9131s(f8, -displayHeight, (syntheticInputEvent.getDisplayHeight() - 1) + displayHeight);
            }
            m85Var.f25433j = f3;
            m85Var.f25434k = f2;
            f = f3;
        }
        if (this.euroEnabled) {
            long eventTime = eventTime();
            m85Var.f25425b = wm3.m22189a(m85Var.f25435l, f, eventTime, this.euroMinCutoff, this.euroBeta);
            m85Var.f25426c = wm3.m22189a(m85Var.f25436m, f2, eventTime, this.euroMinCutoff, this.euroBeta);
        } else {
            m85Var.f25425b = f;
            m85Var.f25426c = f2;
        }
        if (syntheticInputEvent.getDevType() == 1) {
            m85Var.f25429f = cookPressure(syntheticInputEvent.getPressure(), m85Var.f25429f);
            m85Var.f25430g = cookSize(syntheticInputEvent.getContactMajor());
            m85Var.f25431h = cookTouchMajor(syntheticInputEvent.getContactMajor());
            rememberContact(m85Var);
        }
        this.moveDirty = true;
        this.pendingMoveTime = Math.max(this.pendingMoveTime, stampTime());
    }

    private final long key(SyntheticInputEvent syntheticInputEvent) {
        return (syntheticInputEvent.getDeviceId() << 32) | (syntheticInputEvent.getSlot() & 4294967295L);
    }

    private static final boolean liftPhysicalPointers$lambda$2(long j) {
        return j >= 0;
    }

    private final float maxCurveFactor() {
        return this.sensCurve == 1 ? 1.8f : 1.0f;
    }

    private final void noteHwTime(long j) {
        if (j <= 0) {
            return;
        }
        this.lastHwTimeMs = j / 1000;
        long uptimeMillis = SystemClock.uptimeMillis() - this.lastHwTimeMs;
        if (0 > uptimeMillis || uptimeMillis >= 2001) {
            return;
        }
        long j2 = this.hwLagMs;
        if (uptimeMillis < j2) {
            uptimeMillis = j2 - (((j2 - uptimeMillis) + 7) / 8);
        }
        this.hwLagMs = uptimeMillis;
    }

    private final MotionEvent peekInject() {
        int i = this.injectRingRead;
        if (i == this.injectRingWrite) {
            return null;
        }
        return this.injectRing[i];
    }

    private final long plannedTime(long j) {
        return j <= 0 ? stampTime() : Math.min(j, SystemClock.uptimeMillis()) - this.hwLagMs;
    }

    public static /* synthetic */ void pointerDown$default(SyntheticInputInjector syntheticInputInjector, long j, float f, float f2, long j2, int i, Object obj) {
        if ((i & 8) != 0) {
            j2 = 0;
        }
        syntheticInputInjector.pointerDown(j, f, f2, j2);
    }

    public static /* synthetic */ void pointerUp$default(SyntheticInputInjector syntheticInputInjector, long j, long j2, int i, Object obj) {
        if ((i & 2) != 0) {
            j2 = 0;
        }
        syntheticInputInjector.pointerUp(j, j2);
    }

    private final MotionEvent pollInject() {
        int i = this.injectRingRead;
        if (i == this.injectRingWrite) {
            return null;
        }
        MotionEvent[] motionEventArr = this.injectRing;
        MotionEvent motionEvent = motionEventArr[i];
        motionEventArr[i] = null;
        this.injectRingRead = (i + 1) & 1023;
        return motionEvent;
    }

    private final void rememberContact(m85 m85Var) {
        this.lastContactPressure = m85Var.f25429f;
        this.lastContactSize = m85Var.f25430g;
        this.lastContactMajor = m85Var.f25431h;
    }

    public static /* synthetic */ void setTouchCalibration$default(SyntheticInputInjector syntheticInputInjector, int i, int i2, float f, float f2, float f3, float f4, boolean z, float f5, float f6, boolean z2, int i3, Object obj) {
        if ((i3 & 32) != 0) {
            f4 = Float.NaN;
        }
        if ((i3 & 64) != 0) {
            z = false;
        }
        if ((i3 & 128) != 0) {
            f5 = Float.NaN;
        }
        if ((i3 & 256) != 0) {
            f6 = Float.NaN;
        }
        if ((i3 & 512) != 0) {
            z2 = false;
        }
        syntheticInputInjector.setTouchCalibration(i, i2, f, f2, f3, f4, z, f5, f6, z2);
    }

    private final long stampTime() {
        return ei2.m10070i(this.hwContext.get(), Boolean.TRUE) ? eventTime() : SystemClock.uptimeMillis() - this.hwLagMs;
    }

    private final void startPointer(long j, SyntheticInputEvent syntheticInputEvent) {
        if (syntheticInputEvent.getDevType() != 1) {
            beginPointer$default(this, j, dispXf(syntheticInputEvent), dispYf(syntheticInputEvent), 0.0f, 0.0f, 0.0f, inSensArea(syntheticInputEvent), 0L, 184, null);
            return;
        }
        beginPointer$default(this, j, dispXf(syntheticInputEvent), dispYf(syntheticInputEvent), cookPressure(syntheticInputEvent.getPressure(), 1.0f), cookSize(syntheticInputEvent.getContactMajor()), cookTouchMajor(syntheticInputEvent.getContactMajor()), inSensArea(syntheticInputEvent), 0L, 128, null);
        m85 m85Var = this.active.get(Long.valueOf(j));
        if (m85Var != null) {
            rememberContact(m85Var);
        }
    }

    public final String diagnosticsSummary() {
        long j = this.injectedCount;
        long j2 = this.failedCount;
        long uptimeMillis = this.lastInjectUptime > 0 ? SystemClock.uptimeMillis() - this.lastInjectUptime : -1L;
        String str = this.lastFailure;
        if (str == null) {
            str = "-";
        }
        StringBuilder m8813t = d63.m8813t(j, "injected=", " failed=");
        m8813t.append(j2);
        d63.m8818y(m8813t, " last_inject_ago_ms=", uptimeMillis, " last_failure=");
        m8813t.append(str);
        return m8813t.toString();
    }

    public final long getFailedCount() {
        return this.failedCount;
    }

    public final long getInjectedCount() {
        return this.injectedCount;
    }

    public final String getLastFailure() {
        return this.lastFailure;
    }

    public final long getLastInjectUptime() {
        return this.lastInjectUptime;
    }

    public final int getTargetDisplayId() {
        return this.targetDisplayId;
    }

    public final int getTouchDeviceId() {
        return this.touchDeviceId;
    }

    public final boolean getUseTouchDeviceId() {
        return this.useTouchDeviceId;
    }

    public final synchronized boolean hasActivePointersExcept(long... jArr) {
        boolean z;
        Set set;
        jArr.getClass();
        int length = jArr.length;
        z = true;
        if (length == 0) {
            set = hi1.f17209a;
        } else if (length != 1) {
            set = new LinkedHashSet(m53.m15765Z(jArr.length));
            for (long j : jArr) {
                set.add(Long.valueOf(j));
            }
        } else {
            set = qp7.m18376B(Long.valueOf(jArr[0]));
        }
        Set<Long> keySet = this.active.keySet();
        keySet.getClass();
        Set<Long> set2 = keySet;
        if (!(set2 instanceof Collection) || !set2.isEmpty()) {
            Iterator<T> it = set2.iterator();
            while (it.hasNext()) {
                if (!set.contains((Long) it.next())) {
                    break;
                }
            }
        }
        z = false;
        return z;
    }

    public final void hideSystemCursor() {
        try {
            ze2.m24051b(0);
            this.logger.m11502i("SyntheticInputInjector", "System pointer icon set to TYPE_NULL (0)");
        } catch (Throwable th) {
            this.logger.m11501e("SyntheticInputInjector", th, "Failed to set pointer icon to TYPE_NULL", new Object[0]);
        }
    }

    public final synchronized boolean injectMouseButton(float f, float f2, int i, int i2) {
        if (f < 0.0f || f2 < 0.0f) {
            return false;
        }
        long stampTime = stampTime();
        long j = this.lastInjectEventTime;
        if (stampTime <= j) {
            stampTime = 1 + j;
        }
        this.lastInjectEventTime = stampTime;
        if (i == 0) {
            this.mouseClickDownTime = stampTime;
        }
        long j2 = this.mouseClickDownTime;
        if (j2 <= 0) {
            j2 = stampTime;
        }
        MotionEvent.PointerProperties pointerProperties = this.propsPool[0];
        pointerProperties.clear();
        pointerProperties.id = 0;
        pointerProperties.toolType = 1;
        MotionEvent.PointerCoords pointerCoords = this.coordsPool[0];
        pointerCoords.clear();
        pointerCoords.x = f;
        pointerCoords.y = f2;
        pointerCoords.pressure = i != 1 ? 1.0f : 0.0f;
        pointerCoords.size = 1.0f;
        MotionEvent obtain = MotionEvent.obtain(j2, stampTime, i, 1, this.emitProps, this.emitCoords, 0, 0, 1.0f, 1.0f, 0, 0, 4098, 0);
        obtain.getClass();
        if (!enqueueInject(obtain)) {
            try {
                obtain.recycle();
            } catch (Throwable unused) {
            }
            return false;
        }
        if (i == 1) {
            this.mouseClickDownTime = 0L;
        }
        return true;
    }

    public final synchronized boolean injectScroll(float f, float f2, float f3, float f4) {
        if (f < 0.0f || f2 < 0.0f) {
            return false;
        }
        long stampTime = stampTime();
        long j = this.lastInjectEventTime;
        if (stampTime <= j) {
            stampTime = 1 + j;
        }
        long j2 = stampTime;
        this.lastInjectEventTime = j2;
        MotionEvent.PointerProperties pointerProperties = this.propsPool[0];
        pointerProperties.clear();
        pointerProperties.id = 0;
        pointerProperties.toolType = 3;
        MotionEvent.PointerCoords pointerCoords = this.coordsPool[0];
        pointerCoords.clear();
        pointerCoords.x = f;
        pointerCoords.y = f2;
        pointerCoords.setAxisValue(9, f3);
        if (f4 != 0.0f) {
            pointerCoords.setAxisValue(10, f4);
        }
        MotionEvent obtain = MotionEvent.obtain(j2, j2, 8, 1, this.emitProps, this.emitCoords, 0, 0, 1.0f, 1.0f, 0, 0, 8194, 0);
        obtain.getClass();
        if (enqueueInject(obtain)) {
            return true;
        }
        try {
            obtain.recycle();
        } catch (Throwable unused) {
        }
        return false;
    }

    public final synchronized boolean injectTap(float f, float f2) {
        if (f < 0.0f || f2 < 0.0f) {
            return false;
        }
        long stampTime = stampTime();
        MotionEvent.PointerProperties pointerProperties = this.propsPool[0];
        pointerProperties.clear();
        pointerProperties.id = 0;
        pointerProperties.toolType = 1;
        MotionEvent.PointerCoords pointerCoords = this.coordsPool[0];
        pointerCoords.clear();
        pointerCoords.x = f;
        pointerCoords.y = f2;
        pointerCoords.pressure = 1.0f;
        pointerCoords.size = 1.0f;
        return inject$default(this, stampTime, stampTime, 0, 1, this.emitProps, this.emitCoords, 0, 0.0f, 0.0f, 0, 960, null) && inject$default(this, stampTime, stampTime(), 1, 1, this.emitProps, this.emitCoords, 0, 0.0f, 0.0f, 0, 960, null);
    }

    public final String latencySummary() {
        return hn0.m12936i(this.handoffHist.m15144a("handoff"), " ", this.frameProcessHist.m15144a("kotlin"));
    }

    public final synchronized void liftAllPointers() {
        try {
            try {
                if (!this.active.isEmpty()) {
                    Set<Long> keySet = this.active.keySet();
                    keySet.getClass();
                    Iterator it = new r53(ij0.m13394C0(keySet)).iterator();
                    while (it.hasNext()) {
                        Object next = it.next();
                        next.getClass();
                        long longValue = ((Number) next).longValue();
                        if (this.active.containsKey(Long.valueOf(longValue))) {
                            SyntheticInputInjector syntheticInputInjector = this;
                            emit$default(syntheticInputInjector, this.active.size() != 1 ? 6 : 1, Long.valueOf(longValue), 0L, 0, 12, null);
                            m85 remove = syntheticInputInjector.active.remove(Long.valueOf(longValue));
                            if (remove != null) {
                                syntheticInputInjector.usedIds[remove.f25424a] = false;
                            }
                            this = syntheticInputInjector;
                        }
                    }
                    SyntheticInputInjector syntheticInputInjector2 = this;
                    syntheticInputInjector2.moveDirty = false;
                    syntheticInputInjector2.pendingMoveTime = 0L;
                }
            } catch (Throwable th) {
                th = th;
                Throwable th2 = th;
                throw th2;
            }
        } catch (Throwable th3) {
            th = th3;
            SyntheticInputInjector syntheticInputInjector3 = this;
            Throwable th22 = th;
            throw th22;
        }
    }

    public final synchronized void liftPhysicalPointers() {
        Set<Long> keySet = this.active.keySet();
        keySet.getClass();
        ArrayList arrayList = new ArrayList();
        for (Object obj : keySet) {
            if (((Long) obj).longValue() >= 0) {
                arrayList.add(obj);
            }
        }
        Iterator it = new r53(ij0.m13394C0(arrayList)).iterator();
        while (true) {
            if (!((ListIterator) ((ud4) it).f38560b).hasPrevious()) {
                break;
            }
            Object previous = ((ListIterator) ((ud4) it).f38560b).previous();
            previous.getClass();
            long longValue = ((Number) previous).longValue();
            emit$default(this, this.active.size() != 1 ? 6 : 1, Long.valueOf(longValue), 0L, 0, 12, null);
            m85 remove = this.active.remove(Long.valueOf(longValue));
            if (remove != null) {
                this.usedIds[remove.f25424a] = false;
            }
        }
        HashSet<Long> hashSet = this.pending;
        hashSet.getClass();
        Iterator<T> it2 = hashSet.iterator();
        while (it2.hasNext()) {
            if (liftPhysicalPointers$lambda$2(((Long) it2.next()).longValue())) {
                it2.remove();
            }
        }
        this.moveDirty = false;
        this.pendingMoveTime = 0L;
    }

    public final synchronized void onFrame() {
        flushPendingMove();
    }

    public final synchronized void onSample(SyntheticInputEvent syntheticInputEvent) {
        syntheticInputEvent.getClass();
        if (syntheticInputEvent.getAction() == 2 || syntheticInputEvent.getAction() == 4 || !(syntheticInputEvent.getDispX() == Integer.MIN_VALUE || syntheticInputEvent.getDispY() == Integer.MIN_VALUE)) {
            noteHwTime(syntheticInputEvent.getTimestamp());
            Boolean bool = this.hwContext.get();
            Boolean bool2 = Boolean.TRUE;
            boolean m10070i = ei2.m10070i(bool, bool2);
            this.hwContext.set(bool2);
            try {
                applySample(syntheticInputEvent);
            } finally {
                this.hwContext.set(Boolean.valueOf(m10070i));
            }
        }
    }

    public final synchronized void pointerCancel(long j) {
        if (this.active.containsKey(Long.valueOf(j))) {
            flushPendingMove();
            cancelPointer(j);
        }
    }

    public final synchronized void pointerDown(long j, float f, float f2, long j2) {
        if (this.active.containsKey(Long.valueOf(j))) {
            pointerMove(j, f, f2);
        } else {
            flushPendingMove();
            beginPointer$default(this, j, f, f2, 0.0f, 0.0f, 0.0f, false, plannedTime(j2), 120, null);
        }
    }

    public final synchronized void pointerMove(long j, float f, float f2) {
        m85 m85Var = this.active.get(Long.valueOf(j));
        if (m85Var == null) {
            return;
        }
        m85Var.f25425b = f;
        m85Var.f25426c = f2;
        this.moveDirty = true;
        this.pendingMoveTime = Math.max(this.pendingMoveTime, stampTime());
    }

    public final synchronized void pointerUp(long j, long j2) {
        try {
            try {
                if (this.active.containsKey(Long.valueOf(j))) {
                    flushPendingMove();
                    emit$default(this, this.active.size() != 1 ? 6 : 1, Long.valueOf(j), plannedTime(j2), 0, 8, null);
                    m85 remove = this.active.remove(Long.valueOf(j));
                    if (remove != null) {
                        this.usedIds[remove.f25424a] = false;
                    }
                    this.moveDirty = false;
                }
            } catch (Throwable th) {
                th = th;
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    public final void recordFrameProcess(long j) {
        l85 l85Var = this.frameProcessHist;
        l85Var.getClass();
        l85Var.f23889a.incrementAndGet((int) dg2.m9135u(j / 100, 0L, 127L));
    }

    public final synchronized void reset() {
        liftAllPointers();
        this.active.clear();
        boolean[] zArr = this.usedIds;
        Arrays.fill(zArr, 0, zArr.length, false);
        this.pending.clear();
        this.moveDirty = false;
        this.pendingMoveTime = 0L;
        this.lastHwTimeMs = 0L;
        this.hwLagMs = 0L;
        this.lastInjectEventTime = 0L;
        this.mouseClickDownTime = 0L;
        this.clockSource = 0;
        this.lastContactPressure = 1.0f;
        this.lastContactSize = 0.0f;
        this.lastContactMajor = 0.0f;
    }

    public final void setRelativeAim(boolean z) {
        this.relativeAimEnabled = z;
    }

    public final void setSensitivity(float f, float f2) {
        this.sensX = f;
        this.sensY = f2;
    }

    public final void setSensitivityArea(int i) {
        this.sensArea = i;
    }

    public final void setSensitivityCurve(int i) {
        this.sensCurve = i;
    }

    public final void setSmoothing(boolean z, float f, float f2) {
        this.euroEnabled = z;
        if (f < 0.01f) {
            f = 0.01f;
        }
        this.euroMinCutoff = f;
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        this.euroBeta = f2;
    }

    public final void setTargetDisplayId(int i) {
        this.targetDisplayId = i;
    }

    public final void setTouchCalibration(int i, int i2, float f, float f2, float f3, float f4, boolean z, float f5, float f6, boolean z2) {
        float f7 = 0.0f;
        if (z || i <= 0) {
            f4 = 0.0f;
        } else if (Float.isNaN(f4)) {
            f4 = 1.0f / i;
        }
        this.pressureScale = f4;
        if (!z2 && i2 > 0) {
            f7 = 1.0f / i2;
        }
        this.sizeScale = f7;
        this.idcSizeScale = f5;
        this.idcSizeBias = f6;
        this.geometricScale = f;
        this.xPrecision = f2;
        this.yPrecision = f3;
    }

    public final void setTouchDeviceId(int i) {
        this.touchDeviceId = i;
    }

    public final void setUseTouchDeviceId(boolean z) {
        this.useTouchDeviceId = z;
    }

    public final void showSystemCursor() {
        try {
            ze2.m24051b(UnityAdsConstants.SafeGuards.InitRequestTimeoutPolicy.MIN_TIMEOUT);
            this.logger.m11502i("SyntheticInputInjector", "System pointer icon restored to TYPE_ARROW (1000)");
        } catch (Throwable th) {
            this.logger.m11501e("SyntheticInputInjector", th, "Failed to restore pointer icon", new Object[0]);
        }
    }

    public final <T> T withHardwareClock(long j, xy1 xy1Var) {
        xy1Var.getClass();
        synchronized (this) {
            noteHwTime(j);
        }
        Boolean bool = this.hwContext.get();
        Boolean bool2 = Boolean.TRUE;
        boolean m10070i = ei2.m10070i(bool, bool2);
        this.hwContext.set(bool2);
        try {
            return (T) xy1Var.invoke();
        } finally {
            this.hwContext.set(Boolean.valueOf(m10070i));
        }
    }
}
