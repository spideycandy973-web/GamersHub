package frb.axeron.server.input;

import p000.RunnableC0905e1;
import p000.ds3;
import p000.gb1;
import p000.hb1;
import p000.ib1;
import p000.jb1;
import p000.na1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class DisplayTransform {

    @Deprecated
    public static final long POLL_MS = 200;

    @Deprecated
    public static final long POLL_WITH_CALLBACK_MS = 1000;

    @Deprecated
    public static final int ROTATION_180 = 2;

    @Deprecated
    public static final int ROTATION_270 = 3;

    @Deprecated
    public static final int ROTATION_90 = 1;
    private static volatile DisplayTransform active;
    private static volatile boolean callbackRegistered;
    private Thread poller;
    private volatile boolean running;
    private static final ib1 Companion = new ib1();
    private static final na1 displayCallback = new hb1();
    private static final ds3 NONE = new ds3(Integer.MIN_VALUE, Integer.MIN_VALUE);
    private volatile jb1 snapshot = new jb1(0, 0, 0, 0, 0);
    private final ThreadLocal<float[]> localBuffer = ThreadLocal.withInitial(new gb1());

    /* JADX INFO: Access modifiers changed from: private */
    public static final float[] localBuffer$lambda$0() {
        return new float[2];
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void start$lambda$0(DisplayTransform displayTransform) {
        while (displayTransform.running) {
            try {
                Thread.sleep(callbackRegistered ? 1000L : 200L);
                if (displayTransform.running) {
                    displayTransform.refreshNow();
                }
            } catch (InterruptedException unused) {
                return;
            }
        }
    }

    public static /* synthetic */ ds3 toDisplayPixels$default(DisplayTransform displayTransform, float f, float f2, int i, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            i = 0;
        }
        return displayTransform.toDisplayPixels(f, f2, i);
    }

    public static /* synthetic */ float[] toDisplayPixelsF$default(DisplayTransform displayTransform, float f, float f2, int i, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            i = 0;
        }
        return displayTransform.toDisplayPixelsF(f, f2, i);
    }

    public final int getHeight() {
        return this.snapshot.f19971c;
    }

    public final int getRotation() {
        return this.snapshot.f19969a;
    }

    public final jb1 getSnapshot() {
        return this.snapshot;
    }

    public final int getWidth() {
        return this.snapshot.f19970b;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't find top splitter block for handler:B:23:0x004a
        	at jadx.core.utils.BlockUtils.getTopSplitterForHandler(BlockUtils.java:1179)
        	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.collectHandlerRegions(ExcHandlersRegionMaker.java:53)
        	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.process(ExcHandlersRegionMaker.java:38)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:27)
        */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00c3 A[Catch: all -> 0x00d6, TRY_LEAVE, TryCatch #2 {, blocks: (B:4:0x0003, B:36:0x006e, B:38:0x0079, B:50:0x00bf, B:52:0x00c3, B:59:0x002b, B:78:0x0013, B:6:0x0005, B:8:0x000b, B:77:0x000e), top: B:3:0x0003, inners: #1 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final synchronized void refreshNow() {
        /*
            Method dump skipped, instructions count: 216
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.input.DisplayTransform.refreshNow():void");
    }

    public final synchronized void start() {
        if (this.running) {
            return;
        }
        this.running = true;
        active = this;
        Companion.m13232a();
        refreshNow();
        Thread thread = new Thread(new RunnableC0905e1((Object) this, (byte) 15), "touch-display");
        thread.setDaemon(true);
        thread.start();
        this.poller = thread;
    }

    public final synchronized void stop() {
        this.running = false;
        if (active == this) {
            active = null;
        }
        Thread thread = this.poller;
        if (thread != null) {
            thread.interrupt();
        }
        this.poller = null;
    }

    public final ds3 toDisplayPixels(float f, float f2, int i) {
        float[] displayPixelsF = toDisplayPixelsF(f, f2, i);
        return displayPixelsF == null ? NONE : new ds3(Integer.valueOf((int) displayPixelsF[0]), Integer.valueOf((int) displayPixelsF[1]));
    }

    public final float[] toDisplayPixelsF(float f, float f2, int i) {
        jb1 jb1Var = this.snapshot;
        int i2 = jb1Var.f19970b;
        int i3 = jb1Var.f19971c;
        int i4 = jb1Var.f19972d;
        int i5 = jb1Var.f19973e;
        if (i2 <= 0 || i3 <= 0 || i4 <= 0 || i5 <= 0 || f < 0.0f || f2 < 0.0f) {
            return null;
        }
        int i6 = (jb1Var.f19969a + i) & 3;
        if (i6 == 1) {
            f2 = 1.0f - f;
            f = f2;
        } else if (i6 == 2) {
            f = 1.0f - f;
            f2 = 1.0f - f2;
        } else if (i6 == 3) {
            float f3 = 1.0f - f2;
            f2 = f;
            f = f3;
        }
        float f4 = i4;
        float f5 = i5;
        float f6 = i2;
        float f7 = i3;
        float min = Math.min(f4 / f6, f5 / f7);
        float f8 = ((f * f4) - ((f4 - (f6 * min)) / 2.0f)) / min;
        float f9 = ((f2 * f5) - ((f5 - (f7 * min)) / 2.0f)) / min;
        float[] fArr = this.localBuffer.get();
        if (fArr == null) {
            fArr = new float[2];
            this.localBuffer.set(fArr);
        }
        fArr[0] = f8;
        fArr[1] = f9;
        return fArr;
    }
}
