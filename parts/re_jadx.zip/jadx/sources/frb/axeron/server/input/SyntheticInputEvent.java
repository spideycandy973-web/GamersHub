package frb.axeron.server.input;

import android.os.Parcel;
import android.os.Parcelable;
import com.applovin.shadow.okhttp3.internal.http2.Http2;
import com.applovin.shadow.okio.Segment;
import p000.d63;
import p000.h31;
import p000.hn0;
import p000.j85;
import p000.s76;
import p000.yt0;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class SyntheticInputEvent implements Parcelable {
    public static final int ACTION_CANCEL = 4;
    public static final int ACTION_DOWN = 0;
    public static final int ACTION_FRAME = 3;
    public static final int ACTION_HOVER_MOVE = 7;
    public static final int ACTION_MOVE = 1;
    public static final int ACTION_UP = 2;
    public static final int DEV_KEYBOARD = 3;
    public static final int DEV_MOUSE = 4;
    public static final int DEV_TOUCH = 1;
    public static final int UNKNOWN_COORD = Integer.MIN_VALUE;
    private int action;
    private int contactMajor;
    private int devType;
    private int deviceId;
    private int dispX;
    private float dispXf;
    private int dispY;
    private float dispYf;
    private int displayHeight;
    private int displayWidth;
    private float normX;
    private float normY;
    private int pressure;
    private int rawCode;
    private int rawType;
    private int rawValue;
    private int rotation;
    private int slot;
    private long timestamp;
    private int touchMajor;
    private int trackingId;

    /* renamed from: x */
    private int f14425x;

    /* renamed from: y */
    private int f14426y;
    public static final j85 Companion = new j85();
    public static final Parcelable.Creator<SyntheticInputEvent> CREATOR = new s76(23);

    public /* synthetic */ SyntheticInputEvent(int i, int i2, int i3, int i4, int i5, int i6, float f, float f2, int i7, int i8, int i9, int i10, int i11, long j, int i12, int i13, float f3, float f4, int i14, int i15, int i16, int i17, int i18, h31 h31Var) {
        this(i, i2, i3, i4, i5, i6, f, f2, i7, i8, i9, i10, i11, j, (i18 & Http2.INITIAL_MAX_FRAME_SIZE) != 0 ? -1 : i12, (32768 & i18) != 0 ? -1 : i13, (65536 & i18) != 0 ? Float.NaN : f3, (131072 & i18) != 0 ? Float.NaN : f4, (262144 & i18) != 0 ? 0 : i14, (524288 & i18) != 0 ? 0 : i15, (1048576 & i18) != 0 ? 0 : i16, (i18 & 2097152) != 0 ? 1 : i17);
    }

    public static /* synthetic */ SyntheticInputEvent copy$default(SyntheticInputEvent syntheticInputEvent, int i, int i2, int i3, int i4, int i5, int i6, float f, float f2, int i7, int i8, int i9, int i10, int i11, long j, int i12, int i13, float f3, float f4, int i14, int i15, int i16, int i17, int i18, Object obj) {
        int i19;
        int i20;
        int i21 = (i18 & 1) != 0 ? syntheticInputEvent.deviceId : i;
        int i22 = (i18 & 2) != 0 ? syntheticInputEvent.slot : i2;
        int i23 = (i18 & 4) != 0 ? syntheticInputEvent.trackingId : i3;
        int i24 = (i18 & 8) != 0 ? syntheticInputEvent.action : i4;
        int i25 = (i18 & 16) != 0 ? syntheticInputEvent.f14425x : i5;
        int i26 = (i18 & 32) != 0 ? syntheticInputEvent.f14426y : i6;
        float f5 = (i18 & 64) != 0 ? syntheticInputEvent.normX : f;
        float f6 = (i18 & 128) != 0 ? syntheticInputEvent.normY : f2;
        int i27 = (i18 & 256) != 0 ? syntheticInputEvent.pressure : i7;
        int i28 = (i18 & 512) != 0 ? syntheticInputEvent.touchMajor : i8;
        int i29 = (i18 & 1024) != 0 ? syntheticInputEvent.rawType : i9;
        int i30 = (i18 & 2048) != 0 ? syntheticInputEvent.rawCode : i10;
        int i31 = (i18 & 4096) != 0 ? syntheticInputEvent.rawValue : i11;
        int i32 = i21;
        int i33 = i22;
        long j2 = (i18 & Segment.SIZE) != 0 ? syntheticInputEvent.timestamp : j;
        int i34 = (i18 & Http2.INITIAL_MAX_FRAME_SIZE) != 0 ? syntheticInputEvent.dispX : i12;
        int i35 = (i18 & 32768) != 0 ? syntheticInputEvent.dispY : i13;
        float f7 = (i18 & 65536) != 0 ? syntheticInputEvent.dispXf : f3;
        float f8 = (i18 & 131072) != 0 ? syntheticInputEvent.dispYf : f4;
        int i36 = (i18 & 262144) != 0 ? syntheticInputEvent.rotation : i14;
        int i37 = (i18 & 524288) != 0 ? syntheticInputEvent.displayWidth : i15;
        int i38 = (i18 & 1048576) != 0 ? syntheticInputEvent.displayHeight : i16;
        if ((i18 & 2097152) != 0) {
            i20 = i38;
            i19 = syntheticInputEvent.devType;
        } else {
            i19 = i17;
            i20 = i38;
        }
        return syntheticInputEvent.copy(i32, i33, i23, i24, i25, i26, f5, f6, i27, i28, i29, i30, i31, j2, i34, i35, f7, f8, i36, i37, i20, i19);
    }

    public final int component1() {
        return this.deviceId;
    }

    public final int component10() {
        return this.touchMajor;
    }

    public final int component11() {
        return this.rawType;
    }

    public final int component12() {
        return this.rawCode;
    }

    public final int component13() {
        return this.rawValue;
    }

    public final long component14() {
        return this.timestamp;
    }

    public final int component15() {
        return this.dispX;
    }

    public final int component16() {
        return this.dispY;
    }

    public final float component17() {
        return this.dispXf;
    }

    public final float component18() {
        return this.dispYf;
    }

    public final int component19() {
        return this.rotation;
    }

    public final int component2() {
        return this.slot;
    }

    public final int component20() {
        return this.displayWidth;
    }

    public final int component21() {
        return this.displayHeight;
    }

    public final int component22() {
        return this.devType;
    }

    public final int component3() {
        return this.trackingId;
    }

    public final int component4() {
        return this.action;
    }

    public final int component5() {
        return this.f14425x;
    }

    public final int component6() {
        return this.f14426y;
    }

    public final float component7() {
        return this.normX;
    }

    public final float component8() {
        return this.normY;
    }

    public final int component9() {
        return this.pressure;
    }

    public final SyntheticInputEvent copy(int i, int i2, int i3, int i4, int i5, int i6, float f, float f2, int i7, int i8, int i9, int i10, int i11, long j, int i12, int i13, float f3, float f4, int i14, int i15, int i16, int i17) {
        return new SyntheticInputEvent(i, i2, i3, i4, i5, i6, f, f2, i7, i8, i9, i10, i11, j, i12, i13, f3, f4, i14, i15, i16, i17);
    }

    public final void copyFrom(SyntheticInputEvent syntheticInputEvent) {
        syntheticInputEvent.getClass();
        this.deviceId = syntheticInputEvent.deviceId;
        this.slot = syntheticInputEvent.slot;
        this.trackingId = syntheticInputEvent.trackingId;
        this.action = syntheticInputEvent.action;
        this.f14425x = syntheticInputEvent.f14425x;
        this.f14426y = syntheticInputEvent.f14426y;
        this.normX = syntheticInputEvent.normX;
        this.normY = syntheticInputEvent.normY;
        this.pressure = syntheticInputEvent.pressure;
        this.touchMajor = syntheticInputEvent.touchMajor;
        this.rawType = syntheticInputEvent.rawType;
        this.rawCode = syntheticInputEvent.rawCode;
        this.rawValue = syntheticInputEvent.rawValue;
        this.timestamp = syntheticInputEvent.timestamp;
        this.dispX = syntheticInputEvent.dispX;
        this.dispY = syntheticInputEvent.dispY;
        this.dispXf = syntheticInputEvent.dispXf;
        this.dispYf = syntheticInputEvent.dispYf;
        this.rotation = syntheticInputEvent.rotation;
        this.displayWidth = syntheticInputEvent.displayWidth;
        this.displayHeight = syntheticInputEvent.displayHeight;
        this.devType = syntheticInputEvent.devType;
        this.contactMajor = syntheticInputEvent.contactMajor;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SyntheticInputEvent)) {
            return false;
        }
        SyntheticInputEvent syntheticInputEvent = (SyntheticInputEvent) obj;
        return this.deviceId == syntheticInputEvent.deviceId && this.slot == syntheticInputEvent.slot && this.trackingId == syntheticInputEvent.trackingId && this.action == syntheticInputEvent.action && this.f14425x == syntheticInputEvent.f14425x && this.f14426y == syntheticInputEvent.f14426y && Float.compare(this.normX, syntheticInputEvent.normX) == 0 && Float.compare(this.normY, syntheticInputEvent.normY) == 0 && this.pressure == syntheticInputEvent.pressure && this.touchMajor == syntheticInputEvent.touchMajor && this.rawType == syntheticInputEvent.rawType && this.rawCode == syntheticInputEvent.rawCode && this.rawValue == syntheticInputEvent.rawValue && this.timestamp == syntheticInputEvent.timestamp && this.dispX == syntheticInputEvent.dispX && this.dispY == syntheticInputEvent.dispY && Float.compare(this.dispXf, syntheticInputEvent.dispXf) == 0 && Float.compare(this.dispYf, syntheticInputEvent.dispYf) == 0 && this.rotation == syntheticInputEvent.rotation && this.displayWidth == syntheticInputEvent.displayWidth && this.displayHeight == syntheticInputEvent.displayHeight && this.devType == syntheticInputEvent.devType;
    }

    public final int getAction() {
        return this.action;
    }

    public final int getContactMajor() {
        return this.contactMajor;
    }

    public final int getDevType() {
        return this.devType;
    }

    public final int getDeviceId() {
        return this.deviceId;
    }

    public final int getDispX() {
        return this.dispX;
    }

    public final float getDispXf() {
        return this.dispXf;
    }

    public final int getDispY() {
        return this.dispY;
    }

    public final float getDispYf() {
        return this.dispYf;
    }

    public final int getDisplayHeight() {
        return this.displayHeight;
    }

    public final int getDisplayWidth() {
        return this.displayWidth;
    }

    public final float getNormX() {
        return this.normX;
    }

    public final float getNormY() {
        return this.normY;
    }

    public final int getPressure() {
        return this.pressure;
    }

    public final int getRawCode() {
        return this.rawCode;
    }

    public final int getRawType() {
        return this.rawType;
    }

    public final int getRawValue() {
        return this.rawValue;
    }

    public final int getRotation() {
        return this.rotation;
    }

    public final int getSlot() {
        return this.slot;
    }

    public final long getTimestamp() {
        return this.timestamp;
    }

    public final int getTouchMajor() {
        return this.touchMajor;
    }

    public final int getTrackingId() {
        return this.trackingId;
    }

    public final int getX() {
        return this.f14425x;
    }

    public final int getY() {
        return this.f14426y;
    }

    public int hashCode() {
        return Integer.hashCode(this.devType) + hn0.m12930c(this.displayHeight, hn0.m12930c(this.displayWidth, hn0.m12930c(this.rotation, hn0.m12929b(this.dispYf, hn0.m12929b(this.dispXf, hn0.m12930c(this.dispY, hn0.m12930c(this.dispX, d63.m8795b(hn0.m12930c(this.rawValue, hn0.m12930c(this.rawCode, hn0.m12930c(this.rawType, hn0.m12930c(this.touchMajor, hn0.m12930c(this.pressure, hn0.m12929b(this.normY, hn0.m12929b(this.normX, hn0.m12930c(this.f14426y, hn0.m12930c(this.f14425x, hn0.m12930c(this.action, hn0.m12930c(this.trackingId, hn0.m12930c(this.slot, Integer.hashCode(this.deviceId) * 31, 31), 31), 31), 31), 31), 31), 31), 31), 31), 31), 31), 31), 31, this.timestamp), 31), 31), 31), 31), 31), 31), 31);
    }

    public final void populate(int i, int i2, int i3, int i4, int i5, int i6, float f, float f2, int i7, int i8, int i9, int i10, int i11, long j) {
        this.deviceId = i;
        this.slot = i2;
        this.trackingId = i3;
        this.action = i4;
        this.f14425x = i5;
        this.f14426y = i6;
        this.normX = f;
        this.normY = f2;
        this.pressure = i7;
        this.touchMajor = i8;
        this.rawType = i9;
        this.rawCode = i10;
        this.rawValue = i11;
        this.timestamp = j;
        this.dispX = -1;
        this.dispY = -1;
        this.dispXf = Float.NaN;
        this.dispYf = Float.NaN;
        this.rotation = 0;
        this.displayWidth = 0;
        this.displayHeight = 0;
        this.devType = 1;
        this.contactMajor = 0;
    }

    public final void setAction(int i) {
        this.action = i;
    }

    public final void setContactMajor(int i) {
        this.contactMajor = i;
    }

    public final void setDevType(int i) {
        this.devType = i;
    }

    public final void setDeviceId(int i) {
        this.deviceId = i;
    }

    public final void setDispX(int i) {
        this.dispX = i;
    }

    public final void setDispXf(float f) {
        this.dispXf = f;
    }

    public final void setDispY(int i) {
        this.dispY = i;
    }

    public final void setDispYf(float f) {
        this.dispYf = f;
    }

    public final void setDisplayHeight(int i) {
        this.displayHeight = i;
    }

    public final void setDisplayWidth(int i) {
        this.displayWidth = i;
    }

    public final void setNormX(float f) {
        this.normX = f;
    }

    public final void setNormY(float f) {
        this.normY = f;
    }

    public final void setPressure(int i) {
        this.pressure = i;
    }

    public final void setRawCode(int i) {
        this.rawCode = i;
    }

    public final void setRawType(int i) {
        this.rawType = i;
    }

    public final void setRawValue(int i) {
        this.rawValue = i;
    }

    public final void setRotation(int i) {
        this.rotation = i;
    }

    public final void setSlot(int i) {
        this.slot = i;
    }

    public final void setTimestamp(long j) {
        this.timestamp = j;
    }

    public final void setTouchMajor(int i) {
        this.touchMajor = i;
    }

    public final void setTrackingId(int i) {
        this.trackingId = i;
    }

    public final void setX(int i) {
        this.f14425x = i;
    }

    public final void setY(int i) {
        this.f14426y = i;
    }

    public String toString() {
        int i = this.deviceId;
        int i2 = this.slot;
        int i3 = this.trackingId;
        int i4 = this.action;
        int i5 = this.f14425x;
        int i6 = this.f14426y;
        float f = this.normX;
        float f2 = this.normY;
        int i7 = this.pressure;
        int i8 = this.touchMajor;
        int i9 = this.rawType;
        int i10 = this.rawCode;
        int i11 = this.rawValue;
        long j = this.timestamp;
        int i12 = this.dispX;
        int i13 = this.dispY;
        float f3 = this.dispXf;
        float f4 = this.dispYf;
        int i14 = this.rotation;
        int i15 = this.displayWidth;
        int i16 = this.displayHeight;
        int i17 = this.devType;
        StringBuilder m8814u = d63.m8814u("SyntheticInputEvent(deviceId=", i, ", slot=", i2, ", trackingId=");
        d63.m8815v(i3, i4, ", action=", ", x=", m8814u);
        d63.m8815v(i5, i6, ", y=", ", normX=", m8814u);
        hn0.m12948u(m8814u, f, ", normY=", f2, ", pressure=");
        d63.m8815v(i7, i8, ", touchMajor=", ", rawType=", m8814u);
        d63.m8815v(i9, i10, ", rawCode=", ", rawValue=", m8814u);
        m8814u.append(i11);
        m8814u.append(", timestamp=");
        m8814u.append(j);
        yt0.m23626s(i12, i13, ", dispX=", ", dispY=", m8814u);
        m8814u.append(", dispXf=");
        m8814u.append(f3);
        m8814u.append(", dispYf=");
        m8814u.append(f4);
        yt0.m23626s(i14, i15, ", rotation=", ", displayWidth=", m8814u);
        yt0.m23626s(i16, i17, ", displayHeight=", ", devType=", m8814u);
        m8814u.append(")");
        return m8814u.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.getClass();
        parcel.writeInt(this.deviceId);
        parcel.writeInt(this.slot);
        parcel.writeInt(this.trackingId);
        parcel.writeInt(this.action);
        parcel.writeInt(this.f14425x);
        parcel.writeInt(this.f14426y);
        parcel.writeFloat(this.normX);
        parcel.writeFloat(this.normY);
        parcel.writeInt(this.pressure);
        parcel.writeInt(this.touchMajor);
        parcel.writeInt(this.rawType);
        parcel.writeInt(this.rawCode);
        parcel.writeInt(this.rawValue);
        parcel.writeLong(this.timestamp);
        parcel.writeInt(this.dispX);
        parcel.writeInt(this.dispY);
        parcel.writeFloat(this.dispXf);
        parcel.writeFloat(this.dispYf);
        parcel.writeInt(this.rotation);
        parcel.writeInt(this.displayWidth);
        parcel.writeInt(this.displayHeight);
        parcel.writeInt(this.devType);
    }

    public SyntheticInputEvent(int i, int i2, int i3, int i4, int i5, int i6, float f, float f2, int i7, int i8, int i9, int i10, int i11, long j, int i12, int i13, float f3, float f4, int i14, int i15, int i16, int i17) {
        this.deviceId = i;
        this.slot = i2;
        this.trackingId = i3;
        this.action = i4;
        this.f14425x = i5;
        this.f14426y = i6;
        this.normX = f;
        this.normY = f2;
        this.pressure = i7;
        this.touchMajor = i8;
        this.rawType = i9;
        this.rawCode = i10;
        this.rawValue = i11;
        this.timestamp = j;
        this.dispX = i12;
        this.dispY = i13;
        this.dispXf = f3;
        this.dispYf = f4;
        this.rotation = i14;
        this.displayWidth = i15;
        this.displayHeight = i16;
        this.devType = i17;
    }

    public static /* synthetic */ void getContactMajor$annotations() {
    }
}
