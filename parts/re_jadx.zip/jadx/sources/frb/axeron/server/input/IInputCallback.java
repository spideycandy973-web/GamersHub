package frb.axeron.server.input;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public interface IInputCallback extends IInterface {
    public static final String DESCRIPTOR = "frb.axeron.server.input.IInputCallback";

    void onCursorEvent(float f, float f2, boolean z, boolean z2) throws RemoteException;

    void onTouchEvent(SyntheticInputEvent syntheticInputEvent) throws RemoteException;

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static abstract class Stub extends Binder implements IInputCallback {
        static final int TRANSACTION_onCursorEvent = 2;
        static final int TRANSACTION_onTouchEvent = 1;

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        private static final class Proxy implements IInputCallback {
            private IBinder mRemote;

            public Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public final String getInterfaceDescriptor() {
                return IInputCallback.DESCRIPTOR;
            }

            @Override // frb.axeron.server.input.IInputCallback
            public void onCursorEvent(float f, float f2, boolean z, boolean z2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputCallback.DESCRIPTOR);
                    obtain.writeFloat(f);
                    obtain.writeFloat(f2);
                    obtain.writeInt(z ? 1 : 0);
                    obtain.writeInt(z2 ? 1 : 0);
                    this.mRemote.transact(2, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.input.IInputCallback
            public void onTouchEvent(SyntheticInputEvent syntheticInputEvent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IInputCallback.DESCRIPTOR);
                    if (syntheticInputEvent != null) {
                        obtain.writeInt(1);
                        syntheticInputEvent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.mRemote.transact(1, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, IInputCallback.DESCRIPTOR);
        }

        public static IInputCallback asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(IInputCallback.DESCRIPTOR);
            return (queryLocalInterface == null || !(queryLocalInterface instanceof IInputCallback)) ? new Proxy(iBinder) : (IInputCallback) queryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i >= 1 && i <= 16777215) {
                parcel.enforceInterface(IInputCallback.DESCRIPTOR);
            }
            if (i == 1) {
                onTouchEvent(parcel.readInt() != 0 ? SyntheticInputEvent.CREATOR.createFromParcel(parcel) : null);
            } else {
                if (i != 2) {
                    return super.onTransact(i, parcel, parcel2, i2);
                }
                onCursorEvent(parcel.readFloat(), parcel.readFloat(), parcel.readInt() != 0, parcel.readInt() != 0);
            }
            return true;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
