package frb.axeron.server.watcher;

import android.os.Parcel;
import android.os.Parcelable;
import p000.ei2;
import p000.hn0;
import p000.rq3;
import p000.s76;
import p000.yt0;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class PackageEvent implements Parcelable {
    public static final int MASK_GONE = 48;
    public static final int MASK_VISIBLE = 65;
    public static final int STATE_ACTIVE = 64;
    public static final int STATE_BACKGROUND = 2;
    public static final int STATE_CACHED = 8;
    public static final int STATE_FOREGROUND = 1;
    public static final int STATE_PAUSED = 4;
    public static final int STATE_STOPPED = 16;
    public static final int STATE_UNINSTALLED = 32;
    private final String packageName;
    private final int state;
    private final long timestamp;
    private final int uid;
    public static final rq3 Companion = new rq3();
    public static final Parcelable.Creator<PackageEvent> CREATOR = new s76(14);

    public PackageEvent(String str, int i, int i2, long j) {
        str.getClass();
        this.packageName = str;
        this.uid = i;
        this.state = i2;
        this.timestamp = j;
    }

    public static /* synthetic */ PackageEvent copy$default(PackageEvent packageEvent, String str, int i, int i2, long j, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            str = packageEvent.packageName;
        }
        if ((i3 & 2) != 0) {
            i = packageEvent.uid;
        }
        if ((i3 & 4) != 0) {
            i2 = packageEvent.state;
        }
        if ((i3 & 8) != 0) {
            j = packageEvent.timestamp;
        }
        int i4 = i2;
        return packageEvent.copy(str, i, i4, j);
    }

    public final String component1() {
        return this.packageName;
    }

    public final int component2() {
        return this.uid;
    }

    public final int component3() {
        return this.state;
    }

    public final long component4() {
        return this.timestamp;
    }

    public final PackageEvent copy(String str, int i, int i2, long j) {
        str.getClass();
        return new PackageEvent(str, i, i2, j);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof PackageEvent)) {
            return false;
        }
        PackageEvent packageEvent = (PackageEvent) obj;
        return ei2.m10070i(this.packageName, packageEvent.packageName) && this.uid == packageEvent.uid && this.state == packageEvent.state && this.timestamp == packageEvent.timestamp;
    }

    public final String getPackageName() {
        return this.packageName;
    }

    public final int getState() {
        return this.state;
    }

    public final long getTimestamp() {
        return this.timestamp;
    }

    public final int getUid() {
        return this.uid;
    }

    public int hashCode() {
        return Long.hashCode(this.timestamp) + hn0.m12930c(this.state, hn0.m12930c(this.uid, this.packageName.hashCode() * 31, 31), 31);
    }

    public final boolean isAnyOf(int i) {
        return (this.state & i) != 0;
    }

    public String toString() {
        String str = this.packageName;
        int i = this.uid;
        int i2 = this.state;
        long j = this.timestamp;
        StringBuilder m23622o = yt0.m23622o(i, "PackageEvent(packageName=", str, ", uid=", ", state=");
        m23622o.append(i2);
        m23622o.append(", timestamp=");
        m23622o.append(j);
        m23622o.append(")");
        return m23622o.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.getClass();
        parcel.writeString(this.packageName);
        parcel.writeInt(this.uid);
        parcel.writeInt(this.state);
        parcel.writeLong(this.timestamp);
    }
}
