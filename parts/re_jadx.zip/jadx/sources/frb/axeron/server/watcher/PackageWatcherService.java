package frb.axeron.server.watcher;

import android.app.ActivityManager;
import android.app.ActivityTaskManager;
import android.content.ComponentName;
import android.os.Build;
import android.os.Parcel;
import android.os.RemoteCallbackList;
import android.os.SystemClock;
import frb.axeron.server.util.Logger;
import frb.axeron.server.watcher.IPackageWatcher;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import p000.AbstractC0917e5;
import p000.ab5;
import p000.ci1;
import p000.ei2;
import p000.hi1;
import p000.ij0;
import p000.jj0;
import p000.kn5;
import p000.m53;
import p000.md4;
import p000.nd4;
import p000.nr4;
import p000.o30;
import p000.sq3;
import p000.t24;
import p000.xm5;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class PackageWatcherService extends IPackageWatcher.Stub {
    private final FocusListenerImpl FocusListener;
    private final ProcessObserverImpl ProcessObserver;
    private final UidObserverImpl UidObserver;
    private final RemoteCallbackList<IPackageWatcherCallback> callbacks;
    private final Object dispatchLock;
    private volatile String focusedRootTask;
    private volatile List<String> foregroundPackages;
    private String lastEffectiveFocus;
    private final ConcurrentHashMap<String, PackageEvent> lastEvent;
    private final Logger logger;
    private zy1 onEventInternal;
    private final ConcurrentHashMap<Integer, List<String>> uidPackageCache;

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    private final class FocusListenerImpl extends ab5 {
        public FocusListenerImpl() {
        }

        @Override // p000.ab5
        public void onTaskStackChanged() {
            PackageWatcherService.this.refreshFocusedPackage();
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    private final class ProcessObserverImpl extends t24 {
        public ProcessObserverImpl() {
        }

        @Override // p000.t24
        public void onForegroundActivitiesChanged(int i, int i2, boolean z) {
            PackageWatcherService.this.logger.getClass();
            PackageWatcherService.this.emit(i2, z ? 1 : 2);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    private final class UidObserverImpl extends xm5 {
        public UidObserverImpl() {
        }

        @Override // p000.xm5
        public void onUidActive(int i) {
            PackageWatcherService.this.logger.getClass();
            PackageWatcherService.this.emit(i, 64);
        }

        @Override // p000.xm5
        public void onUidCachedChanged(int i, boolean z) {
            PackageWatcherService.this.logger.getClass();
            if (z) {
                PackageWatcherService.this.emit(i, 8);
            }
        }

        @Override // p000.xm5
        public void onUidGone(int i, boolean z) {
            PackageWatcherService.this.logger.getClass();
            PackageWatcherService.this.emit(i, 16);
            PackageWatcherService.this.checkPossibleUninstall(i);
        }

        @Override // p000.xm5
        public void onUidIdle(int i, boolean z) {
            PackageWatcherService.this.logger.getClass();
            PackageWatcherService.this.emit(i, 4);
        }
    }

    public PackageWatcherService(Logger logger) {
        logger.getClass();
        this.logger = logger;
        this.callbacks = new RemoteCallbackList<>();
        this.uidPackageCache = new ConcurrentHashMap<>();
        this.lastEvent = new ConcurrentHashMap<>();
        this.foregroundPackages = ci1.f4141a;
        this.dispatchLock = new Object();
        this.ProcessObserver = new ProcessObserverImpl();
        this.UidObserver = new UidObserverImpl();
        this.FocusListener = new FocusListenerImpl();
    }

    private final void broadcast(PackageEvent packageEvent) {
        int beginBroadcast = this.callbacks.beginBroadcast();
        for (int i = 0; i < beginBroadcast; i++) {
            try {
                Object broadcastCookie = this.callbacks.getBroadcastCookie(i);
                Set set = broadcastCookie instanceof Set ? (Set) broadcastCookie : null;
                Set set2 = set;
                if (set2 == null || set2.isEmpty() || set.contains(packageEvent.getPackageName())) {
                    try {
                        this.callbacks.getBroadcastItem(i).onPackageStateChanged(packageEvent);
                    } catch (Throwable unused) {
                    }
                }
            } finally {
                this.callbacks.finishBroadcast();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void checkPossibleUninstall(int i) {
        List<String> list = this.uidPackageCache.get(Integer.valueOf(i));
        if (list == null || !sq3.m19872d(i).isEmpty() || list.isEmpty()) {
            return;
        }
        this.logger.m11502i("PackageWatcher", "Detected possible uninstall for uid=" + i + ": " + list);
        this.uidPackageCache.remove(Integer.valueOf(i));
        synchronized (this.dispatchLock) {
            for (String str : list) {
                int i2 = i;
                PackageEvent packageEvent = new PackageEvent(str, i2, 32, SystemClock.elapsedRealtime());
                this.lastEvent.put(str, packageEvent);
                updateForeground(str, 32);
                dispatch(packageEvent);
                i = i2;
            }
        }
    }

    private final void dispatch(PackageEvent packageEvent) {
        try {
            zy1 zy1Var = this.onEventInternal;
            if (zy1Var != null) {
                zy1Var.invoke(packageEvent);
            }
        } catch (Throwable th) {
            this.logger.m11499e("PackageWatcher", "internal listener failed", th);
        }
        broadcast(packageEvent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void emit(int i, int i2) {
        List<String> packagesCached = getPackagesCached(i);
        if (packagesCached.isEmpty()) {
            return;
        }
        synchronized (this.dispatchLock) {
            for (String str : packagesCached) {
                PackageEvent packageEvent = this.lastEvent.get(str);
                if (packageEvent == null || packageEvent.getState() != i2) {
                    int i3 = i;
                    int i4 = i2;
                    PackageEvent packageEvent2 = new PackageEvent(str, i3, i4, SystemClock.elapsedRealtime());
                    this.lastEvent.put(str, packageEvent2);
                    updateForeground(str, i4);
                    Logger logger = this.logger;
                    PackageEvent.Companion.getClass();
                    logger.getClass();
                    dispatch(packageEvent2);
                    i = i3;
                    i2 = i4;
                }
            }
            recheckFocus();
        }
    }

    private final List<String> getPackagesCached(int i) {
        ConcurrentHashMap<Integer, List<String>> concurrentHashMap = this.uidPackageCache;
        Integer valueOf = Integer.valueOf(i);
        List<String> list = concurrentHashMap.get(valueOf);
        if (list == null) {
            ArrayList m19872d = sq3.m19872d(i);
            List<String> putIfAbsent = concurrentHashMap.putIfAbsent(valueOf, m19872d);
            list = putIfAbsent == null ? m19872d : putIfAbsent;
        }
        return list;
    }

    private final String queryFocusedPackage() {
        ActivityManager.RunningTaskInfo runningTaskInfo;
        ComponentName componentName;
        ComponentName componentName2;
        if (Build.VERSION.SDK_INT >= 31) {
            ActivityTaskManager.RootTaskInfo m9749c = AbstractC0917e5.m9749c();
            if (m9749c == null || (componentName2 = m9749c.topActivity) == null) {
                return null;
            }
            return componentName2.getPackageName();
        }
        List m9750d = AbstractC0917e5.m9750d();
        if (m9750d == null || (runningTaskInfo = (ActivityManager.RunningTaskInfo) ij0.m13403g0(m9750d)) == null || (componentName = runningTaskInfo.topActivity) == null) {
            return null;
        }
        return componentName.getPackageName();
    }

    private final void recheckFocus() {
        String foregroundPackage = getForegroundPackage();
        if (foregroundPackage != null && !foregroundPackage.equals(this.lastEffectiveFocus)) {
            this.lastEffectiveFocus = foregroundPackage;
            this.logger.getClass();
            PackageEvent packageEvent = this.lastEvent.get(foregroundPackage);
            if (packageEvent != null) {
                PackageEvent packageEvent2 = new PackageEvent(foregroundPackage, packageEvent.getUid(), packageEvent.getState(), SystemClock.elapsedRealtime());
                this.lastEvent.put(foregroundPackage, packageEvent2);
                dispatch(packageEvent2);
            }
        }
        List<String> list = this.foregroundPackages;
        ArrayList arrayList = new ArrayList();
        for (Object obj : list) {
            if (!ei2.m10070i((String) obj, foregroundPackage)) {
                arrayList.add(obj);
            }
        }
        if (arrayList.isEmpty()) {
            return;
        }
        this.logger.getClass();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void refreshFocusedPackage() {
        try {
            String queryFocusedPackage = queryFocusedPackage();
            if (queryFocusedPackage == null || !this.foregroundPackages.contains(queryFocusedPackage) || queryFocusedPackage.equals(this.focusedRootTask)) {
                return;
            }
            synchronized (this.dispatchLock) {
                this.focusedRootTask = queryFocusedPackage;
                this.logger.getClass();
                recheckFocus();
            }
        } catch (Throwable th) {
            Logger logger = this.logger;
            th.getMessage();
            logger.getClass();
        }
    }

    private final void seedFocusedPackage() {
        try {
            String queryFocusedPackage = queryFocusedPackage();
            if (queryFocusedPackage == null) {
                return;
            }
            synchronized (this.dispatchLock) {
                if (!this.foregroundPackages.contains(queryFocusedPackage)) {
                    this.foregroundPackages = ij0.m13415s0(this.foregroundPackages, queryFocusedPackage);
                }
                this.focusedRootTask = queryFocusedPackage;
                this.logger.getClass();
                recheckFocus();
            }
        } catch (Throwable th) {
            Logger logger = this.logger;
            th.getMessage();
            logger.getClass();
        }
    }

    private final void updateForeground(String str, int i) {
        List<String> list = this.foregroundPackages;
        this.foregroundPackages = i != 1 ? (i == 2 || i == 8 || i == 16 || i == 32) ? ij0.m13412p0(this.foregroundPackages, str) : this.foregroundPackages : ij0.m13415s0(ij0.m13412p0(this.foregroundPackages, str), str);
        if (ei2.m10070i(this.foregroundPackages, list)) {
            return;
        }
        Logger logger = this.logger;
        this.foregroundPackages.contains(str);
        logger.getClass();
    }

    @Override // frb.axeron.server.watcher.IPackageWatcher
    public String getForegroundPackage() {
        String str = this.focusedRootTask;
        return (str == null || !this.foregroundPackages.contains(str)) ? (String) ij0.m13410n0(this.foregroundPackages) : str;
    }

    public final zy1 getOnEventInternal() {
        return this.onEventInternal;
    }

    @Override // frb.axeron.server.watcher.IPackageWatcher
    public int getPackageState(String str) {
        if (str == null) {
            return 0;
        }
        PackageEvent packageEvent = this.lastEvent.get(str);
        Integer valueOf = packageEvent != null ? Integer.valueOf(packageEvent.getState()) : null;
        if (valueOf != null) {
            return valueOf.intValue();
        }
        return 0;
    }

    @Override // frb.axeron.server.watcher.IPackageWatcher
    public boolean isForeground(String str) {
        return str != null && this.foregroundPackages.contains(str);
    }

    @Override // frb.axeron.server.watcher.IPackageWatcher.Stub, android.os.Binder
    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        parcel.getClass();
        return nr4.f27900a.m16827h("IPackageWatcher", i, new o30(this, i, parcel, parcel2, i2, (byte) 3));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.util.AbstractCollection, java.util.HashSet] */
    @Override // frb.axeron.server.watcher.IPackageWatcher
    public void registerCallback(IPackageWatcherCallback iPackageWatcherCallback, List<String> list) {
        hi1 hi1Var;
        List list2;
        if (iPackageWatcherCallback == null) {
            return;
        }
        if (list != null) {
            ?? hashSet = new HashSet(m53.m15765Z(jj0.m14060l(list, 12)));
            ij0.m13422z0(list, hashSet);
            hi1Var = hashSet;
        } else {
            hi1Var = hi1.f17209a;
        }
        synchronized (this.dispatchLock) {
            this.callbacks.register(iPackageWatcherCallback, hi1Var);
            if (hi1Var.isEmpty()) {
                Collection<PackageEvent> values = this.lastEvent.values();
                values.getClass();
                list2 = ij0.m13394C0(values);
            } else {
                ArrayList arrayList = new ArrayList();
                Iterator it = hi1Var.iterator();
                while (it.hasNext()) {
                    PackageEvent packageEvent = this.lastEvent.get((String) it.next());
                    if (packageEvent != null) {
                        arrayList.add(packageEvent);
                    }
                }
                list2 = arrayList;
            }
            for (Object obj : list2) {
                obj.getClass();
                try {
                    iPackageWatcherCallback.onPackageStateChanged((PackageEvent) obj);
                } catch (Throwable unused) {
                }
            }
        }
    }

    public final void setOnEventInternal(zy1 zy1Var) {
        this.onEventInternal = zy1Var;
    }

    public final void start() {
        Object md4Var;
        Object md4Var2;
        Object obj = kn5.f22076a;
        try {
            AbstractC0917e5.m9751e(this.ProcessObserver);
            md4Var = obj;
        } catch (Throwable th) {
            md4Var = new md4(th);
        }
        Throwable m16656b = nd4.m16656b(md4Var);
        if (m16656b != null) {
            this.logger.m11499e("PackageWatcher", "registerProcessObserver", m16656b);
        }
        try {
            AbstractC0917e5.m9753g(this.UidObserver, ActivityManager.UID_OBSERVER_GONE | ActivityManager.UID_OBSERVER_IDLE | ActivityManager.UID_OBSERVER_ACTIVE | ActivityManager.UID_OBSERVER_CACHED, ActivityManager.PROCESS_STATE_UNKNOWN);
            md4Var2 = obj;
        } catch (Throwable th2) {
            md4Var2 = new md4(th2);
        }
        Throwable m16656b2 = nd4.m16656b(md4Var2);
        if (m16656b2 != null) {
            this.logger.m11499e("PackageWatcher", "registerUidObserver", m16656b2);
        }
        try {
            AbstractC0917e5.m9752f(this.FocusListener);
        } catch (Throwable th3) {
            obj = new md4(th3);
        }
        Throwable m16656b3 = nd4.m16656b(obj);
        if (m16656b3 != null) {
            this.logger.m11499e("PackageWatcher", "registerTaskStackListener", m16656b3);
        }
        seedFocusedPackage();
    }

    public final void stop() {
        try {
            AbstractC0917e5.m9755i(this.ProcessObserver);
        } catch (Throwable unused) {
        }
        try {
            AbstractC0917e5.m9757k(this.UidObserver);
        } catch (Throwable unused2) {
        }
        try {
            AbstractC0917e5.m9756j(this.FocusListener);
        } catch (Throwable unused3) {
        }
        try {
            this.callbacks.kill();
        } catch (Throwable unused4) {
        }
    }

    @Override // frb.axeron.server.watcher.IPackageWatcher
    public void unregisterCallback(IPackageWatcherCallback iPackageWatcherCallback) {
        if (iPackageWatcherCallback != null) {
            this.callbacks.unregister(iPackageWatcherCallback);
        }
    }
}
