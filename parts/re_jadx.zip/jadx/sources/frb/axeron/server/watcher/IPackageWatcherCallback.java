package frb.axeron.server.watcher;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public interface IPackageWatcherCallback extends IInterface {
    public static final String DESCRIPTOR = "frb.axeron.server.watcher.IPackageWatcherCallback";

    void onPackageStateChanged(PackageEvent packageEvent) throws RemoteException;

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static abstract class Stub extends Binder implements IPackageWatcherCallback {
        static final int TRANSACTION_onPackageStateChanged = 1;

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        private static final class Proxy implements IPackageWatcherCallback {
            private IBinder mRemote;

            public Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public final String getInterfaceDescriptor() {
                return IPackageWatcherCallback.DESCRIPTOR;
            }

            @Override // frb.axeron.server.watcher.IPackageWatcherCallback
            public void onPackageStateChanged(PackageEvent packageEvent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IPackageWatcherCallback.DESCRIPTOR);
                    if (packageEvent != null) {
                        obtain.writeInt(1);
                        packageEvent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.mRemote.transact(1, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, IPackageWatcherCallback.DESCRIPTOR);
        }

        public static IPackageWatcherCallback asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(IPackageWatcherCallback.DESCRIPTOR);
            return (queryLocalInterface == null || !(queryLocalInterface instanceof IPackageWatcherCallback)) ? new Proxy(iBinder) : (IPackageWatcherCallback) queryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i >= 1 && i <= 16777215) {
                parcel.enforceInterface(IPackageWatcherCallback.DESCRIPTOR);
            }
            if (i != 1) {
                return super.onTransact(i, parcel, parcel2, i2);
            }
            onPackageStateChanged(parcel.readInt() != 0 ? PackageEvent.CREATOR.createFromParcel(parcel) : null);
            return true;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
