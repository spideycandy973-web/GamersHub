package frb.axeron.server.watcher;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import frb.axeron.server.watcher.IPackageWatcherCallback;
import java.util.List;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public interface IPackageWatcher extends IInterface {
    public static final String DESCRIPTOR = "frb.axeron.server.watcher.IPackageWatcher";

    String getForegroundPackage() throws RemoteException;

    int getPackageState(String str) throws RemoteException;

    boolean isForeground(String str) throws RemoteException;

    void registerCallback(IPackageWatcherCallback iPackageWatcherCallback, List<String> list) throws RemoteException;

    void unregisterCallback(IPackageWatcherCallback iPackageWatcherCallback) throws RemoteException;

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static abstract class Stub extends Binder implements IPackageWatcher {
        static final int TRANSACTION_getForegroundPackage = 2;
        static final int TRANSACTION_getPackageState = 3;
        static final int TRANSACTION_isForeground = 4;
        static final int TRANSACTION_registerCallback = 5;
        static final int TRANSACTION_unregisterCallback = 6;

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        private static final class Proxy implements IPackageWatcher {
            private IBinder mRemote;

            public Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            @Override // frb.axeron.server.watcher.IPackageWatcher
            public String getForegroundPackage() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IPackageWatcher.DESCRIPTOR);
                    this.mRemote.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readString();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final String getInterfaceDescriptor() {
                return IPackageWatcher.DESCRIPTOR;
            }

            @Override // frb.axeron.server.watcher.IPackageWatcher
            public int getPackageState(String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IPackageWatcher.DESCRIPTOR);
                    obtain.writeString(str);
                    this.mRemote.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.watcher.IPackageWatcher
            public boolean isForeground(String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IPackageWatcher.DESCRIPTOR);
                    obtain.writeString(str);
                    this.mRemote.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.watcher.IPackageWatcher
            public void registerCallback(IPackageWatcherCallback iPackageWatcherCallback, List<String> list) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IPackageWatcher.DESCRIPTOR);
                    obtain.writeStrongInterface(iPackageWatcherCallback);
                    obtain.writeStringList(list);
                    this.mRemote.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.watcher.IPackageWatcher
            public void unregisterCallback(IPackageWatcherCallback iPackageWatcherCallback) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IPackageWatcher.DESCRIPTOR);
                    obtain.writeStrongInterface(iPackageWatcherCallback);
                    this.mRemote.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, IPackageWatcher.DESCRIPTOR);
        }

        public static IPackageWatcher asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(IPackageWatcher.DESCRIPTOR);
            return (queryLocalInterface == null || !(queryLocalInterface instanceof IPackageWatcher)) ? new Proxy(iBinder) : (IPackageWatcher) queryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i >= 1 && i <= 16777215) {
                parcel.enforceInterface(IPackageWatcher.DESCRIPTOR);
            }
            if (i == 2) {
                String foregroundPackage = getForegroundPackage();
                parcel2.writeNoException();
                parcel2.writeString(foregroundPackage);
            } else if (i == 3) {
                int packageState = getPackageState(parcel.readString());
                parcel2.writeNoException();
                parcel2.writeInt(packageState);
            } else if (i == 4) {
                boolean isForeground = isForeground(parcel.readString());
                parcel2.writeNoException();
                parcel2.writeInt(isForeground ? 1 : 0);
            } else if (i == 5) {
                registerCallback(IPackageWatcherCallback.Stub.asInterface(parcel.readStrongBinder()), parcel.createStringArrayList());
                parcel2.writeNoException();
            } else {
                if (i != 6) {
                    return super.onTransact(i, parcel, parcel2, i2);
                }
                unregisterCallback(IPackageWatcherCallback.Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
            }
            return true;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
