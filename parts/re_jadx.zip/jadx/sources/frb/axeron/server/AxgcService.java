package frb.axeron.server;

import android.content.IContentProvider;
import android.content.pm.ApplicationInfo;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Process;
import android.os.SystemClock;
import android.system.Os;
import frb.axeron.manager.Axeron;
import frb.axeron.server.IAxgcService;
import frb.axeron.server.input.InputListenerService;
import frb.axeron.server.provider.ServerProvider;
import frb.axeron.server.util.BinderContainer;
import frb.axeron.server.util.ContentProviderCompat;
import frb.axeron.server.util.Logger;
import frb.axeron.server.watcher.IPackageWatcher;
import frb.axeron.server.watcher.PackageWatcherService;
import java.util.ArrayList;
import java.util.Iterator;
import p000.AbstractC0917e5;
import p000.C0931ej;
import p000.c81;
import p000.d63;
import p000.dp5;
import p000.ei2;
import p000.f55;
import p000.i85;
import p000.iv3;
import p000.nr4;
import p000.o30;
import p000.sq3;
import p000.u30;
import p000.v30;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public class AxgcService extends IAxgcService.Stub {

    /* renamed from: h */
    public static final Logger f14415h = new Logger();

    /* renamed from: i */
    public static Handler f14416i;

    /* renamed from: j */
    public static String f14417j;

    /* renamed from: b */
    public volatile boolean f14419b;

    /* renamed from: c */
    public volatile byte[] f14420c;

    /* renamed from: d */
    public final i85 f14421d;

    /* renamed from: a */
    public final long f14418a = SystemClock.elapsedRealtime();

    /* renamed from: e */
    public final i85 f14422e = new i85(new C0931ej((byte) 26));

    /* renamed from: f */
    public final i85 f14423f = new i85(new C0931ej((byte) 27));

    /* renamed from: g */
    public final u30 f14424g = new u30(this, (byte) 0);

    /* JADX WARN: Removed duplicated region for block: B:165:0x020e A[LOOP:9: B:135:0x0102->B:165:0x020e, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:166:0x0204 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:85:0x03b2  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0418  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x0421  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public AxgcService() {
        /*
            Method dump skipped, instructions count: 1077
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.AxgcService.<init>():void");
    }

    /* renamed from: U0 */
    public static boolean m11459U0() {
        if (Os.getuid() != 0) {
            try {
                if (iv3.m13650a(Os.getuid()) != 0) {
                    return false;
                }
            } catch (Throwable th) {
                f14415h.m11509w("AxgcService", "Failed to check GRANT_RUNTIME_PERMISSIONS, assuming false", th);
                return false;
            }
        }
        return true;
    }

    public static final void main(String[] strArr) {
        v30.m21193a(strArr);
    }

    /* renamed from: q1 */
    public static void m11460q1(AxgcService axgcService, String str, int i, boolean z) {
        Logger logger = f14415h;
        if (str == null) {
            logger.m11498e(ServerProvider.METHOD_SEND_BINDER, "packageName is null");
            return;
        }
        try {
            c81.m2266a(i, str);
            logger.getClass();
        } catch (Throwable th) {
            logger.m11501e(ServerProvider.METHOD_SEND_BINDER, th, "Failed to add %d:%s to power save temp whitelist", Integer.valueOf(i), str);
        }
        String concat = str.concat(".server");
        try {
            IContentProvider m9748b = AbstractC0917e5.m9748b(i, concat, concat);
            if (m9748b == null) {
                logger.m11500e(ServerProvider.METHOD_SEND_BINDER, "provider is null %s %d", concat, Integer.valueOf(i));
                try {
                    AbstractC0917e5.m9754h(concat);
                    return;
                } catch (Throwable th2) {
                    logger.m11511w(ServerProvider.METHOD_SEND_BINDER, th2, "removeContentProviderExternal", new Object[0]);
                    return;
                }
            }
            if (m9748b.asBinder().pingBinder()) {
                if (!z) {
                    logger.m11498e(ServerProvider.METHOD_SEND_BINDER, "retry works");
                }
                Bundle bundle = new Bundle();
                bundle.putParcelable(ServerProvider.EXTRA_BINDER, new BinderContainer(axgcService));
                ContentProviderCompat.INSTANCE.call(m9748b, null, null, concat, ServerProvider.METHOD_SEND_BINDER, null, bundle);
                logger.m11504i(ServerProvider.METHOD_SEND_BINDER, "send binder to user app %s in user %d", str, Integer.valueOf(i));
                try {
                    AbstractC0917e5.m9754h(concat);
                    return;
                } catch (Throwable th3) {
                    logger.m11511w(ServerProvider.METHOD_SEND_BINDER, th3, "removeContentProviderExternal", new Object[0]);
                    return;
                }
            }
            logger.m11500e(ServerProvider.METHOD_SEND_BINDER, "provider is dead %s %d", concat, Integer.valueOf(i));
            if (z) {
                AbstractC0917e5.m9747a(i, str);
                logger.m11500e(ServerProvider.METHOD_SEND_BINDER, "kill %s in user %d and try again", str, Integer.valueOf(i));
                Thread.sleep(1000L);
                m11460q1(axgcService, str, i, false);
            }
            try {
                AbstractC0917e5.m9754h(concat);
            } catch (Throwable th4) {
                logger.m11511w(ServerProvider.METHOD_SEND_BINDER, th4, "removeContentProviderExternal", new Object[0]);
            }
        } catch (Throwable th5) {
            try {
                logger.m11501e(ServerProvider.METHOD_SEND_BINDER, th5, "failed send binder to user app %s in user %d", str, Integer.valueOf(i));
                try {
                    AbstractC0917e5.m9754h(concat);
                } catch (Throwable th6) {
                    logger.m11511w(ServerProvider.METHOD_SEND_BINDER, th6, "removeContentProviderExternal", new Object[0]);
                }
            } finally {
            }
        }
    }

    /* renamed from: A */
    public final void m11461A() {
        f14415h.m11502i("AxgcService", "cleanup: releasing native touch listener and stopping background services...");
        try {
            if (this.f14419b) {
                ((InputListenerService) this.f14421d.getValue()).stop();
            }
        } catch (Exception e) {
            f14415h.m11499e("AxgcService", "Failed to stop inputListener during cleanup", e);
        }
        try {
            m11462P().stop();
        } catch (Exception e2) {
            f14415h.m11499e("AxgcService", "Failed to stop packageWatcher during cleanup", e2);
        }
        try {
            Handler handler = f14416i;
            if (handler != null) {
                handler.removeCallbacksAndMessages(null);
            } else {
                ei2.m10039H("mainHandler");
                throw null;
            }
        } catch (Exception unused) {
        }
    }

    /* renamed from: P */
    public final PackageWatcherService m11462P() {
        return (PackageWatcherService) this.f14423f.getValue();
    }

    /* renamed from: c1 */
    public final void m11463c1() {
        Iterator it = dp5.m9418a().iterator();
        while (it.hasNext()) {
            Integer num = (Integer) it.next();
            String str = f14417j;
            num.getClass();
            m11460q1(this, str, num.intValue(), true);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:28:0x0058, code lost:
    
        r1 = p000.f55.m10706O0(200000, r3);
     */
    @Override // frb.axeron.server.IAxgcService
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.String consumeDiagnostics() {
        /*
            r5 = this;
            nr4 r5 = p000.nr4.f27900a
            monitor-enter(r5)
            java.io.File r0 = p000.nr4.f27909j     // Catch: java.lang.Throwable -> L67
            r1 = 0
            if (r0 == 0) goto L63
            java.io.File r2 = new java.io.File     // Catch: java.lang.Throwable -> L67
            java.lang.String r3 = "reports"
            r2.<init>(r0, r3)     // Catch: java.lang.Throwable -> L67
            java.io.File[] r0 = r2.listFiles()     // Catch: java.lang.Throwable -> L67
            if (r0 == 0) goto L21
            ew1 r2 = new ew1     // Catch: java.lang.Throwable -> L67
            r3 = 19
            r2.<init>(r3)     // Catch: java.lang.Throwable -> L67
            java.util.List r0 = p000.AbstractC0946ew.m10547c1(r0, r2)     // Catch: java.lang.Throwable -> L67
            goto L22
        L21:
            r0 = r1
        L22:
            if (r0 != 0) goto L26
            ci1 r0 = p000.ci1.f4141a     // Catch: java.lang.Throwable -> L67
        L26:
            java.util.Iterator r0 = r0.iterator()     // Catch: java.lang.Throwable -> L67
        L2a:
            boolean r2 = r0.hasNext()     // Catch: java.lang.Throwable -> L67
            if (r2 == 0) goto L61
            java.lang.Object r2 = r0.next()     // Catch: java.lang.Throwable -> L67
            java.io.File r2 = (java.io.File) r2     // Catch: java.lang.Throwable -> L67
            r2.getClass()     // Catch: java.lang.Throwable -> L3e
            java.lang.String r3 = p000.wk0.m22134U(r2)     // Catch: java.lang.Throwable -> L3e
            goto L45
        L3e:
            r3 = move-exception
            md4 r4 = new md4     // Catch: java.lang.Throwable -> L67
            r4.<init>(r3)     // Catch: java.lang.Throwable -> L67
            r3 = r4
        L45:
            boolean r4 = r3 instanceof p000.md4     // Catch: java.lang.Throwable -> L67
            if (r4 == 0) goto L4b
            r3 = r1
        L4b:
            java.lang.String r3 = (java.lang.String) r3     // Catch: java.lang.Throwable -> L67
            r2.delete()     // Catch: java.lang.Throwable -> L50
        L50:
            if (r3 == 0) goto L2a
            boolean r2 = p000.f55.m10718s0(r3)     // Catch: java.lang.Throwable -> L67
            if (r2 != 0) goto L2a
            r0 = 200000(0x30d40, float:2.8026E-40)
            java.lang.String r1 = p000.f55.m10706O0(r0, r3)     // Catch: java.lang.Throwable -> L67
            monitor-exit(r5)
            goto L62
        L61:
            monitor-exit(r5)
        L62:
            return r1
        L63:
            monitor-exit(r5)
            return r1
        L65:
            monitor-exit(r5)     // Catch: java.lang.Throwable -> L67
            throw r0
        L67:
            r0 = move-exception
            goto L65
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.AxgcService.consumeDiagnostics():java.lang.String");
    }

    @Override // frb.axeron.server.IAxgcService
    public final void destroy() {
        f14415h.m11502i("AxgcService", "destroy called — performing daemon cleanup before process exit");
        nr4 nr4Var = nr4.f27900a;
        nr4Var.m16823b("server destroy requested", "server destroy requested");
        nr4Var.m16828i();
        m11461A();
        System.exit(0);
        throw new RuntimeException("System.exit returned normally, while it was supposed to halt JVM.");
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x0078, code lost:
    
        if ((r12 | (r5 ^ (-3036666899081369764L))) == 0) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00df, code lost:
    
        if ((r4 | (r2 ^ (-203685228572790939L))) == 0) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00e9, code lost:
    
        return (frb.axeron.server.input.InputListenerService) r20.f14421d.getValue();
     */
    @Override // frb.axeron.server.IAxgcService
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final frb.axeron.server.input.IInputListener getInputListener() {
        /*
            Method dump skipped, instructions count: 240
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.AxgcService.getInputListener():frb.axeron.server.input.IInputListener");
    }

    @Override // frb.axeron.server.IAxgcService
    public final IPackageWatcher getPackageWatcher() {
        return m11462P();
    }

    @Override // frb.axeron.server.IAxgcService
    public final ServiceInfo getServiceInfo() {
        return new ServiceInfo(Axeron.CLIENT_VERSION, Axeron.CLIENT_VERSION_CODE, this.f14418a, Process.myPid(), Process.myUid(), m11459U0());
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x007a, code lost:
    
        if ((r11 | (r4 ^ (-3036666899081369764L))) == 0) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00e3, code lost:
    
        if ((r2 | (r4 ^ (-203685228572790939L))) == 0) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00f0, code lost:
    
        return new p000.p30(r20, r21, r22);
     */
    @Override // frb.axeron.server.IAxgcService
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final p000.fa2 newProcess(java.lang.String[] r20, java.lang.String[] r21, java.lang.String r22) {
        /*
            Method dump skipped, instructions count: 247
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.AxgcService.newProcess(java.lang.String[], java.lang.String[], java.lang.String):fa2");
    }

    @Override // frb.axeron.server.IAxgcService.Stub, android.os.Binder
    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        parcel.getClass();
        return nr4.f27900a.m16827h("IAxgcService", i, new o30(this, i, parcel, parcel2, i2, (byte) 1));
    }

    @Override // frb.axeron.server.IAxgcService
    public final void recordTestDiagnostics() {
        nr4 nr4Var = nr4.f27900a;
        nr4Var.m16823b("diagnostics test requested", "diagnostics test requested");
        ArrayList m16811e = nr4.m16811e(true);
        synchronized (nr4Var) {
            nr4.m16821v("test", Thread.currentThread(), new Throwable("AXGC server diagnostics test"), nr4.m16812f(), m16811e, null, null, null);
        }
    }

    /* renamed from: s0 */
    public final boolean m11464s0(int i, Parcel parcel, Parcel parcel2, int i2) {
        ApplicationInfo applicationInfo;
        if (i != 1599098439 && i != 1598968902) {
            int callingUid = Binder.getCallingUid();
            try {
                applicationInfo = sq3.m19869a(f14417j);
            } catch (Throwable unused) {
                applicationInfo = null;
            }
            Integer valueOf = applicationInfo != null ? Integer.valueOf(applicationInfo.uid) : null;
            if (valueOf != null && callingUid != valueOf.intValue() && callingUid != Process.myUid() && callingUid != 0 && callingUid != 1000) {
                f14415h.m11500e("AxgcService", "Rejecting transaction %d from unauthorized caller UID %d (expected %d)", Integer.valueOf(i), Integer.valueOf(callingUid), valueOf);
                throw new SecurityException(d63.m8804k(callingUid, "Calling UID ", " is not authorized"));
            }
        }
        if (i != 16777114) {
            return super.onTransact(i, parcel, parcel2, i2);
        }
        parcel.enforceInterface(IAxgcService.DESCRIPTOR);
        String readString = parcel.readString();
        if (readString != null && readString.length() != 0 && ((Boolean) this.f14422e.getValue()).booleanValue()) {
            f14415h.m11502i("AxgcService", "update: releasing touch listener daemon before spawning new server...");
            try {
                if (this.f14419b) {
                    ((InputListenerService) this.f14421d.getValue()).stop();
                }
            } catch (Exception e) {
                f14415h.m11499e("AxgcService", "Failed to stop inputListener during update", e);
            }
            nr4 nr4Var = nr4.f27900a;
            nr4Var.m16823b("update: spawning replacement server", "update: spawning replacement server");
            nr4Var.m16828i();
            f55.m10706O0(120, readString);
            UpdateCommand.nativeExecDetached("export AXGC_SPAWN=update:" + Process.myPid() + ":13015; " + readString);
        }
        if (parcel2 == null) {
            return true;
        }
        parcel2.writeNoException();
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x0080, code lost:
    
        if ((r12 | (r5 ^ (-3036666899081369764L))) == 0) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00e8, code lost:
    
        if ((r4 | (r11 ^ (-203685228572790939L))) == 0) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00ea, code lost:
    
        r1 = android.os.Parcel.obtain();
        r1.getClass();
        r2 = android.os.Parcel.obtain();
        r2.getClass();
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00f8, code lost:
    
        r1.unmarshall(r21, 0, r21.length);
        r1.setDataPosition(0);
        r19.transact(r20, r1, r2, r22);
        r2.setDataPosition(0);
        r0 = r2.marshall();
        r0.getClass();
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x0118, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x0119, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x011a, code lost:
    
        r1.recycle();
        r2.recycle();
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x0120, code lost:
    
        throw r0;
     */
    @Override // frb.axeron.server.IAxgcService
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final byte[] transactRemote(android.os.IBinder r19, int r20, byte[] r21, int r22) {
        /*
            Method dump skipped, instructions count: 295
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.server.AxgcService.transactRemote(android.os.IBinder, int, byte[], int):byte[]");
    }
}
