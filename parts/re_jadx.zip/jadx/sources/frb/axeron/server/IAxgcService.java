package frb.axeron.server;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import frb.axeron.server.input.IInputListener;
import frb.axeron.server.watcher.IPackageWatcher;
import p000.ea2;
import p000.fa2;
import p000.p30;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public interface IAxgcService extends IInterface {
    public static final String DESCRIPTOR = "frb.axeron.server.IAxgcService";

    String consumeDiagnostics() throws RemoteException;

    void destroy() throws RemoteException;

    IInputListener getInputListener() throws RemoteException;

    IPackageWatcher getPackageWatcher() throws RemoteException;

    ServiceInfo getServiceInfo() throws RemoteException;

    fa2 newProcess(String[] strArr, String[] strArr2, String str) throws RemoteException;

    void recordTestDiagnostics() throws RemoteException;

    byte[] transactRemote(IBinder iBinder, int i, byte[] bArr, int i2) throws RemoteException;

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static abstract class Stub extends Binder implements IAxgcService {
        static final int TRANSACTION_consumeDiagnostics = 8;
        static final int TRANSACTION_destroy = 16777115;
        static final int TRANSACTION_getInputListener = 4;
        static final int TRANSACTION_getPackageWatcher = 5;
        static final int TRANSACTION_getServiceInfo = 3;
        static final int TRANSACTION_newProcess = 6;
        static final int TRANSACTION_recordTestDiagnostics = 9;
        static final int TRANSACTION_transactRemote = 7;

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        private static final class Proxy implements IAxgcService {
            private IBinder mRemote;

            public Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            @Override // frb.axeron.server.IAxgcService
            public String consumeDiagnostics() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IAxgcService.DESCRIPTOR);
                    this.mRemote.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readString();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.IAxgcService
            public void destroy() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IAxgcService.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_destroy, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.IAxgcService
            public IInputListener getInputListener() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IAxgcService.DESCRIPTOR);
                    this.mRemote.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                    return IInputListener.Stub.asInterface(obtain2.readStrongBinder());
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public final String getInterfaceDescriptor() {
                return IAxgcService.DESCRIPTOR;
            }

            @Override // frb.axeron.server.IAxgcService
            public IPackageWatcher getPackageWatcher() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IAxgcService.DESCRIPTOR);
                    this.mRemote.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                    return IPackageWatcher.Stub.asInterface(obtain2.readStrongBinder());
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.IAxgcService
            public ServiceInfo getServiceInfo() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IAxgcService.DESCRIPTOR);
                    this.mRemote.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0 ? ServiceInfo.CREATOR.createFromParcel(obtain2) : null;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.IAxgcService
            public fa2 newProcess(String[] strArr, String[] strArr2, String str) throws RemoteException {
                fa2 fa2Var;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IAxgcService.DESCRIPTOR);
                    obtain.writeStringArray(strArr);
                    obtain.writeStringArray(strArr2);
                    obtain.writeString(str);
                    this.mRemote.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                    IBinder readStrongBinder = obtain2.readStrongBinder();
                    int i = p30.f29724d;
                    if (readStrongBinder == null) {
                        fa2Var = null;
                    } else {
                        IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("frb.axeron.server.process.IAxeronRemoteProcess");
                        if (queryLocalInterface == null || !(queryLocalInterface instanceof fa2)) {
                            ea2 ea2Var = new ea2();
                            ea2Var.f11569a = readStrongBinder;
                            fa2Var = ea2Var;
                        } else {
                            fa2Var = (fa2) queryLocalInterface;
                        }
                    }
                    return fa2Var;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.IAxgcService
            public void recordTestDiagnostics() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IAxgcService.DESCRIPTOR);
                    this.mRemote.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // frb.axeron.server.IAxgcService
            public byte[] transactRemote(IBinder iBinder, int i, byte[] bArr, int i2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IAxgcService.DESCRIPTOR);
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeInt(i);
                    obtain.writeByteArray(bArr);
                    obtain.writeInt(i2);
                    this.mRemote.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.createByteArray();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, IAxgcService.DESCRIPTOR);
        }

        public static IAxgcService asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(IAxgcService.DESCRIPTOR);
            return (queryLocalInterface == null || !(queryLocalInterface instanceof IAxgcService)) ? new Proxy(iBinder) : (IAxgcService) queryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i >= 1 && i <= 16777215) {
                parcel.enforceInterface(IAxgcService.DESCRIPTOR);
            }
            if (i != TRANSACTION_destroy) {
                switch (i) {
                    case 3:
                        ServiceInfo serviceInfo = getServiceInfo();
                        parcel2.writeNoException();
                        if (serviceInfo == null) {
                            parcel2.writeInt(0);
                            break;
                        } else {
                            parcel2.writeInt(1);
                            serviceInfo.writeToParcel(parcel2, 1);
                            break;
                        }
                    case 4:
                        IInputListener inputListener = getInputListener();
                        parcel2.writeNoException();
                        parcel2.writeStrongInterface(inputListener);
                        break;
                    case 5:
                        IPackageWatcher packageWatcher = getPackageWatcher();
                        parcel2.writeNoException();
                        parcel2.writeStrongInterface(packageWatcher);
                        break;
                    case 6:
                        fa2 newProcess = newProcess(parcel.createStringArray(), parcel.createStringArray(), parcel.readString());
                        parcel2.writeNoException();
                        parcel2.writeStrongInterface(newProcess);
                        break;
                    case 7:
                        byte[] transactRemote = transactRemote(parcel.readStrongBinder(), parcel.readInt(), parcel.createByteArray(), parcel.readInt());
                        parcel2.writeNoException();
                        parcel2.writeByteArray(transactRemote);
                        break;
                    case 8:
                        String consumeDiagnostics = consumeDiagnostics();
                        parcel2.writeNoException();
                        parcel2.writeString(consumeDiagnostics);
                        break;
                    case 9:
                        recordTestDiagnostics();
                        parcel2.writeNoException();
                        break;
                    default:
                        return super.onTransact(i, parcel, parcel2, i2);
                }
            } else {
                destroy();
            }
            return true;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
