package frb.axeron.server;

import android.os.Parcel;
import android.os.Parcelable;
import p000.d63;
import p000.ei2;
import p000.hn0;
import p000.s76;
import p000.yt0;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ServiceInfo implements Parcelable {
    public static final Parcelable.Creator<ServiceInfo> CREATOR = new s76((byte) 20);
    private final boolean grantRuntime;
    private final int pid;
    private final long startTimestamp;
    private final int uid;
    private final String version;
    private final int versionCode;

    public ServiceInfo(String str, int i, long j, int i2, int i3, boolean z) {
        str.getClass();
        this.version = str;
        this.versionCode = i;
        this.startTimestamp = j;
        this.pid = i2;
        this.uid = i3;
        this.grantRuntime = z;
    }

    public static /* synthetic */ ServiceInfo copy$default(ServiceInfo serviceInfo, String str, int i, long j, int i2, int i3, boolean z, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            str = serviceInfo.version;
        }
        if ((i4 & 2) != 0) {
            i = serviceInfo.versionCode;
        }
        if ((i4 & 4) != 0) {
            j = serviceInfo.startTimestamp;
        }
        if ((i4 & 8) != 0) {
            i2 = serviceInfo.pid;
        }
        if ((i4 & 16) != 0) {
            i3 = serviceInfo.uid;
        }
        if ((i4 & 32) != 0) {
            z = serviceInfo.grantRuntime;
        }
        boolean z2 = z;
        int i5 = i2;
        long j2 = j;
        return serviceInfo.copy(str, i, j2, i5, i3, z2);
    }

    public final String component1() {
        return this.version;
    }

    public final int component2() {
        return this.versionCode;
    }

    public final long component3() {
        return this.startTimestamp;
    }

    public final int component4() {
        return this.pid;
    }

    public final int component5() {
        return this.uid;
    }

    public final boolean component6() {
        return this.grantRuntime;
    }

    public final ServiceInfo copy(String str, int i, long j, int i2, int i3, boolean z) {
        str.getClass();
        return new ServiceInfo(str, i, j, i2, i3, z);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ServiceInfo)) {
            return false;
        }
        ServiceInfo serviceInfo = (ServiceInfo) obj;
        return ei2.m10070i(this.version, serviceInfo.version) && this.versionCode == serviceInfo.versionCode && this.startTimestamp == serviceInfo.startTimestamp && this.pid == serviceInfo.pid && this.uid == serviceInfo.uid && this.grantRuntime == serviceInfo.grantRuntime;
    }

    public final boolean getGrantRuntime() {
        return this.grantRuntime;
    }

    public final int getPid() {
        return this.pid;
    }

    public final long getStartTimestamp() {
        return this.startTimestamp;
    }

    public final int getUid() {
        return this.uid;
    }

    public final String getVersion() {
        return this.version;
    }

    public final int getVersionCode() {
        return this.versionCode;
    }

    public int hashCode() {
        return Boolean.hashCode(this.grantRuntime) + hn0.m12930c(this.uid, hn0.m12930c(this.pid, d63.m8795b(hn0.m12930c(this.versionCode, this.version.hashCode() * 31, 31), 31, this.startTimestamp), 31), 31);
    }

    public String toString() {
        String str = this.version;
        int i = this.versionCode;
        long j = this.startTimestamp;
        int i2 = this.pid;
        int i3 = this.uid;
        boolean z = this.grantRuntime;
        StringBuilder m23622o = yt0.m23622o(i, "ServiceInfo(version=", str, ", versionCode=", ", startTimestamp=");
        m23622o.append(j);
        m23622o.append(", pid=");
        m23622o.append(i2);
        m23622o.append(", uid=");
        m23622o.append(i3);
        m23622o.append(", grantRuntime=");
        m23622o.append(z);
        m23622o.append(")");
        return m23622o.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.getClass();
        parcel.writeString(this.version);
        parcel.writeInt(this.versionCode);
        parcel.writeLong(this.startTimestamp);
        parcel.writeInt(this.pid);
        parcel.writeInt(this.uid);
        parcel.writeInt(this.grantRuntime ? 1 : 0);
    }
}
