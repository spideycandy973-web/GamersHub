package frb.axeron.gyro;

import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import frb.axeron.base.FloatingFactoryBase;
import p000.at0;
import p000.bf1;
import p000.bz5;
import p000.ei2;
import p000.f52;
import p000.g52;
import p000.h52;
import p000.i85;
import p000.tm4;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class GyroCalibrationFeature extends FloatingFactoryBase implements h52 {

    /* renamed from: q */
    public View f14318q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14319r;

    /* renamed from: s */
    public final g52 f14320s = new g52();

    /* renamed from: t */
    public final i85 f14321t = new i85(new at0(this, 10));

    /* renamed from: I */
    public final void m11375I() {
        if (this.f14318q == null) {
            return;
        }
        g52 g52Var = this.f14320s;
        float m10488h = g52Var.f15291b.m10488h();
        int m20382b = (int) tm4.f37267a.m20382b(m11348p(), m10488h);
        WindowManager.LayoutParams layoutParams = this.f14319r;
        if (layoutParams == null) {
            ei2.m10039H("params");
            throw null;
        }
        layoutParams.width = m20382b;
        layoutParams.height = m20382b;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(bz5.m2074B(g52Var.m11829a()));
        View view = this.f14318q;
        if (view != null) {
            view.setBackground(gradientDrawable);
        } else {
            ei2.m10039H("view");
            throw null;
        }
    }

    @Override // p000.h52
    /* renamed from: d */
    public final void mo11376d(g52 g52Var) {
        float m10488h = g52Var.f15291b.m10488h();
        g52 g52Var2 = this.f14320s;
        g52Var2.f15291b.m10489i(m10488h);
        g52Var2.f15292c.m10489i(g52Var.f15292c.m10488h());
        g52Var2.m11830b(g52Var.m11829a());
        m11375I();
        View view = this.f14318q;
        if (view == null || view.getParent() == null) {
            return;
        }
        View view2 = this.f14318q;
        if (view2 == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams = this.f14319r;
        if (layoutParams != null) {
            updateViewLayout(view2, layoutParams);
        } else {
            ei2.m10039H("params");
            throw null;
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        if (bundle != null) {
            g52 g52Var = this.f14320s;
            g52Var.getClass();
            f52 f52Var = g52Var.f15290a;
            g52Var.f15291b.m10489i(bundle.getFloat("size", f52Var.f13288b));
            g52Var.f15292c.m10489i(bundle.getFloat("sensitivity", f52Var.f13289c));
            g52Var.m11830b(bz5.m2093c(bundle.getInt("color", f52Var.f13290d)));
        }
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 824, -3);
        layoutParams.gravity = 17;
        layoutParams.layoutInDisplayCutoutMode = 1;
        this.f14319r = layoutParams;
        this.f14318q = new View(m11348p());
        m11375I();
        View view = this.f14318q;
        if (view == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14319r;
        if (layoutParams2 == null) {
            ei2.m10039H("params");
            throw null;
        }
        addView(view, layoutParams2);
        bf1 bf1Var = (bf1) this.f14321t.getValue();
        Sensor sensor = bf1Var.f2374c;
        if (sensor != null) {
            bf1Var.f2373b.registerListener(bf1Var, sensor, 1);
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        View view;
        try {
            bf1 bf1Var = (bf1) this.f14321t.getValue();
            bf1Var.f2373b.unregisterListener(bf1Var);
            view = this.f14318q;
        } catch (Exception unused) {
            Log.w("GyroCalibration", "Already detached");
        }
        if (view == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(view);
        super.mo11334u();
    }
}
