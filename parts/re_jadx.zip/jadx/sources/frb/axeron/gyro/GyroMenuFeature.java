package frb.axeron.gyro;

import android.content.Context;
import android.os.Bundle;
import android.view.WindowManager;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import p000.ViewOnTouchListenerC1541sh;
import p000.di2;
import p000.ei2;
import p000.g52;
import p000.gm0;
import p000.h52;
import p000.i52;
import p000.i85;
import p000.it3;
import p000.k52;
import p000.l52;
import p000.m52;
import p000.v86;
import p000.z80;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class GyroMenuFeature extends FloatingFactoryBase implements h52 {

    /* renamed from: q */
    public zm5 f14322q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14323r;

    /* renamed from: s */
    public final i85 f14324s = new i85(new i52(this, 0));

    /* renamed from: t */
    public final g52 f14325t = new g52();

    /* renamed from: u */
    public final it3 f14326u = z80.m23867J(Boolean.FALSE);

    @Override // p000.h52
    /* renamed from: d */
    public final void mo11376d(g52 g52Var) {
        v86.m21284K(m11349q(), null, null, new m52(this, g52Var, null, (byte) 1), 3);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: l */
    public final void mo11344l(Context context) {
        super.mo11344l(context);
        v86.m21284K(m11349q(), null, null, new l52(this, null, (byte) 0), 3);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 262952, -3);
        if (m11348p().getResources().getConfiguration().orientation == 1) {
            layoutParams.gravity = 81;
            layoutParams.y = di2.m9248W(18, m11348p());
            layoutParams.windowAnimations = R.style.WAnim_InBottom_OutBottom;
        } else {
            layoutParams.gravity = 21;
            layoutParams.x = di2.m9248W(18, m11348p());
            layoutParams.windowAnimations = R.style.WAnim_InRight_OutRight;
        }
        this.f14323r = layoutParams;
        zm5 m11345m = m11345m(false, new gm0(31088372, true, new k52(this, (byte) 0)));
        this.f14322q = m11345m;
        m11345m.setOnTouchListener(new ViewOnTouchListenerC1541sh(this, (byte) 5));
        zm5 zm5Var = this.f14322q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14323r;
        if (layoutParams2 != null) {
            addView(zm5Var, layoutParams2);
        } else {
            ei2.m10039H("params");
            throw null;
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        zm5 zm5Var = this.f14322q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(zm5Var);
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: w */
    public final void mo11352w() {
        super.mo11352w();
        zm5 zm5Var = this.f14322q;
        if (zm5Var != null) {
            m11358D(zm5Var, null);
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: x */
    public final void mo11353x() {
        super.mo11353x();
        zm5 zm5Var = this.f14322q;
        if (zm5Var != null) {
            WindowManager.LayoutParams layoutParams = this.f14323r;
            if (layoutParams != null) {
                m11361H(zm5Var, layoutParams, null);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        }
    }
}
