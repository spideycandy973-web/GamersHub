package frb.axeron.crosshair;

import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ImageView;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import p000.di2;
import p000.ei2;
import p000.kn5;
import p000.ky0;
import p000.lx0;
import p000.px0;
import p000.qx0;
import p000.t75;
import p000.ur0;
import p000.wr0;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class CrosshairFeature extends FloatingFactoryBase implements qx0 {

    /* renamed from: q */
    public ImageView f14284q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14285r;

    /* renamed from: s */
    public final px0 f14286s = new px0();

    /* renamed from: I */
    public final void m11364I() {
        if (this.f14284q == null) {
            return;
        }
        float m9248W = di2.m9248W(165, m11348p());
        px0 px0Var = this.f14286s;
        float m10488h = px0Var.f31016c.m10488h() * m9248W;
        if (m10488h < 1.0f) {
            m10488h = 1.0f;
        }
        int i = (int) m10488h;
        WindowManager.LayoutParams layoutParams = this.f14285r;
        if (layoutParams == null) {
            ei2.m10039H("params");
            throw null;
        }
        layoutParams.width = i;
        layoutParams.height = i;
        ImageView imageView = this.f14284q;
        if (imageView == null) {
            ei2.m10039H("imageView");
            throw null;
        }
        imageView.setImageResource(px0Var.m17915b().f22558b);
        imageView.setColorFilter(Color.parseColor(px0Var.m17914a().f24971a));
        imageView.setScaleX(1.0f);
        imageView.setScaleY(1.0f);
        imageView.setAlpha(px0Var.f31017d.m10488h());
        imageView.setRotation(px0Var.f31018e.m10488h() * 360.0f);
    }

    /* renamed from: J */
    public final void m11365J() {
        WindowManager.LayoutParams layoutParams = this.f14285r;
        if (layoutParams == null) {
            ei2.m10039H("params");
            throw null;
        }
        px0 px0Var = this.f14286s;
        layoutParams.x = (int) px0Var.f31014a.m10488h();
        WindowManager.LayoutParams layoutParams2 = this.f14285r;
        if (layoutParams2 == null) {
            ei2.m10039H("params");
            throw null;
        }
        layoutParams2.y = (int) px0Var.f31015b.m10488h();
        ImageView imageView = this.f14284q;
        if (imageView == null || imageView.getParent() == null) {
            return;
        }
        ImageView imageView2 = this.f14284q;
        if (imageView2 == null) {
            ei2.m10039H("imageView");
            throw null;
        }
        WindowManager.LayoutParams layoutParams3 = this.f14285r;
        if (layoutParams3 != null) {
            updateViewLayout(imageView2, layoutParams3);
        } else {
            ei2.m10039H("params");
            throw null;
        }
    }

    @Override // p000.qx0
    /* renamed from: i */
    public final Object mo11366i(px0 px0Var, t75 t75Var) {
        float m10488h = px0Var.f31014a.m10488h();
        px0 px0Var2 = this.f14286s;
        px0Var2.f31014a.m10489i(m10488h);
        px0Var2.f31015b.m10489i(px0Var.f31015b.m10488h());
        px0Var2.f31016c.m10489i(px0Var.f31016c.m10488h());
        px0Var2.f31017d.m10489i(px0Var.f31017d.m10488h());
        px0Var2.f31018e.m10489i(px0Var.f31018e.m10488h());
        ky0 m17915b = px0Var.m17915b();
        m17915b.getClass();
        px0Var2.f31019f.setValue(m17915b);
        lx0 m17914a = px0Var.m17914a();
        m17914a.getClass();
        px0Var2.f31020g.setValue(m17914a);
        m11364I();
        m11365J();
        return kn5.f22076a;
    }

    @Override // frb.axeron.base.FloatingFactoryBase, frb.axeron.base.FeatureFactoryBase
    /* renamed from: s */
    public final void mo11351s(Configuration configuration) {
        configuration.getClass();
        super.mo11351s(configuration);
        m11364I();
        m11365J();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        if (bundle != null) {
            float f = bundle.getFloat("x", 0.0f);
            float f2 = bundle.getFloat("y", 0.0f);
            float f3 = bundle.getFloat("size", 0.2f);
            float f4 = bundle.getFloat("opacity", 1.0f);
            float f5 = bundle.getFloat("rotation", 0.0f);
            int i = bundle.getInt("style", 0);
            int i2 = bundle.getInt("color", 0);
            px0 px0Var = this.f14286s;
            px0Var.getClass();
            px0Var.f31014a.m10489i(f);
            px0Var.f31015b.m10489i(f2);
            px0Var.f31016c.m10489i(f3);
            px0Var.f31017d.m10489i(f4);
            px0Var.f31018e.m10489i(f5);
            ky0.f22553c.getClass();
            px0Var.f31019f.setValue(ur0.m21021g(i));
            lx0.f24967b.getClass();
            lx0 m22350t = wr0.m22350t(i2);
            m22350t.getClass();
            px0Var.f31020g.setValue(m22350t);
        }
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 792, -3);
        layoutParams.gravity = 17;
        layoutParams.windowAnimations = R.style.WAnim_Fade;
        layoutParams.layoutInDisplayCutoutMode = 1;
        this.f14285r = layoutParams;
        int m9248W = di2.m9248W(165, m11348p());
        WindowManager.LayoutParams layoutParams2 = this.f14285r;
        if (layoutParams2 == null) {
            ei2.m10039H("params");
            throw null;
        }
        layoutParams2.width = m9248W;
        layoutParams2.height = m9248W;
        this.f14284q = new ImageView(m11348p());
        m11364I();
        ImageView imageView = this.f14284q;
        if (imageView == null) {
            ei2.m10039H("imageView");
            throw null;
        }
        WindowManager.LayoutParams layoutParams3 = this.f14285r;
        if (layoutParams3 == null) {
            ei2.m10039H("params");
            throw null;
        }
        addView(imageView, layoutParams3);
        m11365J();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        ImageView imageView = this.f14284q;
        if (imageView == null) {
            ei2.m10039H("imageView");
            throw null;
        }
        m11357C(imageView);
        super.mo11334u();
    }
}
