package frb.axeron.crosshair;

import android.graphics.drawable.Icon;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import p000.C0122cl;
import p000.at0;
import p000.bo1;
import p000.fn5;
import p000.hv3;
import p000.i80;
import p000.i85;
import p000.j03;
import p000.ka1;
import p000.ls0;
import p000.m35;
import p000.ns0;
import p000.o65;
import p000.qp7;
import p000.r41;
import p000.v86;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class CrosshairTileService extends TileService {

    /* renamed from: i */
    public static final /* synthetic */ int f14292i = 0;

    /* renamed from: a */
    public final o65 f14293a;

    /* renamed from: b */
    public final ls0 f14294b;

    /* renamed from: c */
    public final i85 f14295c;

    /* renamed from: d */
    public final bo1 f14296d;

    /* renamed from: e */
    public final hv3 f14297e;

    /* renamed from: f */
    public boolean f14298f;

    /* renamed from: g */
    public m35 f14299g;

    /* renamed from: h */
    public boolean f14300h;

    public CrosshairTileService() {
        o65 m18391b = qp7.m18391b();
        this.f14293a = m18391b;
        r41 r41Var = ka1.f21425a;
        this.f14294b = fn5.m11125b(j03.f19481a.plus(m18391b));
        this.f14295c = new i85(new at0(this, (byte) 2));
        this.f14296d = new bo1(this);
        this.f14297e = new hv3(this);
    }

    /* renamed from: a */
    public final void m11367a() {
        Tile qsTile = getQsTile();
        if (qsTile != null) {
            qsTile.setIcon((Icon) this.f14295c.getValue());
            qsTile.setState(this.f14298f ? 2 : 1);
            qsTile.setLabel("Crosshair");
            qsTile.updateTile();
        }
    }

    /* renamed from: b */
    public final void m11368b() {
        this.f14293a.mo1322a(null);
        super.onDestroy();
    }

    @Override // android.service.quicksettings.TileService
    public final void onClick() {
        if (this.f14300h) {
            return;
        }
        this.f14300h = true;
        v86.m21284K(this.f14294b, null, null, new i80(this, null, (byte) 2), 3);
    }

    @Override // android.service.quicksettings.TileService, android.app.Service
    public final void onDestroy() {
        this.f14296d.m1874b();
        m11368b();
    }

    @Override // android.service.quicksettings.TileService
    public final void onStartListening() {
        super.onStartListening();
        this.f14296d.m1873a();
        m35 m35Var = this.f14299g;
        ns0 ns0Var = null;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        this.f14299g = v86.m21284K(this.f14294b, null, null, new C0122cl((Object) this, ns0Var, (byte) 6), 3);
    }

    @Override // android.service.quicksettings.TileService
    public final void onStopListening() {
        m35 m35Var = this.f14299g;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        this.f14299g = null;
        super.onStopListening();
    }

    @Override // android.service.quicksettings.TileService
    public final void onTileAdded() {
        super.onTileAdded();
        m11367a();
    }
}
