package frb.axeron.activation;

import android.util.Log;
import com.android.org.conscrypt.Conscrypt;
import com.applovin.shadow.okio.Segment;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import p000.AbstractC0946ew;
import p000.C0009a8;
import p000.C0950f;
import p000.C1738x7;
import p000.C1816z4;
import p000.EnumC1178j8;
import p000.ei2;
import p000.fs3;
import p000.hg0;
import p000.vu3;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: frb.axeron.activation.a */
/* loaded from: classes2.dex */
public final class C0980a implements Closeable {

    /* renamed from: a */
    public final String f14233a;

    /* renamed from: b */
    public final int f14234b;

    /* renamed from: c */
    public final String f14235c;

    /* renamed from: d */
    public final C0009a8 f14236d;

    /* renamed from: e */
    public Socket f14237e;

    /* renamed from: f */
    public DataInputStream f14238f;

    /* renamed from: g */
    public DataOutputStream f14239g;

    /* renamed from: h */
    public final vu3 f14240h;

    /* renamed from: i */
    public PairingContext f14241i;

    /* renamed from: j */
    public EnumC1178j8 f14242j;

    public C0980a(String str, int i, String str2, C0009a8 c0009a8) {
        str.getClass();
        str2.getClass();
        this.f14233a = str;
        this.f14234b = i;
        this.f14235c = str2;
        this.f14236d = c0009a8;
        this.f14240h = new vu3((byte[]) c0009a8.f295e.getValue(), (byte) 0);
        this.f14242j = EnumC1178j8.f19798a;
    }

    /* renamed from: a */
    public final fs3 m11321a() {
        byte[] bArr = new byte[6];
        DataInputStream dataInputStream = this.f14238f;
        if (dataInputStream == null) {
            ei2.m10039H("inputStream");
            throw null;
        }
        dataInputStream.readFully(bArr);
        ByteBuffer order = ByteBuffer.wrap(bArr).order(ByteOrder.BIG_ENDIAN);
        order.getClass();
        byte b = order.get();
        byte b2 = order.get();
        int i = order.getInt();
        if (b < 1 || b > 1) {
            Log.e("AdbPairClient", "PairingPacketHeader version mismatch (us=1 them=" + ((int) b) + ")");
            return null;
        }
        if (b2 != 0 && b2 != 1) {
            Log.e("AdbPairClient", "Unknown PairingPacket type=" + ((int) b2));
            return null;
        }
        if (i > 0 && i <= 16384) {
            return new fs3(b, b2, i);
        }
        Log.e("AdbPairClient", "header payload not within a safe payload size (size=" + i + ")");
        return null;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        PairingContext pairingContext;
        Socket socket;
        DataOutputStream dataOutputStream;
        DataInputStream dataInputStream;
        try {
            dataInputStream = this.f14238f;
        } catch (Throwable unused) {
        }
        if (dataInputStream == null) {
            ei2.m10039H("inputStream");
            throw null;
        }
        dataInputStream.close();
        try {
            dataOutputStream = this.f14239g;
        } catch (Throwable unused2) {
        }
        if (dataOutputStream == null) {
            ei2.m10039H("outputStream");
            throw null;
        }
        dataOutputStream.close();
        try {
            socket = this.f14237e;
        } catch (Exception unused3) {
        }
        if (socket == null) {
            ei2.m10039H("socket");
            throw null;
        }
        socket.close();
        if (this.f14242j == EnumC1178j8.f19798a || (pairingContext = this.f14241i) == null) {
            return;
        }
        pairingContext.m11318c();
    }

    /* renamed from: f */
    public final void m11322f() {
        long nativeConstructor;
        C1816z4 c1816z4 = C1816z4.f46500a;
        C1816z4.m23802s();
        String str = this.f14233a;
        int i = this.f14234b;
        Socket socket = new Socket(str, i);
        socket.setTcpNoDelay(true);
        this.f14237e = socket;
        Object value = this.f14236d.f296f.getValue();
        value.getClass();
        Socket createSocket = ((SSLContext) value).getSocketFactory().createSocket(socket, str, i, true);
        createSocket.getClass();
        SSLSocket sSLSocket = (SSLSocket) createSocket;
        sSLSocket.startHandshake();
        this.f14238f = new DataInputStream(sSLSocket.getInputStream());
        this.f14239g = new DataOutputStream(sSLSocket.getOutputStream());
        byte[] bytes = this.f14235c.getBytes(hg0.f17140a);
        bytes.getClass();
        byte[] exportKeyingMaterial = Conscrypt.exportKeyingMaterial(sSLSocket, "adb-label\u0000", (byte[]) null, 64);
        byte[] bArr = new byte[bytes.length + exportKeyingMaterial.length];
        AbstractC0946ew.m10529K0(bytes, bArr, 0, 0, 0, 14);
        AbstractC0946ew.m10529K0(exportKeyingMaterial, bArr, bytes.length, 0, 0, 12);
        nativeConstructor = PairingContext.nativeConstructor(true, bArr);
        PairingContext pairingContext = nativeConstructor != 0 ? new PairingContext(nativeConstructor) : null;
        if (pairingContext != null) {
            this.f14241i = pairingContext;
        } else {
            C0950f.m10585p("Unable to create PairingContext.");
        }
    }

    /* renamed from: g */
    public final boolean m11323g() {
        boolean z;
        m11322f();
        this.f14242j = EnumC1178j8.f19799b;
        PairingContext pairingContext = this.f14241i;
        if (pairingContext == null) {
            ei2.m10039H("pairingContext");
            throw null;
        }
        byte[] bArr = pairingContext.f14232b;
        int length = bArr.length;
        ByteBuffer allocate = ByteBuffer.allocate(6);
        ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
        ByteBuffer order = allocate.order(byteOrder);
        order.getClass();
        order.put((byte) 1);
        order.put((byte) 0);
        order.putInt(length);
        DataOutputStream dataOutputStream = this.f14239g;
        if (dataOutputStream == null) {
            ei2.m10039H("outputStream");
            throw null;
        }
        dataOutputStream.write(order.array());
        DataOutputStream dataOutputStream2 = this.f14239g;
        if (dataOutputStream2 == null) {
            ei2.m10039H("outputStream");
            throw null;
        }
        dataOutputStream2.write(bArr);
        fs3 m11321a = m11321a();
        if (m11321a == null || m11321a.f14453b != 0) {
            z = false;
        } else {
            byte[] bArr2 = new byte[m11321a.f14454c];
            DataInputStream dataInputStream = this.f14238f;
            if (dataInputStream == null) {
                ei2.m10039H("inputStream");
                throw null;
            }
            dataInputStream.readFully(bArr2);
            PairingContext pairingContext2 = this.f14241i;
            if (pairingContext2 == null) {
                ei2.m10039H("pairingContext");
                throw null;
            }
            z = pairingContext2.m11320e(bArr2);
        }
        EnumC1178j8 enumC1178j8 = EnumC1178j8.f19801d;
        if (!z) {
            this.f14242j = enumC1178j8;
            return false;
        }
        this.f14242j = EnumC1178j8.f19800c;
        ByteBuffer order2 = ByteBuffer.allocate(Segment.SIZE).order(byteOrder);
        order2.getClass();
        vu3 vu3Var = this.f14240h;
        order2.put(vu3Var.f41136b);
        order2.put((byte[]) vu3Var.f41137c);
        PairingContext pairingContext3 = this.f14241i;
        if (pairingContext3 == null) {
            ei2.m10039H("pairingContext");
            throw null;
        }
        byte[] array = order2.array();
        array.getClass();
        byte[] m11319d = pairingContext3.m11319d(array);
        if (m11319d != null) {
            int length2 = m11319d.length;
            ByteBuffer order3 = ByteBuffer.allocate(6).order(byteOrder);
            order3.getClass();
            order3.put((byte) 1);
            order3.put((byte) 1);
            order3.putInt(length2);
            DataOutputStream dataOutputStream3 = this.f14239g;
            if (dataOutputStream3 == null) {
                ei2.m10039H("outputStream");
                throw null;
            }
            dataOutputStream3.write(order3.array());
            DataOutputStream dataOutputStream4 = this.f14239g;
            if (dataOutputStream4 == null) {
                ei2.m10039H("outputStream");
                throw null;
            }
            dataOutputStream4.write(m11319d);
            fs3 m11321a2 = m11321a();
            if (m11321a2 != null && m11321a2.f14453b == 1) {
                byte[] bArr3 = new byte[m11321a2.f14454c];
                DataInputStream dataInputStream2 = this.f14238f;
                if (dataInputStream2 == null) {
                    ei2.m10039H("inputStream");
                    throw null;
                }
                dataInputStream2.readFully(bArr3);
                PairingContext pairingContext4 = this.f14241i;
                if (pairingContext4 == null) {
                    ei2.m10039H("pairingContext");
                    throw null;
                }
                byte[] m11317b = pairingContext4.m11317b(bArr3);
                if (m11317b == null) {
                    throw new C1738x7((byte) 0);
                }
                if (m11317b.length == 8192) {
                    ByteBuffer wrap = ByteBuffer.wrap(m11317b);
                    wrap.getClass();
                    wrap.get();
                    byte[] bArr4 = new byte[8191];
                    wrap.get(bArr4);
                    AbstractC0946ew.m10525G0(bArr4, 0, new byte[8191], 0, 8191);
                    this.f14242j = enumC1178j8;
                    return true;
                }
                Log.e("AdbPairClient", "Got size=" + m11317b.length + " PeerInfo.size=8192");
            }
        }
        this.f14242j = enumC1178j8;
        return false;
    }
}
