package frb.axeron.activation;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
final class PairingContext {

    /* renamed from: a */
    public final long f14231a;

    /* renamed from: b */
    public final byte[] f14232b;

    static {
        System.loadLibrary("axeron_adb");
    }

    public PairingContext(long j) {
        this.f14231a = j;
        this.f14232b = nativeMsg(j);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final native long nativeConstructor(boolean z, byte[] bArr);

    private final native byte[] nativeDecrypt(long j, byte[] bArr);

    private final native void nativeDestroy(long j);

    private final native byte[] nativeEncrypt(long j, byte[] bArr);

    private final native boolean nativeInitCipher(long j, byte[] bArr);

    private final native byte[] nativeMsg(long j);

    /* renamed from: b */
    public final byte[] m11317b(byte[] bArr) {
        return nativeDecrypt(this.f14231a, bArr);
    }

    /* renamed from: c */
    public final void m11318c() {
        nativeDestroy(this.f14231a);
    }

    /* renamed from: d */
    public final byte[] m11319d(byte[] bArr) {
        return nativeEncrypt(this.f14231a, bArr);
    }

    /* renamed from: e */
    public final boolean m11320e(byte[] bArr) {
        return nativeInitCipher(this.f14231a, bArr);
    }
}
