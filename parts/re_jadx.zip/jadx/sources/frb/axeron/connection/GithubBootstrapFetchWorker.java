package frb.axeron.connection;

import android.content.Context;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class GithubBootstrapFetchWorker extends CoroutineWorker {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public GithubBootstrapFetchWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        context.getClass();
        workerParameters.getClass();
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0063 A[Catch: Exception -> 0x0085, LOOP:0: B:12:0x005d->B:14:0x0063, LOOP_END, TryCatch #0 {Exception -> 0x0085, blocks: (B:10:0x0023, B:11:0x0045, B:12:0x005d, B:14:0x0063, B:16:0x0080, B:23:0x0031), top: B:7:0x001f }] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x002e  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0021  */
    @Override // androidx.work.CoroutineWorker
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object doWork(p000.ns0 r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof p000.a22
            if (r0 == 0) goto L13
            r0 = r6
            a22 r0 = (p000.a22) r0
            int r1 = r0.f100c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f100c = r1
            goto L1a
        L13:
            a22 r0 = new a22
            os0 r6 = (p000.os0) r6
            r0.<init>(r5, r6)
        L1a:
            java.lang.Object r6 = r0.f98a
            int r1 = r0.f100c
            r2 = 1
            if (r1 == 0) goto L2e
            if (r1 != r2) goto L27
            p000.v86.m21297X(r6)     // Catch: java.lang.Exception -> L85
            goto L45
        L27:
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r5)
            r5 = 0
            return r5
        L2e:
            p000.v86.m21297X(r6)
            d22 r6 = p000.d22.f9634a     // Catch: java.lang.Exception -> L85
            android.content.Context r1 = r5.getApplicationContext()     // Catch: java.lang.Exception -> L85
            r1.getClass()     // Catch: java.lang.Exception -> L85
            r0.f100c = r2     // Catch: java.lang.Exception -> L85
            java.lang.Object r6 = r6.m8630a(r1, r0)     // Catch: java.lang.Exception -> L85
            nu0 r0 = p000.nu0.f28013a
            if (r6 != r0) goto L45
            return r0
        L45:
            i11 r6 = (p000.i11) r6     // Catch: java.lang.Exception -> L85
            d22 r0 = p000.d22.f9634a     // Catch: java.lang.Exception -> L85
            android.content.Context r5 = r5.getApplicationContext()     // Catch: java.lang.Exception -> L85
            r5.getClass()     // Catch: java.lang.Exception -> L85
            zy5 r5 = p000.zy5.m24414b(r5)     // Catch: java.lang.Exception -> L85
            r6.getClass()     // Catch: java.lang.Exception -> L85
            java.util.List r0 = p000.d22.f9635b     // Catch: java.lang.Exception -> L85
            java.util.Iterator r0 = r0.iterator()     // Catch: java.lang.Exception -> L85
        L5d:
            boolean r1 = r0.hasNext()     // Catch: java.lang.Exception -> L85
            if (r1 == 0) goto L80
            java.lang.Object r1 = r0.next()     // Catch: java.lang.Exception -> L85
            u32 r1 = (p000.u32) r1     // Catch: java.lang.Exception -> L85
            java.lang.String r2 = r1.m20644c()     // Catch: java.lang.Exception -> L85
            el1 r3 = p000.el1.f12013a     // Catch: java.lang.Exception -> L85
            ym3 r1 = r1.m20642a(r6)     // Catch: java.lang.Exception -> L85
            java.util.List r1 = p000.jj0.m14030C(r1)     // Catch: java.lang.Exception -> L85
            py5 r4 = new py5     // Catch: java.lang.Exception -> L85
            r4.<init>(r5, r2, r3, r1)     // Catch: java.lang.Exception -> L85
            r4.m17952a()     // Catch: java.lang.Exception -> L85
            goto L5d
        L80:
            hw2 r5 = p000.iw2.m13658a()     // Catch: java.lang.Exception -> L85
            return r5
        L85:
            gw2 r5 = new gw2
            r5.<init>()
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.connection.GithubBootstrapFetchWorker.doWork(ns0):java.lang.Object");
    }
}
