package frb.axeron.connection;

import android.app.job.JobScheduler;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import java.util.List;
import p000.ci1;
import p000.fv8;
import p000.kn5;
import p000.md4;
import p000.wp0;
import p000.xd2;
import p000.zy5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class SafeWorkManagerInitializer implements xd2 {
    @Override // p000.xd2
    public final Object create(Context context) {
        Object md4Var;
        context.getClass();
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                md4Var = JobScheduler.class.getMethod("forNamespace", String.class);
            } catch (Throwable th) {
                md4Var = new md4(th);
            }
            if (md4Var instanceof md4) {
                Log.w("SafeWorkManager", "JobScheduler.forNamespace missing on SDK " + Build.VERSION.SDK_INT + ", WorkManager disabled");
                return kn5.f22076a;
            }
        }
        zy5.m24415c(context, new wp0(new fv8((byte) 29)));
        return kn5.f22076a;
    }

    @Override // p000.xd2
    public final List dependencies() {
        return ci1.f4141a;
    }
}
