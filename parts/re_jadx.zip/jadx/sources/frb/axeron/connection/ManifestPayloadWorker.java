package frb.axeron.connection;

import android.content.Context;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ManifestPayloadWorker extends CoroutineWorker {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ManifestPayloadWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        context.getClass();
        workerParameters.getClass();
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0054 A[Catch: Exception -> 0x005f, TryCatch #0 {Exception -> 0x005f, blocks: (B:10:0x0023, B:11:0x004c, B:13:0x0054, B:16:0x0059, B:21:0x0031), top: B:7:0x001f }] */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0059 A[Catch: Exception -> 0x005f, TRY_LEAVE, TryCatch #0 {Exception -> 0x005f, blocks: (B:10:0x0023, B:11:0x004c, B:13:0x0054, B:16:0x0059, B:21:0x0031), top: B:7:0x001f }] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x002e  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0021  */
    @Override // androidx.work.CoroutineWorker
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object doWork(p000.ns0 r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof p000.a13
            if (r0 == 0) goto L13
            r0 = r5
            a13 r0 = (p000.a13) r0
            int r1 = r0.f64c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f64c = r1
            goto L1a
        L13:
            a13 r0 = new a13
            os0 r5 = (p000.os0) r5
            r0.<init>(r4, r5)
        L1a:
            java.lang.Object r5 = r0.f62a
            int r1 = r0.f64c
            r2 = 1
            if (r1 == 0) goto L2e
            if (r1 != r2) goto L27
            p000.v86.m21297X(r5)     // Catch: java.lang.Exception -> L5f
            goto L4c
        L27:
            java.lang.String r4 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r4)
            r4 = 0
            return r4
        L2e:
            p000.v86.m21297X(r5)
            u32 r5 = p000.u32.f38172c     // Catch: java.lang.Exception -> L5f
            android.content.Context r1 = r4.getApplicationContext()     // Catch: java.lang.Exception -> L5f
            r1.getClass()     // Catch: java.lang.Exception -> L5f
            i11 r4 = r4.getInputData()     // Catch: java.lang.Exception -> L5f
            r4.getClass()     // Catch: java.lang.Exception -> L5f
            r0.f64c = r2     // Catch: java.lang.Exception -> L5f
            java.lang.Object r5 = r5.m20643b(r1, r4, r0)     // Catch: java.lang.Exception -> L5f
            nu0 r4 = p000.nu0.f28013a
            if (r5 != r4) goto L4c
            return r4
        L4c:
            java.lang.Boolean r5 = (java.lang.Boolean) r5     // Catch: java.lang.Exception -> L5f
            boolean r4 = r5.booleanValue()     // Catch: java.lang.Exception -> L5f
            if (r4 == 0) goto L59
            hw2 r4 = p000.iw2.m13658a()     // Catch: java.lang.Exception -> L5f
            return r4
        L59:
            fw2 r4 = new fw2     // Catch: java.lang.Exception -> L5f
            r4.<init>()     // Catch: java.lang.Exception -> L5f
            return r4
        L5f:
            gw2 r4 = new gw2
            r4.<init>()
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.connection.ManifestPayloadWorker.doWork(ns0):java.lang.Object");
    }
}
