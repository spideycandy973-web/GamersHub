package frb.axeron.base;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import frb.axeron.panel.component.ScreenshotFeature;
import frb.axeron.redcorner.R;
import frb.axeron.service.FeatureService;
import java.util.Iterator;
import p000.AbstractC0871d6;
import p000.C1576tc;
import p000.a45;
import p000.au2;
import p000.b45;
import p000.bn1;
import p000.cc1;
import p000.d33;
import p000.ei2;
import p000.gm0;
import p000.it5;
import p000.jq5;
import p000.jt5;
import p000.la2;
import p000.lj2;
import p000.lu2;
import p000.ns0;
import p000.nz1;
import p000.os0;
import p000.ou2;
import p000.oua;
import p000.sp3;
import p000.t75;
import p000.ti4;
import p000.tn0;
import p000.ui4;
import p000.v74;
import p000.vi4;
import p000.vt2;
import p000.wi4;
import p000.wi7;
import p000.wr0;
import p000.xt2;
import p000.y35;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public abstract class FeatureFactoryBase implements la2, lu2, wi4, jt5 {

    /* renamed from: a */
    public Context f14254a;

    /* renamed from: b */
    public FeatureService f14255b;

    /* renamed from: c */
    public final ui4 f14256c = new ui4(new vi4(this, new sp3(this, 14)));

    /* renamed from: d */
    public final wi7 f14257d = new wi7(this);

    /* renamed from: e */
    public final a45 f14258e;

    /* renamed from: f */
    public final v74 f14259f;

    /* renamed from: g */
    public final a45 f14260g;

    /* renamed from: h */
    public final v74 f14261h;

    /* renamed from: i */
    public final it5 f14262i;

    /* renamed from: j */
    public bn1 f14263j;

    public FeatureFactoryBase() {
        a45 m1397a = b45.m1397a(vt2.ON_ANY);
        this.f14258e = m1397a;
        this.f14259f = cc1.m2438m(m1397a);
        a45 m1397a2 = b45.m1397a(new Configuration());
        this.f14260g = m1397a2;
        this.f14261h = cc1.m2438m(m1397a2);
        this.f14262i = new it5();
    }

    /* renamed from: A */
    public final void m11342A() {
        if (((a45) this.f14259f.f39911a).getValue() == vt2.ON_RESUME) {
            return;
        }
        m11347o(vt2.ON_START);
        mo11353x();
    }

    /* renamed from: B */
    public final void m11343B(int i, boolean z) {
        bn1 bn1Var = this.f14263j;
        if (bn1Var == null) {
            ei2.m10039H("handler");
            throw null;
        }
        d33 d33Var = bn1Var.f2708b;
        if (d33Var == null) {
            ei2.m10039H("onForegroundTypeUpdate");
            throw null;
        }
        FeatureService featureService = (FeatureService) d33Var.f9722b;
        FeatureService featureService2 = FeatureService.f14430h;
        featureService.m11517l(32, z);
    }

    @Override // p000.la2
    /* renamed from: a */
    public final Object mo1846a(Class cls, ns0 ns0Var) {
        bn1 bn1Var = this.f14263j;
        if (bn1Var != null) {
            return bn1Var.mo1846a(ScreenshotFeature.class, ns0Var);
        }
        ei2.m10039H("handler");
        throw null;
    }

    @Override // p000.la2
    /* renamed from: c */
    public final Object mo1848c(Class cls, Bundle bundle, os0 os0Var) {
        bn1 bn1Var = this.f14263j;
        if (bn1Var != null) {
            return bn1Var.mo1848c(cls, bundle, os0Var);
        }
        ei2.m10039H("handler");
        throw null;
    }

    @Override // p000.la2
    /* renamed from: f */
    public final Object mo1850f(Class cls, os0 os0Var) {
        m11354y();
        bn1 bn1Var = this.f14263j;
        if (bn1Var != null) {
            return bn1Var.mo1850f(cls, os0Var);
        }
        ei2.m10039H("handler");
        throw null;
    }

    @Override // p000.ma2
    /* renamed from: g */
    public final y35 mo409g() {
        bn1 bn1Var = this.f14263j;
        if (bn1Var != null) {
            return bn1Var.f2713g;
        }
        ei2.m10039H("handler");
        throw null;
    }

    @Override // p000.lu2
    public final xt2 getLifecycle() {
        return (ou2) this.f14257d.f42151b;
    }

    @Override // p000.wi4
    public final ti4 getSavedStateRegistry() {
        return this.f14256c.f38718b;
    }

    @Override // p000.jt5
    public final it5 getViewModelStore() {
        return this.f14262i;
    }

    @Override // p000.ma2
    /* renamed from: h */
    public final Object mo410h(Class cls, Class cls2, nz1 nz1Var, t75 t75Var) {
        bn1 bn1Var = this.f14263j;
        if (bn1Var != null) {
            return bn1Var.mo410h(cls, cls2, nz1Var, t75Var);
        }
        ei2.m10039H("handler");
        throw null;
    }

    @Override // p000.la2
    /* renamed from: j */
    public final Object mo1852j(Class cls, ns0 ns0Var) {
        m11354y();
        bn1 bn1Var = this.f14263j;
        if (bn1Var != null) {
            return bn1Var.mo1852j(cls, ns0Var);
        }
        ei2.m10039H("handler");
        throw null;
    }

    @Override // p000.ma2
    /* renamed from: k */
    public final FeatureFactoryBase mo411k(Class cls) {
        bn1 bn1Var = this.f14263j;
        if (bn1Var != null) {
            return bn1Var.mo411k(cls);
        }
        ei2.m10039H("handler");
        throw null;
    }

    /* renamed from: l */
    public void mo11344l(Context context) {
        this.f14255b = (FeatureService) context;
        this.f14254a = context;
        Configuration configuration = new Configuration(context.getResources().getConfiguration());
        a45 a45Var = this.f14260g;
        a45Var.getClass();
        a45Var.m94l(null, configuration);
        this.f14256c.m20853a();
    }

    /* renamed from: m */
    public final zm5 m11345m(boolean z, gm0 gm0Var) {
        tn0 tn0Var = new tn0(m11348p());
        tn0Var.setTag(R.id.view_tree_lifecycle_owner, this);
        tn0Var.setTag(R.id.view_tree_saved_state_registry_owner, this);
        tn0Var.setTag(R.id.view_tree_view_model_store_owner, this);
        tn0Var.setViewCompositionStrategy(new wr0(jq5.f20569f));
        tn0Var.setContent(new gm0(-673054163, true, new C1576tc(this, gm0Var, (byte) 27)));
        zm5 zm5Var = new zm5(m11348p(), z);
        zm5Var.setTag(R.id.view_tree_lifecycle_owner, this);
        zm5Var.setTag(R.id.view_tree_saved_state_registry_owner, this);
        zm5Var.setTag(R.id.view_tree_view_model_store_owner, this);
        zm5Var.addView(tn0Var);
        return zm5Var;
    }

    /* renamed from: n */
    public final void m11346n() {
        if (((a45) this.f14259f.f39911a).getValue() == vt2.ON_DESTROY) {
            return;
        }
        try {
            m11354y();
            lj2 lj2Var = (lj2) m11349q().f1469b.get(oua.f29419r);
            if (lj2Var != null) {
                Iterator it = lj2Var.mo15340m().iterator();
                while (it.hasNext()) {
                    ((lj2) it.next()).mo1322a(null);
                }
            }
            mo11334u();
        } catch (Exception unused) {
            Log.w("FeatureFactory", "[" + getClass().getSimpleName() + "] destroy failed!");
        }
    }

    /* renamed from: o */
    public final void m11347o(vt2 vt2Var) {
        this.f14258e.m93k(vt2Var);
        this.f14257d.m22095i(vt2Var);
    }

    /* renamed from: p */
    public final Context m11348p() {
        Context context = this.f14254a;
        if (context != null) {
            return context;
        }
        ei2.m10039H("context");
        throw null;
    }

    /* renamed from: q */
    public final au2 m11349q() {
        return AbstractC0871d6.m8786v((ou2) this.f14257d.f42151b);
    }

    /* renamed from: r */
    public final Object m11350r(ns0 ns0Var) {
        return ((a45) this.f14259f.f39911a).getValue() == vt2.ON_DESTROY ? Boolean.FALSE : mo1852j(getClass(), ns0Var);
    }

    /* renamed from: s */
    public void mo11351s(Configuration configuration) {
        configuration.getClass();
        FeatureService featureService = this.f14255b;
        if (featureService == null) {
            ei2.m10039H("baseContext");
            throw null;
        }
        Context createConfigurationContext = featureService.createConfigurationContext(configuration);
        createConfigurationContext.getClass();
        this.f14254a = createConfigurationContext;
        Configuration configuration2 = new Configuration(configuration);
        a45 a45Var = this.f14260g;
        a45Var.getClass();
        a45Var.m94l(null, configuration2);
    }

    /* renamed from: t */
    public void mo11333t(Bundle bundle) {
        this.f14256c.m20854b(bundle);
        m11347o(vt2.ON_CREATE);
    }

    /* renamed from: u */
    public void mo11334u() {
        m11347o(vt2.ON_DESTROY);
        this.f14257d.m22091b();
        this.f14262i.m13619a();
    }

    /* renamed from: w */
    public void mo11352w() {
        m11347o(vt2.ON_PAUSE);
    }

    /* renamed from: x */
    public void mo11353x() {
        m11347o(vt2.ON_RESUME);
    }

    /* renamed from: y */
    public final void m11354y() {
        Object value = ((a45) this.f14259f.f39911a).getValue();
        vt2 vt2Var = vt2.ON_STOP;
        if (value == vt2Var) {
            return;
        }
        mo11352w();
        m11347o(vt2Var);
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x002e  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
    /* renamed from: z */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11355z(p000.os0 r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof p000.qm1
            if (r0 == 0) goto L13
            r0 = r5
            qm1 r0 = (p000.qm1) r0
            int r1 = r0.f32183c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f32183c = r1
            goto L18
        L13:
            qm1 r0 = new qm1
            r0.<init>(r4, r5)
        L18:
            java.lang.Object r5 = r0.f32181a
            int r1 = r0.f32183c
            kn5 r2 = p000.kn5.f22076a
            r3 = 1
            if (r1 == 0) goto L2e
            if (r1 != r3) goto L27
            p000.v86.m21297X(r5)
            return r2
        L27:
            java.lang.String r4 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r4)
            r4 = 0
            return r4
        L2e:
            p000.v86.m21297X(r5)
            v74 r5 = r4.f14259f
            ff3 r5 = r5.f39911a
            a45 r5 = (p000.a45) r5
            java.lang.Object r5 = r5.getValue()
            vt2 r1 = p000.vt2.ON_DESTROY
            if (r5 == r1) goto L4e
            java.lang.Class r5 = r4.getClass()
            r0.f32183c = r3
            java.lang.Object r4 = r4.mo1850f(r5, r0)
            nu0 r5 = p000.nu0.f28013a
            if (r4 != r5) goto L4e
            return r5
        L4e:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.base.FeatureFactoryBase.m11355z(os0):java.lang.Object");
    }

    /* renamed from: v */
    public void mo11335v(Bundle bundle) {
    }
}
