package frb.axeron.base;

import android.app.ActivityManager;
import android.content.res.Configuration;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import java.util.Iterator;
import java.util.LinkedHashSet;
import p000.AbstractC0952f1;
import p000.au2;
import p000.aw2;
import p000.cl5;
import p000.i80;
import p000.i85;
import p000.ij0;
import p000.j03;
import p000.ka1;
import p000.kn5;
import p000.m35;
import p000.md4;
import p000.mf1;
import p000.nd4;
import p000.ns0;
import p000.qf1;
import p000.r41;
import p000.sz2;
import p000.ur0;
import p000.v86;
import p000.xy1;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public abstract class FloatingFactoryBase extends FeatureFactoryBase implements WindowManager {

    /* renamed from: p */
    public static volatile aw2 f14264p;

    /* renamed from: k */
    public final i85 f14265k;

    /* renamed from: l */
    public final LinkedHashSet f14266l = new LinkedHashSet();

    /* renamed from: m */
    public final LinkedHashSet f14267m = new LinkedHashSet();

    /* renamed from: n */
    public final i85 f14268n;

    /* renamed from: o */
    public m35 f14269o;

    public FloatingFactoryBase() {
        final byte b = 0;
        this.f14265k = new i85(new xy1(this) { // from class: yr1

            /* renamed from: b */
            public final /* synthetic */ FloatingFactoryBase f45969b;

            {
                this.f45969b = this;
            }

            @Override // p000.xy1
            public final Object invoke() {
                byte b2 = b;
                FloatingFactoryBase floatingFactoryBase = this.f45969b;
                switch (b2) {
                    case 0:
                        Object systemService = floatingFactoryBase.m11348p().getSystemService("window");
                        systemService.getClass();
                        return (WindowManager) systemService;
                    default:
                        Object systemService2 = floatingFactoryBase.m11348p().getSystemService("activity");
                        ActivityManager activityManager = systemService2 instanceof ActivityManager ? (ActivityManager) systemService2 : null;
                        return Boolean.valueOf(activityManager == null || activityManager.isLowRamDevice() || activityManager.getMemoryClass() <= 192);
                }
            }
        });
        final byte b2 = 1;
        this.f14268n = new i85(new xy1(this) { // from class: yr1

            /* renamed from: b */
            public final /* synthetic */ FloatingFactoryBase f45969b;

            {
                this.f45969b = this;
            }

            @Override // p000.xy1
            public final Object invoke() {
                byte b22 = b2;
                FloatingFactoryBase floatingFactoryBase = this.f45969b;
                switch (b22) {
                    case 0:
                        Object systemService = floatingFactoryBase.m11348p().getSystemService("window");
                        systemService.getClass();
                        return (WindowManager) systemService;
                    default:
                        Object systemService2 = floatingFactoryBase.m11348p().getSystemService("activity");
                        ActivityManager activityManager = systemService2 instanceof ActivityManager ? (ActivityManager) systemService2 : null;
                        return Boolean.valueOf(activityManager == null || activityManager.isLowRamDevice() || activityManager.getMemoryClass() <= 192);
                }
            }
        });
    }

    /* renamed from: F */
    public static AbstractC0952f1 m11356F(View view) {
        if (view instanceof AbstractC0952f1) {
            return (AbstractC0952f1) view;
        }
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            childAt.getClass();
            AbstractC0952f1 m11356F = m11356F(childAt);
            if (m11356F != null) {
                return m11356F;
            }
        }
        return null;
    }

    /* renamed from: C */
    public final void m11357C(View view) {
        Object md4Var;
        if (view == null) {
            return;
        }
        m35 m35Var = this.f14269o;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        this.f14269o = null;
        this.f14267m.remove(view);
        this.f14266l.remove(view);
        view.setOnTouchListener(null);
        view.clearFocus();
        Object systemService = m11348p().getSystemService("input_method");
        InputMethodManager inputMethodManager = systemService instanceof InputMethodManager ? (InputMethodManager) systemService : null;
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        view.clearAnimation();
        view.jumpDrawablesToCurrentState();
        AbstractC0952f1 m11356F = m11356F(view);
        try {
            ((WindowManager) this.f14265k.getValue()).removeViewImmediate(view);
            md4Var = kn5.f22076a;
        } catch (Throwable th) {
            md4Var = new md4(th);
        }
        Throwable m16656b = nd4.m16656b(md4Var);
        if (m16656b != null) {
            Log.w("FloatingFactory", "[" + getClass().getSimpleName() + "] removeView failed", m16656b);
        }
        if (m11356F != null) {
            try {
                m11356F.m10604e();
            } catch (Throwable unused) {
            }
        }
        view.setTag(R.id.view_tree_lifecycle_owner, null);
        view.setTag(R.id.view_tree_saved_state_registry_owner, null);
        view.setTag(R.id.view_tree_view_model_store_owner, null);
    }

    /* renamed from: D */
    public final void m11358D(zm5 zm5Var, xy1 xy1Var) {
        zm5Var.getClass();
        if (this.f14267m.remove(zm5Var)) {
            zm5Var.clearFocus();
            Object systemService = m11348p().getSystemService("input_method");
            ns0 ns0Var = null;
            InputMethodManager inputMethodManager = systemService instanceof InputMethodManager ? (InputMethodManager) systemService : null;
            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(zm5Var.getWindowToken(), 0);
            }
            zm5Var.clearAnimation();
            zm5Var.jumpDrawablesToCurrentState();
            try {
                ((WindowManager) this.f14265k.getValue()).removeView(zm5Var);
            } catch (Throwable unused) {
            }
            m35 m35Var = this.f14269o;
            if (m35Var != null) {
                m35Var.mo1322a(null);
            }
            if (m11360G() != mf1.f25814c) {
                au2 m11349q = m11349q();
                r41 r41Var = ka1.f21425a;
                this.f14269o = v86.m21284K(m11349q, j03.f19481a, null, new i80(this, ns0Var, (byte) 4), 2);
            }
            if (xy1Var != null) {
                xy1Var.invoke();
            }
        }
    }

    /* renamed from: E */
    public final void m11359E(View view) {
        view.getClass();
        view.setTag(R.id.view_tree_lifecycle_owner, this);
        view.setTag(R.id.view_tree_saved_state_registry_owner, this);
        view.setTag(R.id.view_tree_view_model_store_owner, this);
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = viewGroup.getChildAt(i);
                childAt.getClass();
                childAt.setTag(R.id.view_tree_lifecycle_owner, this);
                childAt.setTag(R.id.view_tree_saved_state_registry_owner, this);
                childAt.setTag(R.id.view_tree_view_model_store_owner, this);
            }
        }
    }

    /* renamed from: G */
    public final long m11360G() {
        if (((Boolean) this.f14268n.getValue()).booleanValue()) {
            ur0 ur0Var = mf1.f25813b;
            return 0L;
        }
        ur0 ur0Var2 = mf1.f25813b;
        return cl5.m2662M(30, qf1.MINUTES);
    }

    /* renamed from: H */
    public final void m11361H(zm5 zm5Var, WindowManager.LayoutParams layoutParams, sz2 sz2Var) {
        zm5Var.getClass();
        layoutParams.getClass();
        m35 m35Var = this.f14269o;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        this.f14269o = null;
        m11359E(zm5Var);
        if (this.f14267m.contains(zm5Var)) {
            return;
        }
        addView(zm5Var, layoutParams);
        if (sz2Var != null) {
            sz2Var.invoke();
        }
    }

    @Override // android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (view != null) {
            m11359E(view);
            if (this.f14267m.add(view)) {
                ((WindowManager) this.f14265k.getValue()).addView(view, layoutParams);
                this.f14266l.add(view);
                aw2 aw2Var = f14264p;
                if (aw2Var != null) {
                    aw2Var.invoke(this, view);
                }
            }
        }
    }

    @Override // android.view.WindowManager
    public final Display getDefaultDisplay() {
        Display defaultDisplay = ((WindowManager) this.f14265k.getValue()).getDefaultDisplay();
        defaultDisplay.getClass();
        return defaultDisplay;
    }

    @Override // android.view.ViewManager
    public final void removeView(View view) {
        m11357C(view);
    }

    @Override // android.view.WindowManager
    public final void removeViewImmediate(View view) {
        m11357C(view);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: s */
    public void mo11351s(Configuration configuration) {
        configuration.getClass();
        super.mo11351s(configuration);
        Iterator it = ij0.m13394C0(this.f14266l).iterator();
        while (it.hasNext()) {
            ((View) it.next()).dispatchConfigurationChanged(configuration);
        }
    }

    @Override // android.view.ViewManager
    public final void updateViewLayout(View view, ViewGroup.LayoutParams layoutParams) {
        ((WindowManager) this.f14265k.getValue()).updateViewLayout(view, layoutParams);
    }
}
