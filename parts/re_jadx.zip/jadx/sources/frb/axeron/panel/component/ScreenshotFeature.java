package frb.axeron.panel.component;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.media.projection.MediaProjection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import frb.axeron.base.FeatureFactoryBase;
import java.io.OutputStream;
import p000.cc1;
import p000.hn0;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ScreenshotFeature extends FeatureFactoryBase {

    /* renamed from: k */
    public MediaProjection f14414k;

    /* JADX WARN: Removed duplicated region for block: B:12:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x002c  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* renamed from: C */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11456C(p000.os0 r7) {
        /*
            r6 = this;
            boolean r0 = r7 instanceof p000.hl4
            if (r0 == 0) goto L13
            r0 = r7
            hl4 r0 = (p000.hl4) r0
            int r1 = r0.f17330c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f17330c = r1
            goto L18
        L13:
            hl4 r0 = new hl4
            r0.<init>(r6, r7)
        L18:
            java.lang.Object r7 = r0.f17328a
            int r1 = r0.f17330c
            r2 = 0
            r3 = 1
            if (r1 == 0) goto L2c
            if (r1 != r3) goto L26
            p000.v86.m21297X(r7)
            goto L47
        L26:
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r6)
            return r2
        L2c:
            p000.v86.m21297X(r7)
            wr0 r7 = frb.axeron.core.ExecutionActivity.f14276f
            android.content.Context r1 = r6.m11348p()
            vr0 r4 = new vr0
            r5 = 23
            r4.<init>(r5)
            r0.f17330c = r3
            java.lang.Object r7 = r7.m22354r(r1, r4, r0)
            nu0 r0 = p000.nu0.f28013a
            if (r7 != r0) goto L47
            return r0
        L47:
            ka2 r7 = (p000.ka2) r7
            boolean r0 = r7 instanceof p000.b73
            if (r0 == 0) goto L81
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 32
            r4 = 29
            if (r0 < r4) goto L58
            r6.m11343B(r1, r3)
        L58:
            android.content.Context r0 = r6.m11348p()
            java.lang.String r3 = "media_projection"
            java.lang.Object r0 = r0.getSystemService(r3)
            r0.getClass()
            android.media.projection.MediaProjectionManager r0 = (android.media.projection.MediaProjectionManager) r0
            r3 = r7
            b73 r3 = (p000.b73) r3     // Catch: java.lang.Exception -> L77
            int r3 = r3.f2039a     // Catch: java.lang.Exception -> L77
            b73 r7 = (p000.b73) r7     // Catch: java.lang.Exception -> L77
            android.content.Intent r7 = r7.f2040b     // Catch: java.lang.Exception -> L77
            android.media.projection.MediaProjection r7 = r0.getMediaProjection(r3, r7)     // Catch: java.lang.Exception -> L77
            r6.f14414k = r7     // Catch: java.lang.Exception -> L77
            goto L81
        L77:
            r6.f14414k = r2
            int r7 = android.os.Build.VERSION.SDK_INT
            if (r7 < r4) goto L81
            r7 = 0
            r6.m11343B(r1, r7)
        L81:
            kn5 r6 = p000.kn5.f22076a
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.panel.component.ScreenshotFeature.m11456C(os0):java.lang.Object");
    }

    /* renamed from: D */
    public final Uri m11457D(Bitmap bitmap) {
        String m12934g = hn0.m12934g(SystemClock.uptimeMillis(), "Screenshot_", ".png");
        ContentValues contentValues = new ContentValues();
        contentValues.put("_display_name", m12934g);
        contentValues.put("mime_type", "image/png");
        contentValues.put("relative_path", Environment.DIRECTORY_PICTURES + "/Screenshots");
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
            contentValues.put("is_pending", (Integer) 1);
        }
        ContentResolver contentResolver = m11348p().getContentResolver();
        Uri insert = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        if (insert != null) {
            OutputStream openOutputStream = contentResolver.openOutputStream(insert);
            if (openOutputStream != null) {
                try {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, openOutputStream);
                } finally {
                }
            }
            cc1.m2458w(openOutputStream, null);
            if (i >= 29) {
                contentValues.clear();
                contentValues.put("is_pending", (Integer) 0);
                contentResolver.update(insert, contentValues, null, null);
            }
        }
        return insert;
    }

    /* JADX WARN: Code restructure failed: missing block: B:53:0x009d, code lost:
    
        if (m11456C(r0) != r10) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x006c, code lost:
    
        if (r13 != r10) goto L24;
     */
    /* JADX WARN: Removed duplicated region for block: B:16:0x00c5 A[Catch: all -> 0x00fc, TryCatch #1 {all -> 0x00fc, blocks: (B:13:0x0033, B:14:0x00bd, B:16:0x00c5, B:18:0x00d9, B:22:0x00dd, B:24:0x00f3), top: B:12:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00dd A[Catch: all -> 0x00fc, TryCatch #1 {all -> 0x00fc, blocks: (B:13:0x0033, B:14:0x00bd, B:16:0x00c5, B:18:0x00d9, B:22:0x00dd, B:24:0x00f3), top: B:12:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0076  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0046  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x002b  */
    /* renamed from: E */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11458E(p000.os0 r13) {
        /*
            Method dump skipped, instructions count: 266
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.panel.component.ScreenshotFeature.m11458E(os0):java.lang.Object");
    }
}
