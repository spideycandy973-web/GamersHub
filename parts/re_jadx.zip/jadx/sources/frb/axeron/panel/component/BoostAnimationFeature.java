package frb.axeron.panel.component;

import android.os.Bundle;
import android.view.WindowManager;
import com.unity3d.ads.core.domain.HandleInvocationsFromAdViewer;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import p000.di2;
import p000.gm0;
import p000.s40;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class BoostAnimationFeature extends FloatingFactoryBase {

    /* renamed from: q */
    public zm5 f14410q;

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        String string = bundle != null ? bundle.getString(HandleInvocationsFromAdViewer.KEY_PACKAGE_NAME) : null;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 280, -3);
        layoutParams.gravity = 81;
        layoutParams.y = di2.m9248W(80, m11348p());
        layoutParams.windowAnimations = R.style.WAnim_InBottom_OutBottom;
        zm5 m11345m = m11345m(false, new gm0(195117835, true, new s40(string, this, (byte) 2)));
        this.f14410q = m11345m;
        addView(m11345m, layoutParams);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        zm5 zm5Var = this.f14410q;
        if (zm5Var != null) {
            m11357C(zm5Var);
            this.f14410q = null;
        }
        super.mo11334u();
    }
}
