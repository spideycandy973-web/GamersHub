package frb.axeron.panel.component;

import android.os.Bundle;
import frb.axeron.base.FeatureFactoryBase;
import p000.gw3;
import p000.m35;
import p000.m50;
import p000.v86;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class PingOptimizerFeature extends FeatureFactoryBase {

    /* renamed from: k */
    public m35 f14413k;

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        String string;
        super.mo11333t(bundle);
        if (bundle != null && (string = bundle.getString("host")) != null) {
            gw3.m12391b(string);
        }
        this.f14413k = v86.m21284K(m11349q(), null, null, new m50(2, null, (byte) 3), 3);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        super.mo11334u();
        m35 m35Var = this.f14413k;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        this.f14413k = null;
    }
}
