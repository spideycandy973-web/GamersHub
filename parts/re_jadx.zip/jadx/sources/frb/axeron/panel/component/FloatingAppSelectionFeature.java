package frb.axeron.panel.component;

import android.os.Bundle;
import android.view.WindowManager;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import p000.C1792yj;
import p000.ViewOnTouchListenerC1541sh;
import p000.di2;
import p000.ei2;
import p000.gm0;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class FloatingAppSelectionFeature extends FloatingFactoryBase {

    /* renamed from: q */
    public zm5 f14411q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14412r;

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 262944, -3);
        layoutParams.gravity = 21;
        layoutParams.x = di2.m9248W(18, m11348p());
        layoutParams.windowAnimations = R.style.WAnim_InRight_OutRight;
        this.f14412r = layoutParams;
        zm5 m11345m = m11345m(false, new gm0(-706722259, true, new C1792yj((Object) this, (byte) 7)));
        this.f14411q = m11345m;
        m11345m.setOnTouchListener(new ViewOnTouchListenerC1541sh(this, (byte) 2));
        zm5 zm5Var = this.f14411q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14412r;
        if (layoutParams2 != null) {
            addView(zm5Var, layoutParams2);
        } else {
            ei2.m10039H("params");
            throw null;
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        zm5 zm5Var = this.f14411q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(zm5Var);
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: w */
    public final void mo11352w() {
        super.mo11352w();
        zm5 zm5Var = this.f14411q;
        if (zm5Var != null) {
            m11358D(zm5Var, null);
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: x */
    public final void mo11353x() {
        super.mo11353x();
        zm5 zm5Var = this.f14411q;
        if (zm5Var != null) {
            WindowManager.LayoutParams layoutParams = this.f14412r;
            if (layoutParams != null) {
                m11361H(zm5Var, layoutParams, null);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        }
    }
}
