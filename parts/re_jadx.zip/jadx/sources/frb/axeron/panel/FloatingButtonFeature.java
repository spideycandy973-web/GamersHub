package frb.axeron.panel;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Choreographer;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.mapping.pipeline.MappingCoordinatorFeature;
import frb.axeron.panel.FloatingButtonFeature;
import frb.axeron.redcorner.R;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import p000.AbstractC0871d6;
import p000.C0950f;
import p000.C1792yj;
import p000.a45;
import p000.ba4;
import p000.ce1;
import p000.cl5;
import p000.d33;
import p000.dc1;
import p000.dg2;
import p000.di2;
import p000.ds3;
import p000.ef3;
import p000.ei2;
import p000.el4;
import p000.et0;
import p000.gm0;
import p000.hl3;
import p000.it3;
import p000.l11;
import p000.lj2;
import p000.m55;
import p000.m84;
import p000.mf1;
import p000.mg1;
import p000.mt7;
import p000.mu0;
import p000.ns0;
import p000.nz1;
import p000.ov9;
import p000.p50;
import p000.p70;
import p000.qf1;
import p000.s02;
import p000.sv8;
import p000.sx8;
import p000.u62;
import p000.ur0;
import p000.v86;
import p000.vd1;
import p000.xr1;
import p000.y35;
import p000.yn0;
import p000.z80;
import p000.z94;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class FloatingButtonFeature extends FloatingFactoryBase {

    /* renamed from: x */
    public static final long f14391x;

    /* renamed from: y */
    public static final long f14392y;

    /* renamed from: z */
    public static final DecelerateInterpolator f14393z;

    /* renamed from: q */
    public final it3 f14394q = z80.m23867J(Boolean.FALSE);

    /* renamed from: r */
    public final it3 f14395r = z80.m23867J(new dc1(0));

    /* renamed from: s */
    public xr1 f14396s;

    /* renamed from: t */
    public el4 f14397t;

    /* renamed from: u */
    public String f14398u;

    /* renamed from: v */
    public zm5 f14399v;

    /* renamed from: w */
    public WindowManager.LayoutParams f14400w;

    static {
        ur0 ur0Var = mf1.f25813b;
        qf1 qf1Var = qf1.MILLISECONDS;
        f14391x = cl5.m2662M(1500, qf1Var);
        f14392y = cl5.m2662M(100, qf1Var);
        f14393z = new DecelerateInterpolator();
    }

    /* renamed from: J */
    public static final void m11442J(ba4 ba4Var, mu0 mu0Var, FloatingButtonFeature floatingButtonFeature, Class cls, Bundle bundle) {
        lj2 lj2Var = (lj2) ba4Var.f2173a;
        if (lj2Var == null || !lj2Var.isActive()) {
            ba4Var.f2173a = v86.m21284K(mu0Var, null, null, new vd1(floatingButtonFeature, bundle, cls, (ns0) null), 3);
        }
    }

    /* renamed from: I */
    public final void m11443I(int i, s02 s02Var) {
        s02 s02Var2;
        final float f;
        float f2;
        ba4 ba4Var;
        float f3;
        s02Var.m19312b0(-756910868);
        int i2 = i | (s02Var.m19323h(this) ? 4 : 2);
        if (s02Var.m19300R(i2 & 1, (i2 & 3) != 2)) {
            y35 mo409g = mo409g();
            ef3 m8781q = AbstractC0871d6.m8781q(mo409g, ((a45) mo409g).getValue(), s02Var, 0, 0);
            final boolean contains = ((Set) m8781q.getValue()).contains(FloatingPanelFeature.class);
            final boolean contains2 = ((Set) m8781q.getValue()).contains(FloatingPanelSideFeature.class);
            final boolean z = ((Configuration) AbstractC0871d6.m8782r(this.f14261h, s02Var).getValue()).orientation == 2;
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (m19298O == sv8Var) {
                m19298O = ov9.m17465q(s02Var);
                s02Var.m19330k0(m19298O);
            }
            final mu0 mu0Var = (mu0) m19298O;
            float m9238M = di2.m9238M(36, s02Var, 6);
            float m9238M2 = di2.m9238M(36, s02Var, 6);
            float m9238M3 = di2.m9238M(36, s02Var, 6);
            float m9238M4 = di2.m9238M(80, s02Var, 6);
            final float m9232G = di2.m9232G(2.6f, s02Var, 6);
            float m9232G2 = di2.m9232G(48.6f, s02Var, 6);
            float m9232G3 = di2.m9232G(4.2f, s02Var, 6);
            dc1 m11447N = m11447N();
            boolean m8936a = m11447N.m8936a();
            int i3 = m11447N.f10082a;
            boolean z2 = m8936a || (i3 & 8) != 0;
            p70 p70Var = m11447N.m8936a() ? mg1.f25862e : (i3 & 8) != 0 ? mg1.f25864g : mg1.f25863f;
            if (z2) {
                s02Var.m19308Z(-1541838413);
                s02Var.m19338p(false);
                m9238M = m9238M3;
                m9238M2 = m9232G2;
                f2 = m9238M4;
                f = m9232G3;
            } else {
                s02Var.m19308Z(-1541837937);
                float m9238M5 = di2.m9238M(0, s02Var, 6);
                s02Var.m19338p(false);
                f = m9238M5;
                m9232G = m9238M;
                f2 = m9238M2;
            }
            final it3 it3Var = this.f14394q;
            float f4 = (contains || contains2 || ((Boolean) it3Var.getValue()).booleanValue()) ? 0.0f : 1.0f;
            final p70 p70Var2 = p70Var;
            Object m19298O2 = s02Var.m19298O();
            if (m19298O2 == sv8Var) {
                m19298O2 = new ba4(null);
                s02Var.m19330k0(m19298O2);
            }
            final ba4 ba4Var2 = (ba4) m19298O2;
            Object m19298O3 = s02Var.m19298O();
            if (m19298O3 == sv8Var) {
                m19298O3 = new ba4(0);
                s02Var.m19330k0(m19298O3);
            }
            ba4 ba4Var3 = (ba4) m19298O3;
            Object m19298O4 = s02Var.m19298O();
            if (m19298O4 == sv8Var) {
                m19298O4 = new ba4(0);
                s02Var.m19330k0(m19298O4);
            }
            final ba4 ba4Var4 = (ba4) m19298O4;
            Object m19298O5 = s02Var.m19298O();
            if (m19298O5 == sv8Var) {
                ba4Var = ba4Var3;
                f3 = f2;
                m19298O5 = new ba4(new hl3(0L));
                s02Var.m19330k0(m19298O5);
            } else {
                ba4Var = ba4Var3;
                f3 = f2;
            }
            final ba4 ba4Var5 = (ba4) m19298O5;
            final float f5 = f4;
            final float f6 = m9238M;
            final float f7 = m9238M2;
            final float f8 = f3;
            final ba4 ba4Var6 = ba4Var;
            nz1 nz1Var = new nz1() { // from class: vr1
                @Override // p000.nz1
                public final Object invoke(Object obj, Object obj2) {
                    ba4 ba4Var7;
                    ba4 ba4Var8;
                    s02 s02Var3 = (s02) obj;
                    int intValue = ((Integer) obj2).intValue();
                    DecelerateInterpolator decelerateInterpolator = FloatingButtonFeature.f14393z;
                    boolean z3 = false;
                    if (s02Var3.m19300R(intValue & 1, (intValue & 3) != 2)) {
                        final k64 k64Var = (k64) s02Var3.m19327j(rj0.f33758k);
                        if (!contains && !contains2 && !((Boolean) it3Var.getValue()).booleanValue()) {
                            z3 = true;
                        }
                        na3 m11710f = fy4.m11710f(fy4.m11719o(ka3.f21426a, f6), f8);
                        float f9 = f5;
                        boolean m19313c = s02Var3.m19313c(f9);
                        Object m19298O6 = s02Var3.m19298O();
                        sv8 sv8Var2 = yn0.f45724a;
                        if (m19313c || m19298O6 == sv8Var2) {
                            m19298O6 = new C1573t9(f9, (byte) 2);
                            s02Var3.m19330k0(m19298O6);
                        }
                        na3 m9241P = di2.m9241P(m11710f, (zy1) m19298O6);
                        FloatingButtonFeature floatingButtonFeature = this;
                        boolean m19323h = s02Var3.m19323h(floatingButtonFeature);
                        ba4 ba4Var9 = ba4Var6;
                        boolean m19323h2 = m19323h | s02Var3.m19323h(ba4Var9);
                        ba4 ba4Var10 = ba4Var5;
                        boolean m19323h3 = m19323h2 | s02Var3.m19323h(ba4Var10);
                        ba4 ba4Var11 = ba4Var4;
                        boolean m19323h4 = m19323h3 | s02Var3.m19323h(ba4Var11);
                        Object m19298O7 = s02Var3.m19298O();
                        if (m19323h4 || m19298O7 == sv8Var2) {
                            C1354nn c1354nn = new C1354nn((Object) floatingButtonFeature, (Object) ba4Var9, (Object) ba4Var10, (Object) ba4Var11, (byte) 4);
                            ba4Var7 = ba4Var10;
                            ba4Var8 = ba4Var11;
                            s02Var3.m19330k0(c1354nn);
                            m19298O7 = c1354nn;
                        } else {
                            ba4Var7 = ba4Var10;
                            ba4Var8 = ba4Var11;
                        }
                        zy1 zy1Var = (zy1) m19298O7;
                        boolean m19323h5 = s02Var3.m19323h(floatingButtonFeature) | s02Var3.m19323h(ba4Var9) | s02Var3.m19323h(ba4Var8) | s02Var3.m19323h(ba4Var7);
                        Object m19298O8 = s02Var3.m19298O();
                        if (m19323h5 || m19298O8 == sv8Var2) {
                            C1227ke c1227ke = new C1227ke(floatingButtonFeature, ba4Var9, ba4Var8, ba4Var7, null, (byte) 4);
                            s02Var3.m19330k0(c1227ke);
                            m19298O8 = c1227ke;
                        }
                        nz1 nz1Var2 = (nz1) m19298O8;
                        boolean z4 = z;
                        boolean m19321g = s02Var3.m19321g(z4);
                        ba4 ba4Var12 = ba4Var2;
                        boolean m19323h6 = m19321g | s02Var3.m19323h(ba4Var12);
                        mu0 mu0Var2 = mu0Var;
                        boolean m19323h7 = m19323h6 | s02Var3.m19323h(mu0Var2) | s02Var3.m19323h(floatingButtonFeature);
                        Object m19298O9 = s02Var3.m19298O();
                        if (m19323h7 || m19298O9 == sv8Var2) {
                            C1788yf c1788yf = new C1788yf(z4, (Object) floatingButtonFeature, (Object) ba4Var12, (Object) mu0Var2, (byte) 2);
                            s02Var3.m19330k0(c1788yf);
                            m19298O9 = c1788yf;
                        }
                        zy1 zy1Var2 = (zy1) m19298O9;
                        final float f10 = f;
                        final float f11 = m9232G;
                        final float f12 = f7;
                        final p70 p70Var3 = p70Var2;
                        m12.m15685a(m9241P, 0L, 0.0f, 0.0f, 0L, z3, zy1Var, nz1Var2, zy1Var2, mt7.m16166P(471634111, new pz1() { // from class: wr1
                            @Override // p000.pz1
                            public final Object invoke(Object obj3, Object obj4, Object obj5) {
                                n12 n12Var = (n12) obj3;
                                s02 s02Var4 = (s02) obj4;
                                int intValue2 = ((Integer) obj5).intValue();
                                DecelerateInterpolator decelerateInterpolator2 = FloatingButtonFeature.f14393z;
                                n12Var.getClass();
                                if ((intValue2 & 6) == 0) {
                                    intValue2 |= s02Var4.m19319f(n12Var) ? 4 : 2;
                                }
                                if (s02Var4.m19300R(intValue2 & 1, (intValue2 & 19) != 18)) {
                                    ka3 ka3Var = ka3.f21426a;
                                    na3 m23273i = y53.m23273i(n12Var.mo16389a(fy4.m11710f(fy4.m11719o(AbstractC0871d6.m8745F(ka3Var, f10), f11), f12), p70Var3), dg2.m9071C(3, 0.0f));
                                    k64 k64Var2 = k64Var;
                                    na3 m19001O = rc6.m19001O(m23273i, qj0.m18297b(0.6f, k64Var2.f21260a), bz5.f3249o);
                                    o63 m15156c = l90.m15156c(mg1.f25859b, false);
                                    int hashCode = Long.hashCode(s02Var4.f34520T);
                                    ov3 m19331l = s02Var4.m19331l();
                                    na3 m20748R = u99.m20748R(s02Var4, m19001O);
                                    sn0.f35689X8.getClass();
                                    s02Var4.m19316d0();
                                    if (s02Var4.f34519S) {
                                        s02Var4.m19329k(wo2.f42501S);
                                    } else {
                                        s02Var4.m19336n0();
                                    }
                                    z80.m23871N(oua.f29409h, s02Var4, m15156c);
                                    z80.m23871N(oua.f29408g, s02Var4, m19331l);
                                    z80.m23871N(oua.f29410i, s02Var4, Integer.valueOf(hashCode));
                                    z80.m23869L(s02Var4);
                                    z80.m23871N(oua.f29407f, s02Var4, m20748R);
                                    kb2.m14510a(z21.m23719B(R.drawable.axgc, s02Var4, 0), null, AbstractC0871d6.m8745F(ka3Var, di2.m9238M(5, s02Var4, 6)), k64Var2.f21264e, s02Var4, 56, 0);
                                    s02Var4.m19338p(true);
                                } else {
                                    s02Var4.m19303U();
                                }
                                return kn5.f22076a;
                            }
                        }, s02Var3), s02Var3, 805306368, 30);
                    } else {
                        s02Var3.m19303U();
                    }
                    return kn5.f22076a;
                }
            };
            s02Var2 = s02Var;
            dg2.m9103e(null, mt7.m16166P(-1610405437, nz1Var, s02Var2), s02Var2, 48, 1);
        } else {
            s02Var2 = s02Var;
            s02Var2.m19303U();
        }
        m84 m19342t = s02Var2.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new d33(this, i, (byte) 23);
        }
    }

    /* renamed from: K */
    public final void m11444K() {
        xr1 xr1Var = this.f14396s;
        if (xr1Var != null) {
            Choreographer.getInstance().removeFrameCallback(xr1Var);
        }
        this.f14396s = null;
    }

    /* renamed from: L */
    public final String m11445L() {
        return m11348p().getResources().getConfiguration().orientation == 2 ? "norm_anchor_land" : "norm_anchor_port";
    }

    /* renamed from: M */
    public final WindowManager.LayoutParams m11446M() {
        WindowManager.LayoutParams layoutParams = this.f14400w;
        if (layoutParams != null) {
            return layoutParams;
        }
        ei2.m10039H("params");
        throw null;
    }

    /* renamed from: N */
    public final dc1 m11447N() {
        return (dc1) this.f14395r.getValue();
    }

    /* renamed from: O */
    public final View m11448O() {
        zm5 zm5Var = this.f14399v;
        if (zm5Var != null) {
            return zm5Var;
        }
        ei2.m10039H("view");
        throw null;
    }

    /* renamed from: P */
    public final void m11449P() {
        int m9248W = di2.m9248W(36, m11348p());
        int m9248W2 = m11447N().f10082a == 0 ? m9248W : di2.m9248W(80, m11348p());
        View m11448O = m11448O();
        WindowManager.LayoutParams m11446M = m11446M();
        el4 el4Var = this.f14397t;
        if (el4Var != null) {
            ce1.m2514e(this, m11448O, m11446M, m9248W, m9248W2, el4Var, 4080);
        } else {
            ei2.m10039H("specs");
            throw null;
        }
    }

    /* renamed from: Q */
    public final ds3 m11450Q() {
        String m11445L = m11445L();
        p50 p50Var = sx8.f36147A;
        if (p50Var == null) {
            C0950f.m10585p("AppPreferences must be initialized in Application.onCreate()");
            return null;
        }
        SharedPreferences sharedPreferences = p50Var.getSharedPreferences("floating_button_prefs", 0);
        sharedPreferences.getClass();
        if (sharedPreferences.getInt("layout_version", 0) != 2) {
            SharedPreferences.Editor edit = sharedPreferences.edit();
            edit.getClass();
            Set<String> keySet = sharedPreferences.getAll().keySet();
            ArrayList arrayList = new ArrayList();
            for (Object obj : keySet) {
                String str = (String) obj;
                str.getClass();
                if (m55.m15777Y(str, "_x", false) || m55.m15777Y(str, "_y", false)) {
                    arrayList.add(obj);
                }
            }
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                Object obj2 = arrayList.get(i);
                i++;
                edit.remove((String) obj2);
            }
            edit.putInt("layout_version", 2);
            edit.apply();
        }
        p50 p50Var2 = sx8.f36147A;
        if (p50Var2 == null) {
            C0950f.m10585p("AppPreferences must be initialized in Application.onCreate()");
            return null;
        }
        SharedPreferences sharedPreferences2 = p50Var2.getSharedPreferences("floating_button_prefs", 0);
        sharedPreferences2.getClass();
        if (!sharedPreferences2.contains(m11445L.concat("_x"))) {
            return null;
        }
        float f = sharedPreferences2.getFloat(m11445L.concat("_x"), 0.0f);
        float f2 = sharedPreferences2.getFloat(m11445L.concat("_y"), 0.0f);
        if (0.0f <= f && f <= 1.0f && 0.0f <= f2 && f2 <= 1.0f) {
            return new ds3(Float.valueOf(f), Float.valueOf(f2));
        }
        SharedPreferences.Editor edit2 = sharedPreferences2.edit();
        edit2.getClass();
        edit2.remove(m11445L.concat("_x"));
        edit2.remove(m11445L.concat("_y"));
        edit2.apply();
        return null;
    }

    /* renamed from: R */
    public final void m11451R(boolean z, boolean z2) {
        dc1 dc1Var;
        m11444K();
        int m9248W = di2.m9248W(36, m11348p());
        el4 el4Var = this.f14397t;
        if (el4Var == null) {
            ei2.m10039H("specs");
            throw null;
        }
        int i = el4Var.f12018a - m9248W;
        if (i < 0) {
            i = 0;
        }
        float m10171c = el4Var.m10171c() * 0.08f;
        int i2 = m11446M().x;
        int i3 = i - m11446M().x;
        if (i2 <= i3) {
            if (i2 < m10171c) {
                dc1Var = new dc1(4);
            }
            dc1Var = new dc1(0);
        } else {
            if (i3 < m10171c) {
                dc1Var = new dc1(8);
            }
            dc1Var = new dc1(0);
        }
        this.f14395r.setValue(dc1Var);
        if (m11447N().f10082a == 0) {
            m11449P();
            if (z) {
                m11452S(m11446M());
                return;
            }
            return;
        }
        int i4 = m11447N().m8936a() ? 0 : i;
        if (!z2) {
            m11446M().x = i4;
            m11449P();
            if (z) {
                m11452S(m11446M());
                return;
            }
            return;
        }
        m11449P();
        et0 et0Var = new et0((byte) 1, this, z);
        m11444K();
        int i5 = m11446M().x;
        Choreographer choreographer = Choreographer.getInstance();
        z94 z94Var = new z94();
        z94Var.f46764a = -1L;
        xr1 xr1Var = new xr1(z94Var, this, i5, i4, choreographer, et0Var);
        this.f14396s = xr1Var;
        choreographer.postFrameCallback(xr1Var);
    }

    /* renamed from: S */
    public final void m11452S(WindowManager.LayoutParams layoutParams) {
        int m9248W = di2.m9248W(36, m11348p());
        Context m11348p = m11348p();
        ConcurrentHashMap concurrentHashMap = ce1.f4012a;
        ds3 m2511b = ce1.m2511b(layoutParams, m11348p, m9248W, m9248W, l11.m15025p(m11348p));
        float floatValue = ((Number) m2511b.f10834a).floatValue();
        float floatValue2 = ((Number) m2511b.f10835b).floatValue();
        String m11445L = m11445L();
        p50 p50Var = sx8.f36147A;
        if (p50Var == null) {
            C0950f.m10585p("AppPreferences must be initialized in Application.onCreate()");
            return;
        }
        SharedPreferences sharedPreferences = p50Var.getSharedPreferences("floating_button_prefs", 0);
        sharedPreferences.getClass();
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.getClass();
        edit.putFloat(m11445L.concat("_x"), floatValue);
        edit.putFloat(m11445L.concat("_y"), floatValue2);
        edit.putInt("layout_version", 2);
        edit.apply();
    }

    /* renamed from: T */
    public final void m11453T(boolean z) {
        this.f14394q.setValue(Boolean.valueOf(!z));
    }

    @Override // frb.axeron.base.FloatingFactoryBase, frb.axeron.base.FeatureFactoryBase
    /* renamed from: s */
    public final void mo11351s(Configuration configuration) {
        configuration.getClass();
        super.mo11351s(configuration);
        this.f14397t = l11.m15025p(m11348p());
        int m9248W = di2.m9248W(36, m11348p());
        ds3 m11450Q = m11450Q();
        if (m11450Q != null) {
            WindowManager.LayoutParams m11446M = m11446M();
            Context m11348p = m11348p();
            float floatValue = ((Number) m11450Q.f10834a).floatValue();
            float floatValue2 = ((Number) m11450Q.f10835b).floatValue();
            el4 el4Var = this.f14397t;
            if (el4Var == null) {
                ei2.m10039H("specs");
                throw null;
            }
            ce1.m2510a(m11446M, m11348p, floatValue, floatValue2, m9248W, m9248W, el4Var);
        } else {
            int m9248W2 = di2.m9248W(42, m11348p());
            m11446M().x = m9248W2;
            m11446M().y = m9248W2;
        }
        m11451R(false, false);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        this.f14398u = bundle != null ? bundle.getString("target") : null;
        this.f14397t = l11.m15025p(m11348p());
        this.f14399v = m11345m(false, new gm0(-2058954804, true, new C1792yj((Object) this, (byte) 8)));
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 776, -3);
        layoutParams.gravity = 51;
        int m9248W = di2.m9248W(42, m11348p());
        layoutParams.x = m9248W;
        layoutParams.y = m9248W;
        layoutParams.windowAnimations = R.style.WAnim_Fade;
        this.f14400w = layoutParams;
        ds3 m11450Q = m11450Q();
        if (m11450Q != null) {
            float floatValue = ((Number) m11450Q.f10834a).floatValue();
            float floatValue2 = ((Number) m11450Q.f10835b).floatValue();
            int m9248W2 = di2.m9248W(36, m11348p());
            WindowManager.LayoutParams m11446M = m11446M();
            Context m11348p = m11348p();
            el4 el4Var = this.f14397t;
            if (el4Var == null) {
                ei2.m10039H("specs");
                throw null;
            }
            ce1.m2510a(m11446M, m11348p, floatValue, floatValue2, m9248W2, m9248W2, el4Var);
        }
        m11451R(false, false);
        addView(m11448O(), m11446M());
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        u62.m20673j(m11348p(), "ACTION_KILL_FEATURE", MappingCoordinatorFeature.class, null);
        m11444K();
        m11357C(m11448O());
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: v */
    public final void mo11335v(Bundle bundle) {
        if (bundle.containsKey("target")) {
            this.f14398u = bundle.getString("target");
        }
    }
}
