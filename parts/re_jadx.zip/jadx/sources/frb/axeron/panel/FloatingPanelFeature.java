package frb.axeron.panel;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.WindowManager;
import com.unity3d.ads.core.domain.HandleInvocationsFromAdViewer;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import p000.C1792yj;
import p000.ViewOnTouchListenerC1541sh;
import p000.a45;
import p000.ei2;
import p000.gm0;
import p000.v86;
import p000.vt2;
import p000.zm5;
import p000.zr1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class FloatingPanelFeature extends FloatingFactoryBase {

    /* renamed from: q */
    public zm5 f14401q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14402r;

    /* renamed from: s */
    public String f14403s;

    @Override // frb.axeron.base.FloatingFactoryBase, frb.axeron.base.FeatureFactoryBase
    /* renamed from: s */
    public final void mo11351s(Configuration configuration) {
        configuration.getClass();
        int i = ((Configuration) ((a45) this.f14261h.f39911a).getValue()).orientation;
        super.mo11351s(configuration);
        if (configuration.orientation == i || ((a45) this.f14259f.f39911a).getValue() == vt2.ON_DESTROY) {
            return;
        }
        v86.m21284K(m11349q(), null, null, new zr1(this, null, (byte) 0), 3);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        this.f14403s = bundle != null ? bundle.getString(HandleInvocationsFromAdViewer.KEY_PACKAGE_NAME) : null;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 262922, -3);
        layoutParams.gravity = 80;
        layoutParams.dimAmount = 0.4f;
        layoutParams.windowAnimations = R.style.WAnim_InBottom_OutBottom;
        this.f14402r = layoutParams;
        zm5 m11345m = m11345m(false, new gm0(-503590922, true, new C1792yj((Object) this, (byte) 9)));
        this.f14401q = m11345m;
        m11345m.setOnTouchListener(new ViewOnTouchListenerC1541sh(this, (byte) 3));
        zm5 zm5Var = this.f14401q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14402r;
        if (layoutParams2 != null) {
            addView(zm5Var, layoutParams2);
        } else {
            ei2.m10039H("params");
            throw null;
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        zm5 zm5Var = this.f14401q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(zm5Var);
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: v */
    public final void mo11335v(Bundle bundle) {
        this.f14403s = bundle.getString(HandleInvocationsFromAdViewer.KEY_PACKAGE_NAME);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: w */
    public final void mo11352w() {
        super.mo11352w();
        zm5 zm5Var = this.f14401q;
        if (zm5Var != null) {
            m11358D(zm5Var, null);
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: x */
    public final void mo11353x() {
        super.mo11353x();
        zm5 zm5Var = this.f14401q;
        if (zm5Var != null) {
            WindowManager.LayoutParams layoutParams = this.f14402r;
            if (layoutParams != null) {
                m11361H(zm5Var, layoutParams, null);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        }
    }
}
