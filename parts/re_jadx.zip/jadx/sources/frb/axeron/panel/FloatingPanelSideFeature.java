package frb.axeron.panel;

import android.os.Bundle;
import android.view.WindowManager;
import com.unity3d.ads.core.domain.HandleInvocationsFromAdViewer;
import frb.axeron.base.FeatureFactoryBase;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import p000.C1792yj;
import p000.ViewOnTouchListenerC1541sh;
import p000.at0;
import p000.ce1;
import p000.dg2;
import p000.di2;
import p000.ei2;
import p000.el4;
import p000.gm0;
import p000.l11;
import p000.m35;
import p000.ve0;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class FloatingPanelSideFeature extends FloatingFactoryBase {

    /* renamed from: q */
    public zm5 f14404q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14405r;

    /* renamed from: s */
    public boolean f14406s = true;

    /* renamed from: t */
    public int f14407t;

    /* renamed from: u */
    public int f14408u;

    /* renamed from: v */
    public String f14409v;

    /* renamed from: I */
    public final void m11454I(Bundle bundle) {
        this.f14406s = bundle != null ? bundle.getBoolean("isLeft", true) : true;
        this.f14407t = bundle != null ? bundle.getInt("y", 0) : 0;
        this.f14409v = bundle != null ? bundle.getString(HandleInvocationsFromAdViewer.KEY_PACKAGE_NAME) : null;
        this.f14408u = this.f14407t;
    }

    /* renamed from: J */
    public final void m11455J(int i) {
        int m9248W;
        this.f14408u = i;
        if (l11.m15025p(m11348p()).f12025h == 2) {
            int i2 = (this.f14406s ? 8388611 : 8388613) | 16;
            WindowManager.LayoutParams layoutParams = this.f14405r;
            if (layoutParams == null) {
                ei2.m10039H("params");
                throw null;
            }
            if (layoutParams.gravity != i2) {
                layoutParams.gravity = i2;
                layoutParams.y = 0;
                zm5 zm5Var = this.f14404q;
                if (zm5Var != null) {
                    ce1.m2514e(this, zm5Var, layoutParams, 0, 0, null, 8188);
                    return;
                } else {
                    ei2.m10039H("view");
                    throw null;
                }
            }
            return;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14405r;
        if (layoutParams2 == null) {
            ei2.m10039H("params");
            throw null;
        }
        layoutParams2.gravity = (this.f14406s ? 8388611 : 8388613) | 48;
        layoutParams2.y = i;
        zm5 zm5Var2 = this.f14404q;
        if (zm5Var2 == null) {
            ei2.m10039H("view");
            throw null;
        }
        if (zm5Var2.getHeight() > 0) {
            zm5 zm5Var3 = this.f14404q;
            if (zm5Var3 == null) {
                ei2.m10039H("view");
                throw null;
            }
            m9248W = zm5Var3.getHeight();
        } else {
            m9248W = di2.m9248W(320, m11348p());
        }
        ce1.m2514e(this, zm5Var2, layoutParams2, 0, m9248W, null, 8180);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        m11454I(bundle);
        el4 m15025p = l11.m15025p(m11348p());
        byte b = 1;
        boolean z = m15025p.f12025h == 2;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 262920, -3);
        boolean z2 = this.f14406s;
        layoutParams.gravity = (z2 ? 8388611 : 8388613) | (z ? 16 : 48);
        layoutParams.windowAnimations = z2 ? R.style.WAnim_InLeft_OutLeft : R.style.WAnim_InRight_OutRight;
        layoutParams.x = 0;
        if (z) {
            layoutParams.y = 0;
        } else {
            int m9248W = di2.m9248W(320, m11348p());
            int i = this.f14407t;
            int i2 = m15025p.f12019b - m9248W;
            if (i2 < 0) {
                i2 = 0;
            }
            layoutParams.y = dg2.m9133t(i, 0, i2);
        }
        this.f14405r = layoutParams;
        zm5 m11345m = m11345m(false, new gm0(-1496188458, true, new C1792yj((Object) this, (byte) 10)));
        this.f14404q = m11345m;
        m11345m.addOnLayoutChangeListener(new ve0(this, b));
        zm5 zm5Var = this.f14404q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        zm5Var.setOnTouchListener(new ViewOnTouchListenerC1541sh(this, (byte) 4));
        FeatureFactoryBase mo411k = mo411k(FloatingButtonFeature.class);
        if (!(mo411k instanceof FloatingButtonFeature)) {
            mo411k = null;
        }
        FloatingButtonFeature floatingButtonFeature = (FloatingButtonFeature) mo411k;
        if (floatingButtonFeature != null) {
            floatingButtonFeature.m11453T(false);
        }
        zm5 zm5Var2 = this.f14404q;
        if (zm5Var2 == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14405r;
        if (layoutParams2 != null) {
            addView(zm5Var2, layoutParams2);
        } else {
            ei2.m10039H("params");
            throw null;
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        FeatureFactoryBase mo411k = mo411k(FloatingButtonFeature.class);
        if (!(mo411k instanceof FloatingButtonFeature)) {
            mo411k = null;
        }
        FloatingButtonFeature floatingButtonFeature = (FloatingButtonFeature) mo411k;
        if (floatingButtonFeature != null) {
            floatingButtonFeature.m11453T(true);
        }
        zm5 zm5Var = this.f14404q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(zm5Var);
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: v */
    public final void mo11335v(Bundle bundle) {
        m11454I(bundle);
        WindowManager.LayoutParams layoutParams = this.f14405r;
        if (layoutParams != null) {
            layoutParams.windowAnimations = this.f14406s ? R.style.WAnim_InLeft_OutLeft : R.style.WAnim_InRight_OutRight;
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: w */
    public final void mo11352w() {
        super.mo11352w();
        zm5 zm5Var = this.f14404q;
        if (zm5Var != null) {
            m11358D(zm5Var, new at0(this, (byte) 6));
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: x */
    public final void mo11353x() {
        super.mo11353x();
        if (this.f14404q != null) {
            m11455J(this.f14408u);
            zm5 zm5Var = this.f14404q;
            if (zm5Var == null) {
                ei2.m10039H("view");
                throw null;
            }
            WindowManager.LayoutParams layoutParams = this.f14405r;
            if (layoutParams == null) {
                ei2.m10039H("params");
                throw null;
            }
            m35 m35Var = this.f14269o;
            if (m35Var != null) {
                m35Var.mo1322a(null);
            }
            this.f14269o = null;
            m11359E(zm5Var);
            if (this.f14267m.contains(zm5Var)) {
                return;
            }
            addView(zm5Var, layoutParams);
            FeatureFactoryBase mo411k = mo411k(FloatingButtonFeature.class);
            FloatingButtonFeature floatingButtonFeature = (FloatingButtonFeature) (mo411k instanceof FloatingButtonFeature ? mo411k : null);
            if (floatingButtonFeature != null) {
                floatingButtonFeature.m11453T(false);
            }
        }
    }
}
