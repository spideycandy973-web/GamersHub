package frb.axeron.integrity;

import p000.hn0;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class NativeMonkey {

    /* renamed from: a */
    public static final NativeMonkey f14327a = new NativeMonkey();

    /* renamed from: b */
    public static volatile boolean f14328b;

    /* renamed from: c */
    public static volatile String f14329c;

    /* renamed from: a */
    public static String m11377a() {
        if (f14328b) {
            return null;
        }
        if (f14329c != null) {
            return f14329c;
        }
        try {
            System.loadLibrary("monkey");
            f14328b = true;
            return null;
        } catch (Throwable th) {
            String simpleName = th.getClass().getSimpleName();
            String message = th.getMessage();
            if (message == null) {
                message = "-";
            }
            String m12936i = hn0.m12936i(simpleName, ": ", message);
            f14329c = m12936i;
            return m12936i;
        }
    }

    public final native String execHash(String str, String str2);
}
