package frb.axeron.configs.presets;

import android.os.Bundle;
import android.view.WindowManager;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.redcorner.R;
import p000.C1792yj;
import p000.ViewOnTouchListenerC1541sh;
import p000.di2;
import p000.ei2;
import p000.es4;
import p000.gm0;
import p000.i85;
import p000.jq5;
import p000.m04;
import p000.oc4;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class PresetsMenuFeature extends FloatingFactoryBase {

    /* renamed from: q */
    public zm5 f14271q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14272r;

    /* renamed from: s */
    public final es4 f14273s = new es4(jq5.f20569f);

    /* renamed from: t */
    public final i85 f14274t = new i85(new m04(this, 0));

    /* renamed from: u */
    public final i85 f14275u = new i85(new m04(this, 3));

    /* renamed from: I */
    public final oc4 m11362I() {
        return (oc4) this.f14274t.getValue();
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x002c  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
    /* renamed from: J */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11363J(p000.os0 r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof p000.p04
            if (r0 == 0) goto L13
            r0 = r6
            p04 r0 = (p000.p04) r0
            int r1 = r0.f29630c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f29630c = r1
            goto L18
        L13:
            p04 r0 = new p04
            r0.<init>(r5, r6)
        L18:
            java.lang.Object r6 = r0.f29628a
            int r1 = r0.f29630c
            r2 = 1
            if (r1 == 0) goto L2c
            if (r1 != r2) goto L25
            p000.v86.m21297X(r6)
            goto L52
        L25:
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r5)
            r5 = 0
            return r5
        L2c:
            p000.v86.m21297X(r6)
            zm5 r6 = r5.f14271q
            if (r6 == 0) goto L38
            android.content.Context r6 = r6.getContext()
            goto L3c
        L38:
            android.content.Context r6 = r5.m11348p()
        L3c:
            wr0 r1 = frb.axeron.core.ExecutionActivity.f14276f
            r6.getClass()
            o56 r3 = new o56
            r4 = 7
            r3.<init>(r5, r4)
            r0.f29630c = r2
            java.lang.Object r5 = r1.m22354r(r6, r3, r0)
            nu0 r6 = p000.nu0.f28013a
            if (r5 != r6) goto L52
            return r6
        L52:
            kn5 r5 = p000.kn5.f22076a
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.configs.presets.PresetsMenuFeature.m11363J(os0):java.lang.Object");
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 262952, -3);
        if (m11348p().getResources().getConfiguration().orientation == 1) {
            layoutParams.gravity = 81;
            layoutParams.y = di2.m9248W(18, m11348p());
            layoutParams.windowAnimations = R.style.WAnim_InBottom_OutBottom;
        } else {
            layoutParams.gravity = 19;
            layoutParams.x = di2.m9248W(18, m11348p());
            layoutParams.windowAnimations = R.style.WAnim_InLeft_OutLeft;
        }
        this.f14272r = layoutParams;
        zm5 m11345m = m11345m(false, new gm0(-1066624382, true, new C1792yj((Object) this, (byte) 16)));
        this.f14271q = m11345m;
        m11345m.setOnTouchListener(new ViewOnTouchListenerC1541sh(this, (byte) 9));
        zm5 zm5Var = this.f14271q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14272r;
        if (layoutParams2 != null) {
            addView(zm5Var, layoutParams2);
        } else {
            ei2.m10039H("params");
            throw null;
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        zm5 zm5Var = this.f14271q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(zm5Var);
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: w */
    public final void mo11352w() {
        super.mo11352w();
        zm5 zm5Var = this.f14271q;
        if (zm5Var != null) {
            m11358D(zm5Var, null);
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: x */
    public final void mo11353x() {
        super.mo11353x();
        zm5 zm5Var = this.f14271q;
        if (zm5Var != null) {
            WindowManager.LayoutParams layoutParams = this.f14272r;
            if (layoutParams != null) {
                m11361H(zm5Var, layoutParams, null);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        }
    }
}
