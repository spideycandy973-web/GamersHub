package frb.axeron.configs;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import p000.C0972fl;
import p000.fn5;
import p000.ls0;
import p000.v86;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class PresetsImportActivity extends Activity {

    /* renamed from: a */
    public final ls0 f14270a = fn5.m11131h();

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        String action = intent.getAction();
        Uri data = intent.getData();
        if (!"android.intent.action.VIEW".equals(action) || data == null) {
            finish();
        } else {
            v86.m21284K(this.f14270a, null, null, new C0972fl(this, data, null, (byte) 11), 3);
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        fn5.m11133j(this.f14270a, null);
    }
}
