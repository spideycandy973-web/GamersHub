package frb.axeron.angle.probe;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.ResultReceiver;
import p000.RunnableC1625ul;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class AngleProbeService extends Service {

    /* renamed from: a */
    public static final /* synthetic */ int f14244a = 0;

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        new Thread(new RunnableC1625ul(intent != null ? (ResultReceiver) intent.getParcelableExtra("receiver") : null, this, i2, (byte) 0)).start();
        return 2;
    }
}
