package frb.axeron.angle.probe;

import com.unity3d.services.UnityAdsConstants;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p000.AbstractC0946ew;
import p000.C0930ei;
import p000.C0931ej;
import p000.ci1;
import p000.dg2;
import p000.g24;
import p000.i24;
import p000.i85;
import p000.md4;
import p000.mg2;
import p000.nd4;
import p000.sg2;
import p000.tg2;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public abstract class AngleNativeProbe {

    /* renamed from: a */
    public static final i85 f14243a = new i85(new C0931ej(10));

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v2, types: [ci1] */
    /* JADX WARN: Type inference failed for: r5v3 */
    /* JADX WARN: Type inference failed for: r5v9, types: [java.util.ArrayList] */
    /* renamed from: a */
    public static g24 m11324a() {
        Object md4Var;
        i24 i24Var;
        ?? r5;
        C0930ei c0930ei;
        if (!((Boolean) f14243a.getValue()).booleanValue()) {
            return new g24(i24.f18098g, (String) null, (String) null, (String) null, false, (String) null, (String) null, (List) null, "libaxangleprobe.so failed to load", 254);
        }
        try {
            md4Var = nativeProbe();
        } catch (Throwable th) {
            md4Var = new md4(th);
        }
        Throwable m16656b = nd4.m16656b(md4Var);
        if (m16656b != null) {
            i24 i24Var2 = i24.f18101j;
            String message = m16656b.getMessage();
            return new g24(i24Var2, (String) null, (String) null, (String) null, false, (String) null, (String) null, (List) null, message == null ? "" : message, 254);
        }
        String[] strArr = (String[]) md4Var;
        if (strArr == null) {
            return new g24(i24.f18101j, (String) null, (String) null, (String) null, false, (String) null, (String) null, (List) null, "native probe returned null", 254);
        }
        String str = (String) AbstractC0946ew.m10542X0(0, strArr);
        if (str == null) {
            str = "";
        }
        switch (str.hashCode()) {
            case -1627743844:
                if (str.equals("no_entrypoint")) {
                    i24Var = i24.f18095d;
                    break;
                }
                i24Var = i24.f18101j;
                break;
            case 3548:
                if (str.equals("ok")) {
                    i24Var = i24.f18093b;
                    break;
                }
                i24Var = i24.f18101j;
                break;
            case 829389892:
                if (str.equals("no_display")) {
                    i24Var = i24.f18097f;
                    break;
                }
                i24Var = i24.f18101j;
                break;
            case 1256440173:
                if (str.equals("count_failed")) {
                    i24Var = i24.f18096e;
                    break;
                }
                i24Var = i24.f18101j;
                break;
            case 1614587713:
                if (str.equals("no_extension")) {
                    i24Var = i24.f18094c;
                    break;
                }
                i24Var = i24.f18101j;
                break;
            default:
                i24Var = i24.f18101j;
                break;
        }
        i24 i24Var3 = i24Var;
        if (strArr.length > 8) {
            sg2 m9087R = dg2.m9087R(dg2.m9089U(8, strArr.length), 4);
            r5 = new ArrayList();
            Iterator it = m9087R.iterator();
            while (((tg2) it).f37002c) {
                int nextInt = ((mg2) it).nextInt();
                String str2 = (String) AbstractC0946ew.m10542X0(nextInt, strArr);
                if (str2 == null) {
                    str2 = "";
                }
                if (str2.length() == 0) {
                    c0930ei = null;
                } else {
                    String str3 = (String) AbstractC0946ew.m10542X0(nextInt + 1, strArr);
                    if (str3 == null) {
                        str3 = "";
                    }
                    String str4 = (String) AbstractC0946ew.m10542X0(nextInt + 2, strArr);
                    if (str4 == null) {
                        str4 = "";
                    }
                    String str5 = (String) AbstractC0946ew.m10542X0(nextInt + 3, strArr);
                    if (str5 == null) {
                        str5 = "";
                    }
                    c0930ei = new C0930ei(str2, str3, str4, str5);
                }
                if (c0930ei != null) {
                    r5.add(c0930ei);
                }
            }
        } else {
            r5 = ci1.f4141a;
        }
        List list = r5;
        String str6 = (String) AbstractC0946ew.m10542X0(1, strArr);
        if (str6 == null) {
            str6 = "";
        }
        String str7 = (String) AbstractC0946ew.m10542X0(2, strArr);
        if (str7 == null) {
            str7 = "";
        }
        String str8 = (String) AbstractC0946ew.m10542X0(3, strArr);
        if (str8 == null) {
            str8 = "";
        }
        String str9 = (String) AbstractC0946ew.m10542X0(4, strArr);
        if (str9 == null) {
            str9 = "";
        }
        boolean equals = str9.equals(UnityAdsConstants.OpenMeasurement.OM_PARTNER_VERSION);
        String str10 = (String) AbstractC0946ew.m10542X0(5, strArr);
        String str11 = str10 == null ? "" : str10;
        String str12 = (String) AbstractC0946ew.m10542X0(6, strArr);
        return new g24(i24Var3, str6, str7, str8, equals, str11, str12 == null ? "" : str12, list, (String) null, 256);
    }

    private static final native String[] nativeProbe();
}
