package frb.axeron.angle.session;

import android.os.Bundle;
import android.util.Log;
import frb.axeron.base.FeatureFactoryBase;
import p000.C1152ij;
import p000.C1509rm;
import p000.C1655v4;
import p000.a45;
import p000.au2;
import p000.bt4;
import p000.hn0;
import p000.ka1;
import p000.m35;
import p000.n22;
import p000.ns0;
import p000.r41;
import p000.uf3;
import p000.v86;
import p000.w31;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class AngleSessionFeature extends FeatureFactoryBase {

    /* renamed from: k */
    public final uf3 f14245k = new uf3();

    /* renamed from: l */
    public m35 f14246l;

    /* renamed from: m */
    public boolean f14247m;

    /* renamed from: G */
    public static void m11325G(String str, String str2, String str3) {
        StringBuilder m12943p = hn0.m12943p("[", str, "] ", str2, " ");
        m12943p.append(str3);
        Log.i("AngleSessionFeature", m12943p.toString());
        C1152ij c1152ij = C1152ij.f18685a;
        bt4 bt4Var = new bt4(str, str2, str3, null);
        a45 a45Var = C1152ij.f18705u;
        a45Var.getClass();
        a45Var.m94l(null, bt4Var);
    }

    /* renamed from: H */
    public static /* synthetic */ void m11326H(AngleSessionFeature angleSessionFeature, String str, String str2) {
        angleSessionFeature.getClass();
        m11325G(str, str2, "");
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x002e  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* renamed from: C */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11327C(p000.eq3 r7, p000.os0 r8) {
        /*
            r6 = this;
            boolean r0 = r8 instanceof p000.C1194jm
            if (r0 == 0) goto L13
            r0 = r8
            jm r0 = (p000.C1194jm) r0
            int r1 = r0.f20426d
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f20426d = r1
            goto L18
        L13:
            jm r0 = new jm
            r0.<init>(r6, r8)
        L18:
            java.lang.Object r8 = r0.f20424b
            int r1 = r0.f20426d
            r2 = 0
            r3 = 1
            if (r1 == 0) goto L2e
            if (r1 != r3) goto L28
            eq3 r7 = r0.f20423a
            p000.v86.m21297X(r8)
            goto L44
        L28:
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r6)
            return r2
        L2e:
            p000.v86.m21297X(r8)
            ij r8 = p000.C1152ij.f18685a
            ni r8 = p000.C1152ij.m13384e()
            r0.f20423a = r7
            r0.f20426d = r3
            java.lang.Object r8 = r8.m16745b(r7, r0)
            nu0 r0 = p000.nu0.f28013a
            if (r8 != r0) goto L44
            return r0
        L44:
            f70 r8 = (p000.f70) r8
            boolean r0 = r8 instanceof p000.c70
            if (r0 == 0) goto L4d
            r6.f14247m = r3
            goto L76
        L4d:
            boolean r6 = r8 instanceof p000.e70
            if (r6 == 0) goto L67
            java.lang.String r6 = r7.f12380a
            e70 r8 = (p000.e70) r8
            java.util.ArrayList r0 = r8.f11396a
            r4 = 0
            r5 = 63
            r1 = 0
            r2 = 0
            r3 = 0
            java.lang.String r7 = p000.ij0.m13408l0(r0, r1, r2, r3, r4, r5)
            java.lang.String r8 = "overrides_rejected"
            m11325G(r6, r8, r7)
            goto L76
        L67:
            boolean r6 = r8 instanceof p000.d70
            if (r6 == 0) goto L79
            java.lang.String r6 = r7.f12380a
            d70 r8 = (p000.d70) r8
            java.lang.String r7 = r8.f9899a
            java.lang.String r8 = "overrides_failed"
            m11325G(r6, r8, r7)
        L76:
            kn5 r6 = p000.kn5.f22076a
            return r6
        L79:
            p000.vy1.m21774a()
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.angle.session.AngleSessionFeature.m11327C(eq3, os0):java.lang.Object");
    }

    /* JADX WARN: Code restructure failed: missing block: B:28:0x00b3, code lost:
    
        if (r9 == r5) goto L36;
     */
    /* JADX WARN: Removed duplicated region for block: B:19:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0072  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0038  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    /* renamed from: D */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11328D(java.lang.String r8, p000.os0 r9) {
        /*
            r7 = this;
            boolean r0 = r9 instanceof p000.C1235km
            if (r0 == 0) goto L13
            r0 = r9
            km r0 = (p000.C1235km) r0
            int r1 = r0.f22051d
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f22051d = r1
            goto L18
        L13:
            km r0 = new km
            r0.<init>(r7, r9)
        L18:
            java.lang.Object r9 = r0.f22049b
            int r1 = r0.f22051d
            r2 = 1
            r3 = 2
            r4 = 0
            nu0 r5 = p000.nu0.f28013a
            if (r1 == 0) goto L38
            if (r1 == r2) goto L32
            if (r1 != r3) goto L2c
            p000.v86.m21297X(r9)
            goto Lb6
        L2c:
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r7)
            return r4
        L32:
            android.content.Intent r7 = r0.f22048a
            p000.v86.m21297X(r9)
            goto L67
        L38:
            p000.v86.m21297X(r9)
            android.content.Context r9 = r7.m11348p()
            android.content.pm.PackageManager r9 = r9.getPackageManager()
            android.content.Intent r8 = r9.getLaunchIntentForPackage(r8)
            if (r8 == 0) goto L4f
            r9 = 268500992(0x10010000, float:2.5440764E-29)
            r8.addFlags(r9)
            goto L50
        L4f:
            r8 = r4
        L50:
            if (r8 == 0) goto L73
            r41 r9 = p000.ka1.f21425a
            c62 r9 = p000.j03.f19481a
            lm r1 = new lm
            r6 = 0
            r1.<init>(r7, r8, r4, r6)
            r0.f22048a = r8
            r0.f22051d = r2
            java.lang.Object r9 = p000.v86.m21301a0(r9, r1, r0)
            if (r9 == r5) goto Lb5
            r7 = r8
        L67:
            java.lang.Boolean r9 = (java.lang.Boolean) r9
            boolean r8 = r9.booleanValue()
            if (r8 == 0) goto L72
            java.lang.Boolean r7 = java.lang.Boolean.TRUE
            return r7
        L72:
            r8 = r7
        L73:
            if (r8 == 0) goto Lc1
            android.content.ComponentName r7 = r8.getComponent()
            if (r7 == 0) goto Lc1
            java.lang.String r7 = r7.flattenToShortString()
            if (r7 == 0) goto Lc1
            ij r8 = p000.C1152ij.f18685a
            java.lang.String r8 = "'\\''"
            java.lang.String r9 = "'"
            java.lang.String r7 = p000.m55.m15784f0(r7, r9, r8)
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>(r9)
            r8.append(r7)
            r8.append(r9)
            java.lang.String r7 = r8.toString()
            java.lang.String r8 = "am start -n "
            java.lang.String r7 = r8.concat(r7)
            r0.f22048a = r4
            r0.f22051d = r3
            r41 r8 = p000.ka1.f21425a
            w31 r8 = p000.w31.f41501b
            f30 r9 = new f30
            r1 = 10000(0x2710, double:4.9407E-320)
            r9.<init>(r7, r1, r4)
            java.lang.Object r9 = p000.v86.m21301a0(r8, r9, r0)
            if (r9 != r5) goto Lb6
        Lb5:
            return r5
        Lb6:
            hw4 r9 = (p000.hw4) r9
            boolean r7 = r9.m13091a()
            java.lang.Boolean r7 = java.lang.Boolean.valueOf(r7)
            return r7
        Lc1:
            java.lang.Boolean r7 = java.lang.Boolean.FALSE
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.angle.session.AngleSessionFeature.m11328D(java.lang.String, os0):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x00a6  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00c6  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00ce  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0029  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00b9 -> B:11:0x00be). Please report as a decompilation issue!!! */
    /* renamed from: E */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11329E(java.lang.String r18, p000.C1752xl r19, p000.os0 r20) {
        /*
            Method dump skipped, instructions count: 263
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.angle.session.AngleSessionFeature.m11329E(java.lang.String, xl, os0):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0071  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0030  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* renamed from: F */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11330F(java.lang.String r6, p000.jy1 r7, p000.os0 r8) {
        /*
            r5 = this;
            boolean r0 = r8 instanceof p000.C1353nm
            if (r0 == 0) goto L13
            r0 = r8
            nm r0 = (p000.C1353nm) r0
            int r1 = r0.f27692e
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f27692e = r1
            goto L18
        L13:
            nm r0 = new nm
            r0.<init>(r5, r8)
        L18:
            java.lang.Object r8 = r0.f27690c
            int r1 = r0.f27692e
            r2 = 0
            r3 = 1
            if (r1 == 0) goto L30
            if (r1 != r3) goto L2a
            jy1 r7 = r0.f27689b
            java.lang.String r6 = r0.f27688a
            p000.v86.m21297X(r8)
            goto L48
        L2a:
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r5)
            return r2
        L30:
            p000.v86.m21297X(r8)
            ij r8 = p000.C1152ij.f18685a
            ni r8 = p000.C1152ij.m13384e()
            r0.f27688a = r6
            r0.f27689b = r7
            r0.f27692e = r3
            java.lang.Object r8 = r8.m16746c(r0)
            nu0 r0 = p000.nu0.f28013a
            if (r8 != r0) goto L48
            return r0
        L48:
            id4 r8 = (p000.id4) r8
            java.util.List r0 = r8.f18466c
            boolean r0 = r0.isEmpty()
            r0 = r0 ^ r3
            r5.f14247m = r0
            iy1 r5 = r7.f20919a
            java.lang.String r5 = r5.name()
            java.util.Locale r0 = java.util.Locale.ROOT
            java.lang.String r5 = r5.toLowerCase(r0)
            r5.getClass()
            long r0 = r7.f20921c
            java.lang.String r7 = r7.f20920b
            if (r7 == 0) goto L71
            java.lang.String r3 = " ("
            java.lang.String r4 = ")"
            java.lang.String r7 = p000.hn0.m12936i(r3, r7, r4)
            goto L73
        L71:
            java.lang.String r7 = ""
        L73:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "props released after "
            r3.<init>(r4)
            r3.append(r5)
            java.lang.String r5 = " in "
            r3.append(r5)
            r3.append(r0)
            java.lang.String r5 = "ms"
            r3.append(r5)
            r3.append(r7)
            java.lang.String r5 = "; "
            r3.append(r5)
            r3.append(r8)
            java.lang.String r5 = r3.toString()
            ij r7 = p000.C1152ij.f18685a
            bt4 r7 = new bt4
            java.lang.String r8 = "released"
            r7.<init>(r6, r8, r5, r2)
            a45 r5 = p000.C1152ij.f18705u
            r5.getClass()
            r5.m94l(r2, r7)
            kn5 r5 = p000.kn5.f22076a
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.angle.session.AngleSessionFeature.m11330F(java.lang.String, jy1, os0):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0030  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* renamed from: I */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11331I(java.lang.String r6, p000.os0 r7) {
        /*
            r5 = this;
            boolean r0 = r7 instanceof p000.C1394om
            if (r0 == 0) goto L13
            r0 = r7
            om r0 = (p000.C1394om) r0
            int r1 = r0.f29037d
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f29037d = r1
            goto L18
        L13:
            om r0 = new om
            r0.<init>(r5, r7)
        L18:
            java.lang.Object r7 = r0.f29035b
            int r1 = r0.f29037d
            r2 = 0
            kn5 r3 = p000.kn5.f22076a
            r4 = 1
            if (r1 == 0) goto L30
            if (r1 != r4) goto L2a
            java.lang.String r6 = r0.f29034a
            p000.v86.m21297X(r7)
            goto L4b
        L2a:
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            p000.C0950f.m10585p(r5)
            return r2
        L30:
            p000.v86.m21297X(r7)
            boolean r7 = r5.f14247m
            if (r7 != 0) goto L38
            return r3
        L38:
            ij r7 = p000.C1152ij.f18685a
            ni r7 = p000.C1152ij.m13384e()
            r0.f29034a = r6
            r0.f29037d = r4
            java.lang.Object r7 = r7.m16746c(r0)
            nu0 r0 = p000.nu0.f28013a
            if (r7 != r0) goto L4b
            return r0
        L4b:
            id4 r7 = (p000.id4) r7
            java.util.List r0 = r7.f18466c
            boolean r0 = r0.isEmpty()
            r0 = r0 ^ r4
            r5.f14247m = r0
            ij r5 = p000.C1152ij.f18685a
            v74 r5 = p000.C1152ij.f18706v
            ff3 r5 = r5.f39911a
            a45 r5 = (p000.a45) r5
            java.lang.Object r5 = r5.getValue()
            bt4 r5 = (p000.bt4) r5
            bt4 r0 = new bt4
            java.lang.String r7 = r7.toString()
            if (r5 == 0) goto L6f
            vr5 r5 = r5.f3000d
            goto L70
        L6f:
            r5 = r2
        L70:
            java.lang.String r1 = "restored"
            r0.<init>(r6, r1, r7, r5)
            a45 r5 = p000.C1152ij.f18705u
            r5.getClass()
            r5.m94l(r2, r0)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.angle.session.AngleSessionFeature.m11331I(java.lang.String, os0):java.lang.Object");
    }

    /* JADX WARN: Can't wrap try/catch for region: R(9:145|146|(3:148|(1:150)|(6:152|(1:154)|155|156|157|(20:159|38|39|40|41|42|(1:44)|45|(1:47)|48|49|(1:51)(15:87|88|89|90|(1:109)(1:93)|94|95|(1:97)(2:98|(1:100)(2:101|(1:(1:106))(1:104)))|53|54|(3:56|(1:58)(1:61)|59)(3:62|63|(3:65|(1:67)(1:69)|68)(2:70|(3:72|(1:74)(1:76)|75)(2:77|(8:83|84|(1:86)|20|21|22|23|(1:25)(1:26))(2:81|82))))|60|22|23|(0)(0))|52|53|54|(0)(0)|60|22|23|(0)(0))))|163|(0)|155|156|157|(0)) */
    /* JADX WARN: Code restructure failed: missing block: B:161:0x076a, code lost:
    
        r0 = th;
     */
    /* JADX WARN: Code restructure failed: missing block: B:162:0x076b, code lost:
    
        r13 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:243:0x0510, code lost:
    
        if (p000.v86.m21301a0(r4, r5, r6) != r14) goto L185;
     */
    /* JADX WARN: Code restructure failed: missing block: B:245:0x089d, code lost:
    
        return r15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:274:0x0498, code lost:
    
        if (r1.f16678a >= 16) goto L173;
     */
    /* JADX WARN: Code restructure failed: missing block: B:308:0x043a, code lost:
    
        if (p000.u99.m20782z(1000, r6) == r14) goto L266;
     */
    /* JADX WARN: Code restructure failed: missing block: B:316:0x0411, code lost:
    
        if (p000.v86.m21301a0(p000.w31.f41501b, new p000.f30(r3, 10000, null), r6) == r14) goto L266;
     */
    /* JADX WARN: Code restructure failed: missing block: B:337:0x0395, code lost:
    
        if (m11327C(r8, r6) == r14) goto L266;
     */
    /* JADX WARN: Code restructure failed: missing block: B:338:0x03c4, code lost:
    
        r5 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:344:0x03c2, code lost:
    
        if (m11327C(r8, r6) != r14) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:358:0x027b, code lost:
    
        if (m11328D(r1, r6) == r14) goto L266;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0036  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x0090  */
    /* JADX WARN: Removed duplicated region for block: B:128:0x06a5 A[Catch: all -> 0x08b2, TryCatch #11 {all -> 0x08b2, blocks: (B:18:0x0055, B:42:0x0772, B:45:0x0777, B:47:0x077b, B:48:0x0780, B:117:0x076c, B:128:0x06a5, B:130:0x06ab, B:132:0x06b7, B:134:0x06bf, B:137:0x06cc, B:146:0x0713, B:148:0x071d, B:152:0x0728, B:155:0x0730, B:169:0x066a, B:186:0x05dd, B:188:0x05e5, B:189:0x0636, B:192:0x0641, B:196:0x05f5, B:223:0x053a, B:225:0x053e, B:228:0x054e, B:239:0x04dc, B:241:0x04e4, B:246:0x0516, B:284:0x047e, B:290:0x01e1, B:291:0x043c, B:306:0x01f2, B:307:0x041c), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:130:0x06ab A[Catch: all -> 0x08b2, TryCatch #11 {all -> 0x08b2, blocks: (B:18:0x0055, B:42:0x0772, B:45:0x0777, B:47:0x077b, B:48:0x0780, B:117:0x076c, B:128:0x06a5, B:130:0x06ab, B:132:0x06b7, B:134:0x06bf, B:137:0x06cc, B:146:0x0713, B:148:0x071d, B:152:0x0728, B:155:0x0730, B:169:0x066a, B:186:0x05dd, B:188:0x05e5, B:189:0x0636, B:192:0x0641, B:196:0x05f5, B:223:0x053a, B:225:0x053e, B:228:0x054e, B:239:0x04dc, B:241:0x04e4, B:246:0x0516, B:284:0x047e, B:290:0x01e1, B:291:0x043c, B:306:0x01f2, B:307:0x041c), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:13:0x003c  */
    /* JADX WARN: Removed duplicated region for block: B:145:0x070f  */
    /* JADX WARN: Removed duplicated region for block: B:154:0x072e  */
    /* JADX WARN: Removed duplicated region for block: B:159:0x075c  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0043  */
    /* JADX WARN: Removed duplicated region for block: B:164:0x06a8  */
    /* JADX WARN: Removed duplicated region for block: B:165:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:171:0x068b  */
    /* JADX WARN: Removed duplicated region for block: B:176:0x00d7  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0047  */
    /* JADX WARN: Removed duplicated region for block: B:183:0x05a9 A[Catch: all -> 0x0629, TRY_LEAVE, TryCatch #3 {all -> 0x0629, blocks: (B:181:0x059d, B:183:0x05a9), top: B:180:0x059d }] */
    /* JADX WARN: Removed duplicated region for block: B:188:0x05e5 A[Catch: all -> 0x08b2, TryCatch #11 {all -> 0x08b2, blocks: (B:18:0x0055, B:42:0x0772, B:45:0x0777, B:47:0x077b, B:48:0x0780, B:117:0x076c, B:128:0x06a5, B:130:0x06ab, B:132:0x06b7, B:134:0x06bf, B:137:0x06cc, B:146:0x0713, B:148:0x071d, B:152:0x0728, B:155:0x0730, B:169:0x066a, B:186:0x05dd, B:188:0x05e5, B:189:0x0636, B:192:0x0641, B:196:0x05f5, B:223:0x053a, B:225:0x053e, B:228:0x054e, B:239:0x04dc, B:241:0x04e4, B:246:0x0516, B:284:0x047e, B:290:0x01e1, B:291:0x043c, B:306:0x01f2, B:307:0x041c), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:191:0x063c  */
    /* JADX WARN: Removed duplicated region for block: B:194:0x0662  */
    /* JADX WARN: Removed duplicated region for block: B:195:0x063f  */
    /* JADX WARN: Removed duplicated region for block: B:196:0x05f5 A[Catch: all -> 0x08b2, TryCatch #11 {all -> 0x08b2, blocks: (B:18:0x0055, B:42:0x0772, B:45:0x0777, B:47:0x077b, B:48:0x0780, B:117:0x076c, B:128:0x06a5, B:130:0x06ab, B:132:0x06b7, B:134:0x06bf, B:137:0x06cc, B:146:0x0713, B:148:0x071d, B:152:0x0728, B:155:0x0730, B:169:0x066a, B:186:0x05dd, B:188:0x05e5, B:189:0x0636, B:192:0x0641, B:196:0x05f5, B:223:0x053a, B:225:0x053e, B:228:0x054e, B:239:0x04dc, B:241:0x04e4, B:246:0x0516, B:284:0x047e, B:290:0x01e1, B:291:0x043c, B:306:0x01f2, B:307:0x041c), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:199:0x0625  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x010e  */
    /* JADX WARN: Removed duplicated region for block: B:207:0x0143  */
    /* JADX WARN: Removed duplicated region for block: B:220:0x015e  */
    /* JADX WARN: Removed duplicated region for block: B:225:0x053e A[Catch: all -> 0x08b2, TryCatch #11 {all -> 0x08b2, blocks: (B:18:0x0055, B:42:0x0772, B:45:0x0777, B:47:0x077b, B:48:0x0780, B:117:0x076c, B:128:0x06a5, B:130:0x06ab, B:132:0x06b7, B:134:0x06bf, B:137:0x06cc, B:146:0x0713, B:148:0x071d, B:152:0x0728, B:155:0x0730, B:169:0x066a, B:186:0x05dd, B:188:0x05e5, B:189:0x0636, B:192:0x0641, B:196:0x05f5, B:223:0x053a, B:225:0x053e, B:228:0x054e, B:239:0x04dc, B:241:0x04e4, B:246:0x0516, B:284:0x047e, B:290:0x01e1, B:291:0x043c, B:306:0x01f2, B:307:0x041c), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:232:0x0698  */
    /* JADX WARN: Removed duplicated region for block: B:233:0x017e  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x018c  */
    /* JADX WARN: Removed duplicated region for block: B:241:0x04e4 A[Catch: all -> 0x08b2, TRY_LEAVE, TryCatch #11 {all -> 0x08b2, blocks: (B:18:0x0055, B:42:0x0772, B:45:0x0777, B:47:0x077b, B:48:0x0780, B:117:0x076c, B:128:0x06a5, B:130:0x06ab, B:132:0x06b7, B:134:0x06bf, B:137:0x06cc, B:146:0x0713, B:148:0x071d, B:152:0x0728, B:155:0x0730, B:169:0x066a, B:186:0x05dd, B:188:0x05e5, B:189:0x0636, B:192:0x0641, B:196:0x05f5, B:223:0x053a, B:225:0x053e, B:228:0x054e, B:239:0x04dc, B:241:0x04e4, B:246:0x0516, B:284:0x047e, B:290:0x01e1, B:291:0x043c, B:306:0x01f2, B:307:0x041c), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:246:0x0516 A[Catch: all -> 0x08b2, TRY_ENTER, TryCatch #11 {all -> 0x08b2, blocks: (B:18:0x0055, B:42:0x0772, B:45:0x0777, B:47:0x077b, B:48:0x0780, B:117:0x076c, B:128:0x06a5, B:130:0x06ab, B:132:0x06b7, B:134:0x06bf, B:137:0x06cc, B:146:0x0713, B:148:0x071d, B:152:0x0728, B:155:0x0730, B:169:0x066a, B:186:0x05dd, B:188:0x05e5, B:189:0x0636, B:192:0x0641, B:196:0x05f5, B:223:0x053a, B:225:0x053e, B:228:0x054e, B:239:0x04dc, B:241:0x04e4, B:246:0x0516, B:284:0x047e, B:290:0x01e1, B:291:0x043c, B:306:0x01f2, B:307:0x041c), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:252:0x01b1  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:262:0x048a  */
    /* JADX WARN: Removed duplicated region for block: B:268:0x04d1  */
    /* JADX WARN: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:270:0x0490 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:289:0x01d5  */
    /* JADX WARN: Removed duplicated region for block: B:305:0x01e6  */
    /* JADX WARN: Removed duplicated region for block: B:309:0x01f7  */
    /* JADX WARN: Removed duplicated region for block: B:315:0x03cc A[Catch: all -> 0x0419, TRY_ENTER, TRY_LEAVE, TryCatch #15 {all -> 0x0419, blocks: (B:124:0x00a4, B:311:0x0210, B:315:0x03cc, B:323:0x021f, B:325:0x02e5, B:328:0x0310, B:330:0x031b, B:333:0x0323, B:335:0x033a, B:336:0x037c, B:339:0x0350, B:343:0x03a3, B:347:0x0232), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:321:0x01fa  */
    /* JADX WARN: Removed duplicated region for block: B:322:0x0215  */
    /* JADX WARN: Removed duplicated region for block: B:328:0x0310 A[Catch: all -> 0x0419, TRY_ENTER, TryCatch #15 {all -> 0x0419, blocks: (B:124:0x00a4, B:311:0x0210, B:315:0x03cc, B:323:0x021f, B:325:0x02e5, B:328:0x0310, B:330:0x031b, B:333:0x0323, B:335:0x033a, B:336:0x037c, B:339:0x0350, B:343:0x03a3, B:347:0x0232), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:330:0x031b A[Catch: all -> 0x0419, TRY_LEAVE, TryCatch #15 {all -> 0x0419, blocks: (B:124:0x00a4, B:311:0x0210, B:315:0x03cc, B:323:0x021f, B:325:0x02e5, B:328:0x0310, B:330:0x031b, B:333:0x0323, B:335:0x033a, B:336:0x037c, B:339:0x0350, B:343:0x03a3, B:347:0x0232), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:333:0x0323 A[Catch: all -> 0x0419, TRY_ENTER, TryCatch #15 {all -> 0x0419, blocks: (B:124:0x00a4, B:311:0x0210, B:315:0x03cc, B:323:0x021f, B:325:0x02e5, B:328:0x0310, B:330:0x031b, B:333:0x0323, B:335:0x033a, B:336:0x037c, B:339:0x0350, B:343:0x03a3, B:347:0x0232), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:33:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:340:0x0399  */
    /* JADX WARN: Removed duplicated region for block: B:345:0x031e  */
    /* JADX WARN: Removed duplicated region for block: B:346:0x0228  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x005f  */
    /* JADX WARN: Removed duplicated region for block: B:351:0x023b  */
    /* JADX WARN: Removed duplicated region for block: B:353:0x0241  */
    /* JADX WARN: Removed duplicated region for block: B:357:0x026f  */
    /* JADX WARN: Removed duplicated region for block: B:359:0x027f  */
    /* JADX WARN: Removed duplicated region for block: B:382:0x024a  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0776  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x077b A[Catch: all -> 0x08b2, TryCatch #11 {all -> 0x08b2, blocks: (B:18:0x0055, B:42:0x0772, B:45:0x0777, B:47:0x077b, B:48:0x0780, B:117:0x076c, B:128:0x06a5, B:130:0x06ab, B:132:0x06b7, B:134:0x06bf, B:137:0x06cc, B:146:0x0713, B:148:0x071d, B:152:0x0728, B:155:0x0730, B:169:0x066a, B:186:0x05dd, B:188:0x05e5, B:189:0x0636, B:192:0x0641, B:196:0x05f5, B:223:0x053a, B:225:0x053e, B:228:0x054e, B:239:0x04dc, B:241:0x04e4, B:246:0x0516, B:284:0x047e, B:290:0x01e1, B:291:0x043c, B:306:0x01f2, B:307:0x041c), top: B:8:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0790  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x07c8 A[Catch: all -> 0x08a2, TRY_ENTER, TryCatch #0 {all -> 0x08a2, blocks: (B:53:0x07c0, B:56:0x07c8, B:58:0x07d0, B:59:0x07d6, B:62:0x07e2, B:65:0x07ea, B:67:0x07f0, B:68:0x07f6, B:70:0x0802, B:72:0x0808, B:74:0x080e, B:75:0x0814, B:77:0x0823, B:79:0x0829, B:81:0x082f, B:82:0x0835, B:83:0x0836, B:95:0x07a7, B:98:0x07ad, B:101:0x07b3), top: B:94:0x07a7 }] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x07e2 A[Catch: all -> 0x08a2, TRY_LEAVE, TryCatch #0 {all -> 0x08a2, blocks: (B:53:0x07c0, B:56:0x07c8, B:58:0x07d0, B:59:0x07d6, B:62:0x07e2, B:65:0x07ea, B:67:0x07f0, B:68:0x07f6, B:70:0x0802, B:72:0x0808, B:74:0x080e, B:75:0x0814, B:77:0x0823, B:79:0x0829, B:81:0x082f, B:82:0x0835, B:83:0x0836, B:95:0x07a7, B:98:0x07ad, B:101:0x07b3), top: B:94:0x07a7 }] */
    /* JADX WARN: Removed duplicated region for block: B:87:0x0796  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:193:0x061c -> B:174:0x010a). Please report as a decompilation issue!!! */
    /* renamed from: J */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11332J(java.lang.String r32, p000.os0 r33) {
        /*
            Method dump skipped, instructions count: 2332
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.angle.session.AngleSessionFeature.m11332J(java.lang.String, os0):java.lang.Object");
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        String string;
        super.mo11333t(bundle);
        if (bundle == null || (string = bundle.getString("package")) == null) {
            return;
        }
        m35 m35Var = this.f14246l;
        au2 m11349q = m11349q();
        r41 r41Var = ka1.f21425a;
        this.f14246l = v86.m21284K(m11349q, w31.f41501b, null, new C1509rm(m35Var, this, string, (ns0) null), 2);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        if (this.f14247m) {
            r41 r41Var = ka1.f21425a;
            v86.m21284K(n22.f26792a, w31.f41501b, null, new C1655v4(2, null, (byte) 3), 2);
        }
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: v */
    public final void mo11335v(Bundle bundle) {
        String string = bundle.getString("package");
        if (string != null) {
            m35 m35Var = this.f14246l;
            au2 m11349q = m11349q();
            r41 r41Var = ka1.f21425a;
            this.f14246l = v86.m21284K(m11349q, w31.f41501b, null, new C1509rm(m35Var, this, string, (ns0) null), 2);
        }
    }
}
