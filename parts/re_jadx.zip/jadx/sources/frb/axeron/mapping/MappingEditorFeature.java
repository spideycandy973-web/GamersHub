package frb.axeron.mapping;

import android.content.Context;
import android.graphics.DashPathEffect;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import androidx.compose.p003ui.input.pointer.PointerInputEventHandler;
import com.applovin.shadow.okhttp3.internal.http2.Http2;
import com.applovin.shadow.okio.Segment;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.manager.Axeron;
import frb.axeron.mapping.MappingEditorFeature;
import frb.axeron.mapping.mouse.MouseCursorFeature;
import frb.axeron.mapping.pipeline.MappingVisualFeature;
import frb.axeron.mapping.pipeline.MappingVisualLegacyFeature;
import frb.axeron.redcorner.R;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import p000.AbstractC0871d6;
import p000.AbstractC1499rc;
import p000.C0085bl;
import p000.C0962fb;
import p000.C0983fu;
import p000.C1163iv;
import p000.C1503rg;
import p000.C1540sg;
import p000.C1640us;
import p000.C1792yj;
import p000.b62;
import p000.ba4;
import p000.bz5;
import p000.c43;
import p000.ce3;
import p000.cl5;
import p000.d63;
import p000.dg2;
import p000.di2;
import p000.ds3;
import p000.ef3;
import p000.ei2;
import p000.f05;
import p000.fy4;
import p000.g33;
import p000.gm0;
import p000.hl3;
import p000.hn0;
import p000.hp1;
import p000.id1;
import p000.ij0;
import p000.it3;
import p000.j80;
import p000.jc3;
import p000.ji5;
import p000.jj0;
import p000.jq5;
import p000.k64;
import p000.ka3;
import p000.kn2;
import p000.kn5;
import p000.l90;
import p000.lh3;
import p000.lw9;
import p000.m12;
import p000.m84;
import p000.mg1;
import p000.mt7;
import p000.mx0;
import p000.n43;
import p000.n85;
import p000.na3;
import p000.nn1;
import p000.ns0;
import p000.nz1;
import p000.o43;
import p000.o60;
import p000.o63;
import p000.of5;
import p000.oua;
import p000.ov1;
import p000.ov3;
import p000.ov9;
import p000.po0;
import p000.pz1;
import p000.q75;
import p000.q90;
import p000.qj0;
import p000.ra5;
import p000.rc6;
import p000.rg2;
import p000.rj0;
import p000.s02;
import p000.s32;
import p000.s40;
import p000.sl5;
import p000.sn0;
import p000.sv8;
import p000.t23;
import p000.t61;
import p000.tf1;
import p000.tk5;
import p000.ts0;
import p000.tx3;
import p000.u23;
import p000.u43;
import p000.u62;
import p000.u75;
import p000.u99;
import p000.uj0;
import p000.ul1;
import p000.ul5;
import p000.v23;
import p000.v75;
import p000.v86;
import p000.w23;
import p000.w31;
import p000.wa1;
import p000.wj0;
import p000.wk0;
import p000.wo2;
import p000.x13;
import p000.xc0;
import p000.xe5;
import p000.xy1;
import p000.y13;
import p000.y53;
import p000.yn0;
import p000.yt0;
import p000.z13;
import p000.z80;
import p000.zg2;
import p000.zm5;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class MappingEditorFeature extends FloatingFactoryBase {

    /* renamed from: q */
    public zm5 f14336q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14337r;

    /* renamed from: v */
    public boolean f14341v;

    /* renamed from: w */
    public boolean f14342w;

    /* renamed from: s */
    public String f14338s = "";

    /* renamed from: t */
    public final f05 f14339t = new f05();

    /* renamed from: u */
    public final it3 f14340u = z80.m23867J("");

    /* renamed from: x */
    public final ReentrantLock f14343x = new ReentrantLock();

    /* renamed from: L */
    public static final float m11393L(ef3 ef3Var) {
        return ((Number) ef3Var.getValue()).floatValue();
    }

    /* renamed from: M */
    public static final float m11394M(ef3 ef3Var) {
        return ((Number) ef3Var.getValue()).floatValue();
    }

    /* renamed from: O */
    public static final void m11395O(ef3 ef3Var) {
        ef3Var.setValue(Boolean.FALSE);
    }

    /* renamed from: V */
    public static final void m11396V(boolean z, MappingEditorFeature mappingEditorFeature, int i, int i2, zy1 zy1Var) {
        if (z) {
            f05 f05Var = mappingEditorFeature.f14339t;
            if (i >= 0 && i < f05Var.size()) {
                x13 x13Var = (x13) f05Var.get(i);
                x13Var.getClass();
                f05Var.set(i, u43.m20653f(x13Var, i2, zy1Var));
            }
        } else {
            f05 f05Var2 = mappingEditorFeature.f14339t;
            if (i >= 0 && i < f05Var2.size()) {
                x13 x13Var2 = (x13) f05Var2.get(i);
                x13Var2.getClass();
                f05Var2.set(i, u43.m20654g(x13Var2, i2, zy1Var));
            }
        }
        mappingEditorFeature.m11413c0();
    }

    /* renamed from: a0 */
    public static final ra5 m11397a0(ra5 ra5Var, float f, int i, int i2) {
        float m9131s = dg2.m9131s(ra5Var.f33460h, 0.0f, f);
        float m9131s2 = dg2.m9131s(ra5Var.f33461i, 0.0f, f);
        int i3 = ra5Var.f33458f;
        int i4 = i3 < i ? i : i3;
        int i5 = ra5Var.f33459g;
        return ra5.m18937a(ra5Var, null, null, 0, 0, i4, i5 < i2 ? i2 : i5, m9131s, m9131s2, false, false, null, 3615);
    }

    /* renamed from: I */
    public final void m11398I(int i, int i2, x13 x13Var, float f, float f2, boolean z, xy1 xy1Var, s02 s02Var, int i3) {
        m84 m19342t;
        t23 t23Var;
        byte b;
        int i4;
        s02Var.m19312b0(1464345147);
        int i5 = i3 | (s02Var.m19315d(i) ? 4 : 2) | (s02Var.m19315d(i2) ? 32 : 16) | (s02Var.m19323h(x13Var) ? 256 : 128) | (s02Var.m19313c(f) ? 2048 : 1024) | (s02Var.m19313c(f2) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var.m19321g(z) ? 131072 : 65536) | (s02Var.m19323h(xy1Var) ? 1048576 : 524288) | (s02Var.m19323h(this) ? 8388608 : 4194304);
        byte b2 = 0;
        byte b3 = 1;
        if (s02Var.m19300R(i5 & 1, (4793491 & i5) != 4793490)) {
            ra5 ra5Var = (ra5) ij0.m13404h0(i2, x13Var.f43221d.f44649r);
            if (ra5Var == null) {
                m19342t = s02Var.m19342t();
                if (m19342t != null) {
                    t23Var = new t23(this, i, i2, x13Var, f, f2, z, xy1Var, i3, (byte) 0);
                    m19342t.f25420d = t23Var;
                }
                return;
            }
            ds3 m16200q = mt7.m16200q(ra5Var.f33454b, f, f2);
            float floatValue = ((Number) m16200q.f10834a).floatValue();
            float floatValue2 = ((Number) m16200q.f10835b).floatValue();
            t61 t61Var = (t61) s02Var.m19327j(po0.f30726h);
            boolean m19313c = s02Var.m19313c(floatValue) | s02Var.m19313c(floatValue2);
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (m19313c || m19298O == sv8Var) {
                m19298O = new C0983fu(floatValue, floatValue2, b3);
                s02Var.m19330k0(m19298O);
            }
            na3 m23858A = z80.m23858A(fy4.m11715k(ov9.m17421H(ka3.f21426a, (zy1) m19298O), t61Var.mo43P(50.0f)), z ? 1.0f : 0.7f);
            String str = x13Var.f43218a;
            String m8808o = d63.m8808o("alt_", i2);
            int i6 = 3670016 & i5;
            boolean z2 = i6 == 1048576;
            Object m19298O2 = s02Var.m19298O();
            if (z2 || m19298O2 == sv8Var) {
                m19298O2 = new n43(xy1Var, b2);
                s02Var.m19330k0(m19298O2);
            }
            PointerInputEventHandler pointerInputEventHandler = (PointerInputEventHandler) m19298O2;
            tx3 tx3Var = v75.f39912a;
            na3 mo14495d = m23858A.mo14495d(new u75(str, m8808o, null, pointerInputEventHandler, 4));
            boolean m19323h = s02Var.m19323h(this) | ((i5 & 14) == 4) | ((i5 & 112) == 32) | ((i5 & jq5.f20570g) == 2048) | ((i5 & 57344) == 16384);
            Object m19298O3 = s02Var.m19298O();
            if (m19323h || m19298O3 == sv8Var) {
                b = 0;
                m19298O3 = new u23(this, i, i2, f, f2, (byte) 0);
                i4 = i2;
                s02Var.m19330k0(m19298O3);
            } else {
                i4 = i2;
                b = 0;
            }
            zy1 zy1Var = (zy1) m19298O3;
            byte b4 = i6 == 1048576 ? (byte) 1 : b;
            Object m19298O4 = s02Var.m19298O();
            if (b4 != 0 || m19298O4 == sv8Var) {
                m19298O4 = new o43(xy1Var, null, b);
                s02Var.m19330k0(m19298O4);
            }
            nz1 nz1Var = (nz1) m19298O4;
            boolean m19323h2 = s02Var.m19323h(this);
            Object m19298O5 = s02Var.m19298O();
            if (m19323h2 || m19298O5 == sv8Var) {
                m19298O5 = new v23(this, b);
                s02Var.m19330k0(m19298O5);
            }
            m12.m15685a(mo14495d, 0L, 0.0f, 0.0f, 0L, false, zy1Var, nz1Var, (zy1) m19298O5, mt7.m16166P(-748582601, new w23(b, i4), s02Var), s02Var, 805306368, 62);
        } else {
            s02Var.m19303U();
        }
        m19342t = s02Var.m19342t();
        if (m19342t != null) {
            t23Var = new t23(this, i, i2, x13Var, f, f2, z, xy1Var, i3, (byte) 1);
            m19342t.f25420d = t23Var;
        }
    }

    /* renamed from: J */
    public final void m11399J(final int i, final x13 x13Var, final float f, final float f2, final boolean z, final xy1 xy1Var, final xy1 xy1Var2, final xy1 xy1Var3, s02 s02Var, final int i2) {
        s02 s02Var2;
        boolean z2;
        float f3;
        boolean z3;
        Object obj;
        ba4 ba4Var;
        final MappingEditorFeature mappingEditorFeature = this;
        s02Var.m19312b0(-1255174251);
        int i3 = i2 | (s02Var.m19315d(i) ? 4 : 2) | (s02Var.m19323h(x13Var) ? 32 : 16) | (s02Var.m19313c(f) ? 256 : 128) | (s02Var.m19313c(f2) ? 2048 : 1024) | (s02Var.m19321g(z) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var.m19323h(xy1Var) ? 131072 : 65536) | (s02Var.m19323h(xy1Var2) ? 1048576 : 524288) | (s02Var.m19323h(mappingEditorFeature) ? 67108864 : 33554432);
        byte b = 0;
        if (s02Var.m19300R(i3 & 1, (38347923 & i3) != 38347922)) {
            t61 t61Var = (t61) s02Var.m19327j(po0.f30726h);
            C1163iv m16194k = mt7.m16194k(x13Var, f, f2);
            String str = x13Var.f43218a;
            float mo43P = t61Var.mo43P(m16194k.f19305c);
            boolean m19323h = s02Var.m19323h(m16194k);
            Object m19298O = s02Var.m19298O();
            Object obj2 = yn0.f45724a;
            if (m19323h || m19298O == obj2) {
                m19298O = new c43(m16194k, b);
                s02Var.m19330k0(m19298O);
            }
            na3 m23858A = z80.m23858A(fy4.m11715k(ov9.m17421H(ka3.f21426a, (zy1) m19298O), mo43P), z ? 1.0f : 0.7f);
            o63 m15156c = l90.m15156c(mg1.f25859b, false);
            int hashCode = Long.hashCode(s02Var.f34520T);
            ov3 m19331l = s02Var.m19331l();
            na3 m20748R = u99.m20748R(s02Var, m23858A);
            sn0.f35689X8.getClass();
            s02Var.m19316d0();
            if (s02Var.f34519S) {
                s02Var.m19329k(wo2.f42501S);
            } else {
                s02Var.m19336n0();
            }
            z80.m23871N(oua.f29409h, s02Var, m15156c);
            z80.m23871N(oua.f29408g, s02Var, m19331l);
            z80.m23871N(oua.f29410i, s02Var, Integer.valueOf(hashCode));
            z80.m23869L(s02Var);
            z80.m23871N(oua.f29407f, s02Var, m20748R);
            hp1 hp1Var = fy4.f14736c;
            int i4 = 458752 & i3;
            boolean z4 = i4 == 131072;
            Object m19298O2 = s02Var.m19298O();
            if (z4 || m19298O2 == obj2) {
                m19298O2 = new n43(xy1Var, (byte) 1);
                s02Var.m19330k0(m19298O2);
            }
            na3 m21255a = v75.m21255a(hp1Var, str, (PointerInputEventHandler) m19298O2);
            int i5 = i3 & 14;
            int i6 = i3 & 896;
            boolean m19323h2 = s02Var.m19323h(mappingEditorFeature) | (i5 == 4) | (i6 == 256) | ((i3 & jq5.f20570g) == 2048);
            Object m19298O3 = s02Var.m19298O();
            if (m19323h2 || m19298O3 == obj2) {
                m19298O3 = new zy1() { // from class: d43
                    @Override // p000.zy1
                    public final Object invoke(Object obj3) {
                        q12 q12Var = (q12) obj3;
                        q12Var.getClass();
                        MappingEditorFeature.this.m11415e0(i, new by0(q12Var, f, f2));
                        return kn5.f22076a;
                    }
                };
                s02Var.m19330k0(m19298O3);
            }
            zy1 zy1Var = (zy1) m19298O3;
            boolean z5 = i4 == 131072;
            Object m19298O4 = s02Var.m19298O();
            ns0 ns0Var = null;
            if (z5 || m19298O4 == obj2) {
                m19298O4 = new o43(xy1Var, ns0Var, (byte) 1);
                s02Var.m19330k0(m19298O4);
            }
            nz1 nz1Var = (nz1) m19298O4;
            boolean m19323h3 = s02Var.m19323h(mappingEditorFeature);
            Object m19298O5 = s02Var.m19298O();
            if (m19323h3 || m19298O5 == obj2) {
                m19298O5 = new v23(mappingEditorFeature, (byte) 1);
                s02Var.m19330k0(m19298O5);
            }
            m12.m15685a(m21255a, 0L, 0.0f, 0.0f, 0L, false, zy1Var, nz1Var, (zy1) m19298O5, mt7.m16166P(197315667, new pz1() { // from class: e43
                @Override // p000.pz1
                public final Object invoke(Object obj3, Object obj4, Object obj5) {
                    s02 s02Var3 = (s02) obj4;
                    int intValue = ((Integer) obj5).intValue();
                    ((n12) obj3).getClass();
                    if (s02Var3.m19300R(intValue & 1, (intValue & 17) != 16)) {
                        mt7.m16179b(i, x13Var, z, null, s02Var3, 0);
                    } else {
                        s02Var3.m19303U();
                    }
                    return kn5.f22076a;
                }
            }, s02Var), s02Var, 805306368, 62);
            s02Var2 = s02Var;
            if (z) {
                s02Var2.m19308Z(261280453);
                y13 y13Var = x13Var.f43221d;
                if (y13Var.f44646o || y13Var.f44641j == tk5.f37204e || y13Var.f44651t != null) {
                    z2 = true;
                    f3 = mo43P;
                    s02Var2.m19308Z(262858291);
                    s02Var2.m19338p(false);
                } else {
                    s02Var2.m19308Z(261486944);
                    boolean m19319f = s02Var2.m19319f(str);
                    Object m19298O6 = s02Var2.m19298O();
                    if (m19319f || m19298O6 == obj2) {
                        m19298O6 = new ba4(null);
                        s02Var2.m19330k0(m19298O6);
                    }
                    final ba4 ba4Var2 = (ba4) m19298O6;
                    long j = ((uj0) s02Var2.m19327j(wj0.f42164a)).f38759a;
                    boolean m19323h4 = s02Var2.m19323h(ba4Var2) | s02Var2.m19323h(x13Var) | (i6 == 256) | s02Var2.m19323h(mappingEditorFeature) | (i5 == 4);
                    Object m19298O7 = s02Var2.m19298O();
                    if (m19323h4 || m19298O7 == obj2) {
                        z3 = true;
                        obj = obj2;
                        zy1 zy1Var2 = new zy1() { // from class: f43
                            @Override // p000.zy1
                            public final Object invoke(Object obj3) {
                                q12 q12Var = (q12) obj3;
                                q12Var.getClass();
                                long j2 = q12Var.f31213e;
                                ba4 ba4Var3 = ba4.this;
                                ds3 ds3Var = (ds3) ba4Var3.f2173a;
                                if (ds3Var == null) {
                                    ds3 ds3Var2 = new ds3(Float.valueOf(x13Var.f43221d.f44638g), new hl3(j2));
                                    ba4Var3.f2173a = ds3Var2;
                                    ds3Var = ds3Var2;
                                }
                                float floatValue = ((Number) ds3Var.f10834a).floatValue();
                                long m12818d = hl3.m12818d(j2, ((hl3) ds3Var.f10835b).f17327a);
                                mappingEditorFeature.m11415e0(i, new C1573t9((((Float.intBitsToFloat((int) (m12818d & 4294967295L)) + Float.intBitsToFloat((int) (m12818d >> 32))) * 0.70710677f) / f) + floatValue, (byte) 5));
                                return kn5.f22076a;
                            }
                        };
                        ba4Var = ba4Var2;
                        mappingEditorFeature = mappingEditorFeature;
                        s02Var2.m19330k0(zy1Var2);
                        m19298O7 = zy1Var2;
                    } else {
                        ba4Var = ba4Var2;
                        z3 = true;
                        obj = obj2;
                    }
                    zy1 zy1Var3 = (zy1) m19298O7;
                    boolean m19323h5 = s02Var2.m19323h(ba4Var) | s02Var2.m19323h(mappingEditorFeature);
                    Object m19298O8 = s02Var2.m19298O();
                    if (m19323h5 || m19298O8 == obj) {
                        m19298O8 = new b62(ba4Var, mappingEditorFeature, (byte) 13);
                        s02Var2.m19330k0(m19298O8);
                    }
                    z2 = z3;
                    f3 = mo43P;
                    v86.m21304c(45.0f, f3, j, R.drawable.open_in_full, zy1Var3, (zy1) m19298O8, null, s02Var, 54, 64);
                    s02Var2 = s02Var;
                    s02Var2.m19338p(false);
                }
                tf1 tf1Var = wj0.f42164a;
                v86.m21304c(165.0f, f3, ((uj0) s02Var2.m19327j(tf1Var)).f38789w, R.drawable.delete, null, null, xy1Var2, s02Var, 54 | ((i3 << 3) & 29360128), 48);
                v86.m21304c(285.0f, f3, ((uj0) s02Var.m19327j(tf1Var)).f38776j, R.drawable.edit, null, null, xy1Var3, s02Var, 12582966, 48);
                s02Var2 = s02Var;
                s02Var2.m19338p(false);
            } else {
                z2 = true;
                s02Var2.m19308Z(263508051);
                s02Var2.m19338p(false);
            }
            s02Var2.m19338p(z2);
        } else {
            s02Var2 = s02Var;
            s02Var2.m19303U();
        }
        m84 m19342t = s02Var2.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new nz1(i, x13Var, f, f2, z, xy1Var, xy1Var2, xy1Var3, i2) { // from class: g43

                /* renamed from: b */
                public final /* synthetic */ int f15267b;

                /* renamed from: c */
                public final /* synthetic */ x13 f15268c;

                /* renamed from: d */
                public final /* synthetic */ float f15269d;

                /* renamed from: e */
                public final /* synthetic */ float f15270e;

                /* renamed from: f */
                public final /* synthetic */ boolean f15271f;

                /* renamed from: g */
                public final /* synthetic */ xy1 f15272g;

                /* renamed from: h */
                public final /* synthetic */ xy1 f15273h;

                /* renamed from: i */
                public final /* synthetic */ xy1 f15274i;

                @Override // p000.nz1
                public final Object invoke(Object obj3, Object obj4) {
                    ((Integer) obj4).getClass();
                    int m23255A = y53.m23255A(12582913);
                    MappingEditorFeature.this.m11399J(this.f15267b, this.f15268c, this.f15269d, this.f15270e, this.f15271f, this.f15272g, this.f15273h, this.f15274i, (s02) obj3, m23255A);
                    return kn5.f22076a;
                }
            };
        }
    }

    /* renamed from: K */
    public final void m11400K(final int i, final x13 x13Var, final boolean z, final ul1 ul1Var, final ds3 ds3Var, final nz1 nz1Var, final xy1 xy1Var, final xy1 xy1Var2, final xy1 xy1Var3, s02 s02Var, final int i2) {
        s02Var.m19312b0(-131795082);
        int i3 = i2 | (s02Var.m19315d(i) ? 32 : 16) | (s02Var.m19323h(x13Var) ? 256 : 128) | (s02Var.m19321g(z) ? 2048 : 1024) | (s02Var.m19319f(ul1Var) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var.m19319f(ds3Var) ? 131072 : 65536) | (s02Var.m19323h(xy1Var) ? 8388608 : 4194304) | (s02Var.m19323h(xy1Var3) ? 536870912 : 268435456);
        if (s02Var.m19300R(i3 & 1, ((306783379 & i3) == 306783378 && ((s02Var.m19323h(this) ? (char) 4 : (char) 2) & 3) == 2) ? false : true)) {
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (m19298O == sv8Var) {
                m19298O = z80.m23867J(new rg2(0L));
                s02Var.m19330k0(m19298O);
            }
            final ef3 ef3Var = (ef3) m19298O;
            String str = x13Var.f43218a;
            y13 y13Var = x13Var.f43221d;
            boolean m19319f = s02Var.m19319f(str);
            Object m19298O2 = s02Var.m19298O();
            if (m19319f || m19298O2 == sv8Var) {
                m19298O2 = z80.m23867J(Float.valueOf(y13Var.f44638g));
                s02Var.m19330k0(m19298O2);
            }
            final ef3 ef3Var2 = (ef3) m19298O2;
            boolean m19319f2 = s02Var.m19319f(x13Var.f43218a);
            Object m19298O3 = s02Var.m19298O();
            if (m19319f2 || m19298O3 == sv8Var) {
                m19298O3 = z80.m23867J(Float.valueOf(y13Var.f44647p));
                s02Var.m19330k0(m19298O3);
            }
            final ef3 ef3Var3 = (ef3) m19298O3;
            na3 mo16389a = q90.f31530a.mo16389a(ka3.f21426a, z ? mg1.f25866i : mg1.f25864g);
            Object m19298O4 = s02Var.m19298O();
            if (m19298O4 == sv8Var) {
                m19298O4 = new C1540sg(ef3Var, (byte) 17);
                s02Var.m19330k0(m19298O4);
            }
            na3 m23858A = z80.m23858A(fy4.m11710f(fy4.m11719o(AbstractC0871d6.m8745F(ov9.m17421H(mo16389a, (zy1) m19298O4), di2.m9238M(12, s02Var, 6)), di2.m9238M(280, s02Var, 6)), di2.m9238M(380, s02Var, 6)), 0.9f);
            Object m19298O5 = s02Var.m19298O();
            if (m19298O5 == sv8Var) {
                m19298O5 = yt0.m23614g(s02Var);
            }
            ce3 ce3Var = (ce3) m19298O5;
            Object m19298O6 = s02Var.m19298O();
            if (m19298O6 == sv8Var) {
                m19298O6 = new z13((byte) 7);
                s02Var.m19330k0(m19298O6);
            }
            wk0.m22152g(mx0.m16319s(m23858A, ce3Var, null, false, null, (xy1) m19298O6, 28), dg2.m9067A(0.15f, 2.0f), null, null, mt7.m16166P(-1252823845, new pz1() { // from class: l43
                /* JADX WARN: Code restructure failed: missing block: B:138:0x0e5f, code lost:
                
                    if (r7 == r6) goto L209;
                 */
                /* JADX WARN: Code restructure failed: missing block: B:22:0x0217, code lost:
                
                    if (r13 == r11) goto L30;
                 */
                /* JADX WARN: Code restructure failed: missing block: B:236:0x0938, code lost:
                
                    if (r13 == r7) goto L117;
                 */
                /* JADX WARN: Code restructure failed: missing block: B:243:0x0a31, code lost:
                
                    if (r4 == r2) goto L128;
                 */
                /* JADX WARN: Code restructure failed: missing block: B:66:0x0608, code lost:
                
                    if (r14 == r8) goto L88;
                 */
                /* JADX WARN: Code restructure failed: missing block: B:88:0x0ba6, code lost:
                
                    if (r6 == r4) goto L149;
                 */
                /* JADX WARN: Code restructure failed: missing block: B:94:0x0c2b, code lost:
                
                    if (r4 == r2) goto L159;
                 */
                @Override // p000.pz1
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct add '--show-bad-code' argument
                */
                public final java.lang.Object invoke(java.lang.Object r129, java.lang.Object r130, java.lang.Object r131) {
                    /*
                        Method dump skipped, instructions count: 4286
                        To view this dump add '--comments-level debug' option
                    */
                    throw new UnsupportedOperationException("Method not decompiled: p000.l43.invoke(java.lang.Object, java.lang.Object, java.lang.Object):java.lang.Object");
                }
            }, s02Var), s02Var, 24576, 12);
        } else {
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new nz1(i, x13Var, z, ul1Var, ds3Var, nz1Var, xy1Var, xy1Var2, xy1Var3, i2) { // from class: m43

                /* renamed from: b */
                public final /* synthetic */ int f25245b;

                /* renamed from: c */
                public final /* synthetic */ x13 f25246c;

                /* renamed from: d */
                public final /* synthetic */ boolean f25247d;

                /* renamed from: e */
                public final /* synthetic */ ul1 f25248e;

                /* renamed from: f */
                public final /* synthetic */ ds3 f25249f;

                /* renamed from: g */
                public final /* synthetic */ nz1 f25250g;

                /* renamed from: h */
                public final /* synthetic */ xy1 f25251h;

                /* renamed from: i */
                public final /* synthetic */ xy1 f25252i;

                /* renamed from: j */
                public final /* synthetic */ xy1 f25253j;

                @Override // p000.nz1
                public final Object invoke(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int m23255A = y53.m23255A(102236167);
                    MappingEditorFeature.this.m11400K(this.f25245b, this.f25246c, this.f25247d, this.f25248e, this.f25249f, this.f25250g, this.f25251h, this.f25252i, this.f25253j, (s02) obj, m23255A);
                    return kn5.f22076a;
                }
            };
        }
    }

    /*  JADX ERROR: Type inference failed
        jadx.core.utils.exceptions.JadxOverflowException: Type inference error: updates count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:77)
        */
    /* renamed from: N */
    public final void m11401N(android.content.res.Configuration r48, p000.s02 r49, int r50) {
        /*
            Method dump skipped, instructions count: 2349
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.mapping.MappingEditorFeature.m11401N(android.content.res.Configuration, s02, int):void");
    }

    /* renamed from: P */
    public final void m11402P(final String str, final String str2, final int i, final String str3, final ds3 ds3Var, final nz1 nz1Var, final xy1 xy1Var, final na3 na3Var, xy1 xy1Var2, s02 s02Var, final int i2, final int i3) {
        final xy1 xy1Var3;
        int i4;
        final xy1 xy1Var4;
        long m18297b;
        float f;
        final boolean z;
        long m18297b2;
        s02Var.m19312b0(2096405920);
        int i5 = i2 | (s02Var.m19315d(i) ? 256 : 128) | (s02Var.m19319f(str3) ? 2048 : 1024) | (s02Var.m19319f(ds3Var) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var.m19323h(nz1Var) ? 131072 : 65536) | (s02Var.m19323h(xy1Var) ? 1048576 : 524288);
        if ((i2 & 12582912) == 0) {
            i5 |= s02Var.m19319f(na3Var) ? 8388608 : 4194304;
        }
        int i6 = i3 & 256;
        if (i6 != 0) {
            i4 = i5 | 100663296;
            xy1Var3 = xy1Var2;
        } else {
            xy1Var3 = xy1Var2;
            i4 = i5 | (s02Var.m19323h(xy1Var3) ? 67108864 : 33554432);
        }
        int i7 = i4 | (s02Var.m19323h(this) ? 536870912 : 268435456);
        if (s02Var.m19300R(i7 & 1, (306783379 & i7) != 306783378)) {
            if (i6 != 0) {
                xy1Var3 = null;
            }
            boolean z2 = ei2.m10070i(ds3Var != null ? (String) ds3Var.f10834a : null, str3) && ei2.m10070i(ds3Var.f10835b, str2);
            final k64 k64Var = (k64) s02Var.m19327j(rj0.f33758k);
            na3 m23273i = y53.m23273i(na3Var, dg2.m9071C(2, 0.2f));
            float m9238M = di2.m9238M(1, s02Var, 6);
            if (z2) {
                s02Var.m19308Z(306449670);
                s02Var.m19338p(false);
                m18297b = k64Var.f21260a;
            } else {
                s02Var.m19308Z(306451378);
                m18297b = qj0.m18297b(0.5f, ((uj0) s02Var.m19327j(wj0.f42164a)).f38734B);
                s02Var.m19338p(false);
            }
            na3 m2702q = cl5.m2702q(m23273i, m9238M, m18297b, dg2.m9071C(2, 0.2f));
            boolean m19321g = s02Var.m19321g(z2) | ((3670016 & i7) == 1048576) | ((458752 & i7) == 131072) | ((i7 & jq5.f20570g) == 2048);
            Object m19298O = s02Var.m19298O();
            if (m19321g || m19298O == yn0.f45724a) {
                f = 0.2f;
                m19298O = new nn1(z2, xy1Var, nz1Var, str3, str2);
                z = z2;
                s02Var.m19330k0(m19298O);
            } else {
                z = z2;
                f = 0.2f;
            }
            na3 m16320t = mx0.m16320t(15, (xy1) m19298O, m2702q, null, false);
            if (z) {
                s02Var.m19308Z(306460435);
                s02Var.m19338p(false);
                m18297b2 = qj0.m18297b(0.15f, k64Var.f21260a);
            } else {
                s02Var.m19308Z(306462834);
                m18297b2 = qj0.m18297b(0.7f, ((uj0) s02Var.m19327j(wj0.f42164a)).f38740H);
                s02Var.m19338p(false);
            }
            q75.m18052a(m16320t, dg2.m9071C(2, f), m18297b2, 0L, 0.0f, 0.0f, null, mt7.m16166P(-1770687685, new nz1(z, xy1Var3, i, str, this, k64Var) { // from class: w33

                /* renamed from: a */
                public final /* synthetic */ boolean f41505a;

                /* renamed from: b */
                public final /* synthetic */ xy1 f41506b;

                /* renamed from: c */
                public final /* synthetic */ int f41507c;

                /* renamed from: d */
                public final /* synthetic */ String f41508d;

                /* renamed from: e */
                public final /* synthetic */ k64 f41509e;

                {
                    this.f41509e = k64Var;
                }

                @Override // p000.nz1
                public final Object invoke(Object obj, Object obj2) {
                    String str4;
                    tf1 tf1Var;
                    long j;
                    int i8;
                    xy1 xy1Var5;
                    s02 s02Var2 = (s02) obj;
                    int intValue = ((Integer) obj2).intValue();
                    if (s02Var2.m19300R(intValue & 1, (intValue & 3) != 2)) {
                        float m9238M2 = di2.m9238M(6, s02Var2, 6);
                        float m9238M3 = di2.m9238M(5, s02Var2, 6);
                        ka3 ka3Var = ka3.f21426a;
                        na3 m8746G = AbstractC0871d6.m8746G(ka3Var, m9238M2, m9238M3);
                        ug4 m19739a = sg4.m19739a(AbstractC1443pv.f30970f, mg1.f25869l, s02Var2, 54);
                        int hashCode = Long.hashCode(s02Var2.f34520T);
                        ov3 m19331l = s02Var2.m19331l();
                        na3 m20748R = u99.m20748R(s02Var2, m8746G);
                        sn0.f35689X8.getClass();
                        s02Var2.m19316d0();
                        boolean z3 = s02Var2.f34519S;
                        me2 me2Var = wo2.f42501S;
                        if (z3) {
                            s02Var2.m19329k(me2Var);
                        } else {
                            s02Var2.m19336n0();
                        }
                        xm0 xm0Var = oua.f29409h;
                        z80.m23871N(xm0Var, s02Var2, m19739a);
                        xm0 xm0Var2 = oua.f29408g;
                        z80.m23871N(xm0Var2, s02Var2, m19331l);
                        Integer valueOf = Integer.valueOf(hashCode);
                        xm0 xm0Var3 = oua.f29410i;
                        z80.m23871N(xm0Var3, s02Var2, valueOf);
                        z80.m23869L(s02Var2);
                        xm0 xm0Var4 = oua.f29407f;
                        mp2 m8798e = d63.m8798e(s02Var2, m20748R, xm0Var4, 1.0f, true);
                        ek0 m9307a = dk0.m9307a(AbstractC1443pv.f30967c, mg1.f25871n, s02Var2, 0);
                        int hashCode2 = Long.hashCode(s02Var2.f34520T);
                        ov3 m19331l2 = s02Var2.m19331l();
                        na3 m20748R2 = u99.m20748R(s02Var2, m8798e);
                        s02Var2.m19316d0();
                        if (s02Var2.f34519S) {
                            s02Var2.m19329k(me2Var);
                        } else {
                            s02Var2.m19336n0();
                        }
                        z80.m23871N(xm0Var, s02Var2, m9307a);
                        z80.m23871N(xm0Var2, s02Var2, m19331l2);
                        hn0.m12946s(hashCode2, s02Var2, xm0Var3, s02Var2);
                        z80.m23871N(xm0Var4, s02Var2, m20748R2);
                        tf1 tf1Var2 = ul5.f38880a;
                        of5 m17192a = of5.m17192a(((sl5) s02Var2.m19327j(tf1Var2)).f35600o, 0L, di2.m9240O(8, s02Var2), null, null, 0L, null, 0L, null, null, 16777213);
                        tf1 tf1Var3 = wj0.f42164a;
                        xe5.m22686b(this.f41508d, null, ((uj0) s02Var2.m19327j(tf1Var3)).f38733A, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, m17192a, s02Var2, 0, 0, 131066);
                        boolean z4 = this.f41505a;
                        int i9 = this.f41507c;
                        if (z4) {
                            str4 = "Press...";
                        } else if (i9 == 0) {
                            str4 = "None (Disabled)";
                        } else {
                            String m16154D = mt7.m16154D(i9);
                            if (f55.m10718s0(m16154D)) {
                                str4 = String.valueOf(i9);
                            } else {
                                str4 = m16154D + " (" + i9 + ")";
                            }
                        }
                        of5 of5Var = ((sl5) s02Var2.m19327j(tf1Var2)).f35599n;
                        lx1 lx1Var = lx1.f24981k;
                        if (z4) {
                            s02Var2.m19308Z(-514642233);
                            s02Var2.m19338p(false);
                            i8 = i9;
                            j = this.f41509e.f21260a;
                            tf1Var = tf1Var3;
                        } else {
                            if (i9 == 0) {
                                s02Var2.m19308Z(-514639544);
                                tf1Var = tf1Var3;
                                j = ((uj0) s02Var2.m19327j(tf1Var)).f38733A;
                                s02Var2.m19338p(false);
                            } else {
                                tf1Var = tf1Var3;
                                s02Var2.m19308Z(-514637528);
                                j = ((uj0) s02Var2.m19327j(tf1Var)).f38759a;
                                s02Var2.m19338p(false);
                            }
                            i8 = i9;
                        }
                        tf1 tf1Var4 = tf1Var;
                        int i10 = i8;
                        xe5.m22686b(str4, g55.m11862j(ka3Var), j, 0L, lx1Var, null, 0L, null, null, 0L, 0, false, 1, 0, of5Var, s02Var2, 1572912, 24576, 114616);
                        s02Var2.m19338p(true);
                        if (z4 || (xy1Var5 = this.f41506b) == null || i10 == 0) {
                            s02Var2.m19308Z(-615457461);
                            s02Var2.m19338p(false);
                        } else {
                            s02Var2.m19308Z(-615806862);
                            as3 m23719B = z21.m23719B(R.drawable.close, s02Var2, 0);
                            long j2 = ((uj0) s02Var2.m19327j(tf1Var4)).f38733A;
                            na3 m11715k = fy4.m11715k(ka3Var, di2.m9238M(14, s02Var2, 6));
                            boolean m19319f = s02Var2.m19319f(xy1Var5);
                            Object m19298O2 = s02Var2.m19298O();
                            if (m19319f || m19298O2 == yn0.f45724a) {
                                m19298O2 = new C1640us(xy1Var5, (byte) 10);
                                s02Var2.m19330k0(m19298O2);
                            }
                            kb2.m14510a(m23719B, "Clear", mx0.m16320t(15, (xy1) m19298O2, m11715k, null, false), j2, s02Var2, 56, 0);
                            s02Var2.m19338p(false);
                        }
                        s02Var2.m19338p(true);
                    } else {
                        s02Var2.m19303U();
                    }
                    return kn5.f22076a;
                }
            }, s02Var), s02Var, 12582912, 120);
            xy1Var4 = xy1Var3;
        } else {
            s02Var.m19303U();
            xy1Var4 = xy1Var3;
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new nz1() { // from class: y33
                @Override // p000.nz1
                public final Object invoke(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    MappingEditorFeature.this.m11402P(str, str2, i, str3, ds3Var, nz1Var, xy1Var, na3Var, xy1Var4, (s02) obj, y53.m23255A(i2 | 1), i3);
                    return kn5.f22076a;
                }
            };
        }
    }

    /* renamed from: Q */
    public final void m11403Q(final String str, int i, final zy1 zy1Var, final xy1 xy1Var, final zy1 zy1Var2, final zy1 zy1Var3, final zy1 zy1Var4, xy1 xy1Var2, s02 s02Var, int i2) {
        q90 q90Var = q90.f31530a;
        s02Var.m19312b0(393394797);
        int i3 = i2 | (s02Var.m19319f(str) ? 32 : 16) | (s02Var.m19315d(i) ? 256 : 128) | (s02Var.m19323h(zy1Var) ? 2048 : 1024) | (s02Var.m19323h(xy1Var) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var.m19323h(zy1Var2) ? 131072 : 65536) | (s02Var.m19323h(zy1Var3) ? 1048576 : 524288) | (s02Var.m19323h(zy1Var4) ? 8388608 : 4194304) | (s02Var.m19323h(this) ? 536870912 : 268435456);
        if (s02Var.m19300R(i3 & 1, (306783379 & i3) != 306783378)) {
            String str2 = kn2.f22071a;
            final List m14783e = kn2.m14783e(this.f14338s);
            ka3 ka3Var = ka3.f21426a;
            na3 m19001O = rc6.m19001O(q90Var.mo16390b(ka3Var), qj0.m18297b(0.35f, qj0.f32046b), bz5.f3249o);
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (m19298O == sv8Var) {
                m19298O = yt0.m23614g(s02Var);
            }
            ce3 ce3Var = (ce3) m19298O;
            Object m19298O2 = s02Var.m19298O();
            if (m19298O2 == sv8Var) {
                m19298O2 = new C1640us(xy1Var2, jq5.f20569f);
                s02Var.m19330k0(m19298O2);
            }
            l90.m15154a(mx0.m16319s(m19001O, ce3Var, null, false, null, (xy1) m19298O2, 28), s02Var, 0);
            na3 m11721q = fy4.m11721q(AbstractC0871d6.m8745F(q90Var.mo16389a(ka3Var, mg1.f25863f), di2.m9238M(16, s02Var, 6)), 0.0f, di2.m9238M(280, s02Var, 6), 1);
            Object m19298O3 = s02Var.m19298O();
            if (m19298O3 == sv8Var) {
                m19298O3 = yt0.m23614g(s02Var);
            }
            ce3 ce3Var2 = (ce3) m19298O3;
            Object m19298O4 = s02Var.m19298O();
            if (m19298O4 == sv8Var) {
                m19298O4 = new z13((byte) 5);
                s02Var.m19330k0(m19298O4);
            }
            wk0.m22152g(mx0.m16319s(m11721q, ce3Var2, null, false, null, (xy1) m19298O4, 28), dg2.m9067A(0.15f, 2.0f), null, null, mt7.m16166P(-2017304750, new pz1() { // from class: k43
                @Override // p000.pz1
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    sv8 sv8Var2;
                    long j;
                    s02 s02Var2 = (s02) obj2;
                    int intValue = ((Integer) obj3).intValue();
                    ((fk0) obj).getClass();
                    if (s02Var2.m19300R(intValue & 1, (intValue & 17) != 16)) {
                        float m9238M = di2.m9238M(12, s02Var2, 6);
                        ka3 ka3Var2 = ka3.f21426a;
                        na3 m8745F = AbstractC0871d6.m8745F(ka3Var2, m9238M);
                        n70 n70Var = mg1.f25871n;
                        ek0 m9307a = dk0.m9307a(AbstractC1443pv.f30967c, n70Var, s02Var2, 0);
                        int hashCode = Long.hashCode(s02Var2.f34520T);
                        ov3 m19331l = s02Var2.m19331l();
                        na3 m20748R = u99.m20748R(s02Var2, m8745F);
                        sn0.f35689X8.getClass();
                        s02Var2.m19316d0();
                        boolean z = s02Var2.f34519S;
                        me2 me2Var = wo2.f42501S;
                        if (z) {
                            s02Var2.m19329k(me2Var);
                        } else {
                            s02Var2.m19336n0();
                        }
                        xm0 xm0Var = oua.f29409h;
                        z80.m23871N(xm0Var, s02Var2, m9307a);
                        xm0 xm0Var2 = oua.f29408g;
                        z80.m23871N(xm0Var2, s02Var2, m19331l);
                        Integer valueOf = Integer.valueOf(hashCode);
                        xm0 xm0Var3 = oua.f29410i;
                        z80.m23871N(xm0Var3, s02Var2, valueOf);
                        z80.m23869L(s02Var2);
                        xm0 xm0Var4 = oua.f29407f;
                        z80.m23871N(xm0Var4, s02Var2, m20748R);
                        xe5.m22686b("Keymaps", AbstractC0871d6.m8749J(ka3Var2, 0.0f, 0.0f, 0.0f, di2.m9238M(8, s02Var2, 6), 7), 0L, 0L, lx1.f24981k, null, 0L, null, null, 0L, 0, false, 0, 0, ((sl5) s02Var2.m19327j(ul5.f38880a)).f35598m, s02Var2, 1572870, 0, 131004);
                        na3 m15560A = lx6.m15560A(fy4.m11712h(ka3Var2, 0.0f, di2.m9238M(260, s02Var2, 6), 1), lx6.m15599x(s02Var2), true);
                        ek0 m9307a2 = dk0.m9307a(new C1325mv(di2.m9238M(6, s02Var2, 6), true, new C0950f((byte) 9)), n70Var, s02Var2, 0);
                        int hashCode2 = Long.hashCode(s02Var2.f34520T);
                        ov3 m19331l2 = s02Var2.m19331l();
                        na3 m20748R2 = u99.m20748R(s02Var2, m15560A);
                        s02Var2.m19316d0();
                        if (s02Var2.f34519S) {
                            s02Var2.m19329k(me2Var);
                        } else {
                            s02Var2.m19336n0();
                        }
                        z80.m23871N(xm0Var, s02Var2, m9307a2);
                        z80.m23871N(xm0Var2, s02Var2, m19331l2);
                        hn0.m12946s(hashCode2, s02Var2, xm0Var3, s02Var2);
                        z80.m23871N(xm0Var4, s02Var2, m20748R2);
                        s02Var2.m19308Z(1333041167);
                        k43 k43Var = this;
                        List list = m14783e;
                        Iterator it = list.iterator();
                        while (true) {
                            boolean hasNext = it.hasNext();
                            sv8Var2 = yn0.f45724a;
                            if (!hasNext) {
                                break;
                            }
                            in2 in2Var = (in2) it.next();
                            boolean m10070i = ei2.m10070i(in2Var.f18901a, str);
                            na3 m23273i = y53.m23273i(fy4.m11708d(ka3Var2, 1.0f), dg2.m9071C(2, 0.3f));
                            zy1 zy1Var5 = zy1Var;
                            boolean m19319f = s02Var2.m19319f(zy1Var5) | s02Var2.m19323h(in2Var);
                            Object m19298O5 = s02Var2.m19298O();
                            if (m19319f || m19298O5 == sv8Var2) {
                                m19298O5 = new f33(zy1Var5, in2Var, (byte) 0);
                                s02Var2.m19330k0(m19298O5);
                            }
                            na3 m16320t = mx0.m16320t(15, (xy1) m19298O5, m23273i, null, false);
                            if (m10070i) {
                                s02Var2.m19308Z(-1103247639);
                                j = ((uj0) s02Var2.m19327j(wj0.f42164a)).f38763c;
                                s02Var2.m19338p(false);
                            } else {
                                s02Var2.m19308Z(-1103245201);
                                j = ((uj0) s02Var2.m19327j(wj0.f42164a)).f38742J;
                                s02Var2.m19338p(false);
                            }
                            q75.m18052a(m16320t, null, j, 0L, 0.0f, 0.0f, null, mt7.m16166P(-1086918924, new C1464qe(m10070i, in2Var, zy1Var2, zy1Var3, list, zy1Var4), s02Var2), s02Var2, 12582912, 122);
                            k43Var = this;
                            list = list;
                        }
                        s02Var2.m19338p(false);
                        na3 m23273i2 = y53.m23273i(fy4.m11708d(ka3Var2, 1.0f), dg2.m9071C(2, 0.3f));
                        xy1 xy1Var3 = xy1Var;
                        boolean m19319f2 = s02Var2.m19319f(xy1Var3);
                        Object m19298O6 = s02Var2.m19298O();
                        if (m19319f2 || m19298O6 == sv8Var2) {
                            m19298O6 = new C1640us(xy1Var3, (byte) 8);
                            s02Var2.m19330k0(m19298O6);
                        }
                        q75.m18052a(mx0.m16320t(15, (xy1) m19298O6, m23273i2, null, false), null, ((uj0) s02Var2.m19327j(wj0.f42164a)).f38778l, 0L, 0.0f, 0.0f, null, y53.f44929e, s02Var2, 12582912, 122);
                        s02Var2.m19338p(true);
                        s02Var2.m19338p(true);
                    } else {
                        s02Var2.m19303U();
                    }
                    return kn5.f22076a;
                }
            }, s02Var), s02Var, 24576, 12);
        } else {
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new lh3(this, str, i, zy1Var, xy1Var, zy1Var2, zy1Var3, zy1Var4, xy1Var2, i2);
        }
    }

    /* renamed from: R */
    public final void m11404R(String str, xy1 xy1Var, zy1 zy1Var, s02 s02Var, int i) {
        s02Var.m19312b0(-467057962);
        int i2 = i | (s02Var.m19319f(str) ? 32 : 16) | (s02Var.m19323h(xy1Var) ? 256 : 128) | (s02Var.m19323h(zy1Var) ? 2048 : 1024);
        if (s02Var.m19300R(i2 & 1, (i2 & 1171) != 1170)) {
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (m19298O == sv8Var) {
                m19298O = z80.m23867J(str);
                s02Var.m19330k0(m19298O);
            }
            ef3 ef3Var = (ef3) m19298O;
            Object m19298O2 = s02Var.m19298O();
            if (m19298O2 == sv8Var) {
                m19298O2 = new ov1();
                s02Var.m19330k0(m19298O2);
            }
            ov1 ov1Var = (ov1) m19298O2;
            Object m19298O3 = s02Var.m19298O();
            if (m19298O3 == sv8Var) {
                m19298O3 = new C0085bl((Object) ov1Var, (ns0) null, (byte) 22);
                s02Var.m19330k0(m19298O3);
            }
            ov9.m17456i((nz1) m19298O3, s02Var, kn5.f22076a);
            q90 q90Var = q90.f31530a;
            ka3 ka3Var = ka3.f21426a;
            na3 m19001O = rc6.m19001O(q90Var.mo16390b(ka3Var), qj0.m18297b(0.45f, qj0.f32046b), bz5.f3249o);
            Object m19298O4 = s02Var.m19298O();
            if (m19298O4 == sv8Var) {
                m19298O4 = yt0.m23614g(s02Var);
            }
            ce3 ce3Var = (ce3) m19298O4;
            boolean z = (i2 & 896) == 256;
            Object m19298O5 = s02Var.m19298O();
            if (z || m19298O5 == sv8Var) {
                m19298O5 = new C1640us(xy1Var, (byte) 11);
                s02Var.m19330k0(m19298O5);
            }
            l90.m15154a(mx0.m16319s(m19001O, ce3Var, null, false, null, (xy1) m19298O5, 28), s02Var, 0);
            na3 m11721q = fy4.m11721q(AbstractC0871d6.m8745F(q90Var.mo16389a(ka3Var, mg1.f25863f), di2.m9238M(16, s02Var, 6)), 0.0f, di2.m9238M(280, s02Var, 6), 1);
            Object m19298O6 = s02Var.m19298O();
            if (m19298O6 == sv8Var) {
                m19298O6 = yt0.m23614g(s02Var);
            }
            ce3 ce3Var2 = (ce3) m19298O6;
            Object m19298O7 = s02Var.m19298O();
            if (m19298O7 == sv8Var) {
                m19298O7 = new z13((byte) 4);
                s02Var.m19330k0(m19298O7);
            }
            wk0.m22152g(mx0.m16319s(m11721q, ce3Var2, null, false, null, (xy1) m19298O7, 28), dg2.m9067A(0.15f, 2.0f), null, null, mt7.m16166P(398994235, new ts0(ov1Var, ef3Var, xy1Var, zy1Var, (byte) 6), s02Var), s02Var, 24576, 12);
        } else {
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new j80(this, str, xy1Var, zy1Var, i);
        }
    }

    /* renamed from: S */
    public final void m11405S(final long j, final float f, final float f2, final float f3, s02 s02Var, final int i) {
        Object obj;
        sv8 sv8Var;
        int i2;
        int i3;
        s02Var.m19312b0(2088724119);
        int i4 = i | (s02Var.m19317e(j) ? 4 : 2);
        if ((i & 48) == 0) {
            i4 |= s02Var.m19313c(f) ? 32 : 16;
        }
        int i5 = i4 | (s02Var.m19313c(f2) ? 256 : 128) | (s02Var.m19313c(f3) ? 2048 : 1024);
        if (s02Var.m19300R(i5 & 1, (i5 & 1171) != 1170)) {
            float f4 = 0.70710677f * f;
            final long m12818d = hl3.m12818d(j, (Float.floatToRawIntBits(f4) << 32) | (Float.floatToRawIntBits(f4) & 4294967295L));
            long j2 = qj0.f32048d;
            final long m18297b = qj0.m18297b(0.45f, j2);
            hp1 hp1Var = fy4.f14736c;
            boolean z = (i5 & 14) == 4;
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var2 = yn0.f45724a;
            if (z || m19298O == sv8Var2) {
                m19298O = new zy1() { // from class: h43
                    @Override // p000.zy1
                    public final Object invoke(Object obj2) {
                        se1 se1Var = (se1) obj2;
                        se1Var.getClass();
                        C0076bf c0076bf = new C0076bf(new DashPathEffect(new float[]{4.0f, 8.0f}, 0.0f));
                        long j3 = j;
                        long floatToRawIntBits = Float.floatToRawIntBits(Float.intBitsToFloat(r2)) & 4294967295L;
                        float intBitsToFloat = Float.intBitsToFloat((int) (se1Var.mo19719e() >> 32));
                        float intBitsToFloat2 = Float.intBitsToFloat((int) (j3 & 4294967295L));
                        long j4 = m18297b;
                        se1.m19710E0(se1Var, j4, floatToRawIntBits, (Float.floatToRawIntBits(intBitsToFloat) << 32) | (Float.floatToRawIntBits(intBitsToFloat2) & 4294967295L), 1.5f, 0, c0076bf, 464);
                        long floatToRawIntBits2 = Float.floatToRawIntBits(Float.intBitsToFloat(r3)) << 32;
                        float intBitsToFloat3 = Float.intBitsToFloat((int) (j3 >> 32));
                        float intBitsToFloat4 = Float.intBitsToFloat((int) (se1Var.mo19719e() & 4294967295L));
                        se1.m19710E0(se1Var, j4, floatToRawIntBits2, (Float.floatToRawIntBits(intBitsToFloat3) << 32) | (Float.floatToRawIntBits(intBitsToFloat4) & 4294967295L), 1.5f, 0, c0076bf, 464);
                        return kn5.f22076a;
                    }
                };
                s02Var.m19330k0(m19298O);
            }
            lw9.m15528a(hp1Var, (zy1) m19298O, s02Var, 6);
            Object m19298O2 = s02Var.m19298O();
            if (m19298O2 == sv8Var2) {
                m19298O2 = z80.m23867J(new zg2(0L));
                s02Var.m19330k0(m19298O2);
            }
            final ef3 ef3Var = (ef3) m19298O2;
            s02Var.m19308Z(1514173762);
            final float mo47c0 = ((t61) s02Var.m19327j(po0.f30726h)).mo47c0(di2.m9238M(3, s02Var, 6));
            s02Var.m19338p(false);
            String m12933f = hn0.m12933f(y53.m23286v(Float.intBitsToFloat((int) (j >> 32))), "X ", y53.m23286v(Float.intBitsToFloat((int) (j & 4294967295L))), " · Y ");
            of5 m17192a = of5.m17192a(((sl5) s02Var.m19327j(ul5.f38880a)).f35600o, 0L, di2.m9240O(7, s02Var), null, null, 0L, null, di2.m9240O(8, s02Var), null, null, 16646141);
            long m18297b2 = qj0.m18297b(0.85f, j2);
            boolean m19317e = ((i5 & 896) == 256) | ((i5 & jq5.f20570g) == 2048) | s02Var.m19317e(m12818d) | s02Var.m19313c(mo47c0);
            Object m19298O3 = s02Var.m19298O();
            if (m19317e || m19298O3 == sv8Var2) {
                sv8Var = sv8Var2;
                i2 = 3;
                i3 = 6;
                obj = new zy1() { // from class: i43
                    @Override // p000.zy1
                    public final Object invoke(Object obj2) {
                        ((t61) obj2).getClass();
                        ef3 ef3Var2 = ef3Var;
                        int m23286v = y53.m23286v(f2 - ((int) (((zg2) ef3Var2.getValue()).f47050a >> 32)));
                        if (m23286v < 0) {
                            m23286v = 0;
                        }
                        int m23286v2 = y53.m23286v(f3 - ((int) (((zg2) ef3Var2.getValue()).f47050a & 4294967295L)));
                        if (m23286v2 < 0) {
                            m23286v2 = 0;
                        }
                        float intBitsToFloat = Float.intBitsToFloat((int) (m12818d >> 32)) - ((int) (((zg2) ef3Var2.getValue()).f47050a >> 32));
                        float f5 = mo47c0;
                        return new rg2((dg2.m9133t(y53.m23286v(intBitsToFloat - f5), 0, m23286v) << 32) | (dg2.m9133t(y53.m23286v((Float.intBitsToFloat((int) (r7 & 4294967295L)) - ((int) (((zg2) ef3Var2.getValue()).f47050a & 4294967295L))) - f5), 0, m23286v2) & 4294967295L));
                    }
                };
                s02Var.m19330k0(obj);
            } else {
                obj = m19298O3;
                sv8Var = sv8Var2;
                i2 = 3;
                i3 = 6;
            }
            na3 m17421H = ov9.m17421H(ka3.f21426a, (zy1) obj);
            Object m19298O4 = s02Var.m19298O();
            if (m19298O4 == sv8Var) {
                m19298O4 = new C1540sg(ef3Var, (byte) 16);
                s02Var.m19330k0(m19298O4);
            }
            xe5.m22686b(m12933f, AbstractC0871d6.m8746G(rc6.m19001O(yt0.m23613f(i2, i3, s02Var, AbstractC1499rc.m18982x(m17421H, (zy1) m19298O4)), qj0.m18297b(0.55f, qj0.f32046b), bz5.f3249o), di2.m9238M(4, s02Var, i3), di2.m9238M(1, s02Var, i3)), m18297b2, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, m17192a, s02Var, C0962fb.c.f13595h, 0, 131064);
        } else {
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new nz1() { // from class: j43
                @Override // p000.nz1
                public final Object invoke(Object obj2, Object obj3) {
                    ((Integer) obj3).getClass();
                    MappingEditorFeature.this.m11405S(j, f, f2, f3, (s02) obj2, y53.m23255A(i | 1));
                    return kn5.f22076a;
                }
            };
        }
    }

    /* renamed from: T */
    public final void m11406T(int i, x13 x13Var, ra5 ra5Var, ul1 ul1Var, ds3 ds3Var, nz1 nz1Var, xy1 xy1Var, s02 s02Var, int i2) {
        s02Var.m19312b0(-591622241);
        int i3 = i2 | (s02Var.m19315d(i) ? 4 : 2) | (s02Var.m19323h(x13Var) ? 32 : 16) | (s02Var.m19323h(ra5Var) ? 256 : 128) | (s02Var.m19319f(ul1Var) ? 2048 : 1024) | (s02Var.m19319f(ds3Var) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var.m19323h(nz1Var) ? 131072 : 65536) | (s02Var.m19323h(xy1Var) ? 1048576 : 524288) | (s02Var.m19323h(this) ? 8388608 : 4194304);
        if (s02Var.m19300R(i3 & 1, (4793491 & i3) != 4793490)) {
            q75.m18052a(y53.m23273i(fy4.m11708d(ka3.f21426a, 1.0f), dg2.m9071C(2, 0.1f)), null, ((uj0) s02Var.m19327j(wj0.f42164a)).f38742J, 0L, 0.0f, 0.0f, null, mt7.m16166P(-163748550, new g33(x13Var, ra5Var, this, i, ul1Var, ds3Var, nz1Var, xy1Var), s02Var), s02Var, 12582912, 122);
        } else {
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new g33(this, i, x13Var, ra5Var, ul1Var, ds3Var, nz1Var, xy1Var, i2);
        }
    }

    /* renamed from: U */
    public final void m11407U(final int i, final int i2, final ra5 ra5Var, final boolean z, final boolean z2, final boolean z3, final boolean z4, final ul1 ul1Var, s02 s02Var, final int i3) {
        m84 m19342t;
        nz1 nz1Var;
        s02Var.m19312b0(234480488);
        int i4 = i3 | (s02Var.m19315d(i) ? 4 : 2) | (s02Var.m19315d(i2) ? 32 : 16) | (s02Var.m19323h(ra5Var) ? 256 : 128) | (s02Var.m19321g(z) ? 2048 : 1024) | (s02Var.m19321g(z2) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var.m19321g(z3) ? 131072 : 65536) | (s02Var.m19323h(this) ? 67108864 : 33554432);
        if (!s02Var.m19300R(i4 & 1, (34153619 & i4) != 34153618)) {
            s02Var.m19303U();
        } else {
            if (((x13) ij0.m13404h0(i, this.f14339t)) == null) {
                m19342t = s02Var.m19342t();
                if (m19342t != null) {
                    final byte b = 0;
                    nz1Var = new nz1(this, i, i2, ra5Var, z, z2, z3, z4, ul1Var, i3, b) { // from class: h33

                        /* renamed from: a */
                        public final /* synthetic */ byte f16684a;

                        /* renamed from: b */
                        public final /* synthetic */ MappingEditorFeature f16685b;

                        /* renamed from: c */
                        public final /* synthetic */ int f16686c;

                        /* renamed from: d */
                        public final /* synthetic */ int f16687d;

                        /* renamed from: e */
                        public final /* synthetic */ ra5 f16688e;

                        /* renamed from: f */
                        public final /* synthetic */ boolean f16689f;

                        /* renamed from: g */
                        public final /* synthetic */ boolean f16690g;

                        /* renamed from: h */
                        public final /* synthetic */ boolean f16691h;

                        /* renamed from: i */
                        public final /* synthetic */ boolean f16692i;

                        /* renamed from: j */
                        public final /* synthetic */ ul1 f16693j;

                        {
                            this.f16684a = b;
                            this.f16685b = this;
                        }

                        @Override // p000.nz1
                        public final Object invoke(Object obj, Object obj2) {
                            byte b2 = this.f16684a;
                            kn5 kn5Var = kn5.f22076a;
                            switch (b2) {
                                case 0:
                                    ((Integer) obj2).getClass();
                                    int m23255A = y53.m23255A(1572865);
                                    this.f16685b.m11407U(this.f16686c, this.f16687d, this.f16688e, this.f16689f, this.f16690g, this.f16691h, this.f16692i, this.f16693j, (s02) obj, m23255A);
                                    break;
                                default:
                                    ((Integer) obj2).getClass();
                                    int m23255A2 = y53.m23255A(1572865);
                                    this.f16685b.m11407U(this.f16686c, this.f16687d, this.f16688e, this.f16689f, this.f16690g, this.f16691h, this.f16692i, this.f16693j, (s02) obj, m23255A2);
                                    break;
                            }
                            return kn5Var;
                        }
                    };
                    m19342t.f25420d = nz1Var;
                }
                return;
            }
            q75.m18052a(y53.m23273i(fy4.m11708d(ka3.f21426a, 1.0f), dg2.m9071C(2, 0.1f)), null, ((uj0) s02Var.m19327j(wj0.f42164a)).f38742J, 0L, 0.0f, 0.0f, null, mt7.m16166P(109735533, new nz1() { // from class: i33
                /* JADX WARN: Multi-variable type inference failed */
                /* JADX WARN: Type inference failed for: r3v25 */
                /* JADX WARN: Type inference failed for: r3v26, types: [int] */
                /* JADX WARN: Type inference failed for: r3v31 */
                /* JADX WARN: Type inference failed for: r8v10, types: [int] */
                /* JADX WARN: Type inference failed for: r8v14 */
                /* JADX WARN: Type inference failed for: r8v17 */
                @Override // p000.nz1
                public final Object invoke(Object obj, Object obj2) {
                    int i5;
                    boolean z5;
                    long j;
                    boolean z6;
                    MappingEditorFeature mappingEditorFeature;
                    int i6;
                    int i7;
                    boolean z7;
                    boolean z8;
                    s02 s02Var2;
                    int i8;
                    MappingEditorFeature mappingEditorFeature2;
                    boolean z9;
                    int i9;
                    final int i10;
                    boolean z10;
                    MappingEditorFeature mappingEditorFeature3;
                    int i11;
                    int i12;
                    sv8 sv8Var;
                    int i13;
                    ra5 ra5Var2;
                    boolean z11;
                    boolean z12;
                    j53 j53Var;
                    boolean z13;
                    s02 s02Var3;
                    boolean z14;
                    s02 s02Var4;
                    final int i14;
                    final MappingEditorFeature mappingEditorFeature4;
                    boolean z15;
                    int i15;
                    boolean z16;
                    MappingEditorFeature mappingEditorFeature5;
                    int i16;
                    int i17;
                    ra5 ra5Var3;
                    boolean z17;
                    MappingEditorFeature mappingEditorFeature6;
                    int i18;
                    int i19;
                    final int i20;
                    s02 s02Var5 = (s02) obj;
                    int intValue = ((Integer) obj2).intValue();
                    if (s02Var5.m19300R(intValue & 1, (intValue & 3) != 2)) {
                        float m9238M = di2.m9238M(10, s02Var5, 6);
                        ka3 ka3Var = ka3.f21426a;
                        na3 m8745F = AbstractC0871d6.m8745F(ka3Var, m9238M);
                        ek0 m9307a = dk0.m9307a(new C1325mv(di2.m9238M(8, s02Var5, 6), true, new C0950f((byte) 9)), mg1.f25871n, s02Var5, 0);
                        int hashCode = Long.hashCode(s02Var5.f34520T);
                        ov3 m19331l = s02Var5.m19331l();
                        na3 m20748R = u99.m20748R(s02Var5, m8745F);
                        sn0.f35689X8.getClass();
                        s02Var5.m19316d0();
                        boolean z18 = s02Var5.f34519S;
                        me2 me2Var = wo2.f42501S;
                        if (z18) {
                            s02Var5.m19329k(me2Var);
                        } else {
                            s02Var5.m19336n0();
                        }
                        xm0 xm0Var = oua.f29409h;
                        z80.m23871N(xm0Var, s02Var5, m9307a);
                        xm0 xm0Var2 = oua.f29408g;
                        z80.m23871N(xm0Var2, s02Var5, m19331l);
                        Integer valueOf = Integer.valueOf(hashCode);
                        xm0 xm0Var3 = oua.f29410i;
                        z80.m23871N(xm0Var3, s02Var5, valueOf);
                        z80.m23869L(s02Var5);
                        xm0 xm0Var4 = oua.f29407f;
                        z80.m23871N(xm0Var4, s02Var5, m20748R);
                        o70 o70Var = mg1.f25869l;
                        ug4 m19739a = sg4.m19739a(new C1325mv(di2.m9238M(5, s02Var5, 6), true, new C0950f((byte) 9)), o70Var, s02Var5, 48);
                        int hashCode2 = Long.hashCode(s02Var5.f34520T);
                        ov3 m19331l2 = s02Var5.m19331l();
                        na3 m20748R2 = u99.m20748R(s02Var5, ka3Var);
                        s02Var5.m19316d0();
                        if (s02Var5.f34519S) {
                            s02Var5.m19329k(me2Var);
                        } else {
                            s02Var5.m19336n0();
                        }
                        z80.m23871N(xm0Var, s02Var5, m19739a);
                        z80.m23871N(xm0Var2, s02Var5, m19331l2);
                        hn0.m12946s(hashCode2, s02Var5, xm0Var3, s02Var5);
                        z80.m23871N(xm0Var4, s02Var5, m20748R2);
                        int i21 = i2;
                        boolean z19 = z4;
                        String m8808o = d63.m8808o(z19 ? "Alt #" : "#", i21 + 1);
                        tf1 tf1Var = ul5.f38880a;
                        of5 of5Var = ((sl5) s02Var5.m19327j(tf1Var)).f35599n;
                        lx1 lx1Var = lx1.f24981k;
                        if (z19) {
                            s02Var5.m19308Z(1544954136);
                            s02Var5.m19338p(false);
                            i5 = i21;
                            z5 = z19;
                            j = bz5.m2094d(4294940672L);
                        } else {
                            s02Var5.m19308Z(1544955696);
                            i5 = i21;
                            z5 = z19;
                            j = ((uj0) s02Var5.m19327j(wj0.f42164a)).f38783q;
                            s02Var5.m19338p(false);
                        }
                        final int i22 = i5;
                        final boolean z20 = z5;
                        xe5.m22686b(m8808o, new mp2(1.0f, true), j, 0L, lx1Var, null, 0L, null, null, 0L, 0, false, 0, 0, of5Var, s02Var5, 1572864, 0, 131000);
                        boolean m19321g = s02Var5.m19321g(z20);
                        final MappingEditorFeature mappingEditorFeature7 = this;
                        boolean m19323h = m19321g | s02Var5.m19323h(mappingEditorFeature7);
                        final int i23 = i;
                        boolean m19315d = m19323h | s02Var5.m19315d(i23) | s02Var5.m19315d(i22);
                        Object m19298O = s02Var5.m19298O();
                        sv8 sv8Var2 = yn0.f45724a;
                        if (m19315d || m19298O == sv8Var2) {
                            final byte b2 = 0;
                            m19298O = new xy1() { // from class: p33
                                @Override // p000.xy1
                                public final Object invoke() {
                                    byte b3 = b2;
                                    byte b4 = 6;
                                    kn5 kn5Var = kn5.f22076a;
                                    int i24 = i22;
                                    int i25 = i23;
                                    MappingEditorFeature mappingEditorFeature8 = mappingEditorFeature7;
                                    boolean z21 = z20;
                                    switch (b3) {
                                        case 0:
                                            f05 f05Var = mappingEditorFeature8.f14339t;
                                            if (z21) {
                                                if (i25 >= 0 && i25 < f05Var.size()) {
                                                    x13 x13Var = (x13) f05Var.get(i25);
                                                    x13Var.getClass();
                                                    f05Var.set(i25, u43.m20649b(i24, -1, x13Var));
                                                }
                                            } else if (i25 >= 0 && i25 < f05Var.size()) {
                                                x13 x13Var2 = (x13) f05Var.get(i25);
                                                x13Var2.getClass();
                                                f05Var.set(i25, u43.m20650c(i24, -1, x13Var2));
                                            }
                                            mappingEditorFeature8.m11413c0();
                                            break;
                                        case 1:
                                            MappingEditorFeature.m11396V(z21, mappingEditorFeature8, i25, i24, new m03((byte) 6));
                                            break;
                                        case 2:
                                            MappingEditorFeature.m11396V(z21, mappingEditorFeature8, i25, i24, new m03((byte) 1));
                                            break;
                                        case 3:
                                            f05 f05Var2 = mappingEditorFeature8.f14339t;
                                            if (z21) {
                                                if (i25 >= 0 && i25 < f05Var2.size()) {
                                                    x13 x13Var3 = (x13) f05Var2.get(i25);
                                                    x13Var3.getClass();
                                                    f05Var2.set(i25, u43.m20649b(i24, 1, x13Var3));
                                                }
                                            } else if (i25 >= 0 && i25 < f05Var2.size()) {
                                                x13 x13Var4 = (x13) f05Var2.get(i25);
                                                x13Var4.getClass();
                                                f05Var2.set(i25, u43.m20650c(i24, 1, x13Var4));
                                            }
                                            mappingEditorFeature8.m11413c0();
                                            break;
                                        default:
                                            if (z21) {
                                                mappingEditorFeature8.m11415e0(i25, new zv1((byte) 5, i24));
                                            } else {
                                                mappingEditorFeature8.m11415e0(i25, new zv1(b4, i24));
                                            }
                                            mappingEditorFeature8.m11413c0();
                                            break;
                                    }
                                    return kn5Var;
                                }
                            };
                            z6 = z20;
                            mappingEditorFeature = mappingEditorFeature7;
                            i6 = i23;
                            i7 = i22;
                            s02Var5.m19330k0(m19298O);
                        } else {
                            z6 = z20;
                            mappingEditorFeature = mappingEditorFeature7;
                            i6 = i23;
                            i7 = i22;
                        }
                        v86.m21312g("▲", z2, 0L, (xy1) m19298O, s02Var5, 6, 4);
                        boolean m19321g2 = s02Var5.m19321g(z6) | s02Var5.m19323h(mappingEditorFeature) | s02Var5.m19315d(i6) | s02Var5.m19315d(i7);
                        Object m19298O2 = s02Var5.m19298O();
                        if (m19321g2 || m19298O2 == sv8Var2) {
                            final byte b3 = 3;
                            final int i24 = i7;
                            final boolean z21 = z6;
                            final MappingEditorFeature mappingEditorFeature8 = mappingEditorFeature;
                            final int i25 = i6;
                            m19298O2 = new xy1() { // from class: p33
                                @Override // p000.xy1
                                public final Object invoke() {
                                    byte b32 = b3;
                                    byte b4 = 6;
                                    kn5 kn5Var = kn5.f22076a;
                                    int i242 = i24;
                                    int i252 = i25;
                                    MappingEditorFeature mappingEditorFeature82 = mappingEditorFeature8;
                                    boolean z212 = z21;
                                    switch (b32) {
                                        case 0:
                                            f05 f05Var = mappingEditorFeature82.f14339t;
                                            if (z212) {
                                                if (i252 >= 0 && i252 < f05Var.size()) {
                                                    x13 x13Var = (x13) f05Var.get(i252);
                                                    x13Var.getClass();
                                                    f05Var.set(i252, u43.m20649b(i242, -1, x13Var));
                                                }
                                            } else if (i252 >= 0 && i252 < f05Var.size()) {
                                                x13 x13Var2 = (x13) f05Var.get(i252);
                                                x13Var2.getClass();
                                                f05Var.set(i252, u43.m20650c(i242, -1, x13Var2));
                                            }
                                            mappingEditorFeature82.m11413c0();
                                            break;
                                        case 1:
                                            MappingEditorFeature.m11396V(z212, mappingEditorFeature82, i252, i242, new m03((byte) 6));
                                            break;
                                        case 2:
                                            MappingEditorFeature.m11396V(z212, mappingEditorFeature82, i252, i242, new m03((byte) 1));
                                            break;
                                        case 3:
                                            f05 f05Var2 = mappingEditorFeature82.f14339t;
                                            if (z212) {
                                                if (i252 >= 0 && i252 < f05Var2.size()) {
                                                    x13 x13Var3 = (x13) f05Var2.get(i252);
                                                    x13Var3.getClass();
                                                    f05Var2.set(i252, u43.m20649b(i242, 1, x13Var3));
                                                }
                                            } else if (i252 >= 0 && i252 < f05Var2.size()) {
                                                x13 x13Var4 = (x13) f05Var2.get(i252);
                                                x13Var4.getClass();
                                                f05Var2.set(i252, u43.m20650c(i242, 1, x13Var4));
                                            }
                                            mappingEditorFeature82.m11413c0();
                                            break;
                                        default:
                                            if (z212) {
                                                mappingEditorFeature82.m11415e0(i252, new zv1((byte) 5, i242));
                                            } else {
                                                mappingEditorFeature82.m11415e0(i252, new zv1(b4, i242));
                                            }
                                            mappingEditorFeature82.m11413c0();
                                            break;
                                    }
                                    return kn5Var;
                                }
                            };
                            s02Var5.m19330k0(m19298O2);
                        }
                        v86.m21312g("▼", z3, 0L, (xy1) m19298O2, s02Var5, 6, 4);
                        tf1 tf1Var2 = wj0.f42164a;
                        long j2 = ((uj0) s02Var5.m19327j(tf1Var2)).f38791y;
                        boolean m19321g3 = s02Var5.m19321g(z6) | s02Var5.m19323h(mappingEditorFeature) | s02Var5.m19315d(i6) | s02Var5.m19315d(i7);
                        Object m19298O3 = s02Var5.m19298O();
                        if (m19321g3 || m19298O3 == sv8Var2) {
                            final byte b4 = 4;
                            final int i26 = i7;
                            final boolean z22 = z6;
                            final MappingEditorFeature mappingEditorFeature9 = mappingEditorFeature;
                            final int i27 = i6;
                            m19298O3 = new xy1() { // from class: p33
                                @Override // p000.xy1
                                public final Object invoke() {
                                    byte b32 = b4;
                                    byte b42 = 6;
                                    kn5 kn5Var = kn5.f22076a;
                                    int i242 = i26;
                                    int i252 = i27;
                                    MappingEditorFeature mappingEditorFeature82 = mappingEditorFeature9;
                                    boolean z212 = z22;
                                    switch (b32) {
                                        case 0:
                                            f05 f05Var = mappingEditorFeature82.f14339t;
                                            if (z212) {
                                                if (i252 >= 0 && i252 < f05Var.size()) {
                                                    x13 x13Var = (x13) f05Var.get(i252);
                                                    x13Var.getClass();
                                                    f05Var.set(i252, u43.m20649b(i242, -1, x13Var));
                                                }
                                            } else if (i252 >= 0 && i252 < f05Var.size()) {
                                                x13 x13Var2 = (x13) f05Var.get(i252);
                                                x13Var2.getClass();
                                                f05Var.set(i252, u43.m20650c(i242, -1, x13Var2));
                                            }
                                            mappingEditorFeature82.m11413c0();
                                            break;
                                        case 1:
                                            MappingEditorFeature.m11396V(z212, mappingEditorFeature82, i252, i242, new m03((byte) 6));
                                            break;
                                        case 2:
                                            MappingEditorFeature.m11396V(z212, mappingEditorFeature82, i252, i242, new m03((byte) 1));
                                            break;
                                        case 3:
                                            f05 f05Var2 = mappingEditorFeature82.f14339t;
                                            if (z212) {
                                                if (i252 >= 0 && i252 < f05Var2.size()) {
                                                    x13 x13Var3 = (x13) f05Var2.get(i252);
                                                    x13Var3.getClass();
                                                    f05Var2.set(i252, u43.m20649b(i242, 1, x13Var3));
                                                }
                                            } else if (i252 >= 0 && i252 < f05Var2.size()) {
                                                x13 x13Var4 = (x13) f05Var2.get(i252);
                                                x13Var4.getClass();
                                                f05Var2.set(i252, u43.m20650c(i242, 1, x13Var4));
                                            }
                                            mappingEditorFeature82.m11413c0();
                                            break;
                                        default:
                                            if (z212) {
                                                mappingEditorFeature82.m11415e0(i252, new zv1((byte) 5, i242));
                                            } else {
                                                mappingEditorFeature82.m11415e0(i252, new zv1(b42, i242));
                                            }
                                            mappingEditorFeature82.m11413c0();
                                            break;
                                    }
                                    return kn5Var;
                                }
                            };
                            s02Var5.m19330k0(m19298O3);
                        }
                        v86.m21312g("✕", false, j2, (xy1) m19298O3, s02Var5, 6, 2);
                        s02Var5.m19338p(true);
                        final ra5 ra5Var4 = ra5.this;
                        j53 j53Var2 = ra5Var4.f33455c;
                        boolean z23 = ra5Var4.f33462j;
                        boolean z24 = z;
                        j53 j53Var3 = j53.f19671a;
                        if (j53Var2 != j53Var3 || (z24 && i7 == 0)) {
                            z7 = false;
                            s02Var5.m19308Z(56794719);
                            s02Var5.m19338p(false);
                        } else {
                            s02Var5.m19308Z(56590987);
                            boolean z25 = ra5Var4.f33463k;
                            boolean m19321g4 = s02Var5.m19321g(z6) | s02Var5.m19323h(mappingEditorFeature) | s02Var5.m19315d(i6) | s02Var5.m19315d(i7);
                            Object m19298O4 = s02Var5.m19298O();
                            if (m19321g4 || m19298O4 == sv8Var2) {
                                final byte b5 = 3;
                                final int i28 = i7;
                                final boolean z26 = z6;
                                final MappingEditorFeature mappingEditorFeature10 = mappingEditorFeature;
                                final int i29 = i6;
                                m19298O4 = new zy1() { // from class: q33
                                    @Override // p000.zy1
                                    public final Object invoke(Object obj3) {
                                        byte b6 = b5;
                                        byte b7 = 2;
                                        byte b8 = 4;
                                        kn5 kn5Var = kn5.f22076a;
                                        int i30 = i28;
                                        int i31 = i29;
                                        MappingEditorFeature mappingEditorFeature11 = mappingEditorFeature10;
                                        boolean z27 = z26;
                                        switch (b6) {
                                            case 0:
                                                MappingEditorFeature.m11396V(z27, mappingEditorFeature11, i31, i30, new C1573t9(((Float) obj3).floatValue(), (byte) 7));
                                                break;
                                            case 1:
                                                MappingEditorFeature.m11396V(z27, mappingEditorFeature11, i31, i30, new zv1((byte) 8, ((Integer) obj3).intValue()));
                                                break;
                                            case 2:
                                                MappingEditorFeature.m11396V(z27, mappingEditorFeature11, i31, i30, new zv1(b7, ((Integer) obj3).intValue()));
                                                break;
                                            case 3:
                                                MappingEditorFeature.m11396V(z27, mappingEditorFeature11, i31, i30, new C1622ui((byte) 2, ((Boolean) obj3).booleanValue()));
                                                break;
                                            case 4:
                                                wu3 wu3Var = (wu3) obj3;
                                                wu3Var.getClass();
                                                MappingEditorFeature.m11396V(z27, mappingEditorFeature11, i31, i30, new m33(wu3Var, (byte) 1));
                                                break;
                                            case 5:
                                                j53 j53Var4 = (j53) obj3;
                                                j53Var4.getClass();
                                                MappingEditorFeature.m11396V(z27, mappingEditorFeature11, i31, i30, new s33(j53Var4, (byte) 1));
                                                break;
                                            case 6:
                                                MappingEditorFeature.m11396V(z27, mappingEditorFeature11, i31, i30, new zv1(b8, ((Integer) obj3).intValue()));
                                                break;
                                            case 7:
                                                MappingEditorFeature.m11396V(z27, mappingEditorFeature11, i31, i30, new C1622ui((byte) 4, ((Boolean) obj3).booleanValue()));
                                                break;
                                            default:
                                                MappingEditorFeature.m11396V(z27, mappingEditorFeature11, i31, i30, new C1573t9(((Float) obj3).floatValue(), jq5.f20569f));
                                                break;
                                        }
                                        return kn5Var;
                                    }
                                };
                                s02Var5.m19330k0(m19298O4);
                            }
                            v86.m21302b("Start on release (pending)", z25, (zy1) m19298O4, s02Var5, 6);
                            z7 = false;
                            s02Var5.m19338p(false);
                        }
                        if (z24 && i7 == 0 && !z6) {
                            s02Var5.m19308Z(56862299);
                            wu3 wu3Var = ra5Var4.f33464l;
                            boolean m19321g5 = s02Var5.m19321g(z6) | s02Var5.m19323h(mappingEditorFeature) | s02Var5.m19315d(i6) | s02Var5.m19315d(i7);
                            Object m19298O5 = s02Var5.m19298O();
                            if (m19321g5 || m19298O5 == sv8Var2) {
                                final byte b6 = 4;
                                final int i30 = i7;
                                final boolean z27 = z6;
                                final MappingEditorFeature mappingEditorFeature11 = mappingEditorFeature;
                                i20 = i6;
                                m19298O5 = new zy1() { // from class: q33
                                    @Override // p000.zy1
                                    public final Object invoke(Object obj3) {
                                        byte b62 = b6;
                                        byte b7 = 2;
                                        byte b8 = 4;
                                        kn5 kn5Var = kn5.f22076a;
                                        int i302 = i30;
                                        int i31 = i20;
                                        MappingEditorFeature mappingEditorFeature112 = mappingEditorFeature11;
                                        boolean z272 = z27;
                                        switch (b62) {
                                            case 0:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i31, i302, new C1573t9(((Float) obj3).floatValue(), (byte) 7));
                                                break;
                                            case 1:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i31, i302, new zv1((byte) 8, ((Integer) obj3).intValue()));
                                                break;
                                            case 2:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i31, i302, new zv1(b7, ((Integer) obj3).intValue()));
                                                break;
                                            case 3:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i31, i302, new C1622ui((byte) 2, ((Boolean) obj3).booleanValue()));
                                                break;
                                            case 4:
                                                wu3 wu3Var2 = (wu3) obj3;
                                                wu3Var2.getClass();
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i31, i302, new m33(wu3Var2, (byte) 1));
                                                break;
                                            case 5:
                                                j53 j53Var4 = (j53) obj3;
                                                j53Var4.getClass();
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i31, i302, new s33(j53Var4, (byte) 1));
                                                break;
                                            case 6:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i31, i302, new zv1(b8, ((Integer) obj3).intValue()));
                                                break;
                                            case 7:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i31, i302, new C1622ui((byte) 4, ((Boolean) obj3).booleanValue()));
                                                break;
                                            default:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i31, i302, new C1573t9(((Float) obj3).floatValue(), jq5.f20569f));
                                                break;
                                        }
                                        return kn5Var;
                                    }
                                };
                                z9 = z27;
                                mappingEditorFeature2 = mappingEditorFeature11;
                                i9 = i30;
                                s02Var5.m19330k0(m19298O5);
                            } else {
                                i20 = i6;
                                mappingEditorFeature2 = mappingEditorFeature;
                                z9 = z6;
                                i9 = i7;
                            }
                            z8 = z23;
                            s02Var2 = s02Var5;
                            i8 = i20;
                            v86.m21314h("Pending action", wu3.f42928c, wu3Var, (zy1) m19298O5, s02Var2, 6);
                            s02Var2.m19338p(z7);
                        } else {
                            z8 = z23;
                            s02Var2 = s02Var5;
                            i8 = i6;
                            mappingEditorFeature2 = mappingEditorFeature;
                            z9 = z6;
                            i9 = i7;
                            s02Var2.m19308Z(57081407);
                            s02Var2.m19338p(z7);
                        }
                        Object m19298O6 = s02Var2.m19298O();
                        j53 j53Var4 = j53.f19673c;
                        j53 j53Var5 = j53.f19672b;
                        if (m19298O6 == sv8Var2) {
                            m19298O6 = jj0.m14031D(j53Var3, j53Var5, j53Var4);
                            s02Var2.m19330k0(m19298O6);
                        }
                        List list = (List) m19298O6;
                        j53 j53Var6 = ra5Var4.f33455c;
                        boolean m19321g6 = s02Var2.m19321g(z9) | s02Var2.m19323h(mappingEditorFeature2) | s02Var2.m19315d(i8) | s02Var2.m19315d(i9);
                        Object m19298O7 = s02Var2.m19298O();
                        if (m19321g6 || m19298O7 == sv8Var2) {
                            final byte b7 = 5;
                            final int i31 = i9;
                            final boolean z28 = z9;
                            final MappingEditorFeature mappingEditorFeature12 = mappingEditorFeature2;
                            final int i32 = i8;
                            m19298O7 = new zy1() { // from class: q33
                                @Override // p000.zy1
                                public final Object invoke(Object obj3) {
                                    byte b62 = b7;
                                    byte b72 = 2;
                                    byte b8 = 4;
                                    kn5 kn5Var = kn5.f22076a;
                                    int i302 = i31;
                                    int i312 = i32;
                                    MappingEditorFeature mappingEditorFeature112 = mappingEditorFeature12;
                                    boolean z272 = z28;
                                    switch (b62) {
                                        case 0:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), (byte) 7));
                                            break;
                                        case 1:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1((byte) 8, ((Integer) obj3).intValue()));
                                            break;
                                        case 2:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b72, ((Integer) obj3).intValue()));
                                            break;
                                        case 3:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 2, ((Boolean) obj3).booleanValue()));
                                            break;
                                        case 4:
                                            wu3 wu3Var2 = (wu3) obj3;
                                            wu3Var2.getClass();
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new m33(wu3Var2, (byte) 1));
                                            break;
                                        case 5:
                                            j53 j53Var42 = (j53) obj3;
                                            j53Var42.getClass();
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new s33(j53Var42, (byte) 1));
                                            break;
                                        case 6:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b8, ((Integer) obj3).intValue()));
                                            break;
                                        case 7:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 4, ((Boolean) obj3).booleanValue()));
                                            break;
                                        default:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), jq5.f20569f));
                                            break;
                                    }
                                    return kn5Var;
                                }
                            };
                            s02Var2.m19330k0(m19298O7);
                        }
                        v86.m21314h("Type", list, j53Var6, (zy1) m19298O7, s02Var2, 6);
                        String m8803j = d63.m8803j(ra5Var4.f33457e, " ms");
                        int i33 = ra5Var4.f33457e;
                        boolean m19321g7 = s02Var2.m19321g(z9) | s02Var2.m19323h(mappingEditorFeature2) | s02Var2.m19315d(i8) | s02Var2.m19315d(i9);
                        Object m19298O8 = s02Var2.m19298O();
                        if (m19321g7 || m19298O8 == sv8Var2) {
                            final byte b8 = 6;
                            final int i34 = i9;
                            final boolean z29 = z9;
                            final MappingEditorFeature mappingEditorFeature13 = mappingEditorFeature2;
                            i10 = i8;
                            m19298O8 = new zy1() { // from class: q33
                                @Override // p000.zy1
                                public final Object invoke(Object obj3) {
                                    byte b62 = b8;
                                    byte b72 = 2;
                                    byte b82 = 4;
                                    kn5 kn5Var = kn5.f22076a;
                                    int i302 = i34;
                                    int i312 = i10;
                                    MappingEditorFeature mappingEditorFeature112 = mappingEditorFeature13;
                                    boolean z272 = z29;
                                    switch (b62) {
                                        case 0:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), (byte) 7));
                                            break;
                                        case 1:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1((byte) 8, ((Integer) obj3).intValue()));
                                            break;
                                        case 2:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b72, ((Integer) obj3).intValue()));
                                            break;
                                        case 3:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 2, ((Boolean) obj3).booleanValue()));
                                            break;
                                        case 4:
                                            wu3 wu3Var2 = (wu3) obj3;
                                            wu3Var2.getClass();
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new m33(wu3Var2, (byte) 1));
                                            break;
                                        case 5:
                                            j53 j53Var42 = (j53) obj3;
                                            j53Var42.getClass();
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new s33(j53Var42, (byte) 1));
                                            break;
                                        case 6:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b82, ((Integer) obj3).intValue()));
                                            break;
                                        case 7:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 4, ((Boolean) obj3).booleanValue()));
                                            break;
                                        default:
                                            MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), jq5.f20569f));
                                            break;
                                    }
                                    return kn5Var;
                                }
                            };
                            z10 = z29;
                            mappingEditorFeature3 = mappingEditorFeature13;
                            i11 = i34;
                            s02Var2.m19330k0(m19298O8);
                        } else {
                            i10 = i8;
                            mappingEditorFeature3 = mappingEditorFeature2;
                            z10 = z9;
                            i11 = i9;
                        }
                        s02 s02Var6 = s02Var2;
                        boolean z30 = z8;
                        j53 j53Var7 = j53Var2;
                        final int i35 = i11;
                        final int i36 = i10;
                        v86.m21322l("Start delay", m8803j, 5, 0, i33, true, false, (zy1) m19298O8, s02Var6, 200070, 64);
                        s02 s02Var7 = s02Var6;
                        if (j53Var7 == j53Var5) {
                            s02Var7.m19308Z(57754603);
                            boolean m19321g8 = s02Var7.m19321g(z10) | s02Var7.m19323h(mappingEditorFeature3) | s02Var7.m19315d(i36) | s02Var7.m19315d(i35);
                            Object m19298O9 = s02Var7.m19298O();
                            sv8Var = sv8Var2;
                            if (m19321g8 || m19298O9 == sv8Var) {
                                final byte b9 = 7;
                                final boolean z31 = z10;
                                final MappingEditorFeature mappingEditorFeature14 = mappingEditorFeature3;
                                m19298O9 = new zy1() { // from class: q33
                                    @Override // p000.zy1
                                    public final Object invoke(Object obj3) {
                                        byte b62 = b9;
                                        byte b72 = 2;
                                        byte b82 = 4;
                                        kn5 kn5Var = kn5.f22076a;
                                        int i302 = i35;
                                        int i312 = i36;
                                        MappingEditorFeature mappingEditorFeature112 = mappingEditorFeature14;
                                        boolean z272 = z31;
                                        switch (b62) {
                                            case 0:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), (byte) 7));
                                                break;
                                            case 1:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1((byte) 8, ((Integer) obj3).intValue()));
                                                break;
                                            case 2:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b72, ((Integer) obj3).intValue()));
                                                break;
                                            case 3:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 2, ((Boolean) obj3).booleanValue()));
                                                break;
                                            case 4:
                                                wu3 wu3Var2 = (wu3) obj3;
                                                wu3Var2.getClass();
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new m33(wu3Var2, (byte) 1));
                                                break;
                                            case 5:
                                                j53 j53Var42 = (j53) obj3;
                                                j53Var42.getClass();
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new s33(j53Var42, (byte) 1));
                                                break;
                                            case 6:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b82, ((Integer) obj3).intValue()));
                                                break;
                                            case 7:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 4, ((Boolean) obj3).booleanValue()));
                                                break;
                                            default:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), jq5.f20569f));
                                                break;
                                        }
                                        return kn5Var;
                                    }
                                };
                                z16 = z31;
                                mappingEditorFeature5 = mappingEditorFeature14;
                                i16 = i36;
                                i17 = i35;
                                s02Var7.m19330k0(m19298O9);
                            } else {
                                i17 = i35;
                                z16 = z10;
                                i16 = i36;
                                mappingEditorFeature5 = mappingEditorFeature3;
                            }
                            v86.m21302b("Hold only", z30, (zy1) m19298O9, s02Var7, 6);
                            if (z30) {
                                mappingEditorFeature3 = mappingEditorFeature5;
                                i12 = i16;
                                ra5Var2 = ra5Var4;
                                z10 = z16;
                                i13 = i17;
                                z11 = false;
                                s02Var7.m19308Z(59724095);
                                s02Var7.m19338p(false);
                            } else {
                                s02Var7.m19308Z(58114420);
                                float f = ra5Var4.f33460h;
                                float m19407a = s32.m19407a();
                                boolean m19321g9 = s02Var7.m19321g(z16) | s02Var7.m19323h(mappingEditorFeature5) | s02Var7.m19315d(i16) | s02Var7.m19315d(i17);
                                Object m19298O10 = s02Var7.m19298O();
                                if (m19321g9 || m19298O10 == sv8Var) {
                                    final byte b10 = 8;
                                    final int i37 = i17;
                                    final boolean z32 = z16;
                                    final MappingEditorFeature mappingEditorFeature15 = mappingEditorFeature5;
                                    final int i38 = i16;
                                    m19298O10 = new zy1() { // from class: q33
                                        @Override // p000.zy1
                                        public final Object invoke(Object obj3) {
                                            byte b62 = b10;
                                            byte b72 = 2;
                                            byte b82 = 4;
                                            kn5 kn5Var = kn5.f22076a;
                                            int i302 = i37;
                                            int i312 = i38;
                                            MappingEditorFeature mappingEditorFeature112 = mappingEditorFeature15;
                                            boolean z272 = z32;
                                            switch (b62) {
                                                case 0:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), (byte) 7));
                                                    break;
                                                case 1:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1((byte) 8, ((Integer) obj3).intValue()));
                                                    break;
                                                case 2:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b72, ((Integer) obj3).intValue()));
                                                    break;
                                                case 3:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 2, ((Boolean) obj3).booleanValue()));
                                                    break;
                                                case 4:
                                                    wu3 wu3Var2 = (wu3) obj3;
                                                    wu3Var2.getClass();
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new m33(wu3Var2, (byte) 1));
                                                    break;
                                                case 5:
                                                    j53 j53Var42 = (j53) obj3;
                                                    j53Var42.getClass();
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new s33(j53Var42, (byte) 1));
                                                    break;
                                                case 6:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b82, ((Integer) obj3).intValue()));
                                                    break;
                                                case 7:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 4, ((Boolean) obj3).booleanValue()));
                                                    break;
                                                default:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), jq5.f20569f));
                                                    break;
                                            }
                                            return kn5Var;
                                        }
                                    };
                                    s02Var7.m19330k0(m19298O10);
                                }
                                zy1 zy1Var = (zy1) m19298O10;
                                boolean m19323h2 = s02Var7.m19323h(ra5Var4) | s02Var7.m19321g(z16) | s02Var7.m19323h(mappingEditorFeature5) | s02Var7.m19315d(i16) | s02Var7.m19315d(i17);
                                Object m19298O11 = s02Var7.m19298O();
                                if (m19323h2 || m19298O11 == sv8Var) {
                                    final byte b11 = 1;
                                    final int i39 = i17;
                                    final boolean z33 = z16;
                                    final MappingEditorFeature mappingEditorFeature16 = mappingEditorFeature5;
                                    final int i40 = i16;
                                    m19298O11 = new zy1() { // from class: r33
                                        @Override // p000.zy1
                                        public final Object invoke(Object obj3) {
                                            byte b12 = b11;
                                            kn5 kn5Var = kn5.f22076a;
                                            int i41 = i39;
                                            int i42 = i40;
                                            MappingEditorFeature mappingEditorFeature17 = mappingEditorFeature16;
                                            boolean z34 = z33;
                                            ra5 ra5Var5 = ra5Var4;
                                            int intValue2 = ((Integer) obj3).intValue();
                                            switch (b12) {
                                                case 0:
                                                    MappingEditorFeature.m11396V(z34, mappingEditorFeature17, i42, i41, new C1573t9(dg2.m9131s((intValue2 * 0.01f) + ra5Var5.f33461i, 0.0f, s32.m19407a()), (byte) 13));
                                                    break;
                                                default:
                                                    MappingEditorFeature.m11396V(z34, mappingEditorFeature17, i42, i41, new C1573t9(dg2.m9131s((intValue2 * 0.01f) + ra5Var5.f33460h, 0.0f, s32.m19407a()), (byte) 8));
                                                    break;
                                            }
                                            return kn5Var;
                                        }
                                    };
                                    ra5Var3 = ra5Var4;
                                    s02Var7.m19330k0(m19298O11);
                                } else {
                                    ra5Var3 = ra5Var4;
                                }
                                zy1 zy1Var2 = (zy1) m19298O11;
                                boolean m19321g10 = s02Var7.m19321g(z16) | s02Var7.m19323h(mappingEditorFeature5) | s02Var7.m19315d(i16) | s02Var7.m19315d(i17);
                                Object m19298O12 = s02Var7.m19298O();
                                if (m19321g10 || m19298O12 == sv8Var) {
                                    final byte b12 = 1;
                                    final int i41 = i17;
                                    final boolean z34 = z16;
                                    final MappingEditorFeature mappingEditorFeature17 = mappingEditorFeature5;
                                    final int i42 = i16;
                                    m19298O12 = new xy1() { // from class: p33
                                        @Override // p000.xy1
                                        public final Object invoke() {
                                            byte b32 = b12;
                                            byte b42 = 6;
                                            kn5 kn5Var = kn5.f22076a;
                                            int i242 = i41;
                                            int i252 = i42;
                                            MappingEditorFeature mappingEditorFeature82 = mappingEditorFeature17;
                                            boolean z212 = z34;
                                            switch (b32) {
                                                case 0:
                                                    f05 f05Var = mappingEditorFeature82.f14339t;
                                                    if (z212) {
                                                        if (i252 >= 0 && i252 < f05Var.size()) {
                                                            x13 x13Var = (x13) f05Var.get(i252);
                                                            x13Var.getClass();
                                                            f05Var.set(i252, u43.m20649b(i242, -1, x13Var));
                                                        }
                                                    } else if (i252 >= 0 && i252 < f05Var.size()) {
                                                        x13 x13Var2 = (x13) f05Var.get(i252);
                                                        x13Var2.getClass();
                                                        f05Var.set(i252, u43.m20650c(i242, -1, x13Var2));
                                                    }
                                                    mappingEditorFeature82.m11413c0();
                                                    break;
                                                case 1:
                                                    MappingEditorFeature.m11396V(z212, mappingEditorFeature82, i252, i242, new m03((byte) 6));
                                                    break;
                                                case 2:
                                                    MappingEditorFeature.m11396V(z212, mappingEditorFeature82, i252, i242, new m03((byte) 1));
                                                    break;
                                                case 3:
                                                    f05 f05Var2 = mappingEditorFeature82.f14339t;
                                                    if (z212) {
                                                        if (i252 >= 0 && i252 < f05Var2.size()) {
                                                            x13 x13Var3 = (x13) f05Var2.get(i252);
                                                            x13Var3.getClass();
                                                            f05Var2.set(i252, u43.m20649b(i242, 1, x13Var3));
                                                        }
                                                    } else if (i252 >= 0 && i252 < f05Var2.size()) {
                                                        x13 x13Var4 = (x13) f05Var2.get(i252);
                                                        x13Var4.getClass();
                                                        f05Var2.set(i252, u43.m20650c(i242, 1, x13Var4));
                                                    }
                                                    mappingEditorFeature82.m11413c0();
                                                    break;
                                                default:
                                                    if (z212) {
                                                        mappingEditorFeature82.m11415e0(i252, new zv1((byte) 5, i242));
                                                    } else {
                                                        mappingEditorFeature82.m11415e0(i252, new zv1(b42, i242));
                                                    }
                                                    mappingEditorFeature82.m11413c0();
                                                    break;
                                            }
                                            return kn5Var;
                                        }
                                    };
                                    z17 = z34;
                                    mappingEditorFeature6 = mappingEditorFeature17;
                                    i18 = i42;
                                    i13 = i41;
                                    s02Var7.m19330k0(m19298O12);
                                } else {
                                    i18 = i16;
                                    mappingEditorFeature6 = mappingEditorFeature5;
                                    z17 = z16;
                                    i13 = i17;
                                }
                                v86.m21318j(f, zy1Var, zy1Var2, "Sensitivity X (Horizontal)", (xy1) m19298O12, m19407a, s02Var7, 3072);
                                float f2 = ra5Var3.f33461i;
                                float m19407a2 = s32.m19407a();
                                boolean m19321g11 = s02Var7.m19321g(z17) | s02Var7.m19323h(mappingEditorFeature6) | s02Var7.m19315d(i18) | s02Var7.m19315d(i13);
                                Object m19298O13 = s02Var7.m19298O();
                                if (m19321g11 || m19298O13 == sv8Var) {
                                    final byte b13 = 0;
                                    final int i43 = i13;
                                    final boolean z35 = z17;
                                    final MappingEditorFeature mappingEditorFeature18 = mappingEditorFeature6;
                                    final int i44 = i18;
                                    m19298O13 = new zy1() { // from class: q33
                                        @Override // p000.zy1
                                        public final Object invoke(Object obj3) {
                                            byte b62 = b13;
                                            byte b72 = 2;
                                            byte b82 = 4;
                                            kn5 kn5Var = kn5.f22076a;
                                            int i302 = i43;
                                            int i312 = i44;
                                            MappingEditorFeature mappingEditorFeature112 = mappingEditorFeature18;
                                            boolean z272 = z35;
                                            switch (b62) {
                                                case 0:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), (byte) 7));
                                                    break;
                                                case 1:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1((byte) 8, ((Integer) obj3).intValue()));
                                                    break;
                                                case 2:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b72, ((Integer) obj3).intValue()));
                                                    break;
                                                case 3:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 2, ((Boolean) obj3).booleanValue()));
                                                    break;
                                                case 4:
                                                    wu3 wu3Var2 = (wu3) obj3;
                                                    wu3Var2.getClass();
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new m33(wu3Var2, (byte) 1));
                                                    break;
                                                case 5:
                                                    j53 j53Var42 = (j53) obj3;
                                                    j53Var42.getClass();
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new s33(j53Var42, (byte) 1));
                                                    break;
                                                case 6:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b82, ((Integer) obj3).intValue()));
                                                    break;
                                                case 7:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 4, ((Boolean) obj3).booleanValue()));
                                                    break;
                                                default:
                                                    MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), jq5.f20569f));
                                                    break;
                                            }
                                            return kn5Var;
                                        }
                                    };
                                    s02Var7.m19330k0(m19298O13);
                                }
                                zy1 zy1Var3 = (zy1) m19298O13;
                                boolean m19323h3 = s02Var7.m19323h(ra5Var3) | s02Var7.m19321g(z17) | s02Var7.m19323h(mappingEditorFeature6) | s02Var7.m19315d(i18) | s02Var7.m19315d(i13);
                                Object m19298O14 = s02Var7.m19298O();
                                if (m19323h3 || m19298O14 == sv8Var) {
                                    final byte b14 = 0;
                                    final ra5 ra5Var5 = ra5Var3;
                                    final int i45 = i13;
                                    final boolean z36 = z17;
                                    final MappingEditorFeature mappingEditorFeature19 = mappingEditorFeature6;
                                    final int i46 = i18;
                                    m19298O14 = new zy1() { // from class: r33
                                        @Override // p000.zy1
                                        public final Object invoke(Object obj3) {
                                            byte b122 = b14;
                                            kn5 kn5Var = kn5.f22076a;
                                            int i412 = i45;
                                            int i422 = i46;
                                            MappingEditorFeature mappingEditorFeature172 = mappingEditorFeature19;
                                            boolean z342 = z36;
                                            ra5 ra5Var52 = ra5Var5;
                                            int intValue2 = ((Integer) obj3).intValue();
                                            switch (b122) {
                                                case 0:
                                                    MappingEditorFeature.m11396V(z342, mappingEditorFeature172, i422, i412, new C1573t9(dg2.m9131s((intValue2 * 0.01f) + ra5Var52.f33461i, 0.0f, s32.m19407a()), (byte) 13));
                                                    break;
                                                default:
                                                    MappingEditorFeature.m11396V(z342, mappingEditorFeature172, i422, i412, new C1573t9(dg2.m9131s((intValue2 * 0.01f) + ra5Var52.f33460h, 0.0f, s32.m19407a()), (byte) 8));
                                                    break;
                                            }
                                            return kn5Var;
                                        }
                                    };
                                    ra5Var2 = ra5Var5;
                                    z10 = z36;
                                    mappingEditorFeature3 = mappingEditorFeature19;
                                    i19 = i46;
                                    s02Var7.m19330k0(m19298O14);
                                } else {
                                    i19 = i18;
                                    mappingEditorFeature3 = mappingEditorFeature6;
                                    z10 = z17;
                                    ra5Var2 = ra5Var3;
                                }
                                zy1 zy1Var4 = (zy1) m19298O14;
                                boolean m19321g12 = s02Var7.m19321g(z10) | s02Var7.m19323h(mappingEditorFeature3) | s02Var7.m19315d(i19) | s02Var7.m19315d(i13);
                                Object m19298O15 = s02Var7.m19298O();
                                if (m19321g12 || m19298O15 == sv8Var) {
                                    final byte b15 = 2;
                                    final int i47 = i19;
                                    final int i48 = i13;
                                    final boolean z37 = z10;
                                    final MappingEditorFeature mappingEditorFeature20 = mappingEditorFeature3;
                                    m19298O15 = new xy1() { // from class: p33
                                        @Override // p000.xy1
                                        public final Object invoke() {
                                            byte b32 = b15;
                                            byte b42 = 6;
                                            kn5 kn5Var = kn5.f22076a;
                                            int i242 = i48;
                                            int i252 = i47;
                                            MappingEditorFeature mappingEditorFeature82 = mappingEditorFeature20;
                                            boolean z212 = z37;
                                            switch (b32) {
                                                case 0:
                                                    f05 f05Var = mappingEditorFeature82.f14339t;
                                                    if (z212) {
                                                        if (i252 >= 0 && i252 < f05Var.size()) {
                                                            x13 x13Var = (x13) f05Var.get(i252);
                                                            x13Var.getClass();
                                                            f05Var.set(i252, u43.m20649b(i242, -1, x13Var));
                                                        }
                                                    } else if (i252 >= 0 && i252 < f05Var.size()) {
                                                        x13 x13Var2 = (x13) f05Var.get(i252);
                                                        x13Var2.getClass();
                                                        f05Var.set(i252, u43.m20650c(i242, -1, x13Var2));
                                                    }
                                                    mappingEditorFeature82.m11413c0();
                                                    break;
                                                case 1:
                                                    MappingEditorFeature.m11396V(z212, mappingEditorFeature82, i252, i242, new m03((byte) 6));
                                                    break;
                                                case 2:
                                                    MappingEditorFeature.m11396V(z212, mappingEditorFeature82, i252, i242, new m03((byte) 1));
                                                    break;
                                                case 3:
                                                    f05 f05Var2 = mappingEditorFeature82.f14339t;
                                                    if (z212) {
                                                        if (i252 >= 0 && i252 < f05Var2.size()) {
                                                            x13 x13Var3 = (x13) f05Var2.get(i252);
                                                            x13Var3.getClass();
                                                            f05Var2.set(i252, u43.m20649b(i242, 1, x13Var3));
                                                        }
                                                    } else if (i252 >= 0 && i252 < f05Var2.size()) {
                                                        x13 x13Var4 = (x13) f05Var2.get(i252);
                                                        x13Var4.getClass();
                                                        f05Var2.set(i252, u43.m20650c(i242, 1, x13Var4));
                                                    }
                                                    mappingEditorFeature82.m11413c0();
                                                    break;
                                                default:
                                                    if (z212) {
                                                        mappingEditorFeature82.m11415e0(i252, new zv1((byte) 5, i242));
                                                    } else {
                                                        mappingEditorFeature82.m11415e0(i252, new zv1(b42, i242));
                                                    }
                                                    mappingEditorFeature82.m11413c0();
                                                    break;
                                            }
                                            return kn5Var;
                                        }
                                    };
                                    i12 = i47;
                                    s02Var7.m19330k0(m19298O15);
                                } else {
                                    i12 = i19;
                                }
                                v86.m21318j(f2, zy1Var3, zy1Var4, "Sensitivity Y (Vertical)", (xy1) m19298O15, m19407a2, s02Var7, 3072);
                                z11 = false;
                                s02Var7.m19338p(false);
                            }
                            s02Var7.m19338p(z11);
                        } else {
                            i12 = i36;
                            sv8Var = sv8Var2;
                            i13 = i35;
                            ra5Var2 = ra5Var4;
                            z11 = false;
                            s02Var7.m19308Z(59741951);
                            s02Var7.m19338p(false);
                        }
                        if (j53Var7 == j53Var4) {
                            s02Var7.m19308Z(59823419);
                            String m8803j2 = d63.m8803j(Math.max(ra5Var2.f33458f, 2), " ms");
                            ?? r3 = s32.m19408b() ? z11 : 60;
                            int i49 = ra5Var2.f33458f;
                            boolean z38 = i49 < 25 ? true : z11;
                            boolean m19321g13 = s02Var7.m19321g(z10) | s02Var7.m19323h(mappingEditorFeature3) | s02Var7.m19315d(i12) | s02Var7.m19315d(i13);
                            Object m19298O16 = s02Var7.m19298O();
                            if (m19321g13 || m19298O16 == sv8Var) {
                                final byte b16 = 1;
                                i14 = i12;
                                final int i50 = i13;
                                final boolean z39 = z10;
                                mappingEditorFeature4 = mappingEditorFeature3;
                                m19298O16 = new zy1() { // from class: q33
                                    @Override // p000.zy1
                                    public final Object invoke(Object obj3) {
                                        byte b62 = b16;
                                        byte b72 = 2;
                                        byte b82 = 4;
                                        kn5 kn5Var = kn5.f22076a;
                                        int i302 = i50;
                                        int i312 = i14;
                                        MappingEditorFeature mappingEditorFeature112 = mappingEditorFeature4;
                                        boolean z272 = z39;
                                        switch (b62) {
                                            case 0:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), (byte) 7));
                                                break;
                                            case 1:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1((byte) 8, ((Integer) obj3).intValue()));
                                                break;
                                            case 2:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b72, ((Integer) obj3).intValue()));
                                                break;
                                            case 3:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 2, ((Boolean) obj3).booleanValue()));
                                                break;
                                            case 4:
                                                wu3 wu3Var2 = (wu3) obj3;
                                                wu3Var2.getClass();
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new m33(wu3Var2, (byte) 1));
                                                break;
                                            case 5:
                                                j53 j53Var42 = (j53) obj3;
                                                j53Var42.getClass();
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new s33(j53Var42, (byte) 1));
                                                break;
                                            case 6:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b82, ((Integer) obj3).intValue()));
                                                break;
                                            case 7:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 4, ((Boolean) obj3).booleanValue()));
                                                break;
                                            default:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), jq5.f20569f));
                                                break;
                                        }
                                        return kn5Var;
                                    }
                                };
                                z15 = z39;
                                i15 = i50;
                                s02Var7.m19330k0(m19298O16);
                            } else {
                                i14 = i12;
                                mappingEditorFeature4 = mappingEditorFeature3;
                                z15 = z10;
                                i15 = i13;
                            }
                            sv8 sv8Var3 = sv8Var;
                            final int i51 = i15;
                            final MappingEditorFeature mappingEditorFeature21 = mappingEditorFeature4;
                            final int i52 = i14;
                            v86.m21322l("Interval", m8803j2, 5, r3, i49, true, z38, (zy1) m19298O16, s02Var7, 196998, 0);
                            String m8803j3 = d63.m8803j(Math.max(ra5Var2.f33459g, 1), " ms");
                            int i53 = s32.m19408b() ? 0 : 15;
                            int i54 = ra5Var2.f33459g;
                            boolean m19321g14 = s02Var7.m19321g(z15) | s02Var7.m19323h(mappingEditorFeature21) | s02Var7.m19315d(i52) | s02Var7.m19315d(i51);
                            Object m19298O17 = s02Var7.m19298O();
                            if (m19321g14 || m19298O17 == sv8Var3) {
                                final byte b17 = 2;
                                final boolean z40 = z15;
                                m19298O17 = new zy1() { // from class: q33
                                    @Override // p000.zy1
                                    public final Object invoke(Object obj3) {
                                        byte b62 = b17;
                                        byte b72 = 2;
                                        byte b82 = 4;
                                        kn5 kn5Var = kn5.f22076a;
                                        int i302 = i51;
                                        int i312 = i52;
                                        MappingEditorFeature mappingEditorFeature112 = mappingEditorFeature21;
                                        boolean z272 = z40;
                                        switch (b62) {
                                            case 0:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), (byte) 7));
                                                break;
                                            case 1:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1((byte) 8, ((Integer) obj3).intValue()));
                                                break;
                                            case 2:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b72, ((Integer) obj3).intValue()));
                                                break;
                                            case 3:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 2, ((Boolean) obj3).booleanValue()));
                                                break;
                                            case 4:
                                                wu3 wu3Var2 = (wu3) obj3;
                                                wu3Var2.getClass();
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new m33(wu3Var2, (byte) 1));
                                                break;
                                            case 5:
                                                j53 j53Var42 = (j53) obj3;
                                                j53Var42.getClass();
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new s33(j53Var42, (byte) 1));
                                                break;
                                            case 6:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new zv1(b82, ((Integer) obj3).intValue()));
                                                break;
                                            case 7:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1622ui((byte) 4, ((Boolean) obj3).booleanValue()));
                                                break;
                                            default:
                                                MappingEditorFeature.m11396V(z272, mappingEditorFeature112, i312, i302, new C1573t9(((Float) obj3).floatValue(), jq5.f20569f));
                                                break;
                                        }
                                        return kn5Var;
                                    }
                                };
                                s02Var7.m19330k0(m19298O17);
                            }
                            z12 = true;
                            v86.m21322l("Tap Duration", m8803j3, 5, i53, i54, true, false, (zy1) m19298O17, s02Var7, 196998, 64);
                            s02 s02Var8 = s02Var7;
                            z13 = 0;
                            s02Var8.m19338p(false);
                            j53Var = j53Var5;
                            j53Var7 = j53Var7;
                            s02Var3 = s02Var8;
                        } else {
                            boolean z41 = z11;
                            z12 = true;
                            s02Var7.m19308Z(60503807);
                            s02Var7.m19338p(z41);
                            j53Var = j53Var5;
                            s02Var3 = s02Var7;
                            z13 = z41;
                        }
                        if (j53Var7 == j53Var) {
                            s02Var3.m19308Z(60682181);
                            ug4 m19739a2 = sg4.m19739a(AbstractC1443pv.f30965a, o70Var, s02Var3, 48);
                            int hashCode3 = Long.hashCode(s02Var3.f34520T);
                            ov3 m19331l3 = s02Var3.m19331l();
                            na3 m20748R3 = u99.m20748R(s02Var3, ka3Var);
                            s02Var3.m19316d0();
                            if (s02Var3.f34519S) {
                                s02Var3.m19329k(me2Var);
                            } else {
                                s02Var3.m19336n0();
                            }
                            z80.m23871N(xm0Var, s02Var3, m19739a2);
                            z80.m23871N(xm0Var2, s02Var3, m19331l3);
                            hn0.m12946s(hashCode3, s02Var3, xm0Var3, s02Var3);
                            z80.m23871N(xm0Var4, s02Var3, m20748R3);
                            s02 s02Var9 = s02Var3;
                            kb2.m14510a(z21.m23719B(R.drawable.claude_spark, s02Var3, z13), null, fy4.m11715k(ka3Var, di2.m9238M(10, s02Var3, 6)), bz5.m2094d(4292441943L), s02Var9, 3128, 0);
                            yt0.m23605B(4, s02Var9, 6, ka3Var, s02Var9);
                            xe5.m22686b("Co-Authored by Claude Opus 4.8 · Hölder Mean Calculation", g55.m11862j(ka3Var), ((uj0) s02Var9.m19327j(tf1Var2)).f38733A, 0L, null, null, 0L, null, null, 0L, 0, false, 1, 0, of5.m17192a(((sl5) s02Var9.m19327j(tf1Var)).f35600o, 0L, di2.m9240O(7, s02Var9), null, null, 0L, null, 0L, null, null, 16777213), s02Var9, 54, 24576, 114680);
                            s02 s02Var10 = s02Var9;
                            z14 = true;
                            s02Var10.m19338p(true);
                            s02Var10.m19338p(false);
                            s02Var4 = s02Var10;
                        } else {
                            z14 = z12;
                            s02Var3.m19308Z(61537471);
                            s02Var3.m19338p(z13);
                            s02Var4 = s02Var3;
                        }
                        s02Var4.m19338p(z14);
                    } else {
                        s02Var5.m19303U();
                    }
                    return kn5.f22076a;
                }
            }, s02Var), s02Var, 12582912, 122);
        }
        m19342t = s02Var.m19342t();
        if (m19342t != null) {
            final byte b2 = 1;
            nz1Var = new nz1(this, i, i2, ra5Var, z, z2, z3, z4, ul1Var, i3, b2) { // from class: h33

                /* renamed from: a */
                public final /* synthetic */ byte f16684a;

                /* renamed from: b */
                public final /* synthetic */ MappingEditorFeature f16685b;

                /* renamed from: c */
                public final /* synthetic */ int f16686c;

                /* renamed from: d */
                public final /* synthetic */ int f16687d;

                /* renamed from: e */
                public final /* synthetic */ ra5 f16688e;

                /* renamed from: f */
                public final /* synthetic */ boolean f16689f;

                /* renamed from: g */
                public final /* synthetic */ boolean f16690g;

                /* renamed from: h */
                public final /* synthetic */ boolean f16691h;

                /* renamed from: i */
                public final /* synthetic */ boolean f16692i;

                /* renamed from: j */
                public final /* synthetic */ ul1 f16693j;

                {
                    this.f16684a = b2;
                    this.f16685b = this;
                }

                @Override // p000.nz1
                public final Object invoke(Object obj, Object obj2) {
                    byte b22 = this.f16684a;
                    kn5 kn5Var = kn5.f22076a;
                    switch (b22) {
                        case 0:
                            ((Integer) obj2).getClass();
                            int m23255A = y53.m23255A(1572865);
                            this.f16685b.m11407U(this.f16686c, this.f16687d, this.f16688e, this.f16689f, this.f16690g, this.f16691h, this.f16692i, this.f16693j, (s02) obj, m23255A);
                            break;
                        default:
                            ((Integer) obj2).getClass();
                            int m23255A2 = y53.m23255A(1572865);
                            this.f16685b.m11407U(this.f16686c, this.f16687d, this.f16688e, this.f16689f, this.f16690g, this.f16691h, this.f16692i, this.f16693j, (s02) obj, m23255A2);
                            break;
                    }
                    return kn5Var;
                }
            };
            m19342t.f25420d = nz1Var;
        }
    }

    /* renamed from: W */
    public final void m11408W(int i, int i2, x13 x13Var, float f, float f2, boolean z, xy1 xy1Var, s02 s02Var, int i3) {
        x13 x13Var2;
        m84 m19342t;
        t23 t23Var;
        int i4;
        int i5;
        s02Var.m19312b0(1678433102);
        byte b = 2;
        int i6 = i3 | (s02Var.m19315d(i) ? 4 : 2) | (s02Var.m19315d(i2) ? 32 : 16) | (s02Var.m19323h(x13Var) ? 256 : 128) | (s02Var.m19313c(f) ? 2048 : 1024) | (s02Var.m19313c(f2) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var.m19321g(z) ? 131072 : 65536) | (s02Var.m19323h(xy1Var) ? 1048576 : 524288) | (s02Var.m19323h(this) ? 8388608 : 4194304);
        if (s02Var.m19300R(i6 & 1, (4793491 & i6) != 4793490)) {
            ra5 ra5Var = (ra5) ij0.m13404h0(i2, x13Var.f43222e);
            if (ra5Var == null) {
                m19342t = s02Var.m19342t();
                if (m19342t != null) {
                    t23Var = new t23(this, i, i2, x13Var, f, f2, z, xy1Var, i3, (byte) 2);
                    m19342t.f25420d = t23Var;
                }
                return;
            }
            x13Var2 = x13Var;
            ds3 m16200q = mt7.m16200q(ra5Var.f33454b, f, f2);
            float floatValue = ((Number) m16200q.f10834a).floatValue();
            float floatValue2 = ((Number) m16200q.f10835b).floatValue();
            t61 t61Var = (t61) s02Var.m19327j(po0.f30726h);
            boolean m19313c = s02Var.m19313c(floatValue) | s02Var.m19313c(floatValue2);
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (m19313c || m19298O == sv8Var) {
                m19298O = new C0983fu(floatValue, floatValue2, b);
                s02Var.m19330k0(m19298O);
            }
            na3 m23858A = z80.m23858A(fy4.m11715k(ov9.m17421H(ka3.f21426a, (zy1) m19298O), t61Var.mo43P(50.0f)), z ? 1.0f : 0.7f);
            String str = x13Var2.f43218a;
            Integer valueOf = Integer.valueOf(i2);
            int i7 = 3670016 & i6;
            boolean z2 = i7 == 1048576;
            Object m19298O2 = s02Var.m19298O();
            if (z2 || m19298O2 == sv8Var) {
                m19298O2 = new n43(xy1Var, b);
                s02Var.m19330k0(m19298O2);
            }
            tx3 tx3Var = v75.f39912a;
            na3 mo14495d = m23858A.mo14495d(new u75(str, valueOf, null, (PointerInputEventHandler) m19298O2, 4));
            boolean m19323h = s02Var.m19323h(this) | ((i6 & 14) == 4) | ((i6 & 112) == 32) | ((i6 & jq5.f20570g) == 2048) | ((i6 & 57344) == 16384);
            Object m19298O3 = s02Var.m19298O();
            if (m19323h || m19298O3 == sv8Var) {
                i4 = 1048576;
                m19298O3 = new u23(this, i, i2, f, f2, (byte) 1);
                i5 = i2;
                s02Var.m19330k0(m19298O3);
            } else {
                i5 = i2;
                i4 = 1048576;
            }
            zy1 zy1Var = (zy1) m19298O3;
            boolean z3 = i7 == i4;
            Object m19298O4 = s02Var.m19298O();
            if (z3 || m19298O4 == sv8Var) {
                m19298O4 = new o43(xy1Var, null, b);
                s02Var.m19330k0(m19298O4);
            }
            nz1 nz1Var = (nz1) m19298O4;
            boolean m19323h2 = s02Var.m19323h(this);
            Object m19298O5 = s02Var.m19298O();
            if (m19323h2 || m19298O5 == sv8Var) {
                m19298O5 = new v23(this, (byte) 2);
                s02Var.m19330k0(m19298O5);
            }
            m12.m15685a(mo14495d, 0L, 0.0f, 0.0f, 0L, false, zy1Var, nz1Var, (zy1) m19298O5, mt7.m16166P(362231250, new wa1(x13Var2, i5, (byte) 1), s02Var), s02Var, 805306368, 62);
        } else {
            x13Var2 = x13Var;
            s02Var.m19303U();
        }
        m19342t = s02Var.m19342t();
        if (m19342t != null) {
            t23Var = new t23(this, i, i2, x13Var2, f, f2, z, xy1Var, i3, (byte) 3);
            m19342t.f25420d = t23Var;
        }
    }

    /* renamed from: X */
    public final void m11409X(xy1 xy1Var, zy1 zy1Var, s02 s02Var, int i) {
        s02Var.m19312b0(-734586829);
        int i2 = i | (s02Var.m19321g(false) ? 32 : 16) | (s02Var.m19323h(zy1Var) ? 2048 : 1024);
        byte b = 1;
        if (s02Var.m19300R(i2 & 1, (i2 & 1171) != 1170)) {
            q90 q90Var = q90.f31530a;
            ka3 ka3Var = ka3.f21426a;
            na3 m19001O = rc6.m19001O(q90Var.mo16390b(ka3Var), qj0.m18297b(0.35f, qj0.f32046b), bz5.f3249o);
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (m19298O == sv8Var) {
                m19298O = yt0.m23614g(s02Var);
            }
            ce3 ce3Var = (ce3) m19298O;
            Object m19298O2 = s02Var.m19298O();
            if (m19298O2 == sv8Var) {
                m19298O2 = new C1640us(xy1Var, (byte) 13);
                s02Var.m19330k0(m19298O2);
            }
            l90.m15154a(mx0.m16319s(m19001O, ce3Var, null, false, null, (xy1) m19298O2, 28), s02Var, 0);
            na3 mo16389a = q90Var.mo16389a(ka3Var, mg1.f25863f);
            byte b2 = 6;
            na3 m11721q = fy4.m11721q(AbstractC0871d6.m8745F(mo16389a, di2.m9238M(16, s02Var, 6)), 0.0f, di2.m9238M(340, s02Var, 6), 1);
            Object m19298O3 = s02Var.m19298O();
            if (m19298O3 == sv8Var) {
                m19298O3 = yt0.m23614g(s02Var);
            }
            ce3 ce3Var2 = (ce3) m19298O3;
            Object m19298O4 = s02Var.m19298O();
            if (m19298O4 == sv8Var) {
                m19298O4 = new z13(b2);
                s02Var.m19330k0(m19298O4);
            }
            wk0.m22152g(mx0.m16319s(m11721q, ce3Var2, null, false, null, (xy1) m19298O4, 28), dg2.m9067A(0.15f, 2.0f), null, null, mt7.m16166P(-42133074, new id1(zy1Var, b), s02Var), s02Var, 24576, 12);
        } else {
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new C1503rg((byte) 17, i, this, xy1Var, zy1Var);
        }
    }

    /* renamed from: Y */
    public final void m11410Y(ji5 ji5Var, xy1 xy1Var, s02 s02Var, int i) {
        s02Var.m19312b0(852190475);
        int i2 = i | (s02Var.m19319f(ji5Var) ? 32 : 16) | (s02Var.m19323h(xy1Var) ? 256 : 128);
        if (s02Var.m19300R(i2 & 1, (i2 & 147) != 146)) {
            q90 q90Var = q90.f31530a;
            ka3 ka3Var = ka3.f21426a;
            na3 m19001O = rc6.m19001O(q90Var.mo16390b(ka3Var), qj0.m18297b(0.5f, qj0.f32046b), bz5.f3249o);
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (m19298O == sv8Var) {
                m19298O = yt0.m23614g(s02Var);
            }
            ce3 ce3Var = (ce3) m19298O;
            Object m19298O2 = s02Var.m19298O();
            if (m19298O2 == sv8Var) {
                m19298O2 = new z13((byte) 2);
                s02Var.m19330k0(m19298O2);
            }
            l90.m15154a(mx0.m16319s(m19001O, ce3Var, null, false, null, (xy1) m19298O2, 28), s02Var, 0);
            na3 m11720p = fy4.m11720p(AbstractC0871d6.m8745F(q90Var.mo16389a(ka3Var, mg1.f25863f), di2.m9238M(16, s02Var, 6)), di2.m9238M(260, s02Var, 6), di2.m9238M(340, s02Var, 6));
            Object m19298O3 = s02Var.m19298O();
            if (m19298O3 == sv8Var) {
                m19298O3 = yt0.m23614g(s02Var);
            }
            ce3 ce3Var2 = (ce3) m19298O3;
            Object m19298O4 = s02Var.m19298O();
            if (m19298O4 == sv8Var) {
                m19298O4 = new z13((byte) 3);
                s02Var.m19330k0(m19298O4);
            }
            wk0.m22152g(mx0.m16319s(m11720p, ce3Var2, null, false, null, (xy1) m19298O4, 28), dg2.m9067A(0.15f, 2.0f), null, null, mt7.m16166P(1797654726, new s40(ji5Var, xy1Var, (byte) 7), s02Var), s02Var, 24576, 12);
        } else {
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new C1503rg((byte) 16, i, this, ji5Var, xy1Var);
        }
    }

    /* renamed from: Z */
    public final void m11411Z() {
        float m19407a = s32.m19407a();
        int i = s32.m19408b() ? 0 : 60;
        int i2 = s32.m19408b() ? 0 : 15;
        f05 f05Var = this.f14339t;
        int size = f05Var.size();
        for (int i3 = 0; i3 < size; i3++) {
            x13 x13Var = (x13) f05Var.get(i3);
            y13 y13Var = x13Var.f43221d;
            ra5 ra5Var = y13Var.f44644m;
            ra5 m11397a0 = ra5Var != null ? m11397a0(ra5Var, m19407a, i, i2) : null;
            List list = x13Var.f43221d.f44649r;
            ArrayList arrayList = new ArrayList(jj0.m14060l(list, 10));
            Iterator it = list.iterator();
            while (it.hasNext()) {
                arrayList.add(m11397a0((ra5) it.next(), m19407a, i, i2));
            }
            y13 m23117a = y13.m23117a(y13Var, 0.0f, 0.0f, 0.0f, null, null, false, 0, m11397a0, 0, false, 0.0f, 0, arrayList, null, null, 913407);
            List list2 = x13Var.f43222e;
            ArrayList arrayList2 = new ArrayList(jj0.m14060l(list2, 10));
            Iterator it2 = list2.iterator();
            while (it2.hasNext()) {
                arrayList2.add(m11397a0((ra5) it2.next(), m19407a, i, i2));
            }
            f05Var.set(i3, x13.m22426a(x13Var, null, false, m23117a, arrayList2, 7));
        }
    }

    /* renamed from: b0 */
    public final void m11412b0(String str) {
        f05 f05Var = this.f14339t;
        f05Var.clear();
        List m14784f = kn2.m14784f(str);
        ArrayList arrayList = new ArrayList(jj0.m14060l(m14784f, 10));
        Iterator it = m14784f.iterator();
        while (it.hasNext()) {
            arrayList.add(u43.m20648a((x13) it.next()));
        }
        f05Var.addAll(arrayList);
        m11411Z();
    }

    /* renamed from: c0 */
    public final void m11413c0() {
        String str = kn2.f22071a;
        String str2 = (String) this.f14340u.getValue();
        f05 f05Var = this.f14339t;
        f05Var.getClass();
        kn2.m14785g(str2, lw9.m15534l(f05Var).f13266c);
        if (((n85) Axeron.INSTANCE.getInputState().getValue()).f27152f) {
            v86.m21284K(m11349q(), w31.f41501b, null, new o60(rc6.m19014a0(this.f14338s), null, (byte) 9), 2);
        }
    }

    /* renamed from: d0 */
    public final void m11414d0(boolean z) {
        WindowManager.LayoutParams layoutParams = this.f14337r;
        if (layoutParams == null) {
            ei2.m10039H("params");
            throw null;
        }
        int i = layoutParams.flags;
        layoutParams.flags = z ? i & (-9) : i | 8;
        layoutParams.softInputMode = z ? 32 : 1;
        try {
            View view = this.f14336q;
            if (view != null) {
                updateViewLayout(view, layoutParams);
            } else {
                ei2.m10039H("view");
                throw null;
            }
        } catch (Throwable unused) {
        }
    }

    /* renamed from: e0 */
    public final void m11415e0(int i, zy1 zy1Var) {
        if (i >= 0) {
            f05 f05Var = this.f14339t;
            if (i < f05Var.size()) {
                f05Var.set(i, zy1Var.invoke(f05Var.get(i)));
            }
        }
    }

    /* renamed from: f0 */
    public final void m11416f0(int i, zy1 zy1Var) {
        m11415e0(i, new xc0(zy1Var, (byte) 3));
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        jc3 jc3Var;
        f05 f05Var = this.f14339t;
        super.mo11333t(bundle);
        ns0 ns0Var = null;
        String string = bundle != null ? bundle.getString("mapping_editor_package") : null;
        if (string == null) {
            string = "";
        }
        this.f14338s = string;
        n85 n85Var = (n85) Axeron.INSTANCE.getInputState().getValue();
        boolean z = n85Var.f27149c;
        this.f14342w = z;
        this.f14341v = z || n85Var.f27150d || n85Var.f27151e;
        Context m11348p = m11348p();
        u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualFeature.class, null);
        u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualLegacyFeature.class, null);
        v86.m21284K(m11349q(), w31.f41501b, null, new o60(this, ns0Var, (byte) 8), 2);
        String str = kn2.f22071a;
        this.f14340u.setValue(kn2.m14779a(this.f14338s));
        String str2 = this.f14338s;
        str2.getClass();
        List m14784f = kn2.m14784f(kn2.m14779a(str2));
        ArrayList arrayList = new ArrayList(jj0.m14060l(m14784f, 10));
        Iterator it = m14784f.iterator();
        while (it.hasNext()) {
            arrayList.add(u43.m20648a((x13) it.next()));
        }
        f05Var.addAll(arrayList);
        m11411Z();
        if (!f05Var.isEmpty()) {
            m11413c0();
        }
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, 2038, 776, -3);
        layoutParams.gravity = 8388659;
        layoutParams.windowAnimations = R.style.WAnim_Fade;
        layoutParams.layoutInDisplayCutoutMode = 1;
        this.f14337r = layoutParams;
        zm5 m11345m = m11345m(false, new gm0(159384984, true, new C1792yj(this, jq5.f20569f)));
        this.f14336q = m11345m;
        WindowManager.LayoutParams layoutParams2 = this.f14337r;
        if (layoutParams2 == null) {
            ei2.m10039H("params");
            throw null;
        }
        addView(m11345m, layoutParams2);
        MouseCursorFeature mouseCursorFeature = MouseCursorFeature.f14344x;
        if (mouseCursorFeature == null || (jc3Var = mouseCursorFeature.f14345q) == null || !jc3Var.isAttachedToWindow()) {
            return;
        }
        try {
            jc3 jc3Var2 = mouseCursorFeature.f14345q;
            if (jc3Var2 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            mouseCursorFeature.m11357C(jc3Var2);
            jc3 jc3Var3 = mouseCursorFeature.f14345q;
            if (jc3Var3 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            WindowManager.LayoutParams layoutParams3 = mouseCursorFeature.f14346r;
            if (layoutParams3 != null) {
                mouseCursorFeature.addView(jc3Var3, layoutParams3);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        } catch (Exception unused) {
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        zm5 zm5Var = this.f14336q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(zm5Var);
        super.mo11334u();
    }
}
