package frb.axeron.mapping.pipeline;

import android.content.Context;
import android.hardware.input.InputManager;
import android.os.Bundle;
import frb.axeron.base.FeatureFactoryBase;
import frb.axeron.crosshair.CrosshairFeature;
import frb.axeron.gyro.GyroCalibrationFeature;
import frb.axeron.loosening.LooseningFeature;
import frb.axeron.manager.Axeron;
import frb.axeron.mapping.mouse.MouseCursorFeature;
import frb.axeron.mapping.pipeline.MappingCoordinatorFeature;
import frb.axeron.monitor.MonitorFeature;
import frb.axeron.panel.FloatingButtonFeature;
import frb.axeron.panel.component.BoostAnimationFeature;
import frb.axeron.panel.component.PingOptimizerFeature;
import frb.axeron.panel.component.ScreenshotFeature;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import p000.AbstractC0946ew;
import p000.C1509rm;
import p000.a45;
import p000.au2;
import p000.c23;
import p000.d23;
import p000.ds3;
import p000.f55;
import p000.h53;
import p000.hi1;
import p000.hl7;
import p000.j23;
import p000.ka1;
import p000.m35;
import p000.n85;
import p000.ns0;
import p000.r23;
import p000.r41;
import p000.rc6;
import p000.s23;
import p000.s32;
import p000.tq4;
import p000.u62;
import p000.uf3;
import p000.ul1;
import p000.v86;
import p000.w31;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class MappingCoordinatorFeature extends FeatureFactoryBase {

    /* renamed from: t */
    public static final Set f14355t = AbstractC0946ew.m10550f1(new Class[]{FloatingButtonFeature.class, MappingCoordinatorFeature.class, MappingVisualFeature.class, MappingVisualLegacyFeature.class, MouseCursorFeature.class, InputListenerCoordinatorFeature.class, CrosshairFeature.class, MonitorFeature.class, GyroCalibrationFeature.class, BoostAnimationFeature.class, PingOptimizerFeature.class, ScreenshotFeature.class, LooseningFeature.class});

    /* renamed from: k */
    public String f14356k = "";

    /* renamed from: l */
    public final LinkedHashSet f14357l = new LinkedHashSet();

    /* renamed from: m */
    public final LinkedHashSet f14358m = new LinkedHashSet();

    /* renamed from: n */
    public final uf3 f14359n = new uf3();

    /* renamed from: o */
    public m35 f14360o;

    /* renamed from: p */
    public r23 f14361p;

    /* renamed from: q */
    public boolean f14362q;

    /* renamed from: r */
    public Set f14363r;

    /* renamed from: s */
    public Set f14364s;

    public MappingCoordinatorFeature() {
        hi1 hi1Var = hi1.f17209a;
        this.f14363r = hi1Var;
        this.f14364s = hi1Var;
    }

    /* renamed from: G */
    public static boolean m11419G(Set set) {
        Set set2 = set;
        if ((set2 instanceof Collection) && set2.isEmpty()) {
            return false;
        }
        Iterator it = set2.iterator();
        while (it.hasNext()) {
            if (!f14355t.contains((Class) it.next())) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: C */
    public final void m11420C(String str) {
        c23 m11427K = m11427K(str);
        if (m11427K == c23.f3356a) {
            m11423F();
            return;
        }
        Axeron axeron = Axeron.INSTANCE;
        if (!((n85) axeron.getInputState().getValue()).f27148b) {
            axeron.startInputListener();
        }
        m11421D(str, m11427K);
        m11422E(str, m11427K);
        if (m11427K != c23.f3358c && m11427K != c23.f3359d) {
            axeron.setMouseInject(false);
            axeron.setKeyboardInject(false);
            u62.m20673j(m11348p(), "ACTION_KILL_FEATURE", MouseCursorFeature.class, null);
            return;
        }
        if (!((n85) axeron.getInputState().getValue()).f27148b) {
            axeron.startInputListener();
        }
        axeron.setMousePollingRateLimit(h53.m12545a().getInt("mouse_polling_rate_limit", 0));
        axeron.setMouseInject(true);
        axeron.setKeyboardInject(true);
        axeron.hideSystemCursor();
        u62.m20673j(m11348p(), "ACTION_CALL_FEATURE", MouseCursorFeature.class, null);
    }

    /* renamed from: D */
    public final void m11421D(String str, c23 c23Var) {
        u62 u62Var = u62.f38283l;
        if (!h53.m12546b() || c23Var == c23.f3356a) {
            Axeron axeron = Axeron.INSTANCE;
            axeron.setTouchMapping(false);
            axeron.setMappingProfile(null);
            u62Var.m20698v(m11348p());
            return;
        }
        Axeron axeron2 = Axeron.INSTANCE;
        axeron2.setMappingProfile(rc6.m19014a0(str));
        if (this.f14362q) {
            axeron2.setTouchMapping(false);
            u62Var.m20698v(m11348p());
            return;
        }
        axeron2.setTouchMapping(true);
        Context m11348p = m11348p();
        str.getClass();
        Bundle bundle = new Bundle();
        bundle.putString("mapping_visual_package", str);
        if (((Boolean) h53.f16760a.getValue()).booleanValue()) {
            u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualFeature.class, null);
            u62.m20673j(m11348p, "ACTION_CALL_FEATURE", MappingVisualLegacyFeature.class, bundle);
        } else {
            u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualLegacyFeature.class, null);
            u62.m20673j(m11348p, "ACTION_CALL_FEATURE", MappingVisualFeature.class, bundle);
        }
    }

    /* renamed from: E */
    public final void m11422E(String str, c23 c23Var) {
        Float valueOf = Float.valueOf(1.0f);
        if (c23Var != c23.f3357b && c23Var != c23.f3359d) {
            Axeron axeron = Axeron.INSTANCE;
            axeron.setTouchInject(false);
            axeron.setInjectSensitivity(1.0f, 1.0f);
            axeron.setInjectSensitivityCurve(0);
            axeron.setInjectSmoothing(false, 0.0f, 0.0f);
            return;
        }
        Axeron axeron2 = Axeron.INSTANCE;
        if (!((n85) axeron2.getInputState().getValue()).f27148b) {
            axeron2.startInputListener();
        }
        ds3 ds3Var = this.f14362q ? new ds3(valueOf, valueOf) : tq4.m20440g(str);
        float floatValue = ((Number) ds3Var.f10834a).floatValue();
        float floatValue2 = ((Number) ds3Var.f10835b).floatValue();
        axeron2.setTouchInject(true);
        axeron2.setInjectSensitivity(floatValue, floatValue2);
        axeron2.setInjectSmoothing(!this.f14362q && h53.m12545a().getBoolean("smoothing_enabled", false) && s32.m19408b(), h53.m12545a().getFloat("smoothing_min_cutoff", 1.0f), h53.m12545a().getFloat("smoothing_beta", 0.007f));
        axeron2.setInjectSensitivityArea(tq4.m20434a(str));
        axeron2.setInjectSensitivityCurve(this.f14362q ? 0 : tq4.m20436c(str));
    }

    /* renamed from: F */
    public final void m11423F() {
        this.f14356k = "";
        Axeron axeron = Axeron.INSTANCE;
        axeron.setTouchInject(false);
        axeron.setInjectSensitivity(1.0f, 1.0f);
        axeron.setInjectSensitivityCurve(0);
        axeron.setInjectSmoothing(false, 0.0f, 0.0f);
        axeron.setKeyboardInject(false);
        axeron.setMouseInject(false);
        u62.m20673j(m11348p(), "ACTION_KILL_FEATURE", MouseCursorFeature.class, null);
        axeron.setTouchMapping(false);
        axeron.setMappingProfile(null);
        Context m11348p = m11348p();
        u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualFeature.class, null);
        u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualLegacyFeature.class, null);
    }

    /* renamed from: H */
    public final boolean m11424H(String str) {
        if (f55.m10718s0(str)) {
            return false;
        }
        return this.f14357l.contains(str) || this.f14358m.contains(str);
    }

    /* renamed from: I */
    public final void m11425I(Integer num) {
        if (num == null || this.f14363r.contains(num) || this.f14364s.contains(num)) {
            ul1 m12863p = hl7.m12863p(m11348p());
            this.f14363r = m12863p.f38878c;
            this.f14364s = m12863p.f38879d;
            au2 m11349q = m11349q();
            r41 r41Var = ka1.f21425a;
            v86.m21284K(m11349q, w31.f41501b, null, new C1509rm((Object) this, (Object) m12863p, (ns0) null, (byte) 2), 2);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x005e A[Catch: all -> 0x00f2, TryCatch #0 {all -> 0x00f2, blocks: (B:11:0x0058, B:13:0x005e, B:15:0x0066, B:17:0x006e, B:22:0x007e, B:23:0x0083, B:25:0x0094, B:29:0x009d, B:32:0x00a4, B:34:0x00aa, B:36:0x00af, B:40:0x00bb, B:44:0x00c1, B:46:0x00c9, B:48:0x00d9), top: B:10:0x0058 }] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00c1 A[Catch: all -> 0x00f2, TryCatch #0 {all -> 0x00f2, blocks: (B:11:0x0058, B:13:0x005e, B:15:0x0066, B:17:0x006e, B:22:0x007e, B:23:0x0083, B:25:0x0094, B:29:0x009d, B:32:0x00a4, B:34:0x00aa, B:36:0x00af, B:40:0x00bb, B:44:0x00c1, B:46:0x00c9, B:48:0x00d9), top: B:10:0x0058 }] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* renamed from: J */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11426J(java.lang.String r8, p000.ns0 r9) {
        /*
            Method dump skipped, instructions count: 247
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: frb.axeron.mapping.pipeline.MappingCoordinatorFeature.m11426J(java.lang.String, ns0):java.lang.Object");
    }

    /* renamed from: K */
    public final c23 m11427K(String str) {
        str.getClass();
        boolean m10718s0 = f55.m10718s0(str);
        c23 c23Var = c23.f3356a;
        if (m10718s0) {
            return c23Var;
        }
        hl7.m12863p(m11348p());
        LinkedHashSet linkedHashSet = this.f14358m;
        if (linkedHashSet.contains(str)) {
            linkedHashSet.remove(str);
        }
        boolean contains = this.f14357l.contains(str);
        linkedHashSet.contains(str);
        return contains ? c23.f3357b : c23Var;
    }

    /* renamed from: L */
    public final void m11428L(String str, boolean z, boolean z2) {
        if (f55.m10718s0(str)) {
            return;
        }
        au2 m11349q = m11349q();
        r41 r41Var = ka1.f21425a;
        v86.m21284K(m11349q, w31.f41501b, null, new s23(null, this, str, z, z2), 2);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        boolean z;
        boolean z2;
        super.mo11333t(bundle);
        this.f14362q = m11419G((Set) ((a45) mo409g()).getValue());
        ns0 ns0Var = null;
        String string = bundle != null ? bundle.getString("mapping_coord_package") : null;
        if (string == null) {
            string = "";
        }
        String str = string;
        byte b = 0;
        if (bundle != null) {
            boolean z3 = bundle.getBoolean("mapping_coord_want_touch", false);
            z2 = bundle.getBoolean("mapping_coord_want_mouse", false);
            z = z3;
        } else {
            z = false;
            z2 = false;
        }
        au2 m11349q = m11349q();
        r41 r41Var = ka1.f21425a;
        w31 w31Var = w31.f41501b;
        d23 d23Var = new d23(null, this, str, z, z2);
        byte b2 = 2;
        v86.m21284K(m11349q, w31Var, null, d23Var, 2);
        v86.m21284K(m11349q(), w31Var, null, new j23(this, ns0Var, b), 2);
        Object systemService = m11348p().getSystemService("input");
        InputManager inputManager = systemService instanceof InputManager ? (InputManager) systemService : null;
        if (inputManager != null) {
            ul1 m12863p = hl7.m12863p(m11348p());
            this.f14363r = m12863p.f38878c;
            this.f14364s = m12863p.f38879d;
            r23 r23Var = new r23(this);
            this.f14361p = r23Var;
            inputManager.registerInputDeviceListener(r23Var, null);
        }
        v86.m21284K(m11349q(), w31Var, null, new j23(this, ns0Var, (byte) 1), 2);
        v86.m21284K(m11349q(), w31Var, null, new j23(this, ns0Var, b2), 2);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        m35 m35Var = this.f14360o;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        this.f14360o = null;
        r23 r23Var = this.f14361p;
        if (r23Var != null) {
            Object systemService = m11348p().getSystemService("input");
            InputManager inputManager = systemService instanceof InputManager ? (InputManager) systemService : null;
            if (inputManager != null) {
                inputManager.unregisterInputDeviceListener(r23Var);
            }
            this.f14361p = null;
        }
        Context m11348p = m11348p();
        u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualFeature.class, null);
        u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualLegacyFeature.class, null);
        u62.m20673j(m11348p(), "ACTION_KILL_FEATURE", MouseCursorFeature.class, null);
        LinkedHashSet linkedHashSet = this.f14357l;
        final boolean z = !linkedHashSet.isEmpty();
        LinkedHashSet linkedHashSet2 = this.f14358m;
        final boolean z2 = !linkedHashSet2.isEmpty();
        linkedHashSet.clear();
        linkedHashSet2.clear();
        new Thread(new Runnable(this) { // from class: b23
            @Override // java.lang.Runnable
            public final void run() {
                Set set = MappingCoordinatorFeature.f14355t;
                if (z) {
                    try {
                        Axeron axeron = Axeron.INSTANCE;
                        axeron.setTouchInject(false);
                        axeron.setInjectSensitivity(1.0f, 1.0f);
                        axeron.setInjectSensitivityCurve(0);
                    } catch (Throwable unused) {
                        return;
                    }
                }
                if (z2) {
                    Axeron axeron2 = Axeron.INSTANCE;
                    axeron2.setKeyboardInject(false);
                    axeron2.setMouseInject(false);
                }
                Axeron axeron3 = Axeron.INSTANCE;
                axeron3.setTouchMapping(false);
                axeron3.setMappingProfile(null);
            }
        }).start();
        super.mo11334u();
    }
}
