package frb.axeron.mapping.pipeline;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowMetrics;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.mapping.mouse.MouseCursorFeature;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p000.C1163iv;
import p000.ci1;
import p000.ds3;
import p000.ei2;
import p000.gm0;
import p000.i80;
import p000.ij0;
import p000.jc3;
import p000.jj0;
import p000.kn2;
import p000.mt7;
import p000.ns0;
import p000.pz1;
import p000.tk5;
import p000.v86;
import p000.w23;
import p000.x13;
import p000.y53;
import p000.zm5;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class MappingVisualFeature extends FloatingFactoryBase {

    /* renamed from: q */
    public final ArrayList f14365q = new ArrayList();

    /* renamed from: r */
    public String f14366r = "";

    /* renamed from: s */
    public List f14367s = ci1.f4141a;

    /* renamed from: t */
    public ds3 f14368t = new ds3(0, 0);

    /* renamed from: I */
    public static WindowManager.LayoutParams m11429I(int i, int i2, int i3, int i4) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(i, i2, 2038, 792, -3);
        layoutParams.gravity = 8388659;
        layoutParams.x = i3;
        layoutParams.y = i4;
        layoutParams.alpha = 0.3f;
        layoutParams.windowAnimations = 0;
        layoutParams.layoutInDisplayCutoutMode = 1;
        return layoutParams;
    }

    /* renamed from: K */
    public static ds3 m11430K(Context context) {
        WindowMetrics currentWindowMetrics;
        Rect bounds;
        Object systemService = context.getSystemService("window");
        systemService.getClass();
        WindowManager windowManager = (WindowManager) systemService;
        if (Build.VERSION.SDK_INT < 30) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getRealMetrics(displayMetrics);
            return new ds3(Integer.valueOf(displayMetrics.widthPixels), Integer.valueOf(displayMetrics.heightPixels));
        }
        currentWindowMetrics = windowManager.getCurrentWindowMetrics();
        bounds = currentWindowMetrics.getBounds();
        bounds.getClass();
        return new ds3(Integer.valueOf(bounds.width()), Integer.valueOf(bounds.height()));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v14 */
    /* JADX WARN: Type inference failed for: r10v16 */
    /* JADX WARN: Type inference failed for: r10v9, types: [int] */
    /* renamed from: J */
    public final void m11431J() {
        jc3 jc3Var;
        ArrayList arrayList = this.f14365q;
        Iterator it = ij0.m13394C0(arrayList).iterator();
        while (it.hasNext()) {
            m11357C((View) it.next());
        }
        arrayList.clear();
        ds3 ds3Var = this.f14368t;
        int intValue = ((Number) ds3Var.f10834a).intValue();
        int intValue2 = ((Number) ds3Var.f10835b).intValue();
        if (intValue <= 0 || intValue2 <= 0) {
            return;
        }
        float f = intValue;
        float f2 = intValue2;
        boolean z = false;
        final int i = 0;
        for (Object obj : this.f14367s) {
            int i2 = i + 1;
            if (i < 0) {
                jj0.m14043P();
                throw null;
            }
            final x13 x13Var = (x13) obj;
            if (x13Var.f43220c) {
                C1163iv m16194k = mt7.m16194k(x13Var, f, f2);
                final int m23286v = y53.m23286v(m16194k.f19305c);
                if (m23286v < 1) {
                    m23286v = 1;
                }
                zm5 m11345m = m11345m(z, new gm0(1918027828, true, new pz1() { // from class: k53
                    @Override // p000.pz1
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        s02 s02Var = (s02) obj3;
                        ((Integer) obj4).getClass();
                        ((Configuration) obj2).getClass();
                        dg2.m9103e(null, mt7.m16166P(1255735677, new t03(m23286v, i, x13Var), s02Var), s02Var, 48, 1);
                        return kn5.f22076a;
                    }
                }));
                addView(m11345m, m11429I(m23286v, m23286v, y53.m23286v(m16194k.f19303a), y53.m23286v(m16194k.f19304b)));
                arrayList.add(m11345m);
                tk5 tk5Var = x13Var.f43221d.f44641j;
                if (tk5Var != tk5.f37201b && tk5Var != tk5.f37203d && tk5Var != tk5.f37204e) {
                    ArrayList m16169S = mt7.m16169S(x13Var, f, f2);
                    int size = m16169S.size();
                    boolean z2 = z;
                    int i3 = z2 ? 1 : 0;
                    ?? r10 = z2;
                    while (i3 < size) {
                        Object obj2 = m16169S.get(i3);
                        i3++;
                        int i4 = r10 + 1;
                        if (r10 < 0) {
                            jj0.m14043P();
                            throw null;
                        }
                        ds3 ds3Var2 = (ds3) ((ds3) obj2).f10835b;
                        float floatValue = ((Number) ds3Var2.f10834a).floatValue();
                        float floatValue2 = ((Number) ds3Var2.f10835b).floatValue();
                        zm5 m11345m2 = m11345m(false, new gm0(-1568246198, true, new w23((byte) 2, r10)));
                        addView(m11345m2, m11429I(50, 50, y53.m23286v(floatValue - 25.0f), y53.m23286v(floatValue2 - 25.0f)));
                        arrayList.add(m11345m2);
                        z = false;
                        r10 = i4;
                    }
                }
            }
            z = z;
            i = i2;
        }
        MouseCursorFeature mouseCursorFeature = MouseCursorFeature.f14344x;
        if (mouseCursorFeature == null || (jc3Var = mouseCursorFeature.f14345q) == null || !jc3Var.isAttachedToWindow()) {
            return;
        }
        try {
            jc3 jc3Var2 = mouseCursorFeature.f14345q;
            if (jc3Var2 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            mouseCursorFeature.m11357C(jc3Var2);
            jc3 jc3Var3 = mouseCursorFeature.f14345q;
            if (jc3Var3 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            WindowManager.LayoutParams layoutParams = mouseCursorFeature.f14346r;
            if (layoutParams == null) {
                ei2.m10039H("params");
                throw null;
            }
            mouseCursorFeature.addView(jc3Var3, layoutParams);
        } catch (Exception unused) {
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        jc3 jc3Var;
        super.mo11333t(bundle);
        ns0 ns0Var = null;
        String string = bundle != null ? bundle.getString("mapping_visual_package") : null;
        if (string == null) {
            string = "";
        }
        this.f14366r = string;
        this.f14367s = kn2.m14784f(kn2.m14779a(string));
        this.f14368t = m11430K(m11348p());
        m11431J();
        v86.m21284K(m11349q(), null, null, new i80(this, ns0Var, (byte) 8), 3);
        MouseCursorFeature mouseCursorFeature = MouseCursorFeature.f14344x;
        if (mouseCursorFeature == null || (jc3Var = mouseCursorFeature.f14345q) == null || !jc3Var.isAttachedToWindow()) {
            return;
        }
        try {
            jc3 jc3Var2 = mouseCursorFeature.f14345q;
            if (jc3Var2 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            mouseCursorFeature.m11357C(jc3Var2);
            jc3 jc3Var3 = mouseCursorFeature.f14345q;
            if (jc3Var3 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            WindowManager.LayoutParams layoutParams = mouseCursorFeature.f14346r;
            if (layoutParams != null) {
                mouseCursorFeature.addView(jc3Var3, layoutParams);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        } catch (Exception unused) {
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        ArrayList arrayList = this.f14365q;
        Iterator it = ij0.m13394C0(arrayList).iterator();
        while (it.hasNext()) {
            m11357C((View) it.next());
        }
        arrayList.clear();
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: v */
    public final void mo11335v(Bundle bundle) {
        String string = bundle.getString("mapping_visual_package");
        if (string == null) {
            string = "";
        }
        List m14784f = kn2.m14784f(kn2.m14779a(string));
        if (string.equals(this.f14366r) && m14784f.equals(this.f14367s)) {
            return;
        }
        this.f14366r = string;
        this.f14367s = m14784f;
        m11431J();
    }
}
