package frb.axeron.mapping.pipeline;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import frb.axeron.base.FeatureFactoryBase;
import frb.axeron.manager.Axeron;
import p000.cl5;
import p000.d63;
import p000.gh5;
import p000.i80;
import p000.ih5;
import p000.ka1;
import p000.mf1;
import p000.n22;
import p000.pe2;
import p000.qf1;
import p000.r41;
import p000.r70;
import p000.ur0;
import p000.v86;
import p000.w31;
import p000.ys1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class InputListenerCoordinatorFeature extends FeatureFactoryBase {

    /* renamed from: l */
    public static final long f14352l;

    /* renamed from: m */
    public static final /* synthetic */ int f14353m = 0;

    /* renamed from: k */
    public volatile boolean f14354k;

    static {
        ur0 ur0Var = mf1.f25813b;
        f14352l = cl5.m2662M(300, qf1.MILLISECONDS);
    }

    /* renamed from: C */
    public final void m11418C(int i) {
        String m8810q = d63.m8810q("Touch Listener: ", Axeron.INSTANCE.describeStartError(i));
        Context m11348p = m11348p();
        Handler handler = ih5.f18632a;
        ih5.f18633b.add(new gh5(m11348p, m8810q, 1, ys1.f45995a));
        if (ih5.f18634c) {
            return;
        }
        ih5.m13363b();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        v86.m21284K(m11349q(), null, null, new pe2(this, null, (byte) 1), 3);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        r41 r41Var = ka1.f21425a;
        v86.m21284K(n22.f26792a, w31.f41501b, null, new r70(2, null, (byte) 5), 2);
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: x */
    public final void mo11353x() {
        super.mo11353x();
        v86.m21284K(m11349q(), null, null, new i80(this, null, (byte) 6), 3);
    }
}
