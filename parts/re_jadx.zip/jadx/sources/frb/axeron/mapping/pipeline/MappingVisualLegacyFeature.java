package frb.axeron.mapping.pipeline;

import android.os.Bundle;
import android.view.WindowManager;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.mapping.mouse.MouseCursorFeature;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p000.C0962fb;
import p000.C0983fu;
import p000.C1163iv;
import p000.C1792yj;
import p000.c43;
import p000.ci1;
import p000.ds3;
import p000.ei2;
import p000.fy4;
import p000.gm0;
import p000.hn0;
import p000.it3;
import p000.jc3;
import p000.jj0;
import p000.ka3;
import p000.kn2;
import p000.l53;
import p000.l90;
import p000.m84;
import p000.me2;
import p000.mg1;
import p000.mt7;
import p000.na3;
import p000.o63;
import p000.oua;
import p000.ov3;
import p000.ov9;
import p000.p70;
import p000.po0;
import p000.s02;
import p000.sn0;
import p000.sv8;
import p000.t61;
import p000.tk5;
import p000.u99;
import p000.wo2;
import p000.x13;
import p000.xm0;
import p000.yn0;
import p000.z80;
import p000.zm5;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class MappingVisualLegacyFeature extends FloatingFactoryBase {

    /* renamed from: q */
    public zm5 f14369q;

    /* renamed from: r */
    public String f14370r = "";

    /* renamed from: s */
    public final it3 f14371s = z80.m23867J(ci1.f4141a);

    /* renamed from: I */
    public final void m11432I(int i, s02 s02Var) {
        float f;
        ka3 ka3Var;
        xm0 xm0Var;
        Iterator it;
        t61 t61Var;
        int i2;
        float f2;
        sv8 sv8Var;
        ArrayList arrayList;
        s02 s02Var2 = s02Var;
        xm0 xm0Var2 = oua.f29407f;
        xm0 xm0Var3 = oua.f29410i;
        xm0 xm0Var4 = oua.f29408g;
        xm0 xm0Var5 = oua.f29409h;
        p70 p70Var = mg1.f25859b;
        s02Var2.m19312b0(493360126);
        int i3 = i | (s02Var2.m19323h(this) ? 4 : 2);
        if (s02Var2.m19300R(i3 & 1, (i3 & 3) != 2)) {
            t61 t61Var2 = (t61) s02Var2.m19327j(po0.f30726h);
            ds3 m16167Q = mt7.m16167Q(s02Var2);
            Object obj = m16167Q.f10834a;
            Object obj2 = m16167Q.f10835b;
            float intValue = ((Number) obj).intValue();
            Number number = (Number) obj2;
            float intValue2 = number.intValue();
            float mo42M = t61Var2.mo42M(((Number) m16167Q.f10834a).intValue());
            float mo42M2 = t61Var2.mo42M(number.intValue());
            ka3 ka3Var2 = ka3.f21426a;
            na3 m11716l = fy4.m11716l(ka3Var2, mo42M, mo42M2);
            o63 m15156c = l90.m15156c(p70Var, false);
            t61 t61Var3 = t61Var2;
            int hashCode = Long.hashCode(s02Var2.f34520T);
            ov3 m19331l = s02Var2.m19331l();
            na3 m20748R = u99.m20748R(s02Var2, m11716l);
            sn0.f35689X8.getClass();
            s02Var2.m19316d0();
            boolean z = s02Var2.f34519S;
            me2 me2Var = wo2.f42501S;
            if (z) {
                s02Var2.m19329k(me2Var);
            } else {
                s02Var2.m19336n0();
            }
            z80.m23871N(xm0Var5, s02Var2, m15156c);
            z80.m23871N(xm0Var4, s02Var2, m19331l);
            hn0.m12946s(hashCode, s02Var2, xm0Var3, s02Var2);
            z80.m23871N(xm0Var2, s02Var2, m20748R);
            s02Var2.m19308Z(1691190039);
            Iterator it2 = ((List) this.f14371s.getValue()).iterator();
            int i4 = 0;
            while (it2.hasNext()) {
                Object next = it2.next();
                int i5 = i4 + 1;
                if (i4 < 0) {
                    jj0.m14043P();
                    throw null;
                }
                x13 x13Var = (x13) next;
                int i6 = i4;
                if (x13Var.f43220c) {
                    C1163iv m16194k = mt7.m16194k(x13Var, intValue, intValue2);
                    boolean m19323h = s02Var2.m19323h(m16194k);
                    float f3 = intValue;
                    Object m19298O = s02Var2.m19298O();
                    sv8 sv8Var2 = yn0.f45724a;
                    if (m19323h || m19298O == sv8Var2) {
                        sv8Var = sv8Var2;
                        m19298O = new c43(m16194k, (byte) 1);
                        s02Var2.m19330k0(m19298O);
                    } else {
                        sv8Var = sv8Var2;
                    }
                    na3 m11715k = fy4.m11715k(ov9.m17421H(ka3Var2, (zy1) m19298O), t61Var3.mo43P(m16194k.f19305c));
                    o63 m15156c2 = l90.m15156c(p70Var, false);
                    float f4 = intValue2;
                    ka3 ka3Var3 = ka3Var2;
                    int hashCode2 = Long.hashCode(s02Var2.f34520T);
                    ov3 m19331l2 = s02Var2.m19331l();
                    na3 m20748R2 = u99.m20748R(s02Var2, m11715k);
                    sn0.f35689X8.getClass();
                    s02Var2.m19316d0();
                    if (s02Var2.f34519S) {
                        s02Var2.m19329k(me2Var);
                    } else {
                        s02Var2.m19336n0();
                    }
                    z80.m23871N(xm0Var5, s02Var2, m15156c2);
                    z80.m23871N(xm0Var4, s02Var2, m19331l2);
                    hn0.m12946s(hashCode2, s02Var2, xm0Var3, s02Var2);
                    z80.m23871N(xm0Var2, s02Var2, m20748R2);
                    it = it2;
                    t61Var = t61Var3;
                    ka3 ka3Var4 = ka3Var3;
                    float f5 = f4;
                    xm0 xm0Var6 = xm0Var2;
                    i2 = i5;
                    sv8 sv8Var3 = sv8Var;
                    f2 = f3;
                    mt7.m16179b(i6, x13Var, false, null, s02Var, C0962fb.c.f13595h);
                    s02Var2 = s02Var;
                    s02Var2.m19338p(true);
                    tk5 tk5Var = x13Var.f43221d.f44641j;
                    if (tk5Var == tk5.f37201b || tk5Var == tk5.f37203d || tk5Var == tk5.f37204e) {
                        f = f5;
                        ka3Var = ka3Var4;
                        xm0Var = xm0Var6;
                    } else {
                        s02Var2.m19308Z(1691211725);
                        ArrayList m16169S = mt7.m16169S(x13Var, f2, f5);
                        int size = m16169S.size();
                        int i7 = 0;
                        int i8 = 0;
                        while (i8 < size) {
                            Object obj3 = m16169S.get(i8);
                            int i9 = i8 + 1;
                            int i10 = i7 + 1;
                            if (i7 < 0) {
                                jj0.m14043P();
                                throw null;
                            }
                            ds3 ds3Var = (ds3) ((ds3) obj3).f10835b;
                            float floatValue = ((Number) ds3Var.f10834a).floatValue();
                            float floatValue2 = ((Number) ds3Var.f10835b).floatValue();
                            boolean m19313c = s02Var2.m19313c(floatValue) | s02Var2.m19313c(floatValue2);
                            float f6 = f5;
                            Object m19298O2 = s02Var2.m19298O();
                            if (m19313c || m19298O2 == sv8Var3) {
                                arrayList = m16169S;
                                m19298O2 = new C0983fu(floatValue, floatValue2, (byte) 5);
                                s02Var2.m19330k0(m19298O2);
                            } else {
                                arrayList = m16169S;
                            }
                            na3 m11715k2 = fy4.m11715k(ov9.m17421H(ka3Var4, (zy1) m19298O2), t61Var.mo42M(50));
                            o63 m15156c3 = l90.m15156c(p70Var, false);
                            ka3 ka3Var5 = ka3Var4;
                            int hashCode3 = Long.hashCode(s02Var2.f34520T);
                            ov3 m19331l3 = s02Var2.m19331l();
                            na3 m20748R3 = u99.m20748R(s02Var2, m11715k2);
                            sn0.f35689X8.getClass();
                            s02Var2.m19316d0();
                            if (s02Var2.f34519S) {
                                s02Var2.m19329k(me2Var);
                            } else {
                                s02Var2.m19336n0();
                            }
                            z80.m23871N(xm0Var5, s02Var2, m15156c3);
                            z80.m23871N(xm0Var4, s02Var2, m19331l3);
                            hn0.m12946s(hashCode3, s02Var2, xm0Var3, s02Var2);
                            z80.m23871N(xm0Var6, s02Var2, m20748R3);
                            mt7.m16190h(i7, null, null, s02Var2, 0, 6);
                            s02Var2.m19338p(true);
                            size = size;
                            i8 = i9;
                            i7 = i10;
                            m16169S = arrayList;
                            ka3Var4 = ka3Var5;
                            f5 = f6;
                        }
                        f = f5;
                        ka3Var = ka3Var4;
                        xm0Var = xm0Var6;
                        s02Var2.m19338p(false);
                    }
                } else {
                    f = intValue2;
                    ka3Var = ka3Var2;
                    xm0Var = xm0Var2;
                    it = it2;
                    t61Var = t61Var3;
                    i2 = i5;
                    f2 = intValue;
                }
                xm0Var2 = xm0Var;
                intValue = f2;
                i4 = i2;
                ka3Var2 = ka3Var;
                intValue2 = f;
                t61Var3 = t61Var;
                it2 = it;
            }
            s02Var2.m19338p(false);
            s02Var2.m19338p(true);
        } else {
            s02Var2.m19303U();
        }
        m84 m19342t = s02Var2.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new l53(this, i);
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        jc3 jc3Var;
        super.mo11333t(bundle);
        String string = bundle != null ? bundle.getString("mapping_visual_package") : null;
        if (string == null) {
            string = "";
        }
        this.f14370r = string;
        this.f14371s.setValue(kn2.m14784f(kn2.m14779a(string)));
        zm5 m11345m = m11345m(false, new gm0(1869943812, true, new C1792yj((Object) this, (byte) 13)));
        this.f14369q = m11345m;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, 2038, 792, -3);
        layoutParams.gravity = 8388659;
        layoutParams.alpha = 0.3f;
        layoutParams.windowAnimations = 0;
        layoutParams.layoutInDisplayCutoutMode = 1;
        addView(m11345m, layoutParams);
        MouseCursorFeature mouseCursorFeature = MouseCursorFeature.f14344x;
        if (mouseCursorFeature == null || (jc3Var = mouseCursorFeature.f14345q) == null || !jc3Var.isAttachedToWindow()) {
            return;
        }
        try {
            jc3 jc3Var2 = mouseCursorFeature.f14345q;
            if (jc3Var2 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            mouseCursorFeature.m11357C(jc3Var2);
            jc3 jc3Var3 = mouseCursorFeature.f14345q;
            if (jc3Var3 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            WindowManager.LayoutParams layoutParams2 = mouseCursorFeature.f14346r;
            if (layoutParams2 != null) {
                mouseCursorFeature.addView(jc3Var3, layoutParams2);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        } catch (Exception unused) {
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        zm5 zm5Var = this.f14369q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(zm5Var);
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: v */
    public final void mo11335v(Bundle bundle) {
        String string = bundle.getString("mapping_visual_package");
        if (string == null) {
            string = "";
        }
        List m14784f = kn2.m14784f(kn2.m14779a(string));
        boolean equals = string.equals(this.f14370r);
        it3 it3Var = this.f14371s;
        if (equals && m14784f.equals((List) it3Var.getValue())) {
            return;
        }
        this.f14370r = string;
        it3Var.setValue(m14784f);
    }
}
