package frb.axeron.mapping.mouse;

import android.hardware.input.InputManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.PointerIcon;
import android.view.WindowManager;
import com.unity3d.services.UnityAdsConstants;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.manager.Axeron;
import p000.C1655v4;
import p000.C1787ye;
import p000.RunnableC0905e1;
import p000.au2;
import p000.aw2;
import p000.ei2;
import p000.jc3;
import p000.k30;
import p000.ka1;
import p000.m50;
import p000.ns0;
import p000.r41;
import p000.v86;
import p000.w31;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes.dex */
public final class MouseCursorFeature extends FloatingFactoryBase {

    /* renamed from: x */
    public static MouseCursorFeature f14344x;

    /* renamed from: q */
    public jc3 f14345q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14346r;

    /* renamed from: v */
    public volatile boolean f14350v;

    /* renamed from: s */
    public volatile float f14347s = -1.0f;

    /* renamed from: t */
    public volatile float f14348t = -1.0f;

    /* renamed from: u */
    public volatile boolean f14349u = true;

    /* renamed from: w */
    public final RunnableC0905e1 f14351w = new RunnableC0905e1((Object) this, (byte) 24);

    /* renamed from: I */
    public final void m11417I(boolean z) {
        int i = z ? UnityAdsConstants.SafeGuards.InitRequestTimeoutPolicy.MIN_TIMEOUT : 0;
        Object systemService = m11348p().getSystemService("input");
        try {
            InputManager.class.getMethod("setPointerIconType", Integer.TYPE).invoke(systemService instanceof InputManager ? (InputManager) systemService : null, Integer.valueOf(i));
        } catch (Throwable unused) {
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        super.mo11333t(bundle);
        m11417I(false);
        au2 m11349q = m11349q();
        r41 r41Var = ka1.f21425a;
        w31 w31Var = w31.f41501b;
        int i = 2;
        ns0 ns0Var = null;
        v86.m21284K(m11349q, w31Var, null, new C1655v4(i, ns0Var, (byte) 18), 2);
        int i2 = (int) (48.0f * m11348p().getResources().getDisplayMetrics().density);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(i2, i2, 2038, 792, -3);
        layoutParams.gravity = 8388659;
        layoutParams.x = 0;
        layoutParams.y = 0;
        byte b = 1;
        layoutParams.layoutInDisplayCutoutMode = 1;
        this.f14346r = layoutParams;
        jc3 jc3Var = new jc3(m11348p());
        this.f14345q = jc3Var;
        jc3Var.setPointerIcon(PointerIcon.getSystemIcon(m11348p(), 0));
        DisplayMetrics displayMetrics = m11348p().getResources().getDisplayMetrics();
        int i3 = (displayMetrics.widthPixels / 2) + 2;
        int i4 = (displayMetrics.heightPixels / 2) + 2;
        WindowManager.LayoutParams layoutParams2 = this.f14346r;
        if (layoutParams2 == null) {
            ei2.m10039H("params");
            throw null;
        }
        layoutParams2.x = i3;
        layoutParams2.y = i4;
        jc3 jc3Var2 = this.f14345q;
        if (jc3Var2 == null) {
            ei2.m10039H("cursorView");
            throw null;
        }
        jc3Var2.setVisibility(0);
        jc3 jc3Var3 = this.f14345q;
        if (jc3Var3 == null) {
            ei2.m10039H("cursorView");
            throw null;
        }
        WindowManager.LayoutParams layoutParams3 = this.f14346r;
        if (layoutParams3 == null) {
            ei2.m10039H("params");
            throw null;
        }
        addView(jc3Var3, layoutParams3);
        f14344x = this;
        FloatingFactoryBase.f14264p = new aw2(this, (byte) 5);
        k30 k30Var = k30.f21152a;
        k30.f21157f = new C1787ye(this, (byte) 2);
        v86.m21284K(m11349q(), w31Var, null, new m50(i, ns0Var, b), 2);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        m11417I(true);
        if (f14344x == this) {
            f14344x = null;
            FloatingFactoryBase.f14264p = null;
        }
        k30 k30Var = k30.f21152a;
        k30.f21157f = null;
        jc3 jc3Var = this.f14345q;
        if (jc3Var != null) {
            jc3Var.removeCallbacks(this.f14351w);
            jc3 jc3Var2 = this.f14345q;
            if (jc3Var2 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            m11357C(jc3Var2);
        }
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: x */
    public final void mo11353x() {
        jc3 jc3Var;
        super.mo11353x();
        m11417I(false);
        Axeron.INSTANCE.hideSystemCursor();
        MouseCursorFeature mouseCursorFeature = f14344x;
        if (mouseCursorFeature == null || (jc3Var = mouseCursorFeature.f14345q) == null || !jc3Var.isAttachedToWindow()) {
            return;
        }
        try {
            jc3 jc3Var2 = mouseCursorFeature.f14345q;
            if (jc3Var2 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            mouseCursorFeature.m11357C(jc3Var2);
            jc3 jc3Var3 = mouseCursorFeature.f14345q;
            if (jc3Var3 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            WindowManager.LayoutParams layoutParams = mouseCursorFeature.f14346r;
            if (layoutParams != null) {
                mouseCursorFeature.addView(jc3Var3, layoutParams);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        } catch (Exception unused) {
        }
    }
}
