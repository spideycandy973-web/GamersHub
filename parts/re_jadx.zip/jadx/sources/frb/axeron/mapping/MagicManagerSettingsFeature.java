package frb.axeron.mapping;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.DashPathEffect;
import android.os.Bundle;
import android.view.WindowManager;
import androidx.compose.p003ui.input.pointer.PointerInputEventHandler;
import com.applovin.shadow.okhttp3.internal.http2.Http2;
import com.applovin.shadow.okhttp3.internal.p007ws.WebSocketProtocol;
import com.applovin.shadow.okio.Segment;
import frb.axeron.base.FeatureFactoryBase;
import frb.axeron.base.FloatingFactoryBase;
import frb.axeron.manager.Axeron;
import frb.axeron.mapping.MagicManagerSettingsFeature;
import frb.axeron.mapping.mouse.MouseCursorFeature;
import frb.axeron.mapping.pipeline.MappingCoordinatorFeature;
import frb.axeron.mapping.pipeline.MappingVisualFeature;
import frb.axeron.mapping.pipeline.MappingVisualLegacyFeature;
import frb.axeron.redcorner.R;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONObject;
import p000.AbstractC0871d6;
import p000.AbstractC1443pv;
import p000.C0950f;
import p000.C1160ir;
import p000.C1207jv;
import p000.C1266le;
import p000.C1325mv;
import p000.C1404ou;
import p000.C1495r8;
import p000.C1532s8;
import p000.C1576tc;
import p000.C1746xf;
import p000.C1777y4;
import p000.C1792yj;
import p000.ViewOnTouchListenerC1541sh;
import p000.a03;
import p000.as3;
import p000.au2;
import p000.d63;
import p000.dg2;
import p000.di2;
import p000.dk0;
import p000.ds3;
import p000.ef3;
import p000.ei2;
import p000.ek0;
import p000.et3;
import p000.ez2;
import p000.f55;
import p000.fy4;
import p000.gm0;
import p000.h53;
import p000.hn0;
import p000.it3;
import p000.jc3;
import p000.jj0;
import p000.jq5;
import p000.jz2;
import p000.k64;
import p000.ka1;
import p000.ka3;
import p000.kb2;
import p000.kn5;
import p000.l42;
import p000.lw9;
import p000.lx1;
import p000.m35;
import p000.m84;
import p000.me2;
import p000.mg1;
import p000.mp2;
import p000.mt7;
import p000.mu0;
import p000.mx0;
import p000.n85;
import p000.na3;
import p000.ni0;
import p000.ns0;
import p000.nz1;
import p000.o70;
import p000.of5;
import p000.oua;
import p000.ov3;
import p000.ov9;
import p000.oz1;
import p000.oz2;
import p000.pz2;
import p000.q75;
import p000.qj0;
import p000.qp7;
import p000.r41;
import p000.rj0;
import p000.rz2;
import p000.s02;
import p000.s32;
import p000.sg4;
import p000.sl5;
import p000.sn0;
import p000.sv8;
import p000.sz2;
import p000.tq4;
import p000.u62;
import p000.u99;
import p000.ug4;
import p000.uj0;
import p000.ul1;
import p000.ul5;
import p000.v75;
import p000.v86;
import p000.vg4;
import p000.vz2;
import p000.w31;
import p000.wj0;
import p000.wo2;
import p000.wz2;
import p000.xe5;
import p000.xm0;
import p000.xy1;
import p000.y53;
import p000.yn0;
import p000.yt0;
import p000.yz2;
import p000.z21;
import p000.z80;
import p000.zm5;
import p000.zy1;
import p000.zz2;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class MagicManagerSettingsFeature extends FloatingFactoryBase {

    /* renamed from: q */
    public zm5 f14331q;

    /* renamed from: r */
    public WindowManager.LayoutParams f14332r;

    /* renamed from: t */
    public m35 f14334t;

    /* renamed from: s */
    public final it3 f14333s = z80.m23867J("");

    /* renamed from: u */
    public final ReentrantLock f14335u = new ReentrantLock();

    /* renamed from: M */
    public static final boolean m11381M(ef3 ef3Var) {
        return ((Boolean) ef3Var.getValue()).booleanValue();
    }

    /* renamed from: I */
    public final void m11382I(final int i, int i2, s02 s02Var, na3 na3Var, boolean z) {
        na3 na3Var2;
        final long j;
        long j2;
        boolean z2;
        final float f;
        s02Var.m19312b0(632509057);
        int i3 = i2 | (s02Var.m19315d(i) ? 4 : 2) | (s02Var.m19321g(z) ? 32 : 16) | (s02Var.m19319f(na3Var) ? 256 : 128);
        if (s02Var.m19300R(i3 & 1, (i3 & 147) != 146)) {
            k64 k64Var = (k64) s02Var.m19327j(rj0.f33758k);
            uj0 uj0Var = (uj0) s02Var.m19327j(wj0.f42164a);
            if (z) {
                j2 = k64Var.f21265f;
                z2 = true;
                f = 0.9f;
                j = j2;
            } else {
                long j3 = uj0Var.f38783q;
                j = uj0Var.f38733A;
                j2 = j3;
                z2 = true;
                f = 0.35f;
            }
            boolean m19317e = ((i3 & 14) == 4 ? z2 : false) | s02Var.m19317e(j2) | s02Var.m19313c(f) | s02Var.m19317e(j);
            Object m19298O = s02Var.m19298O();
            if (m19317e || m19298O == yn0.f45724a) {
                final long j4 = j2;
                m19298O = new zy1() { // from class: lz2
                    @Override // p000.zy1
                    public final Object invoke(Object obj) {
                        se1 se1Var = (se1) obj;
                        se1Var.getClass();
                        float intBitsToFloat = Float.intBitsToFloat((int) (se1Var.mo19719e() >> 32));
                        float intBitsToFloat2 = Float.intBitsToFloat((int) (se1Var.mo19719e() & 4294967295L));
                        float m24395d = zx4.m24395d(se1Var.mo19719e()) * 0.11f;
                        float f2 = m24395d < 1.2f ? 1.2f : m24395d;
                        int i4 = i;
                        long j5 = j4;
                        float f3 = f;
                        if (i4 == -1) {
                            se1.m19708B(se1Var, qj0.m18297b(f3, j5), 0L, (Float.floatToRawIntBits(intBitsToFloat / 2.0f) << 32) | (Float.floatToRawIntBits(intBitsToFloat2) & 4294967295L), 0.0f, null, 122);
                        } else if (i4 != 1) {
                            se1.m19708B(se1Var, qj0.m18297b(f3, j5), 0L, 0L, 0.0f, null, WebSocketProtocol.PAYLOAD_SHORT);
                        } else {
                            float f4 = intBitsToFloat / 2.0f;
                            se1.m19708B(se1Var, qj0.m18297b(f3, j5), Float.floatToRawIntBits(f4) << 32, (Float.floatToRawIntBits(f4) << 32) | (Float.floatToRawIntBits(intBitsToFloat2) & 4294967295L), 0.0f, null, 120);
                        }
                        se1.m19708B(se1Var, j, 0L, 0L, 0.0f, new n55(f2, 0.0f, 0, 0, null, 30), 110);
                        return kn5.f22076a;
                    }
                };
                s02Var.m19330k0(m19298O);
            }
            na3Var2 = na3Var;
            lw9.m15528a(na3Var2, (zy1) m19298O, s02Var, (i3 >> 6) & 14);
        } else {
            na3Var2 = na3Var;
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new jz2(this, i, z, na3Var2, i2, (byte) 1);
        }
    }

    /* renamed from: J */
    public final void m11383J(final int i, int i2, s02 s02Var, na3 na3Var, final boolean z) {
        na3 na3Var2;
        final long j;
        long j2;
        s02Var.m19312b0(702883835);
        int i3 = i2 | (s02Var.m19315d(i) ? 4 : 2) | (s02Var.m19321g(z) ? 32 : 16) | (s02Var.m19319f(na3Var) ? 256 : 128);
        if (s02Var.m19300R(i3 & 1, (i3 & 147) != 146)) {
            k64 k64Var = (k64) s02Var.m19327j(rj0.f33758k);
            uj0 uj0Var = (uj0) s02Var.m19327j(wj0.f42164a);
            if (z) {
                j2 = k64Var.f21265f;
                j = j2;
            } else {
                j = uj0Var.f38783q;
                j2 = uj0Var.f38733A;
            }
            boolean m19317e = s02Var.m19317e(j) | ((i3 & 112) == 32) | ((i3 & 14) == 4) | s02Var.m19317e(j2);
            Object m19298O = s02Var.m19298O();
            if (m19317e || m19298O == yn0.f45724a) {
                final long j3 = j2;
                zy1 zy1Var = new zy1() { // from class: cz2
                    @Override // p000.zy1
                    public final Object invoke(Object obj) {
                        se1 se1Var = (se1) obj;
                        se1Var.getClass();
                        float intBitsToFloat = Float.intBitsToFloat((int) (se1Var.mo19719e() >> 32));
                        float intBitsToFloat2 = Float.intBitsToFloat((int) (se1Var.mo19719e() & 4294967295L));
                        float m24395d = zx4.m24395d(se1Var.mo19719e()) * 0.14f;
                        float f = m24395d < 1.2f ? 1.2f : m24395d;
                        se1.m19710E0(se1Var, qj0.m18297b(z ? 0.9f : 0.5f, j), Float.floatToRawIntBits(intBitsToFloat2) & 4294967295L, Float.floatToRawIntBits(intBitsToFloat) << 32, f, 0, null, 496);
                        C0076bf c0076bf = new C0076bf(new DashPathEffect(new float[]{0.12f * intBitsToFloat, 0.09f * intBitsToFloat}, 0.0f));
                        C0016af m9040a = AbstractC0880df.m9040a();
                        m9040a.m313f(0.0f, intBitsToFloat2);
                        int i4 = i;
                        if (i4 == 1) {
                            m9040a.m315h(intBitsToFloat, intBitsToFloat2, intBitsToFloat, 0.0f);
                        } else if (i4 != 2) {
                            m9040a.m312e(intBitsToFloat, 0.0f);
                        } else {
                            m9040a.m315h(0.0f, 0.0f, intBitsToFloat, 0.0f);
                        }
                        se1.m19712R(se1Var, m9040a, j3, new n55(f, 0.0f, 0, 0, c0076bf, 14), 52);
                        return kn5.f22076a;
                    }
                };
                s02Var.m19330k0(zy1Var);
                m19298O = zy1Var;
            }
            na3Var2 = na3Var;
            lw9.m15528a(na3Var2, (zy1) m19298O, s02Var, (i3 >> 6) & 14);
        } else {
            na3Var2 = na3Var;
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new jz2(this, i, z, na3Var2, i2, (byte) 0);
        }
    }

    /* renamed from: K */
    public final void m11384K(String str, xy1 xy1Var, s02 s02Var, int i) {
        int i2;
        s02Var.m19312b0(-1704604945);
        if ((i & 6) == 0) {
            i2 = i | (s02Var.m19319f(str) ? 4 : 2);
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= s02Var.m19323h(xy1Var) ? 32 : 16;
        }
        byte b = 0;
        if (s02Var.m19300R(i2 & 1, (i2 & 19) != 18)) {
            uj0 uj0Var = (uj0) s02Var.m19327j(wj0.f42164a);
            Object m19298O = s02Var.m19298O();
            Object obj = yn0.f45724a;
            if (m19298O == obj) {
                m19298O = ov9.m17465q(s02Var);
                s02Var.m19330k0(m19298O);
            }
            mu0 mu0Var = (mu0) m19298O;
            ef3 m23870M = z80.m23870M(xy1Var, s02Var);
            na3 m23273i = y53.m23273i(fy4.m11715k(ka3.f21426a, di2.m9238M(20, s02Var, 6)), dg2.m9071C(2, 0.4f));
            boolean m19323h = s02Var.m19323h(mu0Var) | s02Var.m19319f(m23870M);
            Object m19298O2 = s02Var.m19298O();
            if (m19323h || m19298O2 == obj) {
                m19298O2 = new vz2(mu0Var, m23870M, b);
                s02Var.m19330k0(m19298O2);
            }
            q75.m18052a(v75.m21255a(m23273i, kn5.f22076a, (PointerInputEventHandler) m19298O2), null, uj0Var.f38773h, 0L, 0.0f, 0.0f, null, mt7.m16166P(-693594230, new rz2(uj0Var, str, b), s02Var), s02Var, 12582912, 122);
        } else {
            s02Var.m19303U();
        }
        m84 m19342t = s02Var.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new C1746xf((Object) this, (Object) str, (oz1) xy1Var, i, (byte) 10);
        }
    }

    /* renamed from: L */
    public final void m11385L(int i, s02 s02Var) {
        Integer num;
        nz1 nz1Var;
        Object c1404ou;
        Boolean bool;
        ul1 ul1Var;
        ef3 ef3Var;
        MagicManagerSettingsFeature magicManagerSettingsFeature = this;
        s02 s02Var2 = s02Var;
        Object obj = yn0.f45724a;
        s02Var2.m19312b0(1900905586);
        int i2 = i | (s02Var2.m19323h(magicManagerSettingsFeature) ? 4 : 2);
        if (s02Var2.m19300R(i2 & 1, (i2 & 3) != 2)) {
            final uj0 uj0Var = (uj0) s02Var2.m19327j(wj0.f42164a);
            final sl5 sl5Var = (sl5) s02Var2.m19327j(ul5.f38880a);
            final float m19407a = s32.m19407a();
            boolean m19319f = s02Var2.m19319f(magicManagerSettingsFeature.m11390R());
            Object m19298O = s02Var2.m19298O();
            if (m19319f || m19298O == obj) {
                String str = tq4.f37515a;
                m19298O = tq4.m20442i(magicManagerSettingsFeature.m11390R());
                s02Var2.m19330k0(m19298O);
            }
            ds3 ds3Var = (ds3) m19298O;
            boolean m19319f2 = s02Var2.m19319f(magicManagerSettingsFeature.m11390R());
            Object m19298O2 = s02Var2.m19298O();
            if (m19319f2 || m19298O2 == obj) {
                m19298O2 = new et3(((Number) ds3Var.f10834a).floatValue());
                s02Var2.m19330k0(m19298O2);
            }
            final et3 et3Var = (et3) m19298O2;
            boolean m19319f3 = s02Var2.m19319f(magicManagerSettingsFeature.m11390R());
            Object m19298O3 = s02Var2.m19298O();
            if (m19319f3 || m19298O3 == obj) {
                m19298O3 = new et3(((Number) ds3Var.f10835b).floatValue());
                s02Var2.m19330k0(m19298O3);
            }
            final et3 et3Var2 = (et3) m19298O3;
            Object m19298O4 = s02Var2.m19298O();
            if (m19298O4 == obj) {
                m19298O4 = z80.m23867J(Boolean.valueOf(h53.m12546b()));
                s02Var2.m19330k0(m19298O4);
            }
            final ef3 ef3Var2 = (ef3) m19298O4;
            Object m19298O5 = s02Var2.m19298O();
            if (m19298O5 == obj) {
                m19298O5 = z80.m23867J(Boolean.valueOf(h53.m12545a().getBoolean("sensitivity_enabled", true)));
                s02Var2.m19330k0(m19298O5);
            }
            final ef3 ef3Var3 = (ef3) m19298O5;
            boolean m19319f4 = s02Var2.m19319f(magicManagerSettingsFeature.m11390R());
            Object m19298O6 = s02Var2.m19298O();
            if (m19319f4 || m19298O6 == obj) {
                String str2 = tq4.f37515a;
                m19298O6 = z80.m23867J(Integer.valueOf(tq4.m20434a(magicManagerSettingsFeature.m11390R())));
                s02Var2.m19330k0(m19298O6);
            }
            final ef3 ef3Var4 = (ef3) m19298O6;
            boolean m19319f5 = s02Var2.m19319f(magicManagerSettingsFeature.m11390R());
            Object m19298O7 = s02Var2.m19298O();
            if (m19319f5 || m19298O7 == obj) {
                String str3 = tq4.f37515a;
                m19298O7 = z80.m23867J(Integer.valueOf(tq4.m20436c(magicManagerSettingsFeature.m11390R())));
                s02Var2.m19330k0(m19298O7);
            }
            final ef3 ef3Var5 = (ef3) m19298O7;
            Object m19298O8 = s02Var2.m19298O();
            if (m19298O8 == obj) {
                m19298O8 = z80.m23867J(Boolean.valueOf(h53.m12545a().getBoolean("smoothing_enabled", false) && s32.m19408b()));
                s02Var2.m19330k0(m19298O8);
            }
            final ef3 ef3Var6 = (ef3) m19298O8;
            Object m19298O9 = s02Var2.m19298O();
            if (m19298O9 == obj) {
                et3 et3Var3 = new et3(h53.m12545a().getFloat("smoothing_min_cutoff", 1.0f));
                s02Var2.m19330k0(et3Var3);
                m19298O9 = et3Var3;
            }
            final et3 et3Var4 = (et3) m19298O9;
            Object m19298O10 = s02Var2.m19298O();
            if (m19298O10 == obj) {
                et3 et3Var5 = new et3(h53.m12545a().getFloat("smoothing_beta", 0.007f));
                s02Var2.m19330k0(et3Var5);
                m19298O10 = et3Var5;
            }
            final et3 et3Var6 = (et3) m19298O10;
            ef3 m8782r = AbstractC0871d6.m8782r(Axeron.INSTANCE.getInputState(), s02Var2);
            ul1 m18412z = qp7.m18412z(s02Var2);
            Object m19298O11 = s02Var2.m19298O();
            if (m19298O11 == obj) {
                m19298O11 = z80.m23867J(0);
                s02Var2.m19330k0(m19298O11);
            }
            final ef3 ef3Var7 = (ef3) m19298O11;
            Object m19298O12 = s02Var2.m19298O();
            if (m19298O12 == obj) {
                m19298O12 = z80.m23867J(Boolean.valueOf(((n85) m8782r.getValue()).f27149c));
                s02Var2.m19330k0(m19298O12);
            }
            final ef3 ef3Var8 = (ef3) m19298O12;
            Object m19298O13 = s02Var2.m19298O();
            if (m19298O13 == obj) {
                m19298O13 = z80.m23867J(Boolean.valueOf(((n85) m8782r.getValue()).f27150d));
                s02Var2.m19330k0(m19298O13);
            }
            ef3 ef3Var9 = (ef3) m19298O13;
            Boolean valueOf = Boolean.valueOf(((n85) m8782r.getValue()).f27149c);
            boolean m19319f6 = s02Var2.m19319f(m8782r);
            Object m19298O14 = s02Var2.m19298O();
            ns0 ns0Var = null;
            if (m19319f6 || m19298O14 == obj) {
                num = 0;
                m19298O14 = new wz2(m8782r, ef3Var8, ns0Var, (byte) 0);
                s02Var2.m19330k0(m19298O14);
            } else {
                num = 0;
            }
            ov9.m17456i((nz1) m19298O14, s02Var2, valueOf);
            Boolean valueOf2 = Boolean.valueOf(((n85) m8782r.getValue()).f27150d);
            boolean m19319f7 = s02Var2.m19319f(m8782r);
            Object m19298O15 = s02Var2.m19298O();
            if (m19319f7 || m19298O15 == obj) {
                m19298O15 = new wz2(m8782r, ef3Var9, ns0Var, (byte) 1);
                s02Var2.m19330k0(m19298O15);
            }
            ov9.m17456i((nz1) m19298O15, s02Var2, valueOf2);
            Object m19298O16 = s02Var2.m19298O();
            if (m19298O16 == obj) {
                m19298O16 = new C1576tc(ef3Var8, ef3Var9, (byte) 28);
                s02Var2.m19330k0(m19298O16);
            }
            nz1 nz1Var2 = (nz1) m19298O16;
            kn5 kn5Var = kn5.f22076a;
            Object m19298O17 = s02Var2.m19298O();
            if (m19298O17 == obj) {
                byte b = 2;
                m19298O17 = new C1777y4(b, ns0Var, b);
                s02Var2.m19330k0(m19298O17);
            }
            ov9.m17456i((nz1) m19298O17, s02Var2, kn5Var);
            Object m19298O18 = s02Var2.m19298O();
            if (m19298O18 == obj) {
                m19298O18 = z80.m23867J(num);
                s02Var2.m19330k0(m19298O18);
            }
            final ef3 ef3Var10 = (ef3) m19298O18;
            Object m19298O19 = s02Var2.m19298O();
            if (m19298O19 == obj) {
                m19298O19 = z80.m23867J(num);
                s02Var2.m19330k0(m19298O19);
            }
            final ef3 ef3Var11 = (ef3) m19298O19;
            Object m19298O20 = s02Var2.m19298O();
            if (m19298O20 == obj) {
                m19298O20 = z80.m23867J(Integer.valueOf(h53.m12545a().getInt("mouse_polling_rate_limit", 0)));
                s02Var2.m19330k0(m19298O20);
            }
            final ef3 ef3Var12 = (ef3) m19298O20;
            m18412z.getClass();
            Boolean bool2 = Boolean.FALSE;
            boolean m19323h = s02Var2.m19323h(m18412z) | s02Var2.m19323h(magicManagerSettingsFeature);
            Object m19298O21 = s02Var2.m19298O();
            if (m19323h || m19298O21 == obj) {
                nz1Var = nz1Var2;
                bool = bool2;
                ul1Var = m18412z;
                ef3Var = ef3Var9;
                c1404ou = new C1404ou(ul1Var, magicManagerSettingsFeature, nz1Var, ef3Var, ef3Var8, null);
                s02Var2.m19330k0(c1404ou);
            } else {
                nz1Var = nz1Var2;
                c1404ou = m19298O21;
                bool = bool2;
                ul1Var = m18412z;
                ef3Var = ef3Var9;
            }
            ov9.m17456i((nz1) c1404ou, s02Var2, bool);
            m11381M(ef3Var);
            Integer valueOf3 = Integer.valueOf(((Number) ef3Var7.getValue()).intValue());
            boolean m19321g = s02Var2.m19321g(false);
            Object m19298O22 = s02Var2.m19298O();
            if (m19321g || m19298O22 == obj) {
                m19298O22 = new C1266le(ef3Var7, ef3Var10, ef3Var11, null, (byte) 15);
                s02Var2.m19330k0(m19298O22);
            }
            ov9.m17458j(valueOf3, bool, (nz1) m19298O22, s02Var2);
            boolean m19319f8 = s02Var2.m19319f(m11390R());
            Object m19298O23 = s02Var2.m19298O();
            if (m19319f8 || m19298O23 == obj) {
                String m11390R = m11390R();
                if (f55.m10718s0(m11390R)) {
                    m11390R = "Global Mapping";
                } else {
                    try {
                        PackageManager packageManager = m11348p().getPackageManager();
                        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(m11390R, 0);
                        applicationInfo.getClass();
                        m11390R = packageManager.getApplicationLabel(applicationInfo).toString();
                    } catch (Exception unused) {
                    }
                }
                m19298O23 = m11390R;
                s02Var2.m19330k0(m19298O23);
            }
            final String str4 = (String) m19298O23;
            final k64 k64Var = (k64) s02Var2.m19327j(rj0.f33758k);
            final ef3 ef3Var13 = ef3Var;
            final nz1 nz1Var3 = nz1Var;
            final ul1 ul1Var2 = ul1Var;
            nz1 nz1Var4 = new nz1() { // from class: fz2
                @Override // p000.nz1
                public final Object invoke(Object obj2, Object obj3) {
                    s02 s02Var3 = (s02) obj2;
                    int intValue = ((Integer) obj3).intValue();
                    final byte b2 = 0;
                    final byte b3 = 1;
                    if (s02Var3.m19300R(intValue & 1, (intValue & 3) != 2)) {
                        na3 m11719o = fy4.m11719o(ka3.f21426a, di2.m9238M(260, s02Var3, 6));
                        final MagicManagerSettingsFeature magicManagerSettingsFeature2 = this;
                        boolean m19323h2 = s02Var3.m19323h(magicManagerSettingsFeature2);
                        Object m19298O24 = s02Var3.m19298O();
                        Object obj4 = yn0.f45724a;
                        if (m19323h2 || m19298O24 == obj4) {
                            m19298O24 = new zy1() { // from class: gz2
                                @Override // p000.zy1
                                public final Object invoke(Object obj5) {
                                    byte b4 = b2;
                                    kn5 kn5Var2 = kn5.f22076a;
                                    switch (b4) {
                                        case 0:
                                            q12 q12Var = (q12) obj5;
                                            q12Var.getClass();
                                            long j = q12Var.f31215g;
                                            MagicManagerSettingsFeature magicManagerSettingsFeature3 = magicManagerSettingsFeature2;
                                            WindowManager.LayoutParams layoutParams = magicManagerSettingsFeature3.f14332r;
                                            if (layoutParams == null) {
                                                ei2.m10039H("params");
                                                throw null;
                                            }
                                            layoutParams.x = ce1.m2512c(layoutParams, Float.intBitsToFloat((int) (j >> 32))) + layoutParams.x;
                                            WindowManager.LayoutParams layoutParams2 = magicManagerSettingsFeature3.f14332r;
                                            if (layoutParams2 == null) {
                                                ei2.m10039H("params");
                                                throw null;
                                            }
                                            layoutParams2.y = ce1.m2513d(layoutParams2, Float.intBitsToFloat((int) (j & 4294967295L))) + layoutParams2.y;
                                            zm5 zm5Var = magicManagerSettingsFeature3.f14331q;
                                            if (zm5Var == null) {
                                                ei2.m10039H("view");
                                                throw null;
                                            }
                                            WindowManager.LayoutParams layoutParams3 = magicManagerSettingsFeature3.f14332r;
                                            if (layoutParams3 != null) {
                                                ce1.m2514e(magicManagerSettingsFeature3, zm5Var, layoutParams3, 0, 0, null, 8188);
                                                return kn5Var2;
                                            }
                                            ei2.m10039H("params");
                                            throw null;
                                        default:
                                            ko5 ko5Var = (ko5) obj5;
                                            ko5Var.getClass();
                                            int i3 = ko5Var.f22145d.f10082a;
                                            MagicManagerSettingsFeature magicManagerSettingsFeature4 = magicManagerSettingsFeature2;
                                            if (i3 == 1) {
                                                WindowManager.LayoutParams layoutParams4 = magicManagerSettingsFeature4.f14332r;
                                                if (layoutParams4 == null) {
                                                    ei2.m10039H("params");
                                                    throw null;
                                                }
                                                layoutParams4.windowAnimations = R.style.WAnim_InTop_OutTop;
                                            } else if (i3 == 2) {
                                                WindowManager.LayoutParams layoutParams5 = magicManagerSettingsFeature4.f14332r;
                                                if (layoutParams5 == null) {
                                                    ei2.m10039H("params");
                                                    throw null;
                                                }
                                                layoutParams5.windowAnimations = R.style.WAnim_InBottom_OutBottom;
                                            } else if (i3 == 4) {
                                                WindowManager.LayoutParams layoutParams6 = magicManagerSettingsFeature4.f14332r;
                                                if (layoutParams6 == null) {
                                                    ei2.m10039H("params");
                                                    throw null;
                                                }
                                                layoutParams6.windowAnimations = R.style.WAnim_InLeft_OutLeft;
                                            } else if (i3 == 8) {
                                                WindowManager.LayoutParams layoutParams7 = magicManagerSettingsFeature4.f14332r;
                                                if (layoutParams7 == null) {
                                                    ei2.m10039H("params");
                                                    throw null;
                                                }
                                                layoutParams7.windowAnimations = R.style.WAnim_InRight_OutRight;
                                            }
                                            zm5 zm5Var2 = magicManagerSettingsFeature4.f14331q;
                                            if (zm5Var2 == null) {
                                                ei2.m10039H("view");
                                                throw null;
                                            }
                                            WindowManager.LayoutParams layoutParams8 = magicManagerSettingsFeature4.f14332r;
                                            if (layoutParams8 != null) {
                                                magicManagerSettingsFeature4.updateViewLayout(zm5Var2, layoutParams8);
                                                return kn5Var2;
                                            }
                                            ei2.m10039H("params");
                                            throw null;
                                    }
                                }
                            };
                            s02Var3.m19330k0(m19298O24);
                        }
                        zy1 zy1Var = (zy1) m19298O24;
                        boolean m19323h3 = s02Var3.m19323h(magicManagerSettingsFeature2);
                        Object m19298O25 = s02Var3.m19298O();
                        if (m19323h3 || m19298O25 == obj4) {
                            m19298O25 = new zy1() { // from class: gz2
                                @Override // p000.zy1
                                public final Object invoke(Object obj5) {
                                    byte b4 = b3;
                                    kn5 kn5Var2 = kn5.f22076a;
                                    switch (b4) {
                                        case 0:
                                            q12 q12Var = (q12) obj5;
                                            q12Var.getClass();
                                            long j = q12Var.f31215g;
                                            MagicManagerSettingsFeature magicManagerSettingsFeature3 = magicManagerSettingsFeature2;
                                            WindowManager.LayoutParams layoutParams = magicManagerSettingsFeature3.f14332r;
                                            if (layoutParams == null) {
                                                ei2.m10039H("params");
                                                throw null;
                                            }
                                            layoutParams.x = ce1.m2512c(layoutParams, Float.intBitsToFloat((int) (j >> 32))) + layoutParams.x;
                                            WindowManager.LayoutParams layoutParams2 = magicManagerSettingsFeature3.f14332r;
                                            if (layoutParams2 == null) {
                                                ei2.m10039H("params");
                                                throw null;
                                            }
                                            layoutParams2.y = ce1.m2513d(layoutParams2, Float.intBitsToFloat((int) (j & 4294967295L))) + layoutParams2.y;
                                            zm5 zm5Var = magicManagerSettingsFeature3.f14331q;
                                            if (zm5Var == null) {
                                                ei2.m10039H("view");
                                                throw null;
                                            }
                                            WindowManager.LayoutParams layoutParams3 = magicManagerSettingsFeature3.f14332r;
                                            if (layoutParams3 != null) {
                                                ce1.m2514e(magicManagerSettingsFeature3, zm5Var, layoutParams3, 0, 0, null, 8188);
                                                return kn5Var2;
                                            }
                                            ei2.m10039H("params");
                                            throw null;
                                        default:
                                            ko5 ko5Var = (ko5) obj5;
                                            ko5Var.getClass();
                                            int i3 = ko5Var.f22145d.f10082a;
                                            MagicManagerSettingsFeature magicManagerSettingsFeature4 = magicManagerSettingsFeature2;
                                            if (i3 == 1) {
                                                WindowManager.LayoutParams layoutParams4 = magicManagerSettingsFeature4.f14332r;
                                                if (layoutParams4 == null) {
                                                    ei2.m10039H("params");
                                                    throw null;
                                                }
                                                layoutParams4.windowAnimations = R.style.WAnim_InTop_OutTop;
                                            } else if (i3 == 2) {
                                                WindowManager.LayoutParams layoutParams5 = magicManagerSettingsFeature4.f14332r;
                                                if (layoutParams5 == null) {
                                                    ei2.m10039H("params");
                                                    throw null;
                                                }
                                                layoutParams5.windowAnimations = R.style.WAnim_InBottom_OutBottom;
                                            } else if (i3 == 4) {
                                                WindowManager.LayoutParams layoutParams6 = magicManagerSettingsFeature4.f14332r;
                                                if (layoutParams6 == null) {
                                                    ei2.m10039H("params");
                                                    throw null;
                                                }
                                                layoutParams6.windowAnimations = R.style.WAnim_InLeft_OutLeft;
                                            } else if (i3 == 8) {
                                                WindowManager.LayoutParams layoutParams7 = magicManagerSettingsFeature4.f14332r;
                                                if (layoutParams7 == null) {
                                                    ei2.m10039H("params");
                                                    throw null;
                                                }
                                                layoutParams7.windowAnimations = R.style.WAnim_InRight_OutRight;
                                            }
                                            zm5 zm5Var2 = magicManagerSettingsFeature4.f14331q;
                                            if (zm5Var2 == null) {
                                                ei2.m10039H("view");
                                                throw null;
                                            }
                                            WindowManager.LayoutParams layoutParams8 = magicManagerSettingsFeature4.f14332r;
                                            if (layoutParams8 != null) {
                                                magicManagerSettingsFeature4.updateViewLayout(zm5Var2, layoutParams8);
                                                return kn5Var2;
                                            }
                                            ei2.m10039H("params");
                                            throw null;
                                    }
                                }
                            };
                            s02Var3.m19330k0(m19298O25);
                        }
                        zy1 zy1Var2 = (zy1) m19298O25;
                        final float f = m19407a;
                        final uj0 uj0Var2 = uj0Var;
                        final ul1 ul1Var3 = ul1Var2;
                        final nz1 nz1Var5 = nz1Var3;
                        final ef3 ef3Var14 = ef3Var2;
                        final ef3 ef3Var15 = ef3Var8;
                        final ef3 ef3Var16 = ef3Var13;
                        final ef3 ef3Var17 = ef3Var7;
                        final ef3 ef3Var18 = ef3Var4;
                        final ef3 ef3Var19 = ef3Var5;
                        final ef3 ef3Var20 = ef3Var3;
                        final ef3 ef3Var21 = ef3Var6;
                        final ef3 ef3Var22 = ef3Var10;
                        final ef3 ef3Var23 = ef3Var12;
                        final ef3 ef3Var24 = ef3Var11;
                        final et3 et3Var7 = et3Var;
                        final et3 et3Var8 = et3Var2;
                        final et3 et3Var9 = et3Var4;
                        final et3 et3Var10 = et3Var6;
                        final k64 k64Var2 = k64Var;
                        final sl5 sl5Var2 = sl5Var;
                        final String str5 = str4;
                        m12.m15685a(m11719o, 0L, 0.0f, 0.0f, 0L, false, zy1Var, null, zy1Var2, mt7.m16166P(-1892201473, new pz1() { // from class: hz2
                            @Override // p000.pz1
                            public final Object invoke(Object obj5, Object obj6, Object obj7) {
                                s02 s02Var4 = (s02) obj6;
                                int intValue2 = ((Integer) obj7).intValue();
                                ((n12) obj5).getClass();
                                if (s02Var4.m19300R(intValue2 & 1, (intValue2 & 17) != 16)) {
                                    Object m19298O26 = s02Var4.m19298O();
                                    if (m19298O26 == yn0.f45724a) {
                                        m19298O26 = new l62((byte) 27);
                                        s02Var4.m19330k0(m19298O26);
                                    }
                                    na3 m11712h = fy4.m11712h(di2.m9241P(ka3.f21426a, (zy1) m19298O26), 0.0f, di2.m9238M(300, s02Var4, 6), 1);
                                    vt0 m9067A = dg2.m9067A(0.15f, 2.0f);
                                    final float f2 = f;
                                    final uj0 uj0Var3 = uj0Var2;
                                    final ul1 ul1Var4 = ul1Var3;
                                    final nz1 nz1Var6 = nz1Var5;
                                    final ef3 ef3Var25 = ef3Var14;
                                    final ef3 ef3Var26 = ef3Var15;
                                    final ef3 ef3Var27 = ef3Var16;
                                    final ef3 ef3Var28 = ef3Var17;
                                    final ef3 ef3Var29 = ef3Var18;
                                    final ef3 ef3Var30 = ef3Var19;
                                    final ef3 ef3Var31 = ef3Var20;
                                    final ef3 ef3Var32 = ef3Var21;
                                    final ef3 ef3Var33 = ef3Var22;
                                    final ef3 ef3Var34 = ef3Var23;
                                    final ef3 ef3Var35 = ef3Var24;
                                    final et3 et3Var11 = et3Var7;
                                    final et3 et3Var12 = et3Var8;
                                    final et3 et3Var13 = et3Var9;
                                    final et3 et3Var14 = et3Var10;
                                    final k64 k64Var3 = k64Var2;
                                    final sl5 sl5Var3 = sl5Var2;
                                    final MagicManagerSettingsFeature magicManagerSettingsFeature3 = magicManagerSettingsFeature2;
                                    final String str6 = str5;
                                    wk0.m22152g(m11712h, m9067A, null, null, mt7.m16166P(1297363748, new pz1(f2, uj0Var3, ul1Var4, nz1Var6, ef3Var25, ef3Var26, ef3Var27, ef3Var28, ef3Var29, ef3Var30, ef3Var31, ef3Var32, ef3Var33, ef3Var34, ef3Var35, et3Var11, et3Var12, et3Var13, et3Var14, k64Var3, sl5Var3, magicManagerSettingsFeature3, str6) { // from class: iz2

                                        /* renamed from: a */
                                        public final /* synthetic */ uj0 f19417a;

                                        /* renamed from: b */
                                        public final /* synthetic */ sl5 f19418b;

                                        /* renamed from: c */
                                        public final /* synthetic */ String f19419c;

                                        /* renamed from: d */
                                        public final /* synthetic */ MagicManagerSettingsFeature f19420d;

                                        /* renamed from: e */
                                        public final /* synthetic */ ul1 f19421e;

                                        /* renamed from: f */
                                        public final /* synthetic */ ef3 f19422f;

                                        /* renamed from: g */
                                        public final /* synthetic */ nz1 f19423g;

                                        /* renamed from: h */
                                        public final /* synthetic */ ef3 f19424h;

                                        /* renamed from: i */
                                        public final /* synthetic */ ef3 f19425i;

                                        /* renamed from: j */
                                        public final /* synthetic */ ef3 f19426j;

                                        /* renamed from: k */
                                        public final /* synthetic */ ef3 f19427k;

                                        /* renamed from: l */
                                        public final /* synthetic */ ef3 f19428l;

                                        /* renamed from: m */
                                        public final /* synthetic */ et3 f19429m;

                                        /* renamed from: n */
                                        public final /* synthetic */ float f19430n;

                                        /* renamed from: o */
                                        public final /* synthetic */ et3 f19431o;

                                        /* renamed from: p */
                                        public final /* synthetic */ ef3 f19432p;

                                        /* renamed from: q */
                                        public final /* synthetic */ ef3 f19433q;

                                        /* renamed from: r */
                                        public final /* synthetic */ et3 f19434r;

                                        /* renamed from: s */
                                        public final /* synthetic */ et3 f19435s;

                                        {
                                            this.f19418b = sl5Var3;
                                            this.f19419c = str6;
                                            this.f19420d = magicManagerSettingsFeature3;
                                            this.f19429m = et3Var11;
                                            this.f19431o = et3Var12;
                                            this.f19434r = et3Var13;
                                            this.f19435s = et3Var14;
                                        }

                                        /* JADX WARN: Multi-variable type inference failed */
                                        /* JADX WARN: Type inference failed for: r6v61 */
                                        /* JADX WARN: Type inference failed for: r6v62, types: [boolean, int] */
                                        /* JADX WARN: Type inference failed for: r6v67 */
                                        @Override // p000.pz1
                                        public final Object invoke(Object obj8, Object obj9, Object obj10) {
                                            xy1 xy1Var;
                                            xy1 xy1Var2;
                                            MagicManagerSettingsFeature magicManagerSettingsFeature4;
                                            Object obj11;
                                            nz1 nz1Var7;
                                            ef3 ef3Var36;
                                            ef3 ef3Var37;
                                            xy1 xy1Var3;
                                            ef3 ef3Var38;
                                            MagicManagerSettingsFeature magicManagerSettingsFeature5;
                                            xy1 xy1Var4;
                                            final byte b4;
                                            Object obj12;
                                            final MagicManagerSettingsFeature magicManagerSettingsFeature6;
                                            et3 et3Var15;
                                            final MagicManagerSettingsFeature magicManagerSettingsFeature7;
                                            Object obj13;
                                            et3 et3Var16;
                                            et3 et3Var17;
                                            Object c1354nn;
                                            et3 et3Var18;
                                            Object obj14;
                                            ef3 ef3Var39;
                                            ka3 ka3Var;
                                            ?? r6;
                                            s02 s02Var5;
                                            kn5 kn5Var2;
                                            final et3 et3Var19;
                                            final et3 et3Var20;
                                            final et3 et3Var21;
                                            s02 s02Var6 = (s02) obj9;
                                            int intValue3 = ((Integer) obj10).intValue();
                                            ((fk0) obj8).getClass();
                                            boolean m19300R = s02Var6.m19300R(intValue3 & 1, (intValue3 & 17) != 16);
                                            kn5 kn5Var3 = kn5.f22076a;
                                            if (!m19300R) {
                                                s02Var6.m19303U();
                                                return kn5Var3;
                                            }
                                            float m9238M = di2.m9238M(16, s02Var6, 6);
                                            float m9238M2 = di2.m9238M(14, s02Var6, 6);
                                            ka3 ka3Var2 = ka3.f21426a;
                                            na3 m15560A = lx6.m15560A(AbstractC0871d6.m8746G(ka3Var2, m9238M, m9238M2), lx6.m15599x(s02Var6), true);
                                            n70 n70Var = mg1.f25871n;
                                            C1246kv c1246kv = AbstractC1443pv.f30967c;
                                            ek0 m9307a = dk0.m9307a(c1246kv, n70Var, s02Var6, 0);
                                            int hashCode = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l = s02Var6.m19331l();
                                            na3 m20748R = u99.m20748R(s02Var6, m15560A);
                                            sn0.f35689X8.getClass();
                                            s02Var6.m19316d0();
                                            boolean z = s02Var6.f34519S;
                                            xy1 xy1Var5 = wo2.f42501S;
                                            if (z) {
                                                s02Var6.m19329k(xy1Var5);
                                            } else {
                                                s02Var6.m19336n0();
                                            }
                                            xm0 xm0Var = oua.f29409h;
                                            z80.m23871N(xm0Var, s02Var6, m9307a);
                                            xm0 xm0Var2 = oua.f29408g;
                                            z80.m23871N(xm0Var2, s02Var6, m19331l);
                                            Integer valueOf4 = Integer.valueOf(hashCode);
                                            xm0 xm0Var3 = oua.f29410i;
                                            z80.m23871N(xm0Var3, s02Var6, valueOf4);
                                            z80.m23869L(s02Var6);
                                            xm0 xm0Var4 = oua.f29407f;
                                            z80.m23871N(xm0Var4, s02Var6, m20748R);
                                            na3 m11708d = fy4.m11708d(ka3Var2, 1.0f);
                                            ek0 m9307a2 = dk0.m9307a(c1246kv, n70Var, s02Var6, 0);
                                            int hashCode2 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l2 = s02Var6.m19331l();
                                            na3 m20748R2 = u99.m20748R(s02Var6, m11708d);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                s02Var6.m19329k(xy1Var5);
                                            } else {
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m9307a2);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l2);
                                            hn0.m12946s(hashCode2, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R2);
                                            sl5 sl5Var4 = this.f19418b;
                                            of5 of5Var = sl5Var4.f35592g;
                                            lx1 lx1Var = lx1.f24980j;
                                            xe5.m22686b("Magic Manager", null, 0L, 0L, lx1Var, null, 0L, null, null, 0L, 0, false, 0, 0, of5Var, s02Var6, 1572870, 0, 131006);
                                            yt0.m23628u(2, s02Var6, 6, ka3Var2, s02Var6);
                                            o70 o70Var = mg1.f25869l;
                                            C1207jv c1207jv = AbstractC1443pv.f30965a;
                                            ug4 m19739a = sg4.m19739a(c1207jv, o70Var, s02Var6, 48);
                                            int hashCode3 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l3 = s02Var6.m19331l();
                                            na3 m20748R3 = u99.m20748R(s02Var6, ka3Var2);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                xy1Var = xy1Var5;
                                                s02Var6.m19329k(xy1Var);
                                            } else {
                                                xy1Var = xy1Var5;
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m19739a);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l3);
                                            hn0.m12946s(hashCode3, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R3);
                                            xy1 xy1Var6 = xy1Var;
                                            xe5.m22686b(this.f19419c, g55.m11862j(ka3Var2), 0L, 0L, lx1Var, null, 0L, null, null, 0L, 0, false, 1, 0, sl5Var4.f35599n, s02Var6, 1572912, 24576, 114620);
                                            of5 of5Var2 = sl5Var4.f35600o;
                                            uj0 uj0Var4 = this.f19417a;
                                            xe5.m22686b(" • ", null, uj0Var4.f38733A, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, of5Var2, s02Var6, 6, 0, 131066);
                                            MagicManagerSettingsFeature magicManagerSettingsFeature8 = this.f19420d;
                                            String m11390R2 = magicManagerSettingsFeature8.m11390R();
                                            if (f55.m10718s0(m11390R2)) {
                                                m11390R2 = "system.global";
                                            }
                                            of5 of5Var3 = sl5Var4.f35600o;
                                            xe5.m22686b(m11390R2, g55.m11862j(ka3Var2), uj0Var4.f38733A, 0L, lx1.f24978h, null, 0L, null, null, 0L, 0, false, 1, 0, of5Var3, s02Var6, 1572912, 24576, 114616);
                                            s02Var6.m19338p(true);
                                            s02Var6.m19338p(true);
                                            yt0.m23628u(10, s02Var6, 6, ka3Var2, s02Var6);
                                            na3 m11708d2 = fy4.m11708d(ka3Var2, 1.0f);
                                            ug4 m19739a2 = sg4.m19739a(c1207jv, o70Var, s02Var6, 48);
                                            int hashCode4 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l4 = s02Var6.m19331l();
                                            na3 m20748R4 = u99.m20748R(s02Var6, m11708d2);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                xy1Var2 = xy1Var6;
                                                s02Var6.m19329k(xy1Var2);
                                            } else {
                                                xy1Var2 = xy1Var6;
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m19739a2);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l4);
                                            hn0.m12946s(hashCode4, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R4);
                                            na3 m21468a = vg4.m21468a(ka3Var2, 1.0f);
                                            ek0 m9307a3 = dk0.m9307a(c1246kv, n70Var, s02Var6, 0);
                                            int hashCode5 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l5 = s02Var6.m19331l();
                                            na3 m20748R5 = u99.m20748R(s02Var6, m21468a);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                s02Var6.m19329k(xy1Var2);
                                            } else {
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m9307a3);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l5);
                                            hn0.m12946s(hashCode5, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R5);
                                            xy1 xy1Var7 = xy1Var2;
                                            xe5.m22686b("Use Mapping", null, uj0Var4.f38783q, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, sl5Var4.f35598m, s02Var6, 6, 0, 131066);
                                            xe5.m22686b("Route every armed input source through the mapping profile (MappingArea / AltKey / keyCode).", null, uj0Var4.f38733A, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, of5.m17192a(sl5Var4.f35600o, 0L, di2.m9240O(7, s02Var6), null, null, 0L, null, 0L, null, null, 16777213), s02Var6, 6, 0, 131066);
                                            s02Var6.m19338p(true);
                                            vt0 m9071C = dg2.m9071C(2, 0.4f);
                                            ef3 ef3Var40 = this.f19422f;
                                            boolean booleanValue = ((Boolean) ef3Var40.getValue()).booleanValue();
                                            boolean m19323h4 = s02Var6.m19323h(magicManagerSettingsFeature8);
                                            ul1 ul1Var5 = this.f19421e;
                                            boolean m19323h5 = m19323h4 | s02Var6.m19323h(ul1Var5);
                                            Object m19298O27 = s02Var6.m19298O();
                                            nz1 nz1Var8 = this.f19423g;
                                            ef3 ef3Var41 = this.f19424h;
                                            ef3 ef3Var42 = this.f19425i;
                                            Object obj15 = yn0.f45724a;
                                            if (m19323h5 || m19298O27 == obj15) {
                                                Object c1314mk = new C1314mk(magicManagerSettingsFeature8, ul1Var5, nz1Var8, ef3Var40, ef3Var41, ef3Var42);
                                                magicManagerSettingsFeature4 = magicManagerSettingsFeature8;
                                                obj11 = ul1Var5;
                                                nz1Var7 = nz1Var8;
                                                ef3Var36 = ef3Var41;
                                                ef3Var37 = ef3Var42;
                                                s02Var6.m19330k0(c1314mk);
                                                m19298O27 = c1314mk;
                                            } else {
                                                obj11 = ul1Var5;
                                                ef3Var36 = ef3Var41;
                                                ef3Var37 = ef3Var42;
                                                nz1Var7 = nz1Var8;
                                                magicManagerSettingsFeature4 = magicManagerSettingsFeature8;
                                            }
                                            MagicManagerSettingsFeature magicManagerSettingsFeature9 = magicManagerSettingsFeature4;
                                            Object obj16 = obj11;
                                            z21.m23751e(booleanValue, (zy1) m19298O27, null, 0.0f, 0.0f, m9071C, 0L, 0L, 0L, 0.0f, 0L, s02Var6, 0, 2012);
                                            s02Var6.m19338p(true);
                                            s02Var6.m19308Z(-365575916);
                                            s02Var6.m19338p(false);
                                            yt0.m23628u(12, s02Var6, 6, ka3Var2, s02Var6);
                                            ((Number) this.f19426j.getValue()).intValue();
                                            s02Var6.m19308Z(-364939114);
                                            na3 m11708d3 = fy4.m11708d(ka3Var2, 1.0f);
                                            ug4 m19739a3 = sg4.m19739a(c1207jv, o70Var, s02Var6, 48);
                                            int hashCode6 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l6 = s02Var6.m19331l();
                                            na3 m20748R6 = u99.m20748R(s02Var6, m11708d3);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                xy1Var3 = xy1Var7;
                                                s02Var6.m19329k(xy1Var3);
                                            } else {
                                                xy1Var3 = xy1Var7;
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m19739a3);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l6);
                                            hn0.m12946s(hashCode6, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R6);
                                            na3 m21468a2 = vg4.m21468a(ka3Var2, 1.0f);
                                            ek0 m9307a4 = dk0.m9307a(c1246kv, n70Var, s02Var6, 0);
                                            int hashCode7 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l7 = s02Var6.m19331l();
                                            na3 m20748R7 = u99.m20748R(s02Var6, m21468a2);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                s02Var6.m19329k(xy1Var3);
                                            } else {
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m9307a4);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l7);
                                            hn0.m12946s(hashCode7, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R7);
                                            xy1 xy1Var8 = xy1Var3;
                                            xe5.m22686b("Magic Touch", null, uj0Var4.f38783q, 0L, lx1.f24981k, null, 0L, null, null, 0L, 0, false, 0, 0, sl5Var4.f35598m, s02Var6, 1572870, 0, 131002);
                                            xe5.m22686b("Intercept and remap touchscreen input via privileged injector", null, uj0Var4.f38733A, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, sl5Var4.f35600o, s02Var6, 6, 0, 131066);
                                            s02Var6.m19338p(true);
                                            float m9238M3 = di2.m9238M(34, s02Var6, 6);
                                            float m9238M4 = di2.m9238M(20, s02Var6, 6);
                                            boolean booleanValue2 = ((Boolean) ef3Var36.getValue()).booleanValue();
                                            boolean m19323h6 = s02Var6.m19323h(magicManagerSettingsFeature9) | s02Var6.m19323h(obj16);
                                            Object m19298O28 = s02Var6.m19298O();
                                            if (m19323h6 || m19298O28 == obj15) {
                                                ef3Var38 = ef3Var36;
                                                Object c1072ge = new C1072ge(magicManagerSettingsFeature9, obj16, nz1Var7, ef3Var38, ef3Var37, (byte) 4);
                                                magicManagerSettingsFeature5 = magicManagerSettingsFeature9;
                                                s02Var6.m19330k0(c1072ge);
                                                m19298O28 = c1072ge;
                                            } else {
                                                magicManagerSettingsFeature5 = magicManagerSettingsFeature9;
                                                ef3Var38 = ef3Var36;
                                            }
                                            final MagicManagerSettingsFeature magicManagerSettingsFeature10 = magicManagerSettingsFeature5;
                                            ef3 ef3Var43 = ef3Var38;
                                            rr8.m19195F(booleanValue2, (zy1) m19298O28, null, m9238M3, m9238M4, null, null, 0L, 0L, 0L, 0L, s02Var6, 0, 2020);
                                            s02Var6.m19338p(true);
                                            na3 m11708d4 = fy4.m11708d(ka3Var2, 1.0f);
                                            o63 m15156c = l90.m15156c(mg1.f25859b, false);
                                            int hashCode8 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l8 = s02Var6.m19331l();
                                            na3 m20748R8 = u99.m20748R(s02Var6, m11708d4);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                xy1Var4 = xy1Var8;
                                                s02Var6.m19329k(xy1Var4);
                                            } else {
                                                xy1Var4 = xy1Var8;
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m15156c);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l8);
                                            hn0.m12946s(hashCode8, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R8);
                                            na3 m11708d5 = fy4.m11708d(ka3Var2, 1.0f);
                                            Object m19298O29 = s02Var6.m19298O();
                                            if (m19298O29 == obj15) {
                                                m19298O29 = new C1540sg(ef3Var43, (byte) 8);
                                                s02Var6.m19330k0(m19298O29);
                                            }
                                            na3 m9241P = di2.m9241P(m11708d5, (zy1) m19298O29);
                                            ek0 m9307a5 = dk0.m9307a(c1246kv, n70Var, s02Var6, 0);
                                            int hashCode9 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l9 = s02Var6.m19331l();
                                            na3 m20748R9 = u99.m20748R(s02Var6, m9241P);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                s02Var6.m19329k(xy1Var4);
                                            } else {
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m9307a5);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l9);
                                            hn0.m12946s(hashCode9, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R9);
                                            yt0.m23628u(10, s02Var6, 6, ka3Var2, s02Var6);
                                            na3 m11708d6 = fy4.m11708d(ka3Var2, 1.0f);
                                            ug4 m19739a4 = sg4.m19739a(c1207jv, o70Var, s02Var6, 48);
                                            int hashCode10 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l10 = s02Var6.m19331l();
                                            na3 m20748R10 = u99.m20748R(s02Var6, m11708d6);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                s02Var6.m19329k(xy1Var4);
                                            } else {
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m19739a4);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l10);
                                            hn0.m12946s(hashCode10, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R10);
                                            xy1 xy1Var9 = xy1Var4;
                                            xe5.m22686b("Global Sensitivity", vg4.m21468a(ka3Var2, 1.0f), uj0Var4.f38783q, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, sl5Var4.f35598m, s02Var6, 6, 0, 131064);
                                            vt0 m9071C2 = dg2.m9071C(2, 0.4f);
                                            ef3 ef3Var44 = this.f19432p;
                                            boolean booleanValue3 = ((Boolean) ef3Var44.getValue()).booleanValue();
                                            Object m19298O30 = s02Var6.m19298O();
                                            if (m19298O30 == obj15) {
                                                m19298O30 = new C1540sg(ef3Var44, (byte) 9);
                                                s02Var6.m19330k0(m19298O30);
                                            }
                                            z21.m23751e(booleanValue3, (zy1) m19298O30, null, 0.0f, 0.0f, m9071C2, 0L, 0L, 0L, 0.0f, 0L, s02Var6, 48, 2012);
                                            s02Var6.m19338p(true);
                                            yt0.m23628u(3, s02Var6, 6, ka3Var2, s02Var6);
                                            ug4 m19739a5 = sg4.m19739a(c1207jv, o70Var, s02Var6, 48);
                                            int hashCode11 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l11 = s02Var6.m19331l();
                                            na3 m20748R11 = u99.m20748R(s02Var6, ka3Var2);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                s02Var6.m19329k(xy1Var9);
                                            } else {
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m19739a5);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l11);
                                            hn0.m12946s(hashCode11, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R11);
                                            kb2.m14510a(z21.m23719B(R.drawable.claude_spark, s02Var6, 0), null, fy4.m11715k(ka3Var2, di2.m9238M(10, s02Var6, 6)), bz5.m2094d(4292441943L), s02Var6, 3128, 0);
                                            yt0.m23605B(4, s02Var6, 6, ka3Var2, s02Var6);
                                            xe5.m22686b("Co-Authored by Claude Opus 4.8 · Hölder Mean Calculation", g55.m11862j(ka3Var2), uj0Var4.f38733A, 0L, null, null, 0L, null, null, 0L, 0, false, 1, 0, of5.m17192a(sl5Var4.f35600o, 0L, di2.m9240O(7, s02Var6), null, null, 0L, null, 0L, null, null, 16777213), s02Var6, 54, 24576, 114680);
                                            s02Var6.m19338p(true);
                                            yt0.m23628u(10, s02Var6, 6, ka3Var2, s02Var6);
                                            final ef3 ef3Var45 = this.f19427k;
                                            int intValue4 = ((Number) ef3Var45.getValue()).intValue();
                                            boolean m19319f9 = s02Var6.m19319f(ef3Var45) | s02Var6.m19323h(magicManagerSettingsFeature10);
                                            Object m19298O31 = s02Var6.m19298O();
                                            if (m19319f9 || m19298O31 == obj15) {
                                                b4 = 0;
                                                m19298O31 = new zy1() { // from class: mz2
                                                    @Override // p000.zy1
                                                    public final Object invoke(Object obj17) {
                                                        switch (b4) {
                                                            case 0:
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature11 = magicManagerSettingsFeature10;
                                                                ef3 ef3Var46 = ef3Var45;
                                                                Integer num2 = (Integer) obj17;
                                                                int intValue5 = num2.intValue();
                                                                ef3Var46.setValue(num2);
                                                                magicManagerSettingsFeature11.getClass();
                                                                String str7 = tq4.f37515a;
                                                                String m11390R3 = magicManagerSettingsFeature11.m11390R();
                                                                m11390R3.getClass();
                                                                String string = h53.m12545a().getString("sens_area_profiles_json", "");
                                                                LinkedHashMap linkedHashMap = new LinkedHashMap(tq4.m20438e(string != null ? string : ""));
                                                                linkedHashMap.put(m11390R3, num2);
                                                                JSONObject jSONObject = new JSONObject();
                                                                for (Map.Entry entry : linkedHashMap.entrySet()) {
                                                                    jSONObject.put((String) entry.getKey(), ((Number) entry.getValue()).intValue());
                                                                }
                                                                String jSONObject2 = jSONObject.toString();
                                                                jSONObject2.getClass();
                                                                tq4.f37517c = jSONObject2;
                                                                tq4.f37518d = linkedHashMap;
                                                                SharedPreferences.Editor edit = h53.m12545a().edit();
                                                                edit.getClass();
                                                                edit.putString("sens_area_profiles_json", jSONObject2);
                                                                edit.commit();
                                                                au2 m11349q = magicManagerSettingsFeature11.m11349q();
                                                                r41 r41Var = ka1.f21425a;
                                                                v86.m21284K(m11349q, w31.f41501b, null, new hu1(intValue5, null, (byte) 1), 2);
                                                                break;
                                                            default:
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature12 = magicManagerSettingsFeature10;
                                                                ef3 ef3Var47 = ef3Var45;
                                                                Integer num3 = (Integer) obj17;
                                                                int intValue6 = num3.intValue();
                                                                ef3Var47.setValue(num3);
                                                                magicManagerSettingsFeature12.getClass();
                                                                String str8 = tq4.f37515a;
                                                                String m11390R4 = magicManagerSettingsFeature12.m11390R();
                                                                m11390R4.getClass();
                                                                String string2 = h53.m12545a().getString("sens_curve_profiles_json", "");
                                                                LinkedHashMap linkedHashMap2 = new LinkedHashMap(tq4.m20439f(string2 != null ? string2 : ""));
                                                                linkedHashMap2.put(m11390R4, num3);
                                                                JSONObject jSONObject3 = new JSONObject();
                                                                for (Map.Entry entry2 : linkedHashMap2.entrySet()) {
                                                                    jSONObject3.put((String) entry2.getKey(), ((Number) entry2.getValue()).intValue());
                                                                }
                                                                String jSONObject4 = jSONObject3.toString();
                                                                jSONObject4.getClass();
                                                                tq4.f37519e = jSONObject4;
                                                                tq4.f37520f = linkedHashMap2;
                                                                SharedPreferences.Editor edit2 = h53.m12545a().edit();
                                                                edit2.getClass();
                                                                edit2.putString("sens_curve_profiles_json", jSONObject4);
                                                                edit2.commit();
                                                                au2 m11349q2 = magicManagerSettingsFeature12.m11349q();
                                                                r41 r41Var2 = ka1.f21425a;
                                                                v86.m21284K(m11349q2, w31.f41501b, null, new hu1(intValue6, null, (byte) 2), 2);
                                                                break;
                                                        }
                                                        return kn5.f22076a;
                                                    }
                                                };
                                                s02Var6.m19330k0(m19298O31);
                                            } else {
                                                b4 = 0;
                                            }
                                            magicManagerSettingsFeature10.m11386N(intValue4, b4, (zy1) m19298O31, s02Var6);
                                            yt0.m23628u(10, s02Var6, 6, ka3Var2, s02Var6);
                                            final ef3 ef3Var46 = this.f19428l;
                                            int intValue5 = ((Number) ef3Var46.getValue()).intValue();
                                            boolean m19319f10 = s02Var6.m19319f(ef3Var46) | s02Var6.m19323h(magicManagerSettingsFeature10);
                                            Object m19298O32 = s02Var6.m19298O();
                                            if (m19319f10 || m19298O32 == obj15) {
                                                final byte b5 = 1;
                                                m19298O32 = new zy1() { // from class: mz2
                                                    @Override // p000.zy1
                                                    public final Object invoke(Object obj17) {
                                                        switch (b5) {
                                                            case 0:
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature11 = magicManagerSettingsFeature10;
                                                                ef3 ef3Var462 = ef3Var46;
                                                                Integer num2 = (Integer) obj17;
                                                                int intValue52 = num2.intValue();
                                                                ef3Var462.setValue(num2);
                                                                magicManagerSettingsFeature11.getClass();
                                                                String str7 = tq4.f37515a;
                                                                String m11390R3 = magicManagerSettingsFeature11.m11390R();
                                                                m11390R3.getClass();
                                                                String string = h53.m12545a().getString("sens_area_profiles_json", "");
                                                                LinkedHashMap linkedHashMap = new LinkedHashMap(tq4.m20438e(string != null ? string : ""));
                                                                linkedHashMap.put(m11390R3, num2);
                                                                JSONObject jSONObject = new JSONObject();
                                                                for (Map.Entry entry : linkedHashMap.entrySet()) {
                                                                    jSONObject.put((String) entry.getKey(), ((Number) entry.getValue()).intValue());
                                                                }
                                                                String jSONObject2 = jSONObject.toString();
                                                                jSONObject2.getClass();
                                                                tq4.f37517c = jSONObject2;
                                                                tq4.f37518d = linkedHashMap;
                                                                SharedPreferences.Editor edit = h53.m12545a().edit();
                                                                edit.getClass();
                                                                edit.putString("sens_area_profiles_json", jSONObject2);
                                                                edit.commit();
                                                                au2 m11349q = magicManagerSettingsFeature11.m11349q();
                                                                r41 r41Var = ka1.f21425a;
                                                                v86.m21284K(m11349q, w31.f41501b, null, new hu1(intValue52, null, (byte) 1), 2);
                                                                break;
                                                            default:
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature12 = magicManagerSettingsFeature10;
                                                                ef3 ef3Var47 = ef3Var46;
                                                                Integer num3 = (Integer) obj17;
                                                                int intValue6 = num3.intValue();
                                                                ef3Var47.setValue(num3);
                                                                magicManagerSettingsFeature12.getClass();
                                                                String str8 = tq4.f37515a;
                                                                String m11390R4 = magicManagerSettingsFeature12.m11390R();
                                                                m11390R4.getClass();
                                                                String string2 = h53.m12545a().getString("sens_curve_profiles_json", "");
                                                                LinkedHashMap linkedHashMap2 = new LinkedHashMap(tq4.m20439f(string2 != null ? string2 : ""));
                                                                linkedHashMap2.put(m11390R4, num3);
                                                                JSONObject jSONObject3 = new JSONObject();
                                                                for (Map.Entry entry2 : linkedHashMap2.entrySet()) {
                                                                    jSONObject3.put((String) entry2.getKey(), ((Number) entry2.getValue()).intValue());
                                                                }
                                                                String jSONObject4 = jSONObject3.toString();
                                                                jSONObject4.getClass();
                                                                tq4.f37519e = jSONObject4;
                                                                tq4.f37520f = linkedHashMap2;
                                                                SharedPreferences.Editor edit2 = h53.m12545a().edit();
                                                                edit2.getClass();
                                                                edit2.putString("sens_curve_profiles_json", jSONObject4);
                                                                edit2.commit();
                                                                au2 m11349q2 = magicManagerSettingsFeature12.m11349q();
                                                                r41 r41Var2 = ka1.f21425a;
                                                                v86.m21284K(m11349q2, w31.f41501b, null, new hu1(intValue6, null, (byte) 2), 2);
                                                                break;
                                                        }
                                                        return kn5.f22076a;
                                                    }
                                                };
                                                s02Var6.m19330k0(m19298O32);
                                            }
                                            magicManagerSettingsFeature10.m11387O(intValue5, b4, (zy1) m19298O32, s02Var6);
                                            yt0.m23628u(12, s02Var6, 6, ka3Var2, s02Var6);
                                            final et3 et3Var22 = this.f19429m;
                                            float m10488h = et3Var22.m10488h();
                                            boolean m19319f11 = s02Var6.m19319f(et3Var22);
                                            final float f3 = this.f19430n;
                                            boolean m19313c = m19319f11 | s02Var6.m19313c(f3) | s02Var6.m19323h(magicManagerSettingsFeature10);
                                            final et3 et3Var23 = this.f19431o;
                                            boolean m19319f12 = m19313c | s02Var6.m19319f(et3Var23);
                                            Object m19298O33 = s02Var6.m19298O();
                                            if (m19319f12 || m19298O33 == obj15) {
                                                final byte b6 = 0;
                                                magicManagerSettingsFeature6 = magicManagerSettingsFeature10;
                                                obj12 = new zy1() { // from class: nz2
                                                    @Override // p000.zy1
                                                    public final Object invoke(Object obj17) {
                                                        switch (b6) {
                                                            case 0:
                                                                float f4 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature11 = magicManagerSettingsFeature6;
                                                                et3 et3Var24 = et3Var22;
                                                                et3 et3Var25 = et3Var23;
                                                                et3Var24.m10489i(dg2.m9131s(((Float) obj17).floatValue(), 0.2f, f4));
                                                                String str7 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature11.m11390R(), et3Var24.m10488h(), et3Var25.m10488h());
                                                                break;
                                                            case 1:
                                                                float f5 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature12 = magicManagerSettingsFeature6;
                                                                et3 et3Var26 = et3Var22;
                                                                et3 et3Var27 = et3Var23;
                                                                et3Var26.m10489i(dg2.m9131s((((Integer) obj17).intValue() * 0.01f) + et3Var26.m10488h(), 0.2f, f5));
                                                                String str8 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature12.m11390R(), et3Var26.m10488h(), et3Var27.m10488h());
                                                                break;
                                                            case 2:
                                                                float f6 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature13 = magicManagerSettingsFeature6;
                                                                et3 et3Var28 = et3Var22;
                                                                et3 et3Var29 = et3Var23;
                                                                et3Var28.m10489i(dg2.m9131s(((Float) obj17).floatValue(), 0.2f, f6));
                                                                String str9 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature13.m11390R(), et3Var29.m10488h(), et3Var28.m10488h());
                                                                break;
                                                            default:
                                                                float f7 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature14 = magicManagerSettingsFeature6;
                                                                et3 et3Var30 = et3Var22;
                                                                et3 et3Var31 = et3Var23;
                                                                et3Var30.m10489i(dg2.m9131s((((Integer) obj17).intValue() * 0.01f) + et3Var30.m10488h(), 0.2f, f7));
                                                                String str10 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature14.m11390R(), et3Var31.m10488h(), et3Var30.m10488h());
                                                                break;
                                                        }
                                                        return kn5.f22076a;
                                                    }
                                                };
                                                s02Var6.m19330k0(obj12);
                                            } else {
                                                obj12 = m19298O33;
                                                magicManagerSettingsFeature6 = magicManagerSettingsFeature10;
                                            }
                                            zy1 zy1Var3 = (zy1) obj12;
                                            boolean m19319f13 = s02Var6.m19319f(et3Var22) | s02Var6.m19313c(f3) | s02Var6.m19323h(magicManagerSettingsFeature6) | s02Var6.m19319f(et3Var23);
                                            Object m19298O34 = s02Var6.m19298O();
                                            if (m19319f13 || m19298O34 == obj15) {
                                                final byte b7 = 1;
                                                Object obj17 = new zy1() { // from class: nz2
                                                    @Override // p000.zy1
                                                    public final Object invoke(Object obj172) {
                                                        switch (b7) {
                                                            case 0:
                                                                float f4 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature11 = magicManagerSettingsFeature6;
                                                                et3 et3Var24 = et3Var22;
                                                                et3 et3Var25 = et3Var23;
                                                                et3Var24.m10489i(dg2.m9131s(((Float) obj172).floatValue(), 0.2f, f4));
                                                                String str7 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature11.m11390R(), et3Var24.m10488h(), et3Var25.m10488h());
                                                                break;
                                                            case 1:
                                                                float f5 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature12 = magicManagerSettingsFeature6;
                                                                et3 et3Var26 = et3Var22;
                                                                et3 et3Var27 = et3Var23;
                                                                et3Var26.m10489i(dg2.m9131s((((Integer) obj172).intValue() * 0.01f) + et3Var26.m10488h(), 0.2f, f5));
                                                                String str8 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature12.m11390R(), et3Var26.m10488h(), et3Var27.m10488h());
                                                                break;
                                                            case 2:
                                                                float f6 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature13 = magicManagerSettingsFeature6;
                                                                et3 et3Var28 = et3Var22;
                                                                et3 et3Var29 = et3Var23;
                                                                et3Var28.m10489i(dg2.m9131s(((Float) obj172).floatValue(), 0.2f, f6));
                                                                String str9 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature13.m11390R(), et3Var29.m10488h(), et3Var28.m10488h());
                                                                break;
                                                            default:
                                                                float f7 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature14 = magicManagerSettingsFeature6;
                                                                et3 et3Var30 = et3Var22;
                                                                et3 et3Var31 = et3Var23;
                                                                et3Var30.m10489i(dg2.m9131s((((Integer) obj172).intValue() * 0.01f) + et3Var30.m10488h(), 0.2f, f7));
                                                                String str10 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature14.m11390R(), et3Var31.m10488h(), et3Var30.m10488h());
                                                                break;
                                                        }
                                                        return kn5.f22076a;
                                                    }
                                                };
                                                et3Var15 = et3Var22;
                                                s02Var6.m19330k0(obj17);
                                                m19298O34 = obj17;
                                            } else {
                                                et3Var15 = et3Var22;
                                            }
                                            MagicManagerSettingsFeature magicManagerSettingsFeature11 = magicManagerSettingsFeature6;
                                            magicManagerSettingsFeature11.m11388P("Sensitivity X (Horizontal)", m10488h, zy1Var3, (zy1) m19298O34, f3, s02Var6, 6);
                                            yt0.m23628u(10, s02Var6, 6, ka3Var2, s02Var6);
                                            float m10488h2 = et3Var23.m10488h();
                                            boolean m19319f14 = s02Var6.m19319f(et3Var23) | s02Var6.m19313c(f3) | s02Var6.m19323h(magicManagerSettingsFeature11) | s02Var6.m19319f(et3Var15);
                                            Object m19298O35 = s02Var6.m19298O();
                                            if (m19319f14 || m19298O35 == obj15) {
                                                magicManagerSettingsFeature7 = magicManagerSettingsFeature11;
                                                final byte b8 = 2;
                                                final et3 et3Var24 = et3Var15;
                                                obj13 = new zy1() { // from class: nz2
                                                    @Override // p000.zy1
                                                    public final Object invoke(Object obj172) {
                                                        switch (b8) {
                                                            case 0:
                                                                float f4 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature112 = magicManagerSettingsFeature7;
                                                                et3 et3Var242 = et3Var23;
                                                                et3 et3Var25 = et3Var24;
                                                                et3Var242.m10489i(dg2.m9131s(((Float) obj172).floatValue(), 0.2f, f4));
                                                                String str7 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature112.m11390R(), et3Var242.m10488h(), et3Var25.m10488h());
                                                                break;
                                                            case 1:
                                                                float f5 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature12 = magicManagerSettingsFeature7;
                                                                et3 et3Var26 = et3Var23;
                                                                et3 et3Var27 = et3Var24;
                                                                et3Var26.m10489i(dg2.m9131s((((Integer) obj172).intValue() * 0.01f) + et3Var26.m10488h(), 0.2f, f5));
                                                                String str8 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature12.m11390R(), et3Var26.m10488h(), et3Var27.m10488h());
                                                                break;
                                                            case 2:
                                                                float f6 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature13 = magicManagerSettingsFeature7;
                                                                et3 et3Var28 = et3Var23;
                                                                et3 et3Var29 = et3Var24;
                                                                et3Var28.m10489i(dg2.m9131s(((Float) obj172).floatValue(), 0.2f, f6));
                                                                String str9 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature13.m11390R(), et3Var29.m10488h(), et3Var28.m10488h());
                                                                break;
                                                            default:
                                                                float f7 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature14 = magicManagerSettingsFeature7;
                                                                et3 et3Var30 = et3Var23;
                                                                et3 et3Var31 = et3Var24;
                                                                et3Var30.m10489i(dg2.m9131s((((Integer) obj172).intValue() * 0.01f) + et3Var30.m10488h(), 0.2f, f7));
                                                                String str10 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature14.m11390R(), et3Var31.m10488h(), et3Var30.m10488h());
                                                                break;
                                                        }
                                                        return kn5.f22076a;
                                                    }
                                                };
                                                et3Var16 = et3Var23;
                                                et3Var17 = et3Var24;
                                                s02Var6.m19330k0(obj13);
                                            } else {
                                                magicManagerSettingsFeature7 = magicManagerSettingsFeature11;
                                                obj13 = m19298O35;
                                                et3Var16 = et3Var23;
                                                et3Var17 = et3Var15;
                                            }
                                            zy1 zy1Var4 = (zy1) obj13;
                                            boolean m19319f15 = s02Var6.m19319f(et3Var16) | s02Var6.m19313c(f3) | s02Var6.m19323h(magicManagerSettingsFeature7) | s02Var6.m19319f(et3Var17);
                                            Object m19298O36 = s02Var6.m19298O();
                                            if (m19319f15 || m19298O36 == obj15) {
                                                final byte b9 = 3;
                                                final et3 et3Var25 = et3Var16;
                                                final et3 et3Var26 = et3Var17;
                                                Object obj18 = new zy1() { // from class: nz2
                                                    @Override // p000.zy1
                                                    public final Object invoke(Object obj172) {
                                                        switch (b9) {
                                                            case 0:
                                                                float f4 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature112 = magicManagerSettingsFeature7;
                                                                et3 et3Var242 = et3Var25;
                                                                et3 et3Var252 = et3Var26;
                                                                et3Var242.m10489i(dg2.m9131s(((Float) obj172).floatValue(), 0.2f, f4));
                                                                String str7 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature112.m11390R(), et3Var242.m10488h(), et3Var252.m10488h());
                                                                break;
                                                            case 1:
                                                                float f5 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature12 = magicManagerSettingsFeature7;
                                                                et3 et3Var262 = et3Var25;
                                                                et3 et3Var27 = et3Var26;
                                                                et3Var262.m10489i(dg2.m9131s((((Integer) obj172).intValue() * 0.01f) + et3Var262.m10488h(), 0.2f, f5));
                                                                String str8 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature12.m11390R(), et3Var262.m10488h(), et3Var27.m10488h());
                                                                break;
                                                            case 2:
                                                                float f6 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature13 = magicManagerSettingsFeature7;
                                                                et3 et3Var28 = et3Var25;
                                                                et3 et3Var29 = et3Var26;
                                                                et3Var28.m10489i(dg2.m9131s(((Float) obj172).floatValue(), 0.2f, f6));
                                                                String str9 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature13.m11390R(), et3Var29.m10488h(), et3Var28.m10488h());
                                                                break;
                                                            default:
                                                                float f7 = f3;
                                                                MagicManagerSettingsFeature magicManagerSettingsFeature14 = magicManagerSettingsFeature7;
                                                                et3 et3Var30 = et3Var25;
                                                                et3 et3Var31 = et3Var26;
                                                                et3Var30.m10489i(dg2.m9131s((((Integer) obj172).intValue() * 0.01f) + et3Var30.m10488h(), 0.2f, f7));
                                                                String str10 = tq4.f37515a;
                                                                tq4.m20441h(magicManagerSettingsFeature14.m11390R(), et3Var31.m10488h(), et3Var30.m10488h());
                                                                break;
                                                        }
                                                        return kn5.f22076a;
                                                    }
                                                };
                                                s02Var6.m19330k0(obj18);
                                                m19298O36 = obj18;
                                            }
                                            final MagicManagerSettingsFeature magicManagerSettingsFeature12 = magicManagerSettingsFeature7;
                                            magicManagerSettingsFeature12.m11388P("Sensitivity Y (Vertical)", m10488h2, zy1Var4, (zy1) m19298O36, f3, s02Var6, 6);
                                            yt0.m23628u(14, s02Var6, 6, ka3Var2, s02Var6);
                                            na3 m11708d7 = fy4.m11708d(ka3Var2, 1.0f);
                                            ug4 m19739a6 = sg4.m19739a(c1207jv, o70Var, s02Var6, 48);
                                            int hashCode12 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l12 = s02Var6.m19331l();
                                            na3 m20748R12 = u99.m20748R(s02Var6, m11708d7);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                s02Var6.m19329k(xy1Var9);
                                            } else {
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m19739a6);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l12);
                                            hn0.m12946s(hashCode12, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R12);
                                            na3 m21468a3 = vg4.m21468a(ka3Var2, 1.0f);
                                            ek0 m9307a6 = dk0.m9307a(c1246kv, n70Var, s02Var6, b4);
                                            int hashCode13 = Long.hashCode(s02Var6.f34520T);
                                            ov3 m19331l13 = s02Var6.m19331l();
                                            na3 m20748R13 = u99.m20748R(s02Var6, m21468a3);
                                            s02Var6.m19316d0();
                                            if (s02Var6.f34519S) {
                                                s02Var6.m19329k(xy1Var9);
                                            } else {
                                                s02Var6.m19336n0();
                                            }
                                            z80.m23871N(xm0Var, s02Var6, m9307a6);
                                            z80.m23871N(xm0Var2, s02Var6, m19331l13);
                                            hn0.m12946s(hashCode13, s02Var6, xm0Var3, s02Var6);
                                            z80.m23871N(xm0Var4, s02Var6, m20748R13);
                                            xe5.m22686b("TactiX", null, uj0Var4.f38783q, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, sl5Var4.f35598m, s02Var6, 6, 0, 131066);
                                            xe5.m22686b("Steadier aim when still, no lag on flicks", null, uj0Var4.f38734B, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, sl5Var4.f35600o, s02Var6, 6, 0, 131066);
                                            s02Var6.m19338p(true);
                                            vt0 m9071C3 = dg2.m9071C(2, 0.4f);
                                            ef3 ef3Var47 = this.f19433q;
                                            boolean booleanValue4 = ((Boolean) ef3Var47.getValue()).booleanValue();
                                            boolean m19323h7 = s02Var6.m19323h(magicManagerSettingsFeature12);
                                            Object m19298O37 = s02Var6.m19298O();
                                            et3 et3Var27 = this.f19434r;
                                            et3 et3Var28 = this.f19435s;
                                            if (m19323h7 || m19298O37 == obj15) {
                                                et3Var18 = et3Var28;
                                                obj14 = obj15;
                                                c1354nn = new C1354nn(magicManagerSettingsFeature12, ef3Var47, et3Var27, et3Var18, (byte) 8);
                                                ef3Var39 = ef3Var47;
                                                s02Var6.m19330k0(c1354nn);
                                            } else {
                                                ef3Var39 = ef3Var47;
                                                c1354nn = m19298O37;
                                                et3Var18 = et3Var28;
                                                obj14 = obj15;
                                            }
                                            et3 et3Var29 = et3Var18;
                                            Object obj19 = obj14;
                                            z21.m23751e(booleanValue4, (zy1) c1354nn, null, 0.0f, 0.0f, m9071C3, 0L, 0L, 0L, 0.0f, 0L, s02Var6, 0, 2012);
                                            s02 s02Var7 = s02Var6;
                                            s02Var7.m19338p(true);
                                            if (((Boolean) ef3Var39.getValue()).booleanValue()) {
                                                s02Var7.m19308Z(44690540);
                                                ka3Var = ka3Var2;
                                                yt0.m23628u(12, s02Var7, 6, ka3Var, s02Var7);
                                                float m10488h3 = (6.0f - et3Var27.m10488h()) / 5.7f;
                                                String format = String.format("%.0f%%", Arrays.copyOf(new Object[]{Float.valueOf(m10488h3 * 100.0f)}, 1));
                                                ni0 ni0Var = new ni0(0.0f, 1.0f);
                                                boolean m19323h8 = s02Var7.m19323h(magicManagerSettingsFeature12);
                                                Object m19298O38 = s02Var7.m19298O();
                                                if (m19323h8 || m19298O38 == obj19) {
                                                    et3Var19 = et3Var27;
                                                    et3Var20 = et3Var29;
                                                    final byte b10 = 0;
                                                    m19298O38 = new zy1() { // from class: kz2
                                                        @Override // p000.zy1
                                                        public final Object invoke(Object obj20) {
                                                            byte b11 = b10;
                                                            kn5 kn5Var4 = kn5.f22076a;
                                                            et3 et3Var30 = et3Var20;
                                                            et3 et3Var31 = et3Var19;
                                                            MagicManagerSettingsFeature magicManagerSettingsFeature13 = magicManagerSettingsFeature12;
                                                            switch (b11) {
                                                                case 0:
                                                                    et3Var31.m10489i(6.0f - (((Float) obj20).floatValue() * 5.7f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var31.m10488h(), et3Var30.m10488h(), true);
                                                                    break;
                                                                case 1:
                                                                    et3Var31.m10489i(6.0f - (dg2.m9131s((((Integer) obj20).intValue() * 0.01f) + ((6.0f - et3Var31.m10488h()) / 5.7f), 0.0f, 1.0f) * 5.7f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var31.m10488h(), et3Var30.m10488h(), true);
                                                                    break;
                                                                case 2:
                                                                    et3Var31.m10489i(((Float) obj20).floatValue());
                                                                    magicManagerSettingsFeature13.m11391S(et3Var30.m10488h(), et3Var31.m10488h(), true);
                                                                    break;
                                                                default:
                                                                    et3Var31.m10489i(dg2.m9131s((((Integer) obj20).intValue() * 0.001f) + et3Var31.m10488h(), 0.0f, 0.05f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var30.m10488h(), et3Var31.m10488h(), true);
                                                                    break;
                                                            }
                                                            return kn5Var4;
                                                        }
                                                    };
                                                    s02Var7.m19330k0(m19298O38);
                                                } else {
                                                    et3Var19 = et3Var27;
                                                    et3Var20 = et3Var29;
                                                }
                                                zy1 zy1Var5 = (zy1) m19298O38;
                                                boolean m19323h9 = s02Var7.m19323h(magicManagerSettingsFeature12);
                                                Object m19298O39 = s02Var7.m19298O();
                                                if (m19323h9 || m19298O39 == obj19) {
                                                    final byte b11 = 1;
                                                    m19298O39 = new zy1() { // from class: kz2
                                                        @Override // p000.zy1
                                                        public final Object invoke(Object obj20) {
                                                            byte b112 = b11;
                                                            kn5 kn5Var4 = kn5.f22076a;
                                                            et3 et3Var30 = et3Var20;
                                                            et3 et3Var31 = et3Var19;
                                                            MagicManagerSettingsFeature magicManagerSettingsFeature13 = magicManagerSettingsFeature12;
                                                            switch (b112) {
                                                                case 0:
                                                                    et3Var31.m10489i(6.0f - (((Float) obj20).floatValue() * 5.7f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var31.m10488h(), et3Var30.m10488h(), true);
                                                                    break;
                                                                case 1:
                                                                    et3Var31.m10489i(6.0f - (dg2.m9131s((((Integer) obj20).intValue() * 0.01f) + ((6.0f - et3Var31.m10488h()) / 5.7f), 0.0f, 1.0f) * 5.7f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var31.m10488h(), et3Var30.m10488h(), true);
                                                                    break;
                                                                case 2:
                                                                    et3Var31.m10489i(((Float) obj20).floatValue());
                                                                    magicManagerSettingsFeature13.m11391S(et3Var30.m10488h(), et3Var31.m10488h(), true);
                                                                    break;
                                                                default:
                                                                    et3Var31.m10489i(dg2.m9131s((((Integer) obj20).intValue() * 0.001f) + et3Var31.m10488h(), 0.0f, 0.05f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var30.m10488h(), et3Var31.m10488h(), true);
                                                                    break;
                                                            }
                                                            return kn5Var4;
                                                        }
                                                    };
                                                    s02Var7.m19330k0(m19298O39);
                                                }
                                                final et3 et3Var30 = et3Var19;
                                                et3 et3Var31 = et3Var20;
                                                magicManagerSettingsFeature12.m11389Q("Strength", m10488h3, format, ni0Var, zy1Var5, (zy1) m19298O39, s02Var7, 6);
                                                yt0.m23628u(10, s02Var7, 6, ka3Var, s02Var7);
                                                float m10488h4 = et3Var31.m10488h();
                                                String format2 = String.format("%.0f%%", Arrays.copyOf(new Object[]{Float.valueOf((et3Var31.m10488h() / 0.05f) * 100.0f)}, 1));
                                                ni0 ni0Var2 = new ni0(0.0f, 0.05f);
                                                boolean m19323h10 = s02Var7.m19323h(magicManagerSettingsFeature12);
                                                Object m19298O40 = s02Var7.m19298O();
                                                if (m19323h10 || m19298O40 == obj19) {
                                                    et3Var21 = et3Var31;
                                                    final byte b12 = 2;
                                                    m19298O40 = new zy1() { // from class: kz2
                                                        @Override // p000.zy1
                                                        public final Object invoke(Object obj20) {
                                                            byte b112 = b12;
                                                            kn5 kn5Var4 = kn5.f22076a;
                                                            et3 et3Var302 = et3Var30;
                                                            et3 et3Var312 = et3Var21;
                                                            MagicManagerSettingsFeature magicManagerSettingsFeature13 = magicManagerSettingsFeature12;
                                                            switch (b112) {
                                                                case 0:
                                                                    et3Var312.m10489i(6.0f - (((Float) obj20).floatValue() * 5.7f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var312.m10488h(), et3Var302.m10488h(), true);
                                                                    break;
                                                                case 1:
                                                                    et3Var312.m10489i(6.0f - (dg2.m9131s((((Integer) obj20).intValue() * 0.01f) + ((6.0f - et3Var312.m10488h()) / 5.7f), 0.0f, 1.0f) * 5.7f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var312.m10488h(), et3Var302.m10488h(), true);
                                                                    break;
                                                                case 2:
                                                                    et3Var312.m10489i(((Float) obj20).floatValue());
                                                                    magicManagerSettingsFeature13.m11391S(et3Var302.m10488h(), et3Var312.m10488h(), true);
                                                                    break;
                                                                default:
                                                                    et3Var312.m10489i(dg2.m9131s((((Integer) obj20).intValue() * 0.001f) + et3Var312.m10488h(), 0.0f, 0.05f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var302.m10488h(), et3Var312.m10488h(), true);
                                                                    break;
                                                            }
                                                            return kn5Var4;
                                                        }
                                                    };
                                                    s02Var7.m19330k0(m19298O40);
                                                } else {
                                                    et3Var21 = et3Var31;
                                                }
                                                zy1 zy1Var6 = (zy1) m19298O40;
                                                boolean m19323h11 = s02Var7.m19323h(magicManagerSettingsFeature12);
                                                Object m19298O41 = s02Var7.m19298O();
                                                if (m19323h11 || m19298O41 == obj19) {
                                                    final byte b13 = 3;
                                                    m19298O41 = new zy1() { // from class: kz2
                                                        @Override // p000.zy1
                                                        public final Object invoke(Object obj20) {
                                                            byte b112 = b13;
                                                            kn5 kn5Var4 = kn5.f22076a;
                                                            et3 et3Var302 = et3Var30;
                                                            et3 et3Var312 = et3Var21;
                                                            MagicManagerSettingsFeature magicManagerSettingsFeature13 = magicManagerSettingsFeature12;
                                                            switch (b112) {
                                                                case 0:
                                                                    et3Var312.m10489i(6.0f - (((Float) obj20).floatValue() * 5.7f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var312.m10488h(), et3Var302.m10488h(), true);
                                                                    break;
                                                                case 1:
                                                                    et3Var312.m10489i(6.0f - (dg2.m9131s((((Integer) obj20).intValue() * 0.01f) + ((6.0f - et3Var312.m10488h()) / 5.7f), 0.0f, 1.0f) * 5.7f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var312.m10488h(), et3Var302.m10488h(), true);
                                                                    break;
                                                                case 2:
                                                                    et3Var312.m10489i(((Float) obj20).floatValue());
                                                                    magicManagerSettingsFeature13.m11391S(et3Var302.m10488h(), et3Var312.m10488h(), true);
                                                                    break;
                                                                default:
                                                                    et3Var312.m10489i(dg2.m9131s((((Integer) obj20).intValue() * 0.001f) + et3Var312.m10488h(), 0.0f, 0.05f));
                                                                    magicManagerSettingsFeature13.m11391S(et3Var302.m10488h(), et3Var312.m10488h(), true);
                                                                    break;
                                                            }
                                                            return kn5Var4;
                                                        }
                                                    };
                                                    s02Var7.m19330k0(m19298O41);
                                                }
                                                magicManagerSettingsFeature12.m11389Q("Responsiveness", m10488h4, format2, ni0Var2, zy1Var6, (zy1) m19298O41, s02Var7, 6);
                                                yt0.m23628u(12, s02Var7, 6, ka3Var, s02Var7);
                                                q75.m18052a(fy4.m11708d(ka3Var, 1.0f), dg2.m9067A(0.2f, 1.0f), qj0.m18297b(0.5f, uj0Var4.f38784r), 0L, 0.0f, 0.0f, null, mt7.m16166P(852708586, new C1576tc(uj0Var4, sl5Var4, (byte) 29), s02Var7), s02Var7, 12582918, 120);
                                                s02 s02Var8 = s02Var7;
                                                r6 = 0;
                                                s02Var8.m19338p(false);
                                                s02Var5 = s02Var8;
                                            } else {
                                                ka3Var = ka3Var2;
                                                r6 = 0;
                                                s02Var7.m19308Z(49170722);
                                                s02Var7.m19338p(false);
                                                s02Var5 = s02Var7;
                                            }
                                            s02Var5.m19338p(true);
                                            if (((Boolean) ef3Var43.getValue()).booleanValue()) {
                                                kn5Var2 = kn5Var3;
                                                s02Var5.m19308Z(1592635276);
                                                s02Var5.m19338p(r6);
                                            } else {
                                                s02Var5.m19308Z(1592086545);
                                                na3 mo16390b = q90.f31530a.mo16390b(ka3Var);
                                                Object m19298O42 = s02Var5.m19298O();
                                                if (m19298O42 == obj19) {
                                                    m19298O42 = y41.f44845c;
                                                    s02Var5.m19330k0(m19298O42);
                                                }
                                                kn5Var2 = kn5Var3;
                                                l90.m15154a(v75.m21255a(mo16390b, kn5Var2, (PointerInputEventHandler) m19298O42), s02Var5, r6);
                                                s02Var5.m19338p(r6);
                                            }
                                            d63.m8816w(s02Var5, true, r6, true);
                                            return kn5Var2;
                                        }
                                    }, s02Var4), s02Var4, 24576, 12);
                                } else {
                                    s02Var4.m19303U();
                                }
                                return kn5.f22076a;
                            }
                        }, s02Var3), s02Var3, 805306368, 190);
                    } else {
                        s02Var3.m19303U();
                    }
                    return kn5.f22076a;
                }
            };
            magicManagerSettingsFeature = this;
            s02Var2 = s02Var;
            dg2.m9103e(null, mt7.m16166P(69476219, nz1Var4, s02Var2), s02Var2, 48, 1);
        } else {
            s02Var2.m19303U();
        }
        m84 m19342t = s02Var2.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new ez2(magicManagerSettingsFeature, i);
        }
    }

    /* renamed from: N */
    public final void m11386N(int i, int i2, zy1 zy1Var, s02 s02Var) {
        s02 s02Var2 = s02Var;
        s02Var2.m19312b0(793601765);
        int i3 = i2 | (s02Var2.m19315d(i) ? 4 : 2) | (s02Var2.m19323h(zy1Var) ? 32 : 16) | (s02Var2.m19323h(this) ? 256 : 128);
        if (s02Var2.m19300R(i3 & 1, (i3 & 147) != 146)) {
            k64 k64Var = (k64) s02Var2.m19327j(rj0.f33758k);
            uj0 uj0Var = (uj0) s02Var2.m19327j(wj0.f42164a);
            sl5 sl5Var = (sl5) s02Var2.m19327j(ul5.f38880a);
            List<ds3> m14031D = jj0.m14031D(new ds3(-1, "Left"), new ds3(0, "All"), new ds3(1, "Right"));
            ka3 ka3Var = ka3.f21426a;
            na3 m11708d = fy4.m11708d(ka3Var, 1.0f);
            ek0 m9307a = dk0.m9307a(AbstractC1443pv.f30967c, mg1.f25871n, s02Var2, 0);
            int hashCode = Long.hashCode(s02Var2.f34520T);
            ov3 m19331l = s02Var2.m19331l();
            na3 m20748R = u99.m20748R(s02Var2, m11708d);
            sn0.f35689X8.getClass();
            s02Var2.m19316d0();
            boolean z = s02Var2.f34519S;
            me2 me2Var = wo2.f42501S;
            if (z) {
                s02Var2.m19329k(me2Var);
            } else {
                s02Var2.m19336n0();
            }
            xm0 xm0Var = oua.f29409h;
            z80.m23871N(xm0Var, s02Var2, m9307a);
            xm0 xm0Var2 = oua.f29408g;
            z80.m23871N(xm0Var2, s02Var2, m19331l);
            Integer valueOf = Integer.valueOf(hashCode);
            xm0 xm0Var3 = oua.f29410i;
            z80.m23871N(xm0Var3, s02Var2, valueOf);
            z80.m23869L(s02Var2);
            xm0 xm0Var4 = oua.f29407f;
            z80.m23871N(xm0Var4, s02Var2, m20748R);
            k64 k64Var2 = k64Var;
            xe5.m22686b("Sensitivity Area", null, uj0Var.f38734B, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, of5.m17192a(sl5Var.f35599n, 0L, di2.m9240O(9, s02Var2), null, null, 0L, null, 0L, null, null, 16777213), s02Var, 6, 0, 131066);
            s02 s02Var3 = s02Var;
            yt0.m23628u(5, s02Var3, 6, ka3Var, s02Var3);
            na3 m11708d2 = fy4.m11708d(ka3Var, 1.0f);
            boolean z2 = true;
            ug4 m19739a = sg4.m19739a(new C1325mv(di2.m9238M(6, s02Var3, 6), true, new C0950f((byte) 9)), mg1.f25868k, s02Var3, 0);
            int hashCode2 = Long.hashCode(s02Var3.f34520T);
            ov3 m19331l2 = s02Var3.m19331l();
            na3 m20748R2 = u99.m20748R(s02Var3, m11708d2);
            s02Var3.m19316d0();
            if (s02Var3.f34519S) {
                s02Var3.m19329k(me2Var);
            } else {
                s02Var3.m19336n0();
            }
            z80.m23871N(xm0Var, s02Var3, m19739a);
            z80.m23871N(xm0Var2, s02Var3, m19331l2);
            hn0.m12946s(hashCode2, s02Var3, xm0Var3, s02Var3);
            z80.m23871N(xm0Var4, s02Var3, m20748R2);
            s02Var3.m19308Z(-1167238187);
            for (ds3 ds3Var : m14031D) {
                int intValue = ((Number) ds3Var.f10834a).intValue();
                String str = (String) ds3Var.f10835b;
                boolean z3 = intValue == i ? z2 : false;
                na3 m23273i = y53.m23273i(new mp2(1.0f, z2), dg2.m9071C(2, 0.4f));
                boolean m19315d = ((i3 & 112) == 32 ? z2 : false) | s02Var3.m19315d(intValue);
                Object m19298O = s02Var3.m19298O();
                if (m19315d || m19298O == yn0.f45724a) {
                    m19298O = new l42(zy1Var, intValue, (byte) 2);
                    s02Var3.m19330k0(m19298O);
                }
                k64 k64Var3 = k64Var2;
                k64Var2 = k64Var3;
                s02 s02Var4 = s02Var3;
                q75.m18052a(mx0.m16320t(15, (xy1) m19298O, m23273i, null, false), null, z3 ? qj0.m18297b(0.9f, k64Var3.f21260a) : qj0.m18297b(0.06f, k64Var3.f21264e), 0L, 0.0f, 0.0f, null, mt7.m16166P(-527744723, new oz2(this, intValue, z3, sl5Var, k64Var3, uj0Var, str, (byte) 1), s02Var3), s02Var4, 12582912, 122);
                z2 = z2;
                s02Var3 = s02Var4;
            }
            s02Var2 = s02Var3;
            boolean z4 = z2;
            d63.m8816w(s02Var2, false, z4, z4);
        } else {
            s02Var2.m19303U();
        }
        m84 m19342t = s02Var2.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new pz2(this, i, zy1Var, i2, (byte) 1);
        }
    }

    /* JADX WARN: Type inference failed for: r15v4 */
    /* JADX WARN: Type inference failed for: r15v5, types: [boolean, byte] */
    /* JADX WARN: Type inference failed for: r15v8 */
    /* renamed from: O */
    public final void m11387O(int i, int i2, zy1 zy1Var, s02 s02Var) {
        s02 s02Var2 = s02Var;
        s02Var2.m19312b0(-631269883);
        int i3 = i2 | (s02Var2.m19315d(i) ? 4 : 2) | (s02Var2.m19323h(zy1Var) ? 32 : 16) | (s02Var2.m19323h(this) ? 256 : 128);
        if (s02Var2.m19300R(i3 & 1, (i3 & 147) != 146)) {
            k64 k64Var = (k64) s02Var2.m19327j(rj0.f33758k);
            uj0 uj0Var = (uj0) s02Var2.m19327j(wj0.f42164a);
            sl5 sl5Var = (sl5) s02Var2.m19327j(ul5.f38880a);
            List<ds3> m14031D = jj0.m14031D(new ds3(0, "Linear"), new ds3(1, "Accel"), new ds3(2, "Decel"));
            ka3 ka3Var = ka3.f21426a;
            na3 m11708d = fy4.m11708d(ka3Var, 1.0f);
            ek0 m9307a = dk0.m9307a(AbstractC1443pv.f30967c, mg1.f25871n, s02Var2, 0);
            int hashCode = Long.hashCode(s02Var2.f34520T);
            ov3 m19331l = s02Var2.m19331l();
            na3 m20748R = u99.m20748R(s02Var2, m11708d);
            sn0.f35689X8.getClass();
            s02Var2.m19316d0();
            boolean z = s02Var2.f34519S;
            me2 me2Var = wo2.f42501S;
            if (z) {
                s02Var2.m19329k(me2Var);
            } else {
                s02Var2.m19336n0();
            }
            xm0 xm0Var = oua.f29409h;
            z80.m23871N(xm0Var, s02Var2, m9307a);
            xm0 xm0Var2 = oua.f29408g;
            z80.m23871N(xm0Var2, s02Var2, m19331l);
            Integer valueOf = Integer.valueOf(hashCode);
            xm0 xm0Var3 = oua.f29410i;
            z80.m23871N(xm0Var3, s02Var2, valueOf);
            z80.m23869L(s02Var2);
            xm0 xm0Var4 = oua.f29407f;
            z80.m23871N(xm0Var4, s02Var2, m20748R);
            k64 k64Var2 = k64Var;
            xe5.m22686b("Sensitivity Curve", null, uj0Var.f38734B, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, of5.m17192a(sl5Var.f35599n, 0L, di2.m9240O(9, s02Var2), null, null, 0L, null, 0L, null, null, 16777213), s02Var, 6, 0, 131066);
            s02 s02Var3 = s02Var;
            yt0.m23628u(5, s02Var3, 6, ka3Var, s02Var3);
            na3 m11708d2 = fy4.m11708d(ka3Var, 1.0f);
            boolean z2 = 1;
            ug4 m19739a = sg4.m19739a(new C1325mv(di2.m9238M(6, s02Var3, 6), true, new C0950f((byte) 9)), mg1.f25868k, s02Var3, 0);
            int hashCode2 = Long.hashCode(s02Var3.f34520T);
            ov3 m19331l2 = s02Var3.m19331l();
            na3 m20748R2 = u99.m20748R(s02Var3, m11708d2);
            s02Var3.m19316d0();
            if (s02Var3.f34519S) {
                s02Var3.m19329k(me2Var);
            } else {
                s02Var3.m19336n0();
            }
            z80.m23871N(xm0Var, s02Var3, m19739a);
            z80.m23871N(xm0Var2, s02Var3, m19331l2);
            hn0.m12946s(hashCode2, s02Var3, xm0Var3, s02Var3);
            z80.m23871N(xm0Var4, s02Var3, m20748R2);
            s02Var3.m19308Z(-1279902229);
            for (ds3 ds3Var : m14031D) {
                int intValue = ((Number) ds3Var.f10834a).intValue();
                String str = (String) ds3Var.f10835b;
                boolean z3 = intValue == i ? z2 : false;
                na3 m23273i = y53.m23273i(new mp2(1.0f, z2), dg2.m9071C(2, 0.4f));
                boolean m19315d = ((i3 & 112) == 32 ? z2 : false) | s02Var3.m19315d(intValue);
                Object m19298O = s02Var3.m19298O();
                if (m19315d || m19298O == yn0.f45724a) {
                    m19298O = new l42(zy1Var, intValue, z2);
                    s02Var3.m19330k0(m19298O);
                }
                na3 m16320t = mx0.m16320t(15, (xy1) m19298O, m23273i, null, false);
                k64 k64Var3 = k64Var2;
                k64Var2 = k64Var3;
                s02 s02Var4 = s02Var3;
                q75.m18052a(m16320t, null, z3 ? qj0.m18297b(0.9f, k64Var3.f21260a) : qj0.m18297b(0.06f, k64Var3.f21264e), 0L, 0.0f, 0.0f, null, mt7.m16166P(1356661949, new oz2(this, intValue, z3, sl5Var, k64Var3, uj0Var, str, (byte) 0), s02Var3), s02Var4, 12582912, 122);
                z2 = z2;
                s02Var3 = s02Var4;
            }
            s02Var2 = s02Var3;
            boolean z4 = z2;
            d63.m8816w(s02Var2, false, z4, z4);
        } else {
            s02Var2.m19303U();
        }
        m84 m19342t = s02Var2.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new pz2(this, i, zy1Var, i2, (byte) 0);
        }
    }

    /* renamed from: P */
    public final void m11388P(final String str, final float f, zy1 zy1Var, zy1 zy1Var2, final float f2, s02 s02Var, final int i) {
        zy1 zy1Var3;
        MagicManagerSettingsFeature magicManagerSettingsFeature;
        zy1 zy1Var4;
        s02 s02Var2 = s02Var;
        s02Var2.m19312b0(-2123633889);
        int i2 = i | (s02Var2.m19313c(f) ? 32 : 16) | (s02Var2.m19323h(zy1Var) ? 256 : 128) | (s02Var2.m19323h(zy1Var2) ? 2048 : 1024) | (s02Var2.m19313c(f2) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var2.m19323h(this) ? 131072 : 65536);
        if (s02Var2.m19300R(i2 & 1, (74899 & i2) != 74898)) {
            k64 k64Var = (k64) s02Var2.m19327j(rj0.f33758k);
            uj0 uj0Var = (uj0) s02Var2.m19327j(wj0.f42164a);
            sl5 sl5Var = (sl5) s02Var2.m19327j(ul5.f38880a);
            ka3 ka3Var = ka3.f21426a;
            na3 m11708d = fy4.m11708d(ka3Var, 1.0f);
            ek0 m9307a = dk0.m9307a(AbstractC1443pv.f30967c, mg1.f25871n, s02Var2, 0);
            int hashCode = Long.hashCode(s02Var2.f34520T);
            ov3 m19331l = s02Var2.m19331l();
            na3 m20748R = u99.m20748R(s02Var2, m11708d);
            sn0.f35689X8.getClass();
            s02Var2.m19316d0();
            boolean z = s02Var2.f34519S;
            me2 me2Var = wo2.f42501S;
            if (z) {
                s02Var2.m19329k(me2Var);
            } else {
                s02Var2.m19336n0();
            }
            xm0 xm0Var = oua.f29409h;
            z80.m23871N(xm0Var, s02Var2, m9307a);
            xm0 xm0Var2 = oua.f29408g;
            z80.m23871N(xm0Var2, s02Var2, m19331l);
            Integer valueOf = Integer.valueOf(hashCode);
            xm0 xm0Var3 = oua.f29410i;
            z80.m23871N(xm0Var3, s02Var2, valueOf);
            z80.m23869L(s02Var2);
            xm0 xm0Var4 = oua.f29407f;
            z80.m23871N(xm0Var4, s02Var2, m20748R);
            na3 m11708d2 = fy4.m11708d(ka3Var, 1.0f);
            o70 o70Var = mg1.f25869l;
            C1207jv c1207jv = AbstractC1443pv.f30965a;
            ug4 m19739a = sg4.m19739a(c1207jv, o70Var, s02Var2, 48);
            int hashCode2 = Long.hashCode(s02Var2.f34520T);
            ov3 m19331l2 = s02Var2.m19331l();
            na3 m20748R2 = u99.m20748R(s02Var2, m11708d2);
            s02Var2.m19316d0();
            if (s02Var2.f34519S) {
                s02Var2.m19329k(me2Var);
            } else {
                s02Var2.m19336n0();
            }
            z80.m23871N(xm0Var, s02Var2, m19739a);
            z80.m23871N(xm0Var2, s02Var2, m19331l2);
            hn0.m12946s(hashCode2, s02Var2, xm0Var3, s02Var2);
            z80.m23871N(xm0Var4, s02Var2, m20748R2);
            xe5.m22686b(str, vg4.m21468a(ka3Var, 1.0f), uj0Var.f38734B, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, of5.m17192a(sl5Var.f35599n, 0L, di2.m9240O(9, s02Var2), null, null, 0L, null, 0L, null, null, 16777213), s02Var, 6, 0, 131064);
            xe5.m22686b(String.format("%.2f×", Arrays.copyOf(new Object[]{Float.valueOf(f)}, 1)), null, k64Var.f21260a, 0L, lx1.f24981k, null, 0L, null, null, 0L, 0, false, 0, 0, of5.m17192a(sl5Var.f35599n, 0L, di2.m9240O(9, s02Var), null, null, 0L, null, 0L, null, null, 16777213), s02Var, 1572864, 0, 131002);
            s02Var.m19338p(true);
            yt0.m23628u(4, s02Var, 6, ka3Var, s02Var);
            ug4 m19739a2 = sg4.m19739a(c1207jv, o70Var, s02Var, 48);
            int hashCode3 = Long.hashCode(s02Var.f34520T);
            ov3 m19331l3 = s02Var.m19331l();
            na3 m20748R3 = u99.m20748R(s02Var, ka3Var);
            s02Var.m19316d0();
            if (s02Var.f34519S) {
                s02Var.m19329k(me2Var);
            } else {
                s02Var.m19336n0();
            }
            z80.m23871N(xm0Var, s02Var, m19739a2);
            z80.m23871N(xm0Var2, s02Var, m19331l3);
            hn0.m12946s(hashCode3, s02Var, xm0Var3, s02Var);
            z80.m23871N(xm0Var4, s02Var, m20748R3);
            int i3 = i2 & jq5.f20570g;
            boolean z2 = i3 == 2048;
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (z2 || m19298O == sv8Var) {
                m19298O = new C1495r8(zy1Var2, (byte) 9);
                s02Var.m19330k0(m19298O);
            }
            int i4 = ((i2 >> 9) & 896) | 6;
            m11384K("−", (xy1) m19298O, s02Var, i4);
            yt0.m23605B(8, s02Var, 6, ka3Var, s02Var);
            ov9.m17444c(f, zy1Var, null, vg4.m21468a(ka3Var, 1.0f), false, new ni0(0.2f, f2), null, di2.m9238M(4, s02Var, 6), di2.m9238M(6, s02Var, 6), di2.m9238M(16, s02Var, 6), false, 0.0f, 0L, 0L, null, dg2.m9071C(2, 0.5f), k64Var.f21260a, qj0.m18297b(0.1f, k64Var.f21264e), k64Var.f21260a, 0L, 0.0f, null, s02Var, (i2 >> 3) & WebSocketProtocol.PAYLOAD_SHORT, 0, 14810196);
            zy1Var4 = zy1Var;
            s02Var2 = s02Var;
            yt0.m23605B(8, s02Var2, 6, ka3Var, s02Var2);
            boolean z3 = i3 == 2048;
            Object m19298O2 = s02Var2.m19298O();
            if (z3 || m19298O2 == sv8Var) {
                zy1Var3 = zy1Var2;
                m19298O2 = new C1495r8(zy1Var3, (byte) 10);
                s02Var2.m19330k0(m19298O2);
            } else {
                zy1Var3 = zy1Var2;
            }
            magicManagerSettingsFeature = this;
            magicManagerSettingsFeature.m11384K("+", (xy1) m19298O2, s02Var2, i4);
            yt0.m23605B(12, s02Var2, 6, ka3Var, s02Var2);
            as3 m23719B = z21.m23719B(R.drawable.reset_settings, s02Var2, 0);
            long j = uj0Var.f38734B;
            na3 m23273i = y53.m23273i(fy4.m11715k(ka3Var, di2.m9238M(16, s02Var2, 6)), dg2.m9071C(2, 0.4f));
            boolean z4 = (i2 & 896) == 256;
            Object m19298O3 = s02Var2.m19298O();
            if (z4 || m19298O3 == sv8Var) {
                m19298O3 = new C1495r8(zy1Var4, (byte) 11);
                s02Var2.m19330k0(m19298O3);
            }
            kb2.m14510a(m23719B, "Reset", AbstractC0871d6.m8745F(mx0.m16320t(15, (xy1) m19298O3, m23273i, null, false), di2.m9238M(1, s02Var2, 6)), j, s02Var2, 56, 0);
            s02Var2.m19338p(true);
            s02Var2.m19338p(true);
        } else {
            zy1Var3 = zy1Var2;
            magicManagerSettingsFeature = this;
            zy1Var4 = zy1Var;
            s02Var2.m19303U();
        }
        m84 m19342t = s02Var2.m19342t();
        if (m19342t != null) {
            final zy1 zy1Var5 = zy1Var4;
            final zy1 zy1Var6 = zy1Var3;
            final MagicManagerSettingsFeature magicManagerSettingsFeature2 = magicManagerSettingsFeature;
            m19342t.f25420d = new nz1(str, f, zy1Var5, zy1Var6, f2, i) { // from class: qz2

                /* renamed from: b */
                public final /* synthetic */ String f32874b;

                /* renamed from: c */
                public final /* synthetic */ float f32875c;

                /* renamed from: d */
                public final /* synthetic */ zy1 f32876d;

                /* renamed from: e */
                public final /* synthetic */ zy1 f32877e;

                /* renamed from: f */
                public final /* synthetic */ float f32878f;

                @Override // p000.nz1
                public final Object invoke(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int m23255A = y53.m23255A(7);
                    MagicManagerSettingsFeature.this.m11388P(this.f32874b, this.f32875c, this.f32876d, this.f32877e, this.f32878f, (s02) obj, m23255A);
                    return kn5.f22076a;
                }
            };
        }
    }

    /* renamed from: Q */
    public final void m11389Q(String str, float f, String str2, ni0 ni0Var, zy1 zy1Var, zy1 zy1Var2, s02 s02Var, int i) {
        s02 s02Var2;
        zy1 zy1Var3 = zy1Var2;
        s02Var.m19312b0(-1331428215);
        int i2 = i | (s02Var.m19313c(f) ? 32 : 16) | (s02Var.m19319f(str2) ? 256 : 128) | (s02Var.m19319f(ni0Var) ? 2048 : 1024) | (s02Var.m19323h(zy1Var) ? Http2.INITIAL_MAX_FRAME_SIZE : Segment.SIZE) | (s02Var.m19323h(zy1Var3) ? 131072 : 65536) | (s02Var.m19323h(this) ? 1048576 : 524288);
        if (s02Var.m19300R(i2 & 1, (599187 & i2) != 599186)) {
            k64 k64Var = (k64) s02Var.m19327j(rj0.f33758k);
            uj0 uj0Var = (uj0) s02Var.m19327j(wj0.f42164a);
            sl5 sl5Var = (sl5) s02Var.m19327j(ul5.f38880a);
            ka3 ka3Var = ka3.f21426a;
            na3 m11708d = fy4.m11708d(ka3Var, 1.0f);
            ek0 m9307a = dk0.m9307a(AbstractC1443pv.f30967c, mg1.f25871n, s02Var, 0);
            int hashCode = Long.hashCode(s02Var.f34520T);
            ov3 m19331l = s02Var.m19331l();
            na3 m20748R = u99.m20748R(s02Var, m11708d);
            sn0.f35689X8.getClass();
            s02Var.m19316d0();
            boolean z = s02Var.f34519S;
            me2 me2Var = wo2.f42501S;
            if (z) {
                s02Var.m19329k(me2Var);
            } else {
                s02Var.m19336n0();
            }
            xm0 xm0Var = oua.f29409h;
            z80.m23871N(xm0Var, s02Var, m9307a);
            xm0 xm0Var2 = oua.f29408g;
            z80.m23871N(xm0Var2, s02Var, m19331l);
            Integer valueOf = Integer.valueOf(hashCode);
            xm0 xm0Var3 = oua.f29410i;
            z80.m23871N(xm0Var3, s02Var, valueOf);
            z80.m23869L(s02Var);
            xm0 xm0Var4 = oua.f29407f;
            z80.m23871N(xm0Var4, s02Var, m20748R);
            na3 m11708d2 = fy4.m11708d(ka3Var, 1.0f);
            o70 o70Var = mg1.f25869l;
            C1207jv c1207jv = AbstractC1443pv.f30965a;
            ug4 m19739a = sg4.m19739a(c1207jv, o70Var, s02Var, 48);
            int hashCode2 = Long.hashCode(s02Var.f34520T);
            ov3 m19331l2 = s02Var.m19331l();
            na3 m20748R2 = u99.m20748R(s02Var, m11708d2);
            s02Var.m19316d0();
            if (s02Var.f34519S) {
                s02Var.m19329k(me2Var);
            } else {
                s02Var.m19336n0();
            }
            z80.m23871N(xm0Var, s02Var, m19739a);
            z80.m23871N(xm0Var2, s02Var, m19331l2);
            hn0.m12946s(hashCode2, s02Var, xm0Var3, s02Var);
            z80.m23871N(xm0Var4, s02Var, m20748R2);
            xe5.m22686b(str, vg4.m21468a(ka3Var, 1.0f), uj0Var.f38734B, 0L, null, null, 0L, null, null, 0L, 0, false, 0, 0, of5.m17192a(sl5Var.f35599n, 0L, di2.m9240O(9, s02Var), null, null, 0L, null, 0L, null, null, 16777213), s02Var, 6, 0, 131064);
            xe5.m22686b(str2, null, k64Var.f21260a, 0L, lx1.f24981k, null, 0L, null, null, 0L, 0, false, 0, 0, of5.m17192a(sl5Var.f35599n, 0L, di2.m9240O(9, s02Var), null, null, 0L, null, 0L, null, null, 16777213), s02Var, ((i2 >> 6) & 14) | 1572864, 0, 131002);
            s02Var.m19338p(true);
            yt0.m23628u(4, s02Var, 6, ka3Var, s02Var);
            ug4 m19739a2 = sg4.m19739a(c1207jv, o70Var, s02Var, 48);
            int hashCode3 = Long.hashCode(s02Var.f34520T);
            ov3 m19331l3 = s02Var.m19331l();
            na3 m20748R3 = u99.m20748R(s02Var, ka3Var);
            s02Var.m19316d0();
            if (s02Var.f34519S) {
                s02Var.m19329k(me2Var);
            } else {
                s02Var.m19336n0();
            }
            z80.m23871N(xm0Var, s02Var, m19739a2);
            z80.m23871N(xm0Var2, s02Var, m19331l3);
            hn0.m12946s(hashCode3, s02Var, xm0Var3, s02Var);
            z80.m23871N(xm0Var4, s02Var, m20748R3);
            int i3 = i2 & 458752;
            boolean z2 = i3 == 131072;
            Object m19298O = s02Var.m19298O();
            sv8 sv8Var = yn0.f45724a;
            if (z2 || m19298O == sv8Var) {
                m19298O = new C1495r8(zy1Var2, (byte) 7);
                s02Var.m19330k0(m19298O);
            }
            int i4 = ((i2 >> 12) & 896) | 6;
            m11384K("−", (xy1) m19298O, s02Var, i4);
            yt0.m23605B(8, s02Var, 6, ka3Var, s02Var);
            zy1Var3 = zy1Var2;
            ov9.m17444c(f, zy1Var, null, vg4.m21468a(ka3Var, 1.0f), false, ni0Var, null, di2.m9238M(4, s02Var, 6), di2.m9238M(6, s02Var, 6), di2.m9238M(16, s02Var, 6), false, 0.0f, 0L, 0L, null, dg2.m9071C(2, 0.5f), k64Var.f21260a, qj0.m18297b(0.1f, k64Var.f21264e), k64Var.f21260a, 0L, 0.0f, null, s02Var, ((i2 >> 3) & 14) | ((i2 >> 9) & 112) | ((i2 << 6) & 458752), 0, 14810196);
            s02Var2 = s02Var;
            yt0.m23605B(8, s02Var2, 6, ka3Var, s02Var2);
            boolean z3 = i3 == 131072;
            Object m19298O2 = s02Var2.m19298O();
            if (z3 || m19298O2 == sv8Var) {
                m19298O2 = new C1495r8(zy1Var3, (byte) 8);
                s02Var2.m19330k0(m19298O2);
            }
            m11384K("+", (xy1) m19298O2, s02Var2, i4);
            s02Var2.m19338p(true);
            s02Var2.m19338p(true);
        } else {
            s02Var2 = s02Var;
            s02Var2.m19303U();
        }
        m84 m19342t = s02Var2.m19342t();
        if (m19342t != null) {
            m19342t.f25420d = new C1160ir(this, str, f, str2, ni0Var, zy1Var, zy1Var3, i);
        }
    }

    /* renamed from: R */
    public final String m11390R() {
        return (String) this.f14333s.getValue();
    }

    /* renamed from: S */
    public final void m11391S(float f, float f2, boolean z) {
        boolean z2 = z && s32.m19408b();
        SharedPreferences.Editor edit = h53.m12545a().edit();
        edit.getClass();
        edit.putBoolean("smoothing_enabled", z2);
        edit.commit();
        SharedPreferences.Editor edit2 = h53.m12545a().edit();
        edit2.getClass();
        edit2.putFloat("smoothing_min_cutoff", f);
        edit2.commit();
        SharedPreferences.Editor edit3 = h53.m12545a().edit();
        edit3.getClass();
        edit3.putFloat("smoothing_beta", f2);
        edit3.commit();
        au2 m11349q = m11349q();
        r41 r41Var = ka1.f21425a;
        v86.m21284K(m11349q, w31.f41501b, null, new zz2(z2, f, f2, null), 2);
    }

    /* renamed from: T */
    public final void m11392T(boolean z, boolean z2, boolean z3, boolean z4, nz1 nz1Var) {
        boolean z5 = z4 && (z2 && z);
        boolean z6 = z3 || z5 || z5;
        boolean z7 = z6 && h53.m12546b();
        String m11390R = m11390R();
        if (f55.m10718s0(m11390R)) {
            m11390R = Axeron.INSTANCE.currentForegroundPackage();
            if (m11390R == null || m11390R.equals(m11348p().getPackageName())) {
                m11390R = null;
            }
            if (m11390R == null) {
                m11390R = "";
            }
        }
        String str = m11390R;
        m35 m35Var = this.f14334t;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        au2 m11349q = m11349q();
        r41 r41Var = ka1.f21425a;
        this.f14334t = v86.m21284K(m11349q, w31.f41501b, null, new a03(this, z6, z5, z7, str, z3, z5, nz1Var, null), 2);
        if (z6) {
            FeatureFactoryBase mo411k = mo411k(MappingCoordinatorFeature.class);
            MappingCoordinatorFeature mappingCoordinatorFeature = mo411k instanceof MappingCoordinatorFeature ? (MappingCoordinatorFeature) mo411k : null;
            if (mappingCoordinatorFeature != null) {
                mappingCoordinatorFeature.m11428L(str, z3, z5);
            } else {
                u62.m20669L(m11348p(), str, z3, z5);
            }
        } else {
            FeatureFactoryBase mo411k2 = mo411k(MappingCoordinatorFeature.class);
            MappingCoordinatorFeature mappingCoordinatorFeature2 = mo411k2 instanceof MappingCoordinatorFeature ? (MappingCoordinatorFeature) mo411k2 : null;
            if (mappingCoordinatorFeature2 != null) {
                mappingCoordinatorFeature2.m11428L(str, false, false);
            } else {
                u62.m20673j(m11348p(), "ACTION_KILL_FEATURE", MappingCoordinatorFeature.class, null);
            }
        }
        if (z7) {
            Context m11348p = m11348p();
            Bundle bundle = new Bundle();
            bundle.putString("mapping_visual_package", str);
            if (((Boolean) h53.f16760a.getValue()).booleanValue()) {
                u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualFeature.class, null);
                u62.m20673j(m11348p, "ACTION_CALL_FEATURE", MappingVisualLegacyFeature.class, bundle);
            } else {
                u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualLegacyFeature.class, null);
                u62.m20673j(m11348p, "ACTION_CALL_FEATURE", MappingVisualFeature.class, bundle);
            }
        } else {
            Context m11348p2 = m11348p();
            u62.m20673j(m11348p2, "ACTION_KILL_FEATURE", MappingVisualFeature.class, null);
            u62.m20673j(m11348p2, "ACTION_KILL_FEATURE", MappingVisualLegacyFeature.class, null);
        }
        if (!z5) {
            u62.m20673j(m11348p(), "ACTION_KILL_FEATURE", MouseCursorFeature.class, null);
        } else {
            Axeron.INSTANCE.hideSystemCursor();
            u62.m20673j(m11348p(), "ACTION_CALL_FEATURE", MouseCursorFeature.class, null);
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: t */
    public final void mo11333t(Bundle bundle) {
        jc3 jc3Var;
        super.mo11333t(bundle);
        ns0 ns0Var = null;
        String string = bundle != null ? bundle.getString("magic_manager_settings_package") : null;
        if (string == null) {
            string = "";
        }
        this.f14333s.setValue(string);
        Axeron.INSTANCE.refreshInputState();
        v86.m21284K(m11349q(), w31.f41501b, null, new yz2(this, ns0Var, (byte) 0), 2);
        Context m11348p = m11348p();
        u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualFeature.class, null);
        u62.m20673j(m11348p, "ACTION_KILL_FEATURE", MappingVisualLegacyFeature.class, null);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 262952, -3);
        if (m11348p().getResources().getConfiguration().orientation == 1) {
            layoutParams.gravity = 81;
            layoutParams.y = di2.m9248W(18, m11348p());
            layoutParams.windowAnimations = R.style.WAnim_InBottom_OutBottom;
        } else {
            layoutParams.gravity = 19;
            layoutParams.x = di2.m9248W(18, m11348p());
            layoutParams.windowAnimations = R.style.WAnim_InLeft_OutLeft;
        }
        this.f14332r = layoutParams;
        zm5 m11345m = m11345m(false, new gm0(1612592844, true, new C1792yj((Object) this, (byte) 11)));
        this.f14331q = m11345m;
        m11345m.setOnTouchListener(new ViewOnTouchListenerC1541sh(this, (byte) 6));
        zm5 zm5Var = this.f14331q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams2 = this.f14332r;
        if (layoutParams2 == null) {
            ei2.m10039H("params");
            throw null;
        }
        addView(zm5Var, layoutParams2);
        MouseCursorFeature mouseCursorFeature = MouseCursorFeature.f14344x;
        if (mouseCursorFeature == null || (jc3Var = mouseCursorFeature.f14345q) == null || !jc3Var.isAttachedToWindow()) {
            return;
        }
        try {
            jc3 jc3Var2 = mouseCursorFeature.f14345q;
            if (jc3Var2 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            mouseCursorFeature.m11357C(jc3Var2);
            jc3 jc3Var3 = mouseCursorFeature.f14345q;
            if (jc3Var3 == null) {
                ei2.m10039H("cursorView");
                throw null;
            }
            WindowManager.LayoutParams layoutParams3 = mouseCursorFeature.f14346r;
            if (layoutParams3 != null) {
                mouseCursorFeature.addView(jc3Var3, layoutParams3);
            } else {
                ei2.m10039H("params");
                throw null;
            }
        } catch (Exception unused) {
        }
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: u */
    public final void mo11334u() {
        m35 m35Var = this.f14334t;
        if (m35Var != null) {
            m35Var.mo1322a(null);
        }
        zm5 zm5Var = this.f14331q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        m11357C(zm5Var);
        super.mo11334u();
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: v */
    public final void mo11335v(Bundle bundle) {
        String string = bundle.getString("magic_manager_settings_package");
        if (string == null) {
            string = "";
        }
        this.f14333s.setValue(string);
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: w */
    public final void mo11352w() {
        super.mo11352w();
        zm5 zm5Var = this.f14331q;
        if (zm5Var == null) {
            return;
        }
        m11358D(zm5Var, new sz2(this, (byte) 0));
    }

    @Override // frb.axeron.base.FeatureFactoryBase
    /* renamed from: x */
    public final void mo11353x() {
        super.mo11353x();
        if (this.f14331q == null) {
            return;
        }
        Axeron.INSTANCE.refreshInputState();
        v86.m21284K(m11349q(), w31.f41501b, null, new C1532s8(2, null, (byte) 7), 2);
        zm5 zm5Var = this.f14331q;
        if (zm5Var == null) {
            ei2.m10039H("view");
            throw null;
        }
        WindowManager.LayoutParams layoutParams = this.f14332r;
        if (layoutParams != null) {
            m11361H(zm5Var, layoutParams, new sz2(this, (byte) 1));
        } else {
            ei2.m10039H("params");
            throw null;
        }
    }
}
