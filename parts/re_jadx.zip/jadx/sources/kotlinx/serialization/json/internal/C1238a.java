package kotlinx.serialization.json.internal;

import p000.AbstractC0871d6;
import p000.C1281lr;
import p000.C1290m;
import p000.ar4;
import p000.c31;
import p000.d63;
import p000.dl2;
import p000.do0;
import p000.ek2;
import p000.fr4;
import p000.hl9;
import p000.iaa;
import p000.lk2;
import p000.mg1;
import p000.nm2;
import p000.qk2;
import p000.rr8;
import p000.s06;
import p000.tk2;
import p000.u62;
import p000.ur0;
import p000.vk2;
import p000.x45;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: kotlinx.serialization.json.internal.a */
/* loaded from: classes2.dex */
public final class C1238a extends rr8 implements c31, do0 {

    /* renamed from: k */
    public final ek2 f22211k;

    /* renamed from: l */
    public final s06 f22212l;

    /* renamed from: m */
    public final C1281lr f22213m;

    /* renamed from: n */
    public final ur0 f22214n;

    /* renamed from: o */
    public int f22215o;

    /* renamed from: p */
    public final lk2 f22216p;

    /* renamed from: q */
    public final vk2 f22217q;

    public C1238a(ek2 ek2Var, s06 s06Var, C1281lr c1281lr, ar4 ar4Var) {
        ar4Var.getClass();
        this.f22211k = ek2Var;
        this.f22212l = s06Var;
        this.f22213m = c1281lr;
        this.f22214n = ek2Var.f11967b;
        this.f22215o = -1;
        lk2 lk2Var = ek2Var.f11966a;
        this.f22216p = lk2Var;
        this.f22217q = lk2Var.f24305c ? null : new vk2(ar4Var);
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: A */
    public final byte mo2171A() {
        C1281lr c1281lr = this.f22213m;
        long m15407i = c1281lr.m15407i();
        byte b = (byte) m15407i;
        if (m15407i == b) {
            return b;
        }
        C1281lr.m15387n(c1281lr, "Failed to parse byte for input '" + m15407i + '\'', 0, null, 6);
        throw null;
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: B */
    public final short mo2172B() {
        C1281lr c1281lr = this.f22213m;
        long m15407i = c1281lr.m15407i();
        short s = (short) m15407i;
        if (m15407i == s) {
            return s;
        }
        C1281lr.m15387n(c1281lr, "Failed to parse short for input '" + m15407i + '\'', 0, null, 6);
        throw null;
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: C */
    public final float mo2173C() {
        C1281lr c1281lr = this.f22213m;
        String m15409k = c1281lr.m15409k();
        try {
            float parseFloat = Float.parseFloat(m15409k);
            if (Math.abs(parseFloat) <= Float.MAX_VALUE) {
                return parseFloat;
            }
            C1281lr.m15387n(c1281lr, AbstractC0871d6.m8743B(Float.valueOf(parseFloat), null), 0, "It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'", 2);
            throw null;
        } catch (IllegalArgumentException unused) {
            C1281lr.m15387n(c1281lr, d63.m8801h('\'', "Failed to parse type 'float' for input '", m15409k), 0, null, 6);
            throw null;
        }
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: E */
    public final double mo2174E() {
        C1281lr c1281lr = this.f22213m;
        String m15409k = c1281lr.m15409k();
        try {
            double parseDouble = Double.parseDouble(m15409k);
            if (Math.abs(parseDouble) <= Double.MAX_VALUE) {
                return parseDouble;
            }
            C1281lr.m15387n(c1281lr, AbstractC0871d6.m8743B(Double.valueOf(parseDouble), null), 0, "It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'", 2);
            throw null;
        } catch (IllegalArgumentException unused) {
            C1281lr.m15387n(c1281lr, d63.m8801h('\'', "Failed to parse type 'double' for input '", m15409k), 0, null, 6);
            throw null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:48:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x012e  */
    @Override // p000.c31
    /* renamed from: a */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object mo2175a(p000.nm2 r11) {
        /*
            Method dump skipped, instructions count: 340
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.serialization.json.internal.C1238a.mo2175a(nm2):java.lang.Object");
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: c */
    public final boolean mo2176c() {
        boolean z;
        boolean z2;
        C1281lr c1281lr = this.f22213m;
        int m15391D = c1281lr.m15391D();
        String str = (String) c1281lr.f24671g;
        if (m15391D == str.length()) {
            C1281lr.m15387n(c1281lr, "EOF", 0, null, 6);
            throw null;
        }
        if (str.charAt(m15391D) == '\"') {
            m15391D++;
            z = true;
        } else {
            z = false;
        }
        int m15422y = c1281lr.m15422y(m15391D);
        if (m15422y >= str.length() || m15422y == -1) {
            C1281lr.m15387n(c1281lr, "EOF", 0, null, 6);
            throw null;
        }
        int i = m15422y + 1;
        int charAt = str.charAt(m15422y) | ' ';
        if (charAt == 102) {
            c1281lr.m15402d(i, "alse");
            z2 = false;
        } else {
            if (charAt != 116) {
                C1281lr.m15387n(c1281lr, "Expected valid boolean literal prefix, but had '" + c1281lr.m15409k() + '\'', 0, null, 6);
                throw null;
            }
            c1281lr.m15402d(i, "rue");
            z2 = true;
        }
        if (!z) {
            return z2;
        }
        if (c1281lr.f24666b == str.length()) {
            C1281lr.m15387n(c1281lr, "EOF", 0, null, 6);
            throw null;
        }
        if (str.charAt(c1281lr.f24666b) == '\"') {
            c1281lr.f24666b++;
            return z2;
        }
        C1281lr.m15387n(c1281lr, "Expected closing quotation mark", 0, null, 6);
        throw null;
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: d */
    public final char mo2177d() {
        C1281lr c1281lr = this.f22213m;
        String m15409k = c1281lr.m15409k();
        if (m15409k.length() == 1) {
            return m15409k.charAt(0);
        }
        C1281lr.m15387n(c1281lr, d63.m8801h('\'', "Expected single char, but got '", m15409k), 0, null, 6);
        throw null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:134:0x011d, code lost:
    
        r0 = r15.f40577a;
     */
    /* JADX WARN: Code restructure failed: missing block: B:135:0x0121, code lost:
    
        if (r7 >= 64) goto L85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:136:0x0123, code lost:
    
        r0.f31858a |= 1 << r7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:137:0x012d, code lost:
    
        r1 = (r7 >>> 6) - 1;
        r0 = (long[]) r0.f31861d;
        r0[r1] = r0[r1] | (1 << (r7 & 63));
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r14v1, types: [java.lang.String, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r14v2, types: [java.lang.String, java.lang.Throwable] */
    @Override // p000.do0
    /* renamed from: f */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final int mo9387f(p000.ar4 r23) {
        /*
            Method dump skipped, instructions count: 676
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.serialization.json.internal.C1238a.mo9387f(ar4):int");
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: k */
    public final int mo2178k() {
        C1281lr c1281lr = this.f22213m;
        long m15407i = c1281lr.m15407i();
        int i = (int) m15407i;
        if (m15407i == i) {
            return i;
        }
        C1281lr.m15387n(c1281lr, "Failed to parse int for input '" + m15407i + '\'', 0, null, 6);
        throw null;
    }

    @Override // p000.rr8, p000.do0
    /* renamed from: m */
    public final void mo9393m(ar4 ar4Var) {
        ar4Var.getClass();
        if (ar4Var.mo1100e() == 0 && dl2.m9320b(this.f22211k, ar4Var)) {
            while (mo9387f(ar4Var) != -1) {
            }
        }
        C1281lr c1281lr = this.f22213m;
        if (c1281lr.m15392E()) {
            AbstractC0871d6.m8788x(c1281lr, "");
            throw null;
        }
        c1281lr.m15406h(this.f22212l.f34572b);
        iaa iaaVar = (iaa) c1281lr.f24668d;
        int i = iaaVar.f18383b;
        int[] iArr = (int[]) iaaVar.f18386e;
        if (iArr[i] == -2) {
            iArr[i] = -1;
            i--;
            iaaVar.f18383b = i;
        }
        if (i != -1) {
            iaaVar.f18383b = i - 1;
        }
    }

    @Override // p000.do0
    /* renamed from: o */
    public final ur0 mo9394o() {
        return this.f22214n;
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: p */
    public final c31 mo2179p(ar4 ar4Var) {
        ar4Var.getClass();
        return x45.m22514a(ar4Var) ? new qk2(this.f22213m, this.f22211k) : this;
    }

    @Override // p000.rr8, p000.do0
    /* renamed from: q */
    public final Object mo9395q(ar4 ar4Var, int i, nm2 nm2Var, Object obj) {
        iaa iaaVar = (iaa) this.f22213m.f24668d;
        ar4Var.getClass();
        nm2Var.getClass();
        boolean z = this.f22212l == s06.f34567e && (i & 1) == 0;
        if (z) {
            int[] iArr = (int[]) iaaVar.f18386e;
            int i2 = iaaVar.f18383b;
            if (iArr[i2] == -2) {
                ((Object[]) iaaVar.f18385d)[i2] = u62.f38288q;
            }
        }
        nm2Var.getClass();
        Object mo2175a = mo2175a(nm2Var);
        if (z) {
            int[] iArr2 = (int[]) iaaVar.f18386e;
            int i3 = iaaVar.f18383b;
            if (iArr2[i3] != -2) {
                int i4 = i3 + 1;
                iaaVar.f18383b = i4;
                if (i4 == ((Object[]) iaaVar.f18385d).length) {
                    iaaVar.m13220b();
                }
            }
            Object[] objArr = (Object[]) iaaVar.f18385d;
            int i5 = iaaVar.f18383b;
            objArr[i5] = ((lk2) iaaVar.f18384c).f24311i ? mo2175a : mg1.f25838A;
            ((int[]) iaaVar.f18386e)[i5] = -2;
        }
        return mo2175a;
    }

    /* renamed from: q0 */
    public final tk2 m14843q0() {
        lk2 lk2Var = this.f22211k.f11966a;
        C1290m c1290m = new C1290m();
        c1290m.f25120c = this.f22213m;
        c1290m.f25118a = lk2Var.f24304b;
        return c1290m.m15637d();
    }

    /* renamed from: r0 */
    public final ek2 m14844r0() {
        return this.f22211k;
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: s */
    public final String mo2180s() {
        boolean z = this.f22216p.f24304b;
        C1281lr c1281lr = this.f22213m;
        return z ? c1281lr.m15410l() : c1281lr.m15408j();
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: t */
    public final do0 mo2181t(ar4 ar4Var) {
        ar4Var.getClass();
        ek2 ek2Var = this.f22211k;
        s06 m12887R = hl9.m12887R(ek2Var, ar4Var);
        C1281lr c1281lr = this.f22213m;
        iaa iaaVar = (iaa) c1281lr.f24668d;
        int i = iaaVar.f18383b + 1;
        iaaVar.f18383b = i;
        if (i == ((Object[]) iaaVar.f18385d).length) {
            iaaVar.m13220b();
        }
        ((Object[]) iaaVar.f18385d)[i] = ar4Var;
        c1281lr.m15406h(m12887R.f34571a);
        if (c1281lr.m15420w() != 4) {
            int ordinal = m12887R.ordinal();
            return (ordinal == 1 || ordinal == 2 || ordinal == 3) ? new C1238a(ek2Var, m12887R, c1281lr, ar4Var) : (this.f22212l == m12887R && ek2Var.f11966a.f24305c) ? this : new C1238a(ek2Var, m12887R, c1281lr, ar4Var);
        }
        C1281lr.m15387n(c1281lr, "Unexpected leading comma", 0, null, 6);
        throw null;
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: u */
    public final int mo2182u(ar4 ar4Var) {
        ar4Var.getClass();
        String mo2180s = mo2180s();
        String concat = " at path ".concat(((iaa) this.f22213m.f24668d).m13219a());
        mo2180s.getClass();
        int m9319a = dl2.m9319a(ar4Var, this.f22211k, mo2180s);
        if (m9319a != -3) {
            return m9319a;
        }
        throw new fr4(ar4Var.mo1097a() + " does not contain element with name '" + mo2180s + '\'' + concat);
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: v */
    public final long mo2183v() {
        return this.f22213m.m15407i();
    }

    @Override // p000.rr8, p000.c31
    /* renamed from: w */
    public final boolean mo2184w() {
        vk2 vk2Var = this.f22217q;
        return ((vk2Var != null ? vk2Var.f40578b : false) || this.f22213m.m15393F(true)) ? false : true;
    }
}
