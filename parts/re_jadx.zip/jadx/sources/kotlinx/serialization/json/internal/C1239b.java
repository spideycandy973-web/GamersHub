package kotlinx.serialization.json.internal;

import p000.AbstractC0871d6;
import p000.ao0;
import p000.ar4;
import p000.bo0;
import p000.dl2;
import p000.ek2;
import p000.hl0;
import p000.hl9;
import p000.i14;
import p000.kc3;
import p000.lk2;
import p000.nm2;
import p000.rk2;
import p000.s06;
import p000.uk2;
import p000.ur0;
import p000.x45;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: kotlinx.serialization.json.internal.b */
/* loaded from: classes2.dex */
public final class C1239b {

    /* renamed from: a */
    public final kc3 f22218a;

    /* renamed from: b */
    public final ek2 f22219b;

    /* renamed from: c */
    public final s06 f22220c;

    /* renamed from: d */
    public final C1239b[] f22221d;

    /* renamed from: e */
    public final ur0 f22222e;

    /* renamed from: f */
    public final lk2 f22223f;

    /* renamed from: g */
    public boolean f22224g;

    /* renamed from: h */
    public String f22225h;

    /* renamed from: i */
    public String f22226i;

    public C1239b(kc3 kc3Var, ek2 ek2Var, s06 s06Var, C1239b[] c1239bArr) {
        this.f22218a = kc3Var;
        this.f22219b = ek2Var;
        this.f22220c = s06Var;
        this.f22221d = c1239bArr;
        this.f22222e = ek2Var.f11967b;
        this.f22223f = ek2Var.f11966a;
        int ordinal = s06Var.ordinal();
        if (c1239bArr != null) {
            C1239b c1239b = c1239bArr[ordinal];
            if (c1239b == null && c1239b == this) {
                return;
            }
            c1239bArr[ordinal] = this;
        }
    }

    /* renamed from: a */
    public final C1239b m14845a(ar4 ar4Var) {
        C1239b c1239b;
        ar4Var.getClass();
        ek2 ek2Var = this.f22219b;
        s06 m12887R = hl9.m12887R(ek2Var, ar4Var);
        char c = m12887R.f34571a;
        kc3 kc3Var = this.f22218a;
        kc3Var.m14528i(c);
        kc3Var.f21475b = true;
        String str = this.f22225h;
        if (str != null) {
            String str2 = this.f22226i;
            if (str2 == null) {
                str2 = ar4Var.mo1097a();
            }
            kc3Var.m14527f();
            kc3Var.mo959n(str);
            kc3Var.m14528i(':');
            m14863s(str2);
            this.f22225h = null;
            this.f22226i = null;
        }
        if (this.f22220c == m12887R) {
            return this;
        }
        C1239b[] c1239bArr = this.f22221d;
        return (c1239bArr == null || (c1239b = c1239bArr[m12887R.ordinal()]) == null) ? new C1239b(kc3Var, ek2Var, m12887R, c1239bArr) : c1239b;
    }

    /* renamed from: b */
    public final void m14846b(boolean z) {
        if (this.f22224g) {
            m14863s(String.valueOf(z));
        } else {
            ((hl0) this.f22218a.f21476c).m12811o(String.valueOf(z));
        }
    }

    /* renamed from: c */
    public final void m14847c(byte b) {
        if (this.f22224g) {
            m14863s(String.valueOf((int) b));
        } else {
            this.f22218a.mo1869h(b);
        }
    }

    /* renamed from: d */
    public final void m14848d(char c) {
        m14863s(String.valueOf(c));
    }

    /* renamed from: e */
    public final void m14849e(double d) {
        if (this.f22224g) {
            m14863s(String.valueOf(d));
        } else {
            ((hl0) this.f22218a.f21476c).m12811o(String.valueOf(d));
        }
        if (Math.abs(d) > Double.MAX_VALUE) {
            throw new rk2(AbstractC0871d6.m8743B(Double.valueOf(d), null), "It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'");
        }
    }

    /* renamed from: f */
    public final void m14850f(ar4 ar4Var, int i) {
        ar4Var.getClass();
        int ordinal = this.f22220c.ordinal();
        kc3 kc3Var = this.f22218a;
        boolean z = true;
        if (ordinal == 1) {
            if (!kc3Var.f21475b) {
                kc3Var.m14528i(',');
            }
            kc3Var.m14527f();
            return;
        }
        if (ordinal == 2) {
            if (kc3Var.f21475b) {
                this.f22224g = true;
                kc3Var.m14527f();
                return;
            }
            if (i % 2 == 0) {
                kc3Var.m14528i(',');
                kc3Var.m14527f();
            } else {
                kc3Var.m14528i(':');
                kc3Var.m14530p();
                z = false;
            }
            this.f22224g = z;
            return;
        }
        if (ordinal != 3) {
            if (!kc3Var.f21475b) {
                kc3Var.m14528i(',');
            }
            kc3Var.m14527f();
            dl2.m9321c(this.f22219b, ar4Var);
            m14863s(ar4Var.mo1101f(i));
            kc3Var.m14528i(':');
            kc3Var.m14530p();
            return;
        }
        if (i == 0) {
            this.f22224g = true;
        }
        if (i == 1) {
            kc3Var.m14528i(',');
            kc3Var.m14530p();
            this.f22224g = false;
        }
    }

    /* renamed from: g */
    public final void m14851g(float f) {
        if (this.f22224g) {
            m14863s(String.valueOf(f));
        } else {
            ((hl0) this.f22218a.f21476c).m12811o(String.valueOf(f));
        }
        if (Math.abs(f) > Float.MAX_VALUE) {
            throw new rk2(AbstractC0871d6.m8743B(Float.valueOf(f), null), "It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'");
        }
    }

    /* renamed from: h */
    public final C1239b m14852h(ar4 ar4Var) {
        kc3 kc3Var = this.f22218a;
        hl0 hl0Var = (hl0) kc3Var.f21476c;
        ar4Var.getClass();
        boolean m22514a = x45.m22514a(ar4Var);
        s06 s06Var = this.f22220c;
        ek2 ek2Var = this.f22219b;
        if (m22514a) {
            if (!(kc3Var instanceof bo0)) {
                kc3Var = new bo0(hl0Var, this.f22224g);
            }
            return new C1239b(kc3Var, ek2Var, s06Var, null);
        }
        if (ar4Var.isInline() && ar4Var.equals(uk2.f38841a)) {
            if (!(kc3Var instanceof ao0)) {
                kc3Var = new ao0(hl0Var, this.f22224g);
            }
            return new C1239b(kc3Var, ek2Var, s06Var, null);
        }
        if (this.f22225h != null) {
            this.f22226i = ar4Var.mo1097a();
        }
        return this;
    }

    /* renamed from: i */
    public final C1239b m14853i(i14 i14Var, int i) {
        m14850f(i14Var, i);
        return m14852h(i14Var.mo1103h(i));
    }

    /* renamed from: j */
    public final void m14854j(int i) {
        if (this.f22224g) {
            m14863s(String.valueOf(i));
        } else {
            this.f22218a.mo1870j(i);
        }
    }

    /* renamed from: k */
    public final void m14855k(int i, int i2, ar4 ar4Var) {
        ar4Var.getClass();
        m14850f(ar4Var, i);
        m14854j(i2);
    }

    /* renamed from: l */
    public final void m14856l(long j) {
        if (this.f22224g) {
            m14863s(String.valueOf(j));
        } else {
            this.f22218a.mo1871k(j);
        }
    }

    /* renamed from: m */
    public final void m14857m(ar4 ar4Var, int i, long j) {
        ar4Var.getClass();
        m14850f(ar4Var, i);
        m14856l(j);
    }

    /* renamed from: n */
    public final void m14858n() {
        ((hl0) this.f22218a.f21476c).m12811o("null");
    }

    /* renamed from: o */
    public final void m14859o(ar4 ar4Var, int i, nm2 nm2Var, Object obj) {
        ar4Var.getClass();
        nm2Var.getClass();
        if (obj != null || this.f22223f.f24305c) {
            ar4Var.getClass();
            nm2Var.getClass();
            m14850f(ar4Var, i);
            if (nm2Var.mo282d().mo1098c()) {
                m14861q(nm2Var, obj);
            } else if (obj == null) {
                m14858n();
            } else {
                m14861q(nm2Var, obj);
            }
        }
    }

    /* renamed from: p */
    public final void m14860p(ar4 ar4Var, int i, nm2 nm2Var, Object obj) {
        ar4Var.getClass();
        nm2Var.getClass();
        m14850f(ar4Var, i);
        m14861q(nm2Var, obj);
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x0010, code lost:
    
        if (r3 != p000.rh0.f33694a) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x0039, code lost:
    
        if (p000.ei2.m10070i(r3, p000.p55.f29892y) == false) goto L20;
     */
    /* renamed from: q */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void m14861q(p000.nm2 r7, java.lang.Object r8) {
        /*
            r6 = this;
            r7.getClass()
            ek2 r0 = r6.f22219b
            lk2 r1 = r0.f11966a
            boolean r2 = r7 instanceof p000.ly3
            rh0 r3 = r1.f24310h
            r4 = 0
            if (r2 == 0) goto L13
            rh0 r5 = p000.rh0.f33694a
            if (r3 == r5) goto L44
            goto L3b
        L13:
            int r3 = r3.ordinal()
            if (r3 == 0) goto L44
            r5 = 1
            if (r3 == r5) goto L23
            r5 = 2
            if (r3 == r5) goto L44
            p000.vy1.m21774a()
            return
        L23:
            ar4 r3 = r7.mo282d()
            lx6 r3 = r3.getKind()
            p55 r5 = p000.p55.f29889v
            boolean r5 = p000.ei2.m10070i(r3, r5)
            if (r5 != 0) goto L3b
            p55 r5 = p000.p55.f29892y
            boolean r3 = p000.ei2.m10070i(r3, r5)
            if (r3 == 0) goto L44
        L3b:
            ar4 r3 = r7.mo282d()
            java.lang.String r3 = p000.lx6.m15586g(r0, r3)
            goto L45
        L44:
            r3 = r4
        L45:
            if (r2 == 0) goto L5b
            ly3 r7 = (p000.ly3) r7
            if (r8 != 0) goto L57
            ar4 r6 = r7.mo282d()
            java.lang.String r7 = " should always be non-null. Please report issue to the kotlinx.serialization tracker."
            java.lang.String r8 = "Value for serializer "
            p000.j54.m13782x(r8, r6, r7)
            return
        L57:
            p000.g55.m11868q(r7, r6, r8)
            throw r4
        L5b:
            if (r3 == 0) goto Le6
            ar4 r2 = r7.mo282d()
            r2.getClass()
            p000.dl2.m9321c(r0, r2)
            java.util.Set r0 = p000.di2.m9283s(r2)
            boolean r0 = r0.contains(r3)
            if (r0 == 0) goto Lb0
            ar4 r6 = r7.mo282d()
            java.lang.String r6 = r6.mo1097a()
            ar4 r7 = r7.mo282d()
            java.lang.String r7 = r7.mo1097a()
            rh0 r8 = r1.f24310h
            rh0 r0 = p000.rh0.f33695b
            if (r8 != r0) goto L90
            boolean r8 = p000.ei2.m10070i(r6, r7)
            if (r8 == 0) goto L90
            java.lang.String r6 = "in ALL_JSON_OBJECTS class discriminator mode"
            goto L98
        L90:
            java.lang.String r8 = "as base class '"
            r0 = 39
            java.lang.String r6 = p000.d63.m8801h(r0, r8, r6)
        L98:
            java.lang.String r8 = "' cannot be serialized "
            java.lang.String r0 = " because it has property name that conflicts with JSON class discriminator '"
            java.lang.String r1 = "Class '"
            java.lang.StringBuilder r6 = p000.hn0.m12943p(r1, r7, r8, r6, r0)
            java.lang.String r7 = "'."
            java.lang.String r6 = p000.hn0.m12937j(r3, r7, r6)
            rk2 r7 = new rk2
            java.lang.String r8 = "You can either change class discriminator in JsonConfiguration, or rename property with @SerialName annotation."
            r7.<init>(r6, r8)
            throw r7
        Lb0:
            ar4 r0 = r7.mo282d()
            lx6 r0 = r0.getKind()
            r0.getClass()
            boolean r1 = r0 instanceof p000.er4
            if (r1 != 0) goto Le0
            boolean r1 = r0 instanceof p000.k14
            if (r1 != 0) goto Lda
            boolean r0 = r0 instanceof p000.ky3
            if (r0 != 0) goto Ld4
            ar4 r0 = r7.mo282d()
            java.lang.String r0 = r0.mo1097a()
            r6.f22225h = r3
            r6.f22226i = r0
            goto Le6
        Ld4:
            java.lang.String r6 = "Actual serializer for polymorphic cannot be polymorphic itself"
            p000.C0950f.m10585p(r6)
            return
        Lda:
            java.lang.String r6 = "Primitives cannot be serialized polymorphically with 'type' parameter. You can use 'JsonBuilder.useArrayPolymorphism' instead"
            p000.C0950f.m10585p(r6)
            return
        Le0:
            java.lang.String r6 = "Enums cannot be serialized polymorphically with 'type' parameter. You can use 'JsonBuilder.useArrayPolymorphism' instead"
            p000.C0950f.m10585p(r6)
            return
        Le6:
            r7.mo279a(r6, r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlinx.serialization.json.internal.C1239b.m14861q(nm2, java.lang.Object):void");
    }

    /* renamed from: r */
    public final void m14862r(short s) {
        if (this.f22224g) {
            m14863s(String.valueOf((int) s));
        } else {
            this.f22218a.mo1872l(s);
        }
    }

    /* renamed from: s */
    public final void m14863s(String str) {
        str.getClass();
        this.f22218a.mo959n(str);
    }

    /* renamed from: t */
    public final void m14864t(ar4 ar4Var, int i, String str) {
        ar4Var.getClass();
        str.getClass();
        m14850f(ar4Var, i);
        m14863s(str);
    }

    /* renamed from: u */
    public final void m14865u(ar4 ar4Var) {
        ar4Var.getClass();
        kc3 kc3Var = this.f22218a;
        kc3Var.f21475b = false;
        kc3Var.m14528i(this.f22220c.f34572b);
    }

    /* renamed from: v */
    public final boolean m14866v(ar4 ar4Var) {
        ar4Var.getClass();
        return false;
    }
}
