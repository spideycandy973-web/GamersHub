package gatewayprotocol.p013v1;

import com.google.protobuf.MapEntryLite;
import com.google.protobuf.WireFormat;
import gatewayprotocol.p013v1.InitializationResponseOuterClass;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: gatewayprotocol.v1.i0 */
/* loaded from: classes2.dex */
public abstract class AbstractC1027i0 {

    /* renamed from: a */
    public static final MapEntryLite f15523a = MapEntryLite.newDefaultInstance(WireFormat.FieldType.STRING, "", WireFormat.FieldType.MESSAGE, InitializationResponseOuterClass.Placement.getDefaultInstance());
}
