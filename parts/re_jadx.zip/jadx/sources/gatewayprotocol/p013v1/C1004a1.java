package gatewayprotocol.p013v1;

import com.google.protobuf.Internal;
import gatewayprotocol.p013v1.OperativeEventRequestOuterClass;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: gatewayprotocol.v1.a1 */
/* loaded from: classes2.dex */
public final class C1004a1 implements Internal.EnumVerifier {

    /* renamed from: a */
    public static final C1004a1 f15510a = new C1004a1();

    @Override // com.google.protobuf.Internal.EnumVerifier
    public final boolean isInRange(int i) {
        return OperativeEventRequestOuterClass.OperativeEventErrorType.forNumber(i) != null;
    }
}
