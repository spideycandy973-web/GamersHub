package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.CampaignMetadataKt;
import gatewayprotocol.p013v1.CampaignMetadataOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class CampaignMetadataKtKt {
    /* renamed from: -initializecampaignMetadata, reason: not valid java name */
    public static final CampaignMetadataOuterClass.CampaignMetadata m24714initializecampaignMetadata(zy1 zy1Var) {
        zy1Var.getClass();
        CampaignMetadataKt.Dsl.Companion companion = CampaignMetadataKt.Dsl.Companion;
        CampaignMetadataOuterClass.CampaignMetadata.Builder newBuilder = CampaignMetadataOuterClass.CampaignMetadata.newBuilder();
        newBuilder.getClass();
        CampaignMetadataKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final CampaignMetadataOuterClass.CampaignMetadata copy(CampaignMetadataOuterClass.CampaignMetadata campaignMetadata, zy1 zy1Var) {
        campaignMetadata.getClass();
        zy1Var.getClass();
        CampaignMetadataKt.Dsl.Companion companion = CampaignMetadataKt.Dsl.Companion;
        CampaignMetadataOuterClass.CampaignMetadata.Builder builder = campaignMetadata.toBuilder();
        builder.getClass();
        CampaignMetadataKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
