package gatewayprotocol.p013v1;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import p000.C0950f;
import p000.ua3;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ModuleOuterClass {

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface ModuleOrBuilder extends MessageLiteOrBuilder {
        ByteString getConfig();

        String getName();

        ByteString getNameBytes();
    }

    private ModuleOuterClass() {
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class Module extends GeneratedMessageLite<Module, Builder> implements ModuleOrBuilder {
        public static final int CONFIG_FIELD_NUMBER = 2;
        private static final Module DEFAULT_INSTANCE;
        public static final int NAME_FIELD_NUMBER = 1;
        private static volatile Parser<Module> PARSER;
        private String name_ = "";
        private ByteString config_ = ByteString.EMPTY;

        static {
            Module module = new Module();
            DEFAULT_INSTANCE = module;
            GeneratedMessageLite.registerDefaultInstance(Module.class, module);
        }

        private Module() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearConfig() {
            this.config_ = getDefaultInstance().getConfig();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        public static Module getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static Module parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (Module) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Module parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Module> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setConfig(ByteString byteString) {
            byteString.getClass();
            this.config_ = byteString;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.toStringUtf8();
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = ua3.f38458a[methodToInvoke.ordinal()];
            ua3 ua3Var = null;
            switch (i) {
                case 1:
                    return new Module();
                case 2:
                    return new Builder(ua3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\n", new Object[]{"name_", "config_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Module> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (Module.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.ModuleOuterClass.ModuleOrBuilder
        public ByteString getConfig() {
            return this.config_;
        }

        @Override // gatewayprotocol.v1.ModuleOuterClass.ModuleOrBuilder
        public String getName() {
            return this.name_;
        }

        @Override // gatewayprotocol.v1.ModuleOuterClass.ModuleOrBuilder
        public ByteString getNameBytes() {
            return ByteString.copyFromUtf8(this.name_);
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<Module, Builder> implements ModuleOrBuilder {
            private Builder() {
                super(Module.DEFAULT_INSTANCE);
            }

            public Builder clearConfig() {
                copyOnWrite();
                ((Module) this.instance).clearConfig();
                return this;
            }

            public Builder clearName() {
                copyOnWrite();
                ((Module) this.instance).clearName();
                return this;
            }

            @Override // gatewayprotocol.v1.ModuleOuterClass.ModuleOrBuilder
            public ByteString getConfig() {
                return ((Module) this.instance).getConfig();
            }

            @Override // gatewayprotocol.v1.ModuleOuterClass.ModuleOrBuilder
            public String getName() {
                return ((Module) this.instance).getName();
            }

            @Override // gatewayprotocol.v1.ModuleOuterClass.ModuleOrBuilder
            public ByteString getNameBytes() {
                return ((Module) this.instance).getNameBytes();
            }

            public Builder setConfig(ByteString byteString) {
                copyOnWrite();
                ((Module) this.instance).setConfig(byteString);
                return this;
            }

            public Builder setName(String str) {
                copyOnWrite();
                ((Module) this.instance).setName(str);
                return this;
            }

            public Builder setNameBytes(ByteString byteString) {
                copyOnWrite();
                ((Module) this.instance).setNameBytes(byteString);
                return this;
            }

            public /* synthetic */ Builder(ua3 ua3Var) {
                this();
            }
        }

        public static Builder newBuilder(Module module) {
            return DEFAULT_INSTANCE.createBuilder(module);
        }

        public static Module parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (Module) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Module parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Module parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static Module parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Module parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Module parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Module parseFrom(InputStream inputStream) throws IOException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Module parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Module parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Module parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (Module) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }
}
