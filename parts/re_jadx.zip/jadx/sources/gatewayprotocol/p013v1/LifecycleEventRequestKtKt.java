package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.DynamicDeviceInfoOuterClass;
import gatewayprotocol.p013v1.LifecycleEventRequestKt;
import gatewayprotocol.p013v1.LifecycleEventRequestOuterClass;
import gatewayprotocol.p013v1.StaticDeviceInfoOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class LifecycleEventRequestKtKt {
    /* renamed from: -initializelifecycleEventRequest, reason: not valid java name */
    public static final LifecycleEventRequestOuterClass.LifecycleEventRequest m24739initializelifecycleEventRequest(zy1 zy1Var) {
        zy1Var.getClass();
        LifecycleEventRequestKt.Dsl.Companion companion = LifecycleEventRequestKt.Dsl.Companion;
        LifecycleEventRequestOuterClass.LifecycleEventRequest.Builder newBuilder = LifecycleEventRequestOuterClass.LifecycleEventRequest.newBuilder();
        newBuilder.getClass();
        LifecycleEventRequestKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final LifecycleEventRequestOuterClass.LifecycleEventRequest copy(LifecycleEventRequestOuterClass.LifecycleEventRequest lifecycleEventRequest, zy1 zy1Var) {
        lifecycleEventRequest.getClass();
        zy1Var.getClass();
        LifecycleEventRequestKt.Dsl.Companion companion = LifecycleEventRequestKt.Dsl.Companion;
        LifecycleEventRequestOuterClass.LifecycleEventRequest.Builder builder = lifecycleEventRequest.toBuilder();
        builder.getClass();
        LifecycleEventRequestKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final DynamicDeviceInfoOuterClass.DynamicDeviceInfo getDynamicDeviceInfoOrNull(LifecycleEventRequestOuterClass.LifecycleEventRequestOrBuilder lifecycleEventRequestOrBuilder) {
        lifecycleEventRequestOrBuilder.getClass();
        if (lifecycleEventRequestOrBuilder.hasDynamicDeviceInfo()) {
            return lifecycleEventRequestOrBuilder.getDynamicDeviceInfo();
        }
        return null;
    }

    public static final StaticDeviceInfoOuterClass.StaticDeviceInfo getStaticDeviceInfoOrNull(LifecycleEventRequestOuterClass.LifecycleEventRequestOrBuilder lifecycleEventRequestOrBuilder) {
        lifecycleEventRequestOrBuilder.getClass();
        if (lifecycleEventRequestOrBuilder.hasStaticDeviceInfo()) {
            return lifecycleEventRequestOrBuilder.getStaticDeviceInfo();
        }
        return null;
    }
}
