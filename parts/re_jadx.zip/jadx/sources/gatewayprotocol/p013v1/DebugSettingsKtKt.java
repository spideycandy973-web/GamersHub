package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.DebugSettingsKt;
import gatewayprotocol.p013v1.NativeConfigurationOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class DebugSettingsKtKt {
    /* renamed from: -initializedebugSettings, reason: not valid java name */
    public static final NativeConfigurationOuterClass.DebugSettings m24717initializedebugSettings(zy1 zy1Var) {
        zy1Var.getClass();
        DebugSettingsKt.Dsl.Companion companion = DebugSettingsKt.Dsl.Companion;
        NativeConfigurationOuterClass.DebugSettings.Builder newBuilder = NativeConfigurationOuterClass.DebugSettings.newBuilder();
        newBuilder.getClass();
        DebugSettingsKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final NativeConfigurationOuterClass.DebugSettings copy(NativeConfigurationOuterClass.DebugSettings debugSettings, zy1 zy1Var) {
        debugSettings.getClass();
        zy1Var.getClass();
        DebugSettingsKt.Dsl.Companion companion = DebugSettingsKt.Dsl.Companion;
        NativeConfigurationOuterClass.DebugSettings.Builder builder = debugSettings.toBuilder();
        builder.getClass();
        DebugSettingsKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
