package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.PrivacyUpdateRequestKt;
import gatewayprotocol.p013v1.PrivacyUpdateRequestOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class PrivacyUpdateRequestKtKt {
    /* renamed from: -initializeprivacyUpdateRequest, reason: not valid java name */
    public static final PrivacyUpdateRequestOuterClass.PrivacyUpdateRequest m24753initializeprivacyUpdateRequest(zy1 zy1Var) {
        zy1Var.getClass();
        PrivacyUpdateRequestKt.Dsl.Companion companion = PrivacyUpdateRequestKt.Dsl.Companion;
        PrivacyUpdateRequestOuterClass.PrivacyUpdateRequest.Builder newBuilder = PrivacyUpdateRequestOuterClass.PrivacyUpdateRequest.newBuilder();
        newBuilder.getClass();
        PrivacyUpdateRequestKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final PrivacyUpdateRequestOuterClass.PrivacyUpdateRequest copy(PrivacyUpdateRequestOuterClass.PrivacyUpdateRequest privacyUpdateRequest, zy1 zy1Var) {
        privacyUpdateRequest.getClass();
        zy1Var.getClass();
        PrivacyUpdateRequestKt.Dsl.Companion companion = PrivacyUpdateRequestKt.Dsl.Companion;
        PrivacyUpdateRequestOuterClass.PrivacyUpdateRequest.Builder builder = privacyUpdateRequest.toBuilder();
        builder.getClass();
        PrivacyUpdateRequestKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
