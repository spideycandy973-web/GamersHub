package gatewayprotocol.p013v1;

import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import gatewayprotocol.p013v1.ErrorOuterClass;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import p000.AbstractC1165ix;
import p000.C0950f;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class AudienceManagementResponseOuterClass {

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface AudienceManagementResponseOrBuilder extends MessageLiteOrBuilder {
        ByteString getAudienceManagementData();

        ErrorOuterClass.Error getError();

        boolean hasError();
    }

    private AudienceManagementResponseOuterClass() {
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class AudienceManagementResponse extends GeneratedMessageLite<AudienceManagementResponse, Builder> implements AudienceManagementResponseOrBuilder {
        public static final int AUDIENCE_MANAGEMENT_DATA_FIELD_NUMBER = 1;
        private static final AudienceManagementResponse DEFAULT_INSTANCE;
        public static final int ERROR_FIELD_NUMBER = 2;
        private static volatile Parser<AudienceManagementResponse> PARSER;
        private ByteString audienceManagementData_ = ByteString.EMPTY;
        private int bitField0_;
        private ErrorOuterClass.Error error_;

        static {
            AudienceManagementResponse audienceManagementResponse = new AudienceManagementResponse();
            DEFAULT_INSTANCE = audienceManagementResponse;
            GeneratedMessageLite.registerDefaultInstance(AudienceManagementResponse.class, audienceManagementResponse);
        }

        private AudienceManagementResponse() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearAudienceManagementData() {
            this.audienceManagementData_ = getDefaultInstance().getAudienceManagementData();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearError() {
            this.error_ = null;
            this.bitField0_ &= -2;
        }

        public static AudienceManagementResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeError(ErrorOuterClass.Error error) {
            error.getClass();
            ErrorOuterClass.Error error2 = this.error_;
            if (error2 == null || error2 == ErrorOuterClass.Error.getDefaultInstance()) {
                this.error_ = error;
            } else {
                this.error_ = ErrorOuterClass.Error.newBuilder(this.error_).mergeFrom((ErrorOuterClass.Error.Builder) error).buildPartial();
            }
            this.bitField0_ |= 1;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static AudienceManagementResponse parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AudienceManagementResponse parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AudienceManagementResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAudienceManagementData(ByteString byteString) {
            byteString.getClass();
            this.audienceManagementData_ = byteString;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setError(ErrorOuterClass.Error error) {
            error.getClass();
            this.error_ = error;
            this.bitField0_ |= 1;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = AbstractC1165ix.f19356a[methodToInvoke.ordinal()];
            AbstractC1165ix abstractC1165ix = null;
            switch (i) {
                case 1:
                    return new AudienceManagementResponse();
                case 2:
                    return new Builder(abstractC1165ix);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\n\u0002ဉ\u0000", new Object[]{"bitField0_", "audienceManagementData_", "error_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AudienceManagementResponse> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (AudienceManagementResponse.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.AudienceManagementResponseOuterClass.AudienceManagementResponseOrBuilder
        public ByteString getAudienceManagementData() {
            return this.audienceManagementData_;
        }

        @Override // gatewayprotocol.v1.AudienceManagementResponseOuterClass.AudienceManagementResponseOrBuilder
        public ErrorOuterClass.Error getError() {
            ErrorOuterClass.Error error = this.error_;
            return error == null ? ErrorOuterClass.Error.getDefaultInstance() : error;
        }

        @Override // gatewayprotocol.v1.AudienceManagementResponseOuterClass.AudienceManagementResponseOrBuilder
        public boolean hasError() {
            return (this.bitField0_ & 1) != 0;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<AudienceManagementResponse, Builder> implements AudienceManagementResponseOrBuilder {
            private Builder() {
                super(AudienceManagementResponse.DEFAULT_INSTANCE);
            }

            public Builder clearAudienceManagementData() {
                copyOnWrite();
                ((AudienceManagementResponse) this.instance).clearAudienceManagementData();
                return this;
            }

            public Builder clearError() {
                copyOnWrite();
                ((AudienceManagementResponse) this.instance).clearError();
                return this;
            }

            @Override // gatewayprotocol.v1.AudienceManagementResponseOuterClass.AudienceManagementResponseOrBuilder
            public ByteString getAudienceManagementData() {
                return ((AudienceManagementResponse) this.instance).getAudienceManagementData();
            }

            @Override // gatewayprotocol.v1.AudienceManagementResponseOuterClass.AudienceManagementResponseOrBuilder
            public ErrorOuterClass.Error getError() {
                return ((AudienceManagementResponse) this.instance).getError();
            }

            @Override // gatewayprotocol.v1.AudienceManagementResponseOuterClass.AudienceManagementResponseOrBuilder
            public boolean hasError() {
                return ((AudienceManagementResponse) this.instance).hasError();
            }

            public Builder mergeError(ErrorOuterClass.Error error) {
                copyOnWrite();
                ((AudienceManagementResponse) this.instance).mergeError(error);
                return this;
            }

            public Builder setAudienceManagementData(ByteString byteString) {
                copyOnWrite();
                ((AudienceManagementResponse) this.instance).setAudienceManagementData(byteString);
                return this;
            }

            public Builder setError(ErrorOuterClass.Error.Builder builder) {
                copyOnWrite();
                ((AudienceManagementResponse) this.instance).setError(builder.build());
                return this;
            }

            public /* synthetic */ Builder(AbstractC1165ix abstractC1165ix) {
                this();
            }

            public Builder setError(ErrorOuterClass.Error error) {
                copyOnWrite();
                ((AudienceManagementResponse) this.instance).setError(error);
                return this;
            }
        }

        public static Builder newBuilder(AudienceManagementResponse audienceManagementResponse) {
            return DEFAULT_INSTANCE.createBuilder(audienceManagementResponse);
        }

        public static AudienceManagementResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AudienceManagementResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AudienceManagementResponse parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AudienceManagementResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AudienceManagementResponse parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AudienceManagementResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AudienceManagementResponse parseFrom(InputStream inputStream) throws IOException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AudienceManagementResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AudienceManagementResponse parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AudienceManagementResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (AudienceManagementResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }
}
