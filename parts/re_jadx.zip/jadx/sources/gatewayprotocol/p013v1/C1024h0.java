package gatewayprotocol.p013v1;

import com.google.protobuf.Internal;
import gatewayprotocol.p013v1.AdFormatOuterClass;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: gatewayprotocol.v1.h0 */
/* loaded from: classes2.dex */
public final class C1024h0 implements Internal.ListAdapter.Converter {
    @Override // com.google.protobuf.Internal.ListAdapter.Converter
    public final Object convert(Object obj) {
        AdFormatOuterClass.AdFormat forNumber = AdFormatOuterClass.AdFormat.forNumber(((Integer) obj).intValue());
        return forNumber == null ? AdFormatOuterClass.AdFormat.UNRECOGNIZED : forNumber;
    }
}
