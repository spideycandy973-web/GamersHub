package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.AdViewerResponseKt;
import gatewayprotocol.p013v1.AdViewerResponseOuterClass;
import gatewayprotocol.p013v1.ErrorOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class AdViewerResponseKtKt {
    /* renamed from: -initializeadViewerResponse, reason: not valid java name */
    public static final AdViewerResponseOuterClass.AdViewerResponse m24706initializeadViewerResponse(zy1 zy1Var) {
        zy1Var.getClass();
        AdViewerResponseKt.Dsl.Companion companion = AdViewerResponseKt.Dsl.Companion;
        AdViewerResponseOuterClass.AdViewerResponse.Builder newBuilder = AdViewerResponseOuterClass.AdViewerResponse.newBuilder();
        newBuilder.getClass();
        AdViewerResponseKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final AdViewerResponseOuterClass.AdViewerResponse copy(AdViewerResponseOuterClass.AdViewerResponse adViewerResponse, zy1 zy1Var) {
        adViewerResponse.getClass();
        zy1Var.getClass();
        AdViewerResponseKt.Dsl.Companion companion = AdViewerResponseKt.Dsl.Companion;
        AdViewerResponseOuterClass.AdViewerResponse.Builder builder = adViewerResponse.toBuilder();
        builder.getClass();
        AdViewerResponseKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final ErrorOuterClass.Error getErrorOrNull(AdViewerResponseOuterClass.AdViewerResponseOrBuilder adViewerResponseOrBuilder) {
        adViewerResponseOrBuilder.getClass();
        if (adViewerResponseOrBuilder.hasError()) {
            return adViewerResponseOrBuilder.getError();
        }
        return null;
    }
}
