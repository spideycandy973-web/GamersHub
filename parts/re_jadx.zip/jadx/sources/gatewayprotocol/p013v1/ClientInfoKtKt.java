package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.ClientInfoKt;
import gatewayprotocol.p013v1.ClientInfoOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ClientInfoKtKt {
    /* renamed from: -initializeclientInfo, reason: not valid java name */
    public static final ClientInfoOuterClass.ClientInfo m24716initializeclientInfo(zy1 zy1Var) {
        zy1Var.getClass();
        ClientInfoKt.Dsl.Companion companion = ClientInfoKt.Dsl.Companion;
        ClientInfoOuterClass.ClientInfo.Builder newBuilder = ClientInfoOuterClass.ClientInfo.newBuilder();
        newBuilder.getClass();
        ClientInfoKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final ClientInfoOuterClass.ClientInfo copy(ClientInfoOuterClass.ClientInfo clientInfo, zy1 zy1Var) {
        clientInfo.getClass();
        zy1Var.getClass();
        ClientInfoKt.Dsl.Companion companion = ClientInfoKt.Dsl.Companion;
        ClientInfoOuterClass.ClientInfo.Builder builder = clientInfo.toBuilder();
        builder.getClass();
        ClientInfoKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
