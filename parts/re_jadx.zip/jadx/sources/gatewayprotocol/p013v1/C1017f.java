package gatewayprotocol.p013v1;

import com.google.protobuf.Internal;
import gatewayprotocol.p013v1.AdRequestOuterClass;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: gatewayprotocol.v1.f */
/* loaded from: classes2.dex */
public final class C1017f implements Internal.EnumVerifier {

    /* renamed from: a */
    public static final C1017f f15518a = new C1017f();

    @Override // com.google.protobuf.Internal.EnumVerifier
    public final boolean isInRange(int i) {
        return AdRequestOuterClass.AdRequestType.forNumber(i) != null;
    }
}
