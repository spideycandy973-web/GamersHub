package gatewayprotocol.p013v1;

import com.google.protobuf.Internal;
import gatewayprotocol.p013v1.MonitoringEventRequestOuterClass;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: gatewayprotocol.v1.o0 */
/* loaded from: classes2.dex */
public final class C1045o0 implements Internal.EnumVerifier {

    /* renamed from: a */
    public static final C1045o0 f15532a = new C1045o0();

    @Override // com.google.protobuf.Internal.EnumVerifier
    public final boolean isInRange(int i) {
        return MonitoringEventRequestOuterClass.MonitoringEventType.forNumber(i) != null;
    }
}
