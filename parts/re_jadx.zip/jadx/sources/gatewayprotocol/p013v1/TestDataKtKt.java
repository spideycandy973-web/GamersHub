package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.TestDataKt;
import gatewayprotocol.p013v1.TestDataOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class TestDataKtKt {
    /* renamed from: -initializetestData, reason: not valid java name */
    public static final TestDataOuterClass.TestData m24766initializetestData(zy1 zy1Var) {
        zy1Var.getClass();
        TestDataKt.Dsl.Companion companion = TestDataKt.Dsl.Companion;
        TestDataOuterClass.TestData.Builder newBuilder = TestDataOuterClass.TestData.newBuilder();
        newBuilder.getClass();
        TestDataKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final TestDataOuterClass.TestData copy(TestDataOuterClass.TestData testData, zy1 zy1Var) {
        testData.getClass();
        zy1Var.getClass();
        TestDataKt.Dsl.Companion companion = TestDataKt.Dsl.Companion;
        TestDataOuterClass.TestData.Builder builder = testData.toBuilder();
        builder.getClass();
        TestDataKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
