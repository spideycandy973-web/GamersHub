package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.MonitoringEventKt;
import gatewayprotocol.p013v1.MonitoringEventRequestOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class MonitoringEventKtKt {
    /* renamed from: -initializemonitoringEvent, reason: not valid java name */
    public static final MonitoringEventRequestOuterClass.MonitoringEvent m24744initializemonitoringEvent(zy1 zy1Var) {
        zy1Var.getClass();
        MonitoringEventKt.Dsl.Companion companion = MonitoringEventKt.Dsl.Companion;
        MonitoringEventRequestOuterClass.MonitoringEvent.Builder newBuilder = MonitoringEventRequestOuterClass.MonitoringEvent.newBuilder();
        newBuilder.getClass();
        MonitoringEventKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final MonitoringEventRequestOuterClass.MonitoringEvent copy(MonitoringEventRequestOuterClass.MonitoringEvent monitoringEvent, zy1 zy1Var) {
        monitoringEvent.getClass();
        zy1Var.getClass();
        MonitoringEventKt.Dsl.Companion companion = MonitoringEventKt.Dsl.Companion;
        MonitoringEventRequestOuterClass.MonitoringEvent.Builder builder = monitoringEvent.toBuilder();
        builder.getClass();
        MonitoringEventKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
