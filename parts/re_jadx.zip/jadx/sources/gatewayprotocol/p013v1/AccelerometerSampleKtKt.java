package gatewayprotocol.p013v1;

import com.google.protobuf.Timestamp;
import gatewayprotocol.p013v1.AccelerometerSampleKt;
import gatewayprotocol.p013v1.DynamicDeviceInfoOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class AccelerometerSampleKtKt {
    /* renamed from: -initializeaccelerometerSample, reason: not valid java name */
    public static final DynamicDeviceInfoOuterClass.AccelerometerSample m24695initializeaccelerometerSample(zy1 zy1Var) {
        zy1Var.getClass();
        AccelerometerSampleKt.Dsl.Companion companion = AccelerometerSampleKt.Dsl.Companion;
        DynamicDeviceInfoOuterClass.AccelerometerSample.Builder newBuilder = DynamicDeviceInfoOuterClass.AccelerometerSample.newBuilder();
        newBuilder.getClass();
        AccelerometerSampleKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final DynamicDeviceInfoOuterClass.AccelerometerSample copy(DynamicDeviceInfoOuterClass.AccelerometerSample accelerometerSample, zy1 zy1Var) {
        accelerometerSample.getClass();
        zy1Var.getClass();
        AccelerometerSampleKt.Dsl.Companion companion = AccelerometerSampleKt.Dsl.Companion;
        DynamicDeviceInfoOuterClass.AccelerometerSample.Builder builder = accelerometerSample.toBuilder();
        builder.getClass();
        AccelerometerSampleKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final Timestamp getClientTimestampOrNull(DynamicDeviceInfoOuterClass.AccelerometerSampleOrBuilder accelerometerSampleOrBuilder) {
        accelerometerSampleOrBuilder.getClass();
        if (accelerometerSampleOrBuilder.hasClientTimestamp()) {
            return accelerometerSampleOrBuilder.getClientTimestamp();
        }
        return null;
    }
}
