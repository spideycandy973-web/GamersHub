package gatewayprotocol.p013v1;

import com.google.protobuf.MapEntryLite;
import com.google.protobuf.WireFormat;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: gatewayprotocol.v1.s */
/* loaded from: classes2.dex */
public abstract class AbstractC1053s {

    /* renamed from: a */
    public static final MapEntryLite f15536a = MapEntryLite.newDefaultInstance(WireFormat.FieldType.STRING, "", WireFormat.FieldType.UINT32, 0);
}
