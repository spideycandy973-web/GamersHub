package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.AdViewerRequestKt;
import gatewayprotocol.p013v1.AdViewerRequestOuterClass;
import gatewayprotocol.p013v1.CampaignStateOuterClass;
import gatewayprotocol.p013v1.DynamicDeviceInfoOuterClass;
import gatewayprotocol.p013v1.SessionCountersOuterClass;
import gatewayprotocol.p013v1.StaticDeviceInfoOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class AdViewerRequestKtKt {
    /* renamed from: -initializeadViewerRequest, reason: not valid java name */
    public static final AdViewerRequestOuterClass.AdViewerRequest m24705initializeadViewerRequest(zy1 zy1Var) {
        zy1Var.getClass();
        AdViewerRequestKt.Dsl.Companion companion = AdViewerRequestKt.Dsl.Companion;
        AdViewerRequestOuterClass.AdViewerRequest.Builder newBuilder = AdViewerRequestOuterClass.AdViewerRequest.newBuilder();
        newBuilder.getClass();
        AdViewerRequestKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final AdViewerRequestOuterClass.AdViewerRequest copy(AdViewerRequestOuterClass.AdViewerRequest adViewerRequest, zy1 zy1Var) {
        adViewerRequest.getClass();
        zy1Var.getClass();
        AdViewerRequestKt.Dsl.Companion companion = AdViewerRequestKt.Dsl.Companion;
        AdViewerRequestOuterClass.AdViewerRequest.Builder builder = adViewerRequest.toBuilder();
        builder.getClass();
        AdViewerRequestKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final CampaignStateOuterClass.CampaignState getCampaignStateOrNull(AdViewerRequestOuterClass.AdViewerRequestOrBuilder adViewerRequestOrBuilder) {
        adViewerRequestOrBuilder.getClass();
        if (adViewerRequestOrBuilder.hasCampaignState()) {
            return adViewerRequestOrBuilder.getCampaignState();
        }
        return null;
    }

    public static final DynamicDeviceInfoOuterClass.DynamicDeviceInfo getDynamicDeviceInfoOrNull(AdViewerRequestOuterClass.AdViewerRequestOrBuilder adViewerRequestOrBuilder) {
        adViewerRequestOrBuilder.getClass();
        if (adViewerRequestOrBuilder.hasDynamicDeviceInfo()) {
            return adViewerRequestOrBuilder.getDynamicDeviceInfo();
        }
        return null;
    }

    public static final SessionCountersOuterClass.SessionCounters getSessionCountersOrNull(AdViewerRequestOuterClass.AdViewerRequestOrBuilder adViewerRequestOrBuilder) {
        adViewerRequestOrBuilder.getClass();
        if (adViewerRequestOrBuilder.hasSessionCounters()) {
            return adViewerRequestOrBuilder.getSessionCounters();
        }
        return null;
    }

    public static final StaticDeviceInfoOuterClass.StaticDeviceInfo getStaticDeviceInfoOrNull(AdViewerRequestOuterClass.AdViewerRequestOrBuilder adViewerRequestOrBuilder) {
        adViewerRequestOrBuilder.getClass();
        if (adViewerRequestOrBuilder.hasStaticDeviceInfo()) {
            return adViewerRequestOrBuilder.getStaticDeviceInfo();
        }
        return null;
    }
}
