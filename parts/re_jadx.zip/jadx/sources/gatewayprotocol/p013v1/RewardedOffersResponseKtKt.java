package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.ErrorOuterClass;
import gatewayprotocol.p013v1.RewardedOffersResponseKt;
import gatewayprotocol.p013v1.RewardedOffersResponseOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class RewardedOffersResponseKtKt {
    /* renamed from: -initializerewardedOffersResponse, reason: not valid java name */
    public static final RewardedOffersResponseOuterClass.RewardedOffersResponse m24760initializerewardedOffersResponse(zy1 zy1Var) {
        zy1Var.getClass();
        RewardedOffersResponseKt.Dsl.Companion companion = RewardedOffersResponseKt.Dsl.Companion;
        RewardedOffersResponseOuterClass.RewardedOffersResponse.Builder newBuilder = RewardedOffersResponseOuterClass.RewardedOffersResponse.newBuilder();
        newBuilder.getClass();
        RewardedOffersResponseKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final RewardedOffersResponseOuterClass.RewardedOffersResponse copy(RewardedOffersResponseOuterClass.RewardedOffersResponse rewardedOffersResponse, zy1 zy1Var) {
        rewardedOffersResponse.getClass();
        zy1Var.getClass();
        RewardedOffersResponseKt.Dsl.Companion companion = RewardedOffersResponseKt.Dsl.Companion;
        RewardedOffersResponseOuterClass.RewardedOffersResponse.Builder builder = rewardedOffersResponse.toBuilder();
        builder.getClass();
        RewardedOffersResponseKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final ErrorOuterClass.Error getErrorOrNull(RewardedOffersResponseOuterClass.RewardedOffersResponseOrBuilder rewardedOffersResponseOrBuilder) {
        rewardedOffersResponseOrBuilder.getClass();
        if (rewardedOffersResponseOrBuilder.hasError()) {
            return rewardedOffersResponseOrBuilder.getError();
        }
        return null;
    }
}
