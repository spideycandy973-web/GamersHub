package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.ModuleInitParamsKt;
import gatewayprotocol.p013v1.ModuleInitParamsOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ModuleInitParamsKtKt {
    /* renamed from: -initializemoduleInitParams, reason: not valid java name */
    public static final ModuleInitParamsOuterClass.ModuleInitParams m24742initializemoduleInitParams(zy1 zy1Var) {
        zy1Var.getClass();
        ModuleInitParamsKt.Dsl.Companion companion = ModuleInitParamsKt.Dsl.Companion;
        ModuleInitParamsOuterClass.ModuleInitParams.Builder newBuilder = ModuleInitParamsOuterClass.ModuleInitParams.newBuilder();
        newBuilder.getClass();
        ModuleInitParamsKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final ModuleInitParamsOuterClass.ModuleInitParams copy(ModuleInitParamsOuterClass.ModuleInitParams moduleInitParams, zy1 zy1Var) {
        moduleInitParams.getClass();
        zy1Var.getClass();
        ModuleInitParamsKt.Dsl.Companion companion = ModuleInitParamsKt.Dsl.Companion;
        ModuleInitParamsOuterClass.ModuleInitParams.Builder builder = moduleInitParams.toBuilder();
        builder.getClass();
        ModuleInitParamsKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
