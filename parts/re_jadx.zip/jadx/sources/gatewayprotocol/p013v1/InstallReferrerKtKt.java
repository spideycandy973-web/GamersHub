package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.InitializationRequestOuterClass;
import gatewayprotocol.p013v1.InstallReferrerKt;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class InstallReferrerKtKt {
    /* renamed from: -initializeinstallReferrer, reason: not valid java name */
    public static final InitializationRequestOuterClass.InstallReferrer m24738initializeinstallReferrer(zy1 zy1Var) {
        zy1Var.getClass();
        InstallReferrerKt.Dsl.Companion companion = InstallReferrerKt.Dsl.Companion;
        InitializationRequestOuterClass.InstallReferrer.Builder newBuilder = InitializationRequestOuterClass.InstallReferrer.newBuilder();
        newBuilder.getClass();
        InstallReferrerKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final InitializationRequestOuterClass.InstallReferrer copy(InitializationRequestOuterClass.InstallReferrer installReferrer, zy1 zy1Var) {
        installReferrer.getClass();
        zy1Var.getClass();
        InstallReferrerKt.Dsl.Companion companion = InstallReferrerKt.Dsl.Companion;
        InitializationRequestOuterClass.InstallReferrer.Builder builder = installReferrer.toBuilder();
        builder.getClass();
        InstallReferrerKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
