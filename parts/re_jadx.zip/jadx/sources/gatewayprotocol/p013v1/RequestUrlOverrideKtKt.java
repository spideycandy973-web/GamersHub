package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.InitializationResponseOuterClass;
import gatewayprotocol.p013v1.RequestUrlOverrideKt;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class RequestUrlOverrideKtKt {
    /* renamed from: -initializerequestUrlOverride, reason: not valid java name */
    public static final InitializationResponseOuterClass.RequestUrlOverride m24758initializerequestUrlOverride(zy1 zy1Var) {
        zy1Var.getClass();
        RequestUrlOverrideKt.Dsl.Companion companion = RequestUrlOverrideKt.Dsl.Companion;
        InitializationResponseOuterClass.RequestUrlOverride.Builder newBuilder = InitializationResponseOuterClass.RequestUrlOverride.newBuilder();
        newBuilder.getClass();
        RequestUrlOverrideKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final InitializationResponseOuterClass.RequestUrlOverride copy(InitializationResponseOuterClass.RequestUrlOverride requestUrlOverride, zy1 zy1Var) {
        requestUrlOverride.getClass();
        zy1Var.getClass();
        RequestUrlOverrideKt.Dsl.Companion companion = RequestUrlOverrideKt.Dsl.Companion;
        InitializationResponseOuterClass.RequestUrlOverride.Builder builder = requestUrlOverride.toBuilder();
        builder.getClass();
        RequestUrlOverrideKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
