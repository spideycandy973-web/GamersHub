package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.ModuleKt;
import gatewayprotocol.p013v1.ModuleOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ModuleKtKt {
    /* renamed from: -initializemodule, reason: not valid java name */
    public static final ModuleOuterClass.Module m24743initializemodule(zy1 zy1Var) {
        zy1Var.getClass();
        ModuleKt.Dsl.Companion companion = ModuleKt.Dsl.Companion;
        ModuleOuterClass.Module.Builder newBuilder = ModuleOuterClass.Module.newBuilder();
        newBuilder.getClass();
        ModuleKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final ModuleOuterClass.Module copy(ModuleOuterClass.Module module, zy1 zy1Var) {
        module.getClass();
        zy1Var.getClass();
        ModuleKt.Dsl.Companion companion = ModuleKt.Dsl.Companion;
        ModuleOuterClass.Module.Builder builder = module.toBuilder();
        builder.getClass();
        ModuleKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
