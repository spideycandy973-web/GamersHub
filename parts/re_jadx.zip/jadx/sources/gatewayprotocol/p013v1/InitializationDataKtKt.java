package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.InitializationDataKt;
import gatewayprotocol.p013v1.InitializationDataOuterClass;
import gatewayprotocol.p013v1.InitializationRequestOuterClass;
import gatewayprotocol.p013v1.UniversalRequestOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class InitializationDataKtKt {
    /* renamed from: -initializeinitializationData, reason: not valid java name */
    public static final InitializationDataOuterClass.InitializationData m24734initializeinitializationData(zy1 zy1Var) {
        zy1Var.getClass();
        InitializationDataKt.Dsl.Companion companion = InitializationDataKt.Dsl.Companion;
        InitializationDataOuterClass.InitializationData.Builder newBuilder = InitializationDataOuterClass.InitializationData.newBuilder();
        newBuilder.getClass();
        InitializationDataKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final InitializationDataOuterClass.InitializationData copy(InitializationDataOuterClass.InitializationData initializationData, zy1 zy1Var) {
        initializationData.getClass();
        zy1Var.getClass();
        InitializationDataKt.Dsl.Companion companion = InitializationDataKt.Dsl.Companion;
        InitializationDataOuterClass.InitializationData.Builder builder = initializationData.toBuilder();
        builder.getClass();
        InitializationDataKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final InitializationRequestOuterClass.InitializationRequest getInitializationRequestOrNull(InitializationDataOuterClass.InitializationDataOrBuilder initializationDataOrBuilder) {
        initializationDataOrBuilder.getClass();
        if (initializationDataOrBuilder.hasInitializationRequest()) {
            return initializationDataOrBuilder.getInitializationRequest();
        }
        return null;
    }

    public static final UniversalRequestOuterClass.UniversalRequest.SharedData getSharedDataOrNull(InitializationDataOuterClass.InitializationDataOrBuilder initializationDataOrBuilder) {
        initializationDataOrBuilder.getClass();
        if (initializationDataOrBuilder.hasSharedData()) {
            return initializationDataOrBuilder.getSharedData();
        }
        return null;
    }
}
