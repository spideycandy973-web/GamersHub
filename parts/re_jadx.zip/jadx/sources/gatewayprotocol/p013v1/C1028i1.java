package gatewayprotocol.p013v1;

import com.google.protobuf.Internal;
import gatewayprotocol.p013v1.TransactionEventRequestOuterClass;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: gatewayprotocol.v1.i1 */
/* loaded from: classes2.dex */
public final class C1028i1 implements Internal.EnumVerifier {

    /* renamed from: a */
    public static final C1028i1 f15524a = new C1028i1();

    @Override // com.google.protobuf.Internal.EnumVerifier
    public final boolean isInRange(int i) {
        return TransactionEventRequestOuterClass.StoreKitVersion.forNumber(i) != null;
    }
}
