package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.CachedAssetsConfigurationKt;
import gatewayprotocol.p013v1.NativeConfigurationOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class CachedAssetsConfigurationKtKt {
    /* renamed from: -initializecachedAssetsConfiguration, reason: not valid java name */
    public static final NativeConfigurationOuterClass.CachedAssetsConfiguration m24711initializecachedAssetsConfiguration(zy1 zy1Var) {
        zy1Var.getClass();
        CachedAssetsConfigurationKt.Dsl.Companion companion = CachedAssetsConfigurationKt.Dsl.Companion;
        NativeConfigurationOuterClass.CachedAssetsConfiguration.Builder newBuilder = NativeConfigurationOuterClass.CachedAssetsConfiguration.newBuilder();
        newBuilder.getClass();
        CachedAssetsConfigurationKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final NativeConfigurationOuterClass.CachedAssetsConfiguration copy(NativeConfigurationOuterClass.CachedAssetsConfiguration cachedAssetsConfiguration, zy1 zy1Var) {
        cachedAssetsConfiguration.getClass();
        zy1Var.getClass();
        CachedAssetsConfigurationKt.Dsl.Companion companion = CachedAssetsConfigurationKt.Dsl.Companion;
        NativeConfigurationOuterClass.CachedAssetsConfiguration.Builder builder = cachedAssetsConfiguration.toBuilder();
        builder.getClass();
        CachedAssetsConfigurationKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
