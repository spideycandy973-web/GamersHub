package gatewayprotocol.p013v1;

import com.google.protobuf.ByteString;
import gatewayprotocol.p013v1.RewardedOffersRequestOuterClass;
import p000.h31;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class RewardedOffersRequestKt {
    public static final RewardedOffersRequestKt INSTANCE = new RewardedOffersRequestKt();

    private RewardedOffersRequestKt() {
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class Dsl {
        public static final Companion Companion = new Companion(null);
        private final RewardedOffersRequestOuterClass.RewardedOffersRequest.Builder _builder;

        private Dsl(RewardedOffersRequestOuterClass.RewardedOffersRequest.Builder builder) {
            this._builder = builder;
        }

        public final /* synthetic */ RewardedOffersRequestOuterClass.RewardedOffersRequest _build() {
            RewardedOffersRequestOuterClass.RewardedOffersRequest build = this._builder.build();
            build.getClass();
            return build;
        }

        public final void clearCursor() {
            this._builder.clearCursor();
        }

        public final void clearEntryPoint() {
            this._builder.clearEntryPoint();
        }

        public final ByteString getCursor() {
            ByteString cursor = this._builder.getCursor();
            cursor.getClass();
            return cursor;
        }

        public final RewardedOffersRequestOuterClass.RewardedOffersEntryPoint getEntryPoint() {
            RewardedOffersRequestOuterClass.RewardedOffersEntryPoint entryPoint = this._builder.getEntryPoint();
            entryPoint.getClass();
            return entryPoint;
        }

        public final int getEntryPointValue() {
            return this._builder.getEntryPointValue();
        }

        public final void setCursor(ByteString byteString) {
            byteString.getClass();
            this._builder.setCursor(byteString);
        }

        public final void setEntryPoint(RewardedOffersRequestOuterClass.RewardedOffersEntryPoint rewardedOffersEntryPoint) {
            rewardedOffersEntryPoint.getClass();
            this._builder.setEntryPoint(rewardedOffersEntryPoint);
        }

        public final void setEntryPointValue(int i) {
            this._builder.setEntryPointValue(i);
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Companion {
            public /* synthetic */ Companion(h31 h31Var) {
                this();
            }

            public final /* synthetic */ Dsl _create(RewardedOffersRequestOuterClass.RewardedOffersRequest.Builder builder) {
                builder.getClass();
                return new Dsl(builder, null);
            }

            private Companion() {
            }
        }

        public /* synthetic */ Dsl(RewardedOffersRequestOuterClass.RewardedOffersRequest.Builder builder, h31 h31Var) {
            this(builder);
        }
    }
}
