package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.AccelerometerCollectionConfigurationKt;
import gatewayprotocol.p013v1.NativeConfigurationOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class AccelerometerCollectionConfigurationKtKt {
    /* renamed from: -initializeaccelerometerCollectionConfiguration, reason: not valid java name */
    public static final NativeConfigurationOuterClass.AccelerometerCollectionConfiguration m24694initializeaccelerometerCollectionConfiguration(zy1 zy1Var) {
        zy1Var.getClass();
        AccelerometerCollectionConfigurationKt.Dsl.Companion companion = AccelerometerCollectionConfigurationKt.Dsl.Companion;
        NativeConfigurationOuterClass.AccelerometerCollectionConfiguration.Builder newBuilder = NativeConfigurationOuterClass.AccelerometerCollectionConfiguration.newBuilder();
        newBuilder.getClass();
        AccelerometerCollectionConfigurationKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final NativeConfigurationOuterClass.AccelerometerCollectionConfiguration copy(NativeConfigurationOuterClass.AccelerometerCollectionConfiguration accelerometerCollectionConfiguration, zy1 zy1Var) {
        accelerometerCollectionConfiguration.getClass();
        zy1Var.getClass();
        AccelerometerCollectionConfigurationKt.Dsl.Companion companion = AccelerometerCollectionConfigurationKt.Dsl.Companion;
        NativeConfigurationOuterClass.AccelerometerCollectionConfiguration.Builder builder = accelerometerCollectionConfiguration.toBuilder();
        builder.getClass();
        AccelerometerCollectionConfigurationKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
