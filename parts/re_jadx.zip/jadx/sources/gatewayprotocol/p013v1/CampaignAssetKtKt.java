package gatewayprotocol.p013v1;

import gatewayprotocol.p013v1.CampaignAssetKt;
import gatewayprotocol.p013v1.CampaignMetadataOuterClass;
import p000.zy1;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class CampaignAssetKtKt {
    /* renamed from: -initializecampaignAsset, reason: not valid java name */
    public static final CampaignMetadataOuterClass.CampaignAsset m24712initializecampaignAsset(zy1 zy1Var) {
        zy1Var.getClass();
        CampaignAssetKt.Dsl.Companion companion = CampaignAssetKt.Dsl.Companion;
        CampaignMetadataOuterClass.CampaignAsset.Builder newBuilder = CampaignMetadataOuterClass.CampaignAsset.newBuilder();
        newBuilder.getClass();
        CampaignAssetKt.Dsl _create = companion._create(newBuilder);
        zy1Var.invoke(_create);
        return _create._build();
    }

    public static final CampaignMetadataOuterClass.CampaignAsset copy(CampaignMetadataOuterClass.CampaignAsset campaignAsset, zy1 zy1Var) {
        campaignAsset.getClass();
        zy1Var.getClass();
        CampaignAssetKt.Dsl.Companion companion = CampaignAssetKt.Dsl.Companion;
        CampaignMetadataOuterClass.CampaignAsset.Builder builder = campaignAsset.toBuilder();
        builder.getClass();
        CampaignAssetKt.Dsl _create = companion._create(builder);
        zy1Var.invoke(_create);
        return _create._build();
    }
}
