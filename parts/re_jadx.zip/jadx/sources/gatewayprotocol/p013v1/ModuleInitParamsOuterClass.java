package gatewayprotocol.p013v1;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import p000.C0950f;
import p000.ta3;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class ModuleInitParamsOuterClass {

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface ModuleInitParamsOrBuilder extends MessageLiteOrBuilder {
        String getClassName();

        ByteString getClassNameBytes();

        String getName();

        ByteString getNameBytes();

        ByteString getParams();
    }

    private ModuleInitParamsOuterClass() {
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class ModuleInitParams extends GeneratedMessageLite<ModuleInitParams, Builder> implements ModuleInitParamsOrBuilder {
        public static final int CLASS_NAME_FIELD_NUMBER = 3;
        private static final ModuleInitParams DEFAULT_INSTANCE;
        public static final int NAME_FIELD_NUMBER = 1;
        public static final int PARAMS_FIELD_NUMBER = 2;
        private static volatile Parser<ModuleInitParams> PARSER;
        private String name_ = "";
        private ByteString params_ = ByteString.EMPTY;
        private String className_ = "";

        static {
            ModuleInitParams moduleInitParams = new ModuleInitParams();
            DEFAULT_INSTANCE = moduleInitParams;
            GeneratedMessageLite.registerDefaultInstance(ModuleInitParams.class, moduleInitParams);
        }

        private ModuleInitParams() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearClassName() {
            this.className_ = getDefaultInstance().getClassName();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearParams() {
            this.params_ = getDefaultInstance().getParams();
        }

        public static ModuleInitParams getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static ModuleInitParams parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (ModuleInitParams) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ModuleInitParams parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ModuleInitParams> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setClassName(String str) {
            str.getClass();
            this.className_ = str;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setClassNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.className_ = byteString.toStringUtf8();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.toStringUtf8();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setParams(ByteString byteString) {
            byteString.getClass();
            this.params_ = byteString;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = ta3.f36780a[methodToInvoke.ordinal()];
            ta3 ta3Var = null;
            switch (i) {
                case 1:
                    return new ModuleInitParams();
                case 2:
                    return new Builder(ta3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002\n\u0003Ȉ", new Object[]{"name_", "params_", "className_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ModuleInitParams> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (ModuleInitParams.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
        public String getClassName() {
            return this.className_;
        }

        @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
        public ByteString getClassNameBytes() {
            return ByteString.copyFromUtf8(this.className_);
        }

        @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
        public String getName() {
            return this.name_;
        }

        @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
        public ByteString getNameBytes() {
            return ByteString.copyFromUtf8(this.name_);
        }

        @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
        public ByteString getParams() {
            return this.params_;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<ModuleInitParams, Builder> implements ModuleInitParamsOrBuilder {
            private Builder() {
                super(ModuleInitParams.DEFAULT_INSTANCE);
            }

            public Builder clearClassName() {
                copyOnWrite();
                ((ModuleInitParams) this.instance).clearClassName();
                return this;
            }

            public Builder clearName() {
                copyOnWrite();
                ((ModuleInitParams) this.instance).clearName();
                return this;
            }

            public Builder clearParams() {
                copyOnWrite();
                ((ModuleInitParams) this.instance).clearParams();
                return this;
            }

            @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
            public String getClassName() {
                return ((ModuleInitParams) this.instance).getClassName();
            }

            @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
            public ByteString getClassNameBytes() {
                return ((ModuleInitParams) this.instance).getClassNameBytes();
            }

            @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
            public String getName() {
                return ((ModuleInitParams) this.instance).getName();
            }

            @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
            public ByteString getNameBytes() {
                return ((ModuleInitParams) this.instance).getNameBytes();
            }

            @Override // gatewayprotocol.v1.ModuleInitParamsOuterClass.ModuleInitParamsOrBuilder
            public ByteString getParams() {
                return ((ModuleInitParams) this.instance).getParams();
            }

            public Builder setClassName(String str) {
                copyOnWrite();
                ((ModuleInitParams) this.instance).setClassName(str);
                return this;
            }

            public Builder setClassNameBytes(ByteString byteString) {
                copyOnWrite();
                ((ModuleInitParams) this.instance).setClassNameBytes(byteString);
                return this;
            }

            public Builder setName(String str) {
                copyOnWrite();
                ((ModuleInitParams) this.instance).setName(str);
                return this;
            }

            public Builder setNameBytes(ByteString byteString) {
                copyOnWrite();
                ((ModuleInitParams) this.instance).setNameBytes(byteString);
                return this;
            }

            public Builder setParams(ByteString byteString) {
                copyOnWrite();
                ((ModuleInitParams) this.instance).setParams(byteString);
                return this;
            }

            public /* synthetic */ Builder(ta3 ta3Var) {
                this();
            }
        }

        public static Builder newBuilder(ModuleInitParams moduleInitParams) {
            return DEFAULT_INSTANCE.createBuilder(moduleInitParams);
        }

        public static ModuleInitParams parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (ModuleInitParams) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ModuleInitParams parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ModuleInitParams parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ModuleInitParams parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ModuleInitParams parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ModuleInitParams parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ModuleInitParams parseFrom(InputStream inputStream) throws IOException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ModuleInitParams parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ModuleInitParams parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ModuleInitParams parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (ModuleInitParams) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }
}
