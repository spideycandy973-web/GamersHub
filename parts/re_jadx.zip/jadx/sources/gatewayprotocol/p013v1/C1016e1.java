package gatewayprotocol.p013v1;

import com.google.protobuf.Internal;
import gatewayprotocol.p013v1.RewardedOffersRequestOuterClass;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* renamed from: gatewayprotocol.v1.e1 */
/* loaded from: classes2.dex */
public final class C1016e1 implements Internal.EnumVerifier {

    /* renamed from: a */
    public static final C1016e1 f15517a = new C1016e1();

    @Override // com.google.protobuf.Internal.EnumVerifier
    public final boolean isInRange(int i) {
        return RewardedOffersRequestOuterClass.RewardedOffersEntryPoint.forNumber(i) != null;
    }
}
